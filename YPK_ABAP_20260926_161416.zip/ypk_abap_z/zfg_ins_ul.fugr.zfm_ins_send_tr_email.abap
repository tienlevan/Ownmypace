FUNCTION zfm_ins_send_tr_email.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_TRKORR) TYPE  TRKORR
*"     VALUE(IV_TEXT) TYPE  AS4TEXT
*"  EXPORTING
*"     VALUE(IS_FAILED) TYPE  BOOLE_D
*"----------------------------------------------------------------------

  TYPES : BEGIN OF ty_data,
            sequence TYPE i,
            urgent   TYPE char3,
            request  TYPE string,
            descrpt  TYPE string,
            sys_tg   TYPE char3,
            sys_clt  TYPE char20,
            crno     TYPE char10,
            user     TYPE char10,
          END OF ty_data.

  DATA: result TYPE TABLE OF ty_data,
        fields TYPE TABLE OF sval,
        user   TYPE bapiaddr3,
        return TYPE TABLE OF bapiret2.

  zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'WB_DEV' iv_mainkey = 'EMAIL_CACHED' iv_subkey = CONV #( sy-uname )
                                IMPORTING e_data = fields ).
  IF fields IS INITIAL.
    fields = VALUE #( ( fieldname = 'RECIPIENT' fieldtext = 'Recipient' value = 'Anh Thanh' field_obl = abap_true tabname = 'ZST_TR_EMAIL' )
                      ( fieldname = 'EMAIL'     fieldtext = 'Email'     value = 'v.thanhdx6@vinhomes.vn' field_obl = abap_true tabname = 'ZST_TR_EMAIL' )
                      ( fieldname = 'SYS_TG'    fieldtext = 'System'    value = 'PEC' field_obl = abap_true tabname = 'ZST_TR_EMAIL' )
                      ( fieldname = 'SYS_CLNT'  fieldtext = 'Client'    value = '911' field_obl = abap_true tabname = 'ZST_TR_EMAIL' ) ).
  ENDIF.

  CALL FUNCTION 'POPUP_GET_VALUES'
    EXPORTING
      popup_title = 'Confirm Information'
    TABLES
      fields      = fields.

  APPEND INITIAL LINE TO result ASSIGNING FIELD-SYMBOL(<fs_data>).
  <fs_data>-sequence = 1.
  <fs_data>-urgent   = 'YES'.
  CONCATENATE iv_trkorr sy-uname iv_text INTO <fs_data>-request SEPARATED BY space.
  <fs_data>-descrpt = iv_text.
  <fs_data>-sys_tg  = fields[ fieldname = 'SYS_TG' ]-value.
  <fs_data>-sys_clt = condense( fields[ fieldname = 'SYS_CLNT' ]-value ).
  <fs_data>-user    = sy-uname.

  DATA(lo_document) = NEW zcl_ul_dd_document( iv_no_dialog = abap_true ).
  DATA(document) = lo_document->document.
  document->initialize_document( EXPORTING background_color = cl_dd_document=>col_textarea ).
  document->add_text( text = |Kính gửi { fields[ fieldname = 'RECIPIENT' ]-value } để phê duyệt,| sap_emphasis = cl_dd_area=>strong ).
  document->new_line( ).
  document->add_text( text = |{ fields[ fieldname = 'RECIPIENT' ]-value } duyệt giúp em TR bên dưới để chuyển lên { fields[ fieldname = 'SYS_TG' ]-value } ạ!| ).
  document->new_line( 1 ).
  lo_document->add_table( EXPORTING it_col_header = VALUE #( ( fieldname = 'SEQUENCE'   coltext = 'Sequence' )
                                                             ( fieldname = 'URGENT'     coltext = 'Urgent' )
                                                             ( fieldname = 'REQUEST'    coltext = 'Request ID – Owner – Short Description' )
                                                             ( fieldname = 'DESCRPT'    coltext = 'Description' )
                                                             ( fieldname = 'SYS_TG'     coltext = 'Target System ID' )
                                                             ( fieldname = 'SYS_CLT'    coltext = 'CR No./Helpdesk Ticket No' )
                                                             ( fieldname = 'CRNO'       coltext = 'CR No./Helpdesk Ticket No.' )
                                                             ( fieldname = 'USER'       coltext = 'User SIT, UAT' ) )
                          CHANGING ct_table_value = result ).

  TRY.
      DATA(email) = NEW zcl_ul_send_email( ).
      email->set_subject( |[TR] \{{ condense( fields[ fieldname = 'SYS_CLNT' ]-value ) }_{ iv_trkorr }\}| ).
      email->create_document( i_text = lo_document->export_html( )
                              i_type = 'HTM'
                              i_subject = |[TR] \{{ fields[ fieldname = 'SYS_CLNT' ]-value }_{ iv_trkorr }\}|
                              is_attachment = abap_false
                              i_language = '쁩'
                              i_importance = abap_true ).
      email->set_receipients( internet_address = CONV #( fields[ fieldname = 'EMAIL' ]-value ) ).

      CALL FUNCTION 'BAPI_USER_GET_DETAIL'
        EXPORTING
          username = sy-uname
        IMPORTING
          address  = user
        TABLES
          return   = return.

      IF return IS NOT INITIAL.
        zcx_ul_handle_errors=>raise_message( it_msg_tab = return ).
        RETURN.
      ENDIF.

      email->set_sender( internet_address = user-e_mail ).
      email->send_email( ).

    CATCH zcx_ul_handle_errors INTO DATA(error).
      is_failed = abap_true.

  ENDTRY.

  zcl_ul_data_layer=>write_data( EXPORTING is_key = VALUE #( application = 'WB_DEV' main_key = 'EMAIL_CACHED' sub_key = CONV #( sy-uname ) )
                                           is_data = fields ).

ENDFUNCTION.
