*----------------------------------------------------------------------*
***INCLUDE ZPG_WB_FOR_DEV_USER_COMMANDI01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9999  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9999 INPUT.

  CASE ok_code.
    WHEN 'BACK' OR 'CANCEL' OR 'EXIT'.
      go_tree->save_tree_width(  ).
      LEAVE TO SCREEN 0.
    WHEN 'FIND'.
      CALL FUNCTION 'ZFM_SEARCH_TREE_NODE' EXPORTING io_tree = go_tree->get_tree_object( ).
    WHEN 'SAVE'.
      go_adapter->save( lcl_toolbar=>tool_selected  ).
  ENDCASE.

ENDMODULE.
