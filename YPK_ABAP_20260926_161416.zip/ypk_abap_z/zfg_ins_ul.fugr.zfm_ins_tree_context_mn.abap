FUNCTION zfm_ins_tree_context_mn.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IV_NODE_KEY) TYPE  TV_NODEKEY
*"     REFERENCE(IV_FCODE) TYPE  SY-UCOMM
*"     REFERENCE(IO_TREE) TYPE REF TO  ZCL_UL_TREE_DISPLAY
*"     REFERENCE(IV_MENU) TYPE  CHAR12
*"----------------------------------------------------------------------

" Fill relevant data
node_key = iv_node_key.
_tree    = io_tree.
fcode    = iv_fcode.
menu     = iv_menu.


" Call dialog
CALL SCREEN 101 STARTING AT 5 10.



ENDFUNCTION.
