*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE lzfg_ins_ultop.                    " Global Declarations
  INCLUDE lzfg_ins_uluxx.                    " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFG_INS_ULF...                    " Subroutines
* INCLUDE LZFG_INS_ULO...                    " PBO-Modules
* INCLUDE LZFG_INS_ULI...                    " PAI-Modules
* INCLUDE LZFG_INS_ULE...                    " Events
* INCLUDE LZFG_INS_ULP...                    " Local class implement.
* INCLUDE LZFG_INS_ULT99.                    " ABAP Unit tests

INCLUDE lzfg_ins_ulo01.
INCLUDE lzfg_ins_uli01.
INCLUDE zzfg_ins_cls01.

INCLUDE lzfg_ins_ulf01.
