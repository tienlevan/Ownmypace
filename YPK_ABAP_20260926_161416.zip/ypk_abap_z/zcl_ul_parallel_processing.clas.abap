class ZCL_UL_PARALLEL_PROCESSING definition
  public
  abstract
  create public .

public section.

  constants C_DEFAULT_GROUP type RZLLI_APCL value SPACE ##NO_TEXT.
  constants C_TASK type CHAR6 value 'PARALL' ##NO_TEXT.
  data THREADS type I .

  methods PARALLEL_PROCESSING
  abstract .
  methods ON_GET_RESULTS
  abstract
    importing
      !P_TASK type CLIKE .
  methods ALL_THREADS_ARE_FINISHED
    returning
      value(R_EMPTY) type ABAP_BOOL .
  methods CLEAR_THREAD
    importing
      !I_TASK type CHAR8 .
  methods CONSTRUCTOR
    importing
      !I_TASK_PREFIX type CHAR6 default C_TASK
      !I_THREADS type I
      !I_GROUP type RZLLI_APCL default C_DEFAULT_GROUP .
  methods HANDLE_RESOURCE_FAILURE .
  methods GET_FREE_THREAD
    returning
      value(R_THREAD) type CHAR8 .
  PROTECTED SECTION.
  PRIVATE SECTION.

    TYPES:
      BEGIN OF ty_thread,
        thread TYPE char8,
        used   TYPE abap_bool,
      END OF ty_thread .

    DATA:
      task_prefix  TYPE char6,
      threads_list TYPE TABLE OF ty_thread WITH DEFAULT KEY,
      used_threads TYPE i,
      group        TYPE rzlli_apcl.

    METHODS _get_free_threads
      RETURNING
        VALUE(r_free_threads) TYPE i .

ENDCLASS.



CLASS ZCL_UL_PARALLEL_PROCESSING IMPLEMENTATION.


  METHOD all_threads_are_finished.

    r_empty = xsdbool( used_threads EQ 0 ).

  ENDMETHOD.


  METHOD clear_thread.

    READ TABLE me->threads_list WITH KEY used = abap_true thread = i_task
         ASSIGNING FIELD-SYMBOL(<thread>).
    <thread>-used = abap_false.
    SUBTRACT 1 FROM used_threads.

  ENDMETHOD.


  METHOD constructor.

    me->group = i_group.
    me->task_prefix = i_task_prefix.

    " No more than 100 threads
    IF i_threads GT 100.
      me->threads = 100.
    ELSEIF i_threads LE 0.
      me->threads = 1.
    ELSE.
      me->threads = i_threads.
    ENDIF.

    DATA(free_threads) = me->_get_free_threads( ).

    " Ensure that no more than half of the free threads are used
    free_threads = free_threads / 2 + 1.
    IF free_threads LT me->threads.
      me->threads = free_threads.
    ENDIF.

    " Initialise threads
    DO me->threads TIMES.
      DATA threadn TYPE n LENGTH 2 VALUE '00'.
      INSERT VALUE #( thread = me->task_prefix && threadn used = abap_false )
             INTO TABLE me->threads_list.
      ADD 1 TO threadn.
    ENDDO.

  ENDMETHOD.


  METHOD get_free_thread.

    " Wait for a free thread
    WAIT UNTIL me->used_threads LT me->threads.

    " Get number of first free thread
    READ TABLE me->threads_list WITH KEY used = abap_false ASSIGNING FIELD-SYMBOL(<thread>).

    ADD 1 TO used_threads.
    <thread>-used = abap_true.
    r_thread = <thread>-thread.

  ENDMETHOD.


  METHOD handle_resource_failure.

    DATA(free_threads) = me->_get_free_threads( ).
    IF free_threads LE 1 AND me->threads GT 1.
      SUBTRACT 1 FROM me->threads.
    ENDIF.

    WAIT UP TO 5 SECONDS. " Long enough for the system to update
    WAIT UNTIL me->used_threads LT me->threads. " Now there's an available thread


  ENDMETHOD.


  METHOD _get_free_threads.

    CALL FUNCTION 'SPBT_INITIALIZE'
      EXPORTING
        group_name                     = me->group
      IMPORTING
        free_pbt_wps                   = r_free_threads
      EXCEPTIONS
        invalid_group_name             = 1
        internal_error                 = 2
        pbt_env_already_initialized    = 3
        currently_no_resources_avail   = 4
        no_pbt_resources_found         = 5
        cant_init_different_pbt_groups = 6
        OTHERS                         = 7.

    CASE sy-subrc.
      WHEN 0. " Do nothing

      WHEN 3.
        " Already initialised - get current number of free threads
        CALL FUNCTION 'SPBT_GET_CURR_RESOURCE_INFO'
          IMPORTING
            free_pbt_wps                = r_free_threads
          EXCEPTIONS
            internal_error              = 1
            pbt_env_not_initialized_yet = 2
            OTHERS                      = 3.

        IF sy-subrc IS NOT INITIAL.
          " Something has gone seriously wrong, so end it here.
          MESSAGE ID sy-msgid TYPE 'X' NUMBER sy-msgno WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
        ENDIF.

      WHEN OTHERS.
        " Something has gone seriously wrong, so end it here.
        MESSAGE ID sy-msgid TYPE 'X' NUMBER sy-msgno WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.

    ENDCASE.

  ENDMETHOD.
ENDCLASS.
