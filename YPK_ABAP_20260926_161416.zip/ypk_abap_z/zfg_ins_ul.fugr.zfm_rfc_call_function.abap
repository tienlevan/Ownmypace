FUNCTION zfm_rfc_call_function.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_FUNCTION) TYPE  RS38L_FNAM
*"     VALUE(IV_EXCEPTIONS) TYPE  STRING OPTIONAL
*"  CHANGING
*"     VALUE(CV_PARAMETERS) TYPE  STRING OPTIONAL
*"  EXCEPTIONS
*"      NOT_VALID_METHOD
*"      DYNAMIC_CALL_ERROR
*"----------------------------------------------------------------------

  DATA: ptab TYPE abap_func_parmbind_tab,
        etab TYPE abap_func_excpbind_tab.

  CALL TRANSFORMATION id SOURCE XML cv_parameters
                        RESULT  mydata = ptab.

  CALL TRANSFORMATION id SOURCE XML iv_exceptions
                          RESULT  mydata = etab.

  CALL FUNCTION iv_function
    PARAMETER-TABLE ptab
    EXCEPTION-TABLE etab.

  IF sy-subrc IS NOT INITIAL.
    RAISE dynamic_call_error.
  ENDIF.

  CALL TRANSFORMATION id SOURCE mydata = ptab
                         RESULT XML cv_parameters.

ENDFUNCTION.
