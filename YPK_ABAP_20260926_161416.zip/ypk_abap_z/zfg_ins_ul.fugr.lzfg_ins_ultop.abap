FUNCTION-POOL zfg_ins_ul.                   "MESSAGE-ID ..

INCLUDE zfg_ins_ul_top.
INCLUDE ztree_context_mn_top.
INCLUDE zdoi_create_top.
INCLUDE zfm_alv_adapter_top.
INCLUDE zfm_ins_file_attachment_top.
INCLUDE zfm_release_strategy_top.
INCLUDE zfm_call_configuration_top.
INCLUDE zfm_search_tree_node_top.
