*----------------------------------------------------------------------*
***INCLUDE ZINS_UL_TABLE_MANAGER_STATUO01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_0100  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0100 OUTPUT.

 IF grid IS NOT BOUND.
   grid = NEW #( screen = 'X' event = 'X' iv_tabname = viewname ).
 ENDIF.

 " Set status and title
 SET PF-STATUS 'ST100'.
 SET TITLEBAR 'xxx'.

 " On_user_command
 DATA(lo_ap) = NEW lcl_ap( ).
 SET HANDLER lo_ap->on_user_command FOR grid->ao_alv.

  CHECK sy-ucomm IS NOT INITIAL.

  IF sy-ucomm EQ 'B1' OR sy-ucomm EQ 'B2' OR sy-ucomm = 'B3' .
    mode = sy-ucomm.
  ENDIF.

  " Query data
  DATA new_data TYPE REF TO data.
  IF viewname IS NOT INITIAL AND ( mode = 'B1' OR mode = 'B2' ) AND grid->ar_data IS INITIAL.
  zcl_ul_table_manager=>query_data( iv_tabname = viewname iv_maxsel = maxsel  ).
  CHECK grid->ar_data IS NOT INITIAL.
  ASSIGN grid->ar_data->* TO <ft_data>.
  ELSEIF sy-ucomm = 'B3'.
  UNASSIGN <ft_data>.
  CREATE DATA new_data TYPE TABLE OF (viewname).
  ASSIGN new_data->* TO <ft_data>.
  DO maxsel TIMES.
   APPEND INITIAL LINE TO <ft_data>.
  ENDDO.
  ENDIF.

  " Building field catalogs.
  DATA(field_catalogs) = lcl_ap=>build_catalog( ).
  " Show data
  CALL METHOD grid->ao_alv->set_table_for_first_display
    EXPORTING
     is_variant           = lcl_ap=>build_variant( )
     i_save               = 'A'
     is_layout            = lcl_ap=>build_layout( )
     it_toolbar_excluding = lcl_ap=>hide_func( )
    CHANGING
     it_outtab            = <ft_data>
     it_fieldcatalog      = field_catalogs.



ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  STATUS_1001  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_1001 OUTPUT.

  DATA(content_editor) =  NEW cl_gui_custom_container( container_name = 'ZCONTENT' ).
  r_contents = NEW #( parent = content_editor wordwrap_mode = 2 ).
  r_contents->set_toolbar_mode( toolbar_mode = cl_gui_textedit=>false  ).

ENDMODULE.
