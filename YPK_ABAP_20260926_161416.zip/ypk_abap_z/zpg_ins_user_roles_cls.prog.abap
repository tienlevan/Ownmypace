*&---------------------------------------------------------------------*
*&  Include           ZPG_INS_USER_ROLES_CLS
*&---------------------------------------------------------------------*
CLASS lcl_user DEFINITION.

  PUBLIC SECTION.
    TYPES: BEGIN OF ty_map_role,
             colname  TYPE char30,
             rolename TYPE agr_name,
           END OF ty_map_role,
           tt_map_roles TYPE TABLE OF ty_map_role,
           BEGIN OF ty_return,
             username TYPE sy-uname,
             message  TYPE bapiret2,
           END OF ty_return.
    CLASS-DATA: r_role      TYPE REF TO data,
                t_map_roles TYPE tt_map_roles,
                t_return    TYPE TABLE OF ty_return.
    DATA: s_logondata  TYPE bapilogond,
          s_defaults   TYPE bapidefaul,
          s_address    TYPE bapiaddr3,
          s_islocked   TYPE bapislockd,
          s_admindata  TYPE bapiuseradmin,
          t_parameters TYPE TABLE OF bapiparam,
          t_roles      TYPE TABLE OF bapiagr,
          t_addsmtp    TYPE TABLE OF bapiadsmtp,
          username     TYPE xubname.

    CLASS-METHODS: get_file_data, get_file, role_adjustment, export_role_matrix, create_user,
      show_log, change_user, export_tcode_matrix, reconstruct_role.
    METHODS: constructor IMPORTING iv_username TYPE xubname,
      role_adjust CHANGING  cs_data          TYPE any.


ENDCLASS.

CLASS lcl_event DEFINITION INHERITING FROM zcl_ul_alv_adapter.

  PROTECTED SECTION.
    METHODS mine_double_click REDEFINITION.

ENDCLASS.

CLASS lcl_user IMPLEMENTATION.

  METHOD get_file_data.

    DATA t_components TYPE cl_abap_structdescr=>component_table.
    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.

    TRY.
        DATA(t_raw) = NEW zcl_ul_doi_usage( )->read_excel_data( EXPORTING iv_file_location = CONV #( p_file )
                                                                          is_select_range = VALUE #( column =  1 columns = 200 row = 1 rows = 2000 ) ).
        t_map_roles = VALUE #( FOR s_raw IN t_raw WHERE ( row = 1 AND column > 1 ) ( colname = |COL{ s_raw-column }| rolename = s_raw-value ) ).
      CATCH zcx_ul_handle_errors INTO DATA(error).
        error->show_message( ).
    ENDTRY.

    APPEND INITIAL LINE TO t_components ASSIGNING FIELD-SYMBOL(<fs_component>).
    <fs_component>-name = 'USERNAME'.
    <fs_component>-type ?= cl_abap_typedescr=>describe_by_name( 'XUBNAME' ).

    LOOP AT t_map_roles INTO DATA(s_map_role).
      APPEND INITIAL LINE TO t_components ASSIGNING <fs_component>.
      <fs_component>-name = s_map_role-colname.
      <fs_component>-type ?= cl_abap_typedescr=>describe_by_name( 'CHAR1' ).
    ENDLOOP.

    TRY.
        DATA(r_type) = NEW zcl_ul_rtts_services(  )->create_table( t_components ).
      CATCH zcx_ul_handle_errors INTO error.
        error->show_message(  ).
        LEAVE TO SCREEN 0.
    ENDTRY.

    CREATE DATA r_role TYPE HANDLE r_type.
    ASSIGN r_role->* TO <ft_data>.

    LOOP AT t_raw INTO DATA(group) WHERE row > 1 GROUP BY group-row ASSIGNING FIELD-SYMBOL(<ft_raw>).
      APPEND INITIAL LINE TO <ft_data> ASSIGNING FIELD-SYMBOL(<fs_data>).
      LOOP AT GROUP <ft_raw> ASSIGNING FIELD-SYMBOL(<fs_raw>).
        IF <fs_raw>-column = 1.
          ASSIGN COMPONENT 'USERNAME' OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<value>).
          <value> = <fs_raw>-value.
        ELSE.
          DATA(component) = |COL{ <fs_raw>-column }|.
          ASSIGN COMPONENT component OF STRUCTURE <fs_data> TO <value>.
          <value> = <fs_raw>-value.
        ENDIF.
      ENDLOOP.
    ENDLOOP.

  ENDMETHOD.

  METHOD get_file.

    CALL FUNCTION 'KD_GET_FILENAME_ON_F4'
      CHANGING
        file_name     = p_file
      EXCEPTIONS
        mask_too_long = 1
        OTHERS        = 2.

    IF sy-subrc <> 0.
      zcx_ul_handle_errors=>raise_message(  ).
    ENDIF.

  ENDMETHOD.

  METHOD role_adjustment.

    get_file_data( ).
    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.
    ASSIGN r_role->* TO <ft_data>.

    LOOP AT <ft_data> ASSIGNING FIELD-SYMBOL(<fs_data>).
      ASSIGN COMPONENT 'USERNAME' OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<username>).
      CHECK <username> IS NOT INITIAL.
      NEW lcl_user( <username> )->role_adjust( CHANGING cs_data =  <fs_data> ).
    ENDLOOP.

    show_log( ).

  ENDMETHOD.

  METHOD export_role_matrix.

    DATA t_map_roles TYPE tt_map_roles.
    DATA t_components TYPE cl_abap_structdescr=>component_table.
    DATA t_users TYPE TABLE OF agr_users.
    DATA t_ret TYPE bapiret2tab.
    DATA s_address TYPE bapiaddr3.
    DATA s_logondata  TYPE bapilogond.
    DATA s_lock TYPE bapislockd.
    DATA t_groups TYPE TABLE OF bapigroups.
    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.

    IF s_role IS INITIAL.
      SELECT FROM agr_define FIELDS 'I' AS sign, 'EQ' AS option, agr_name AS low WHERE agr_name LIKE 'Z%' OR agr_name LIKE 'Y%'
        INTO CORRESPONDING FIELDS OF TABLE @s_role[].
    ENDIF.

    t_map_roles = VALUE #( FOR role IN s_role[] INDEX INTO i ( colname = |R{ i }| rolename = role-low ) ).

    APPEND INITIAL LINE TO t_components ASSIGNING FIELD-SYMBOL(<fs_component>).
    <fs_component>-name = 'USER'.
    <fs_component>-type ?= cl_abap_typedescr=>describe_by_name( 'XUBNAME' ).

    APPEND INITIAL LINE TO t_components ASSIGNING <fs_component>.
    <fs_component>-name = 'USERNAME'.
    <fs_component>-type ?= cl_abap_typedescr=>describe_by_name( 'AD_NAMTEXT' ).

    APPEND INITIAL LINE TO t_components ASSIGNING <fs_component>.
    <fs_component>-name = 'GROUP1'.
    <fs_component>-type ?= cl_abap_typedescr=>describe_by_name( 'XUCLASS' ).

    APPEND INITIAL LINE TO t_components ASSIGNING <fs_component>.
    <fs_component>-name = 'GROUP2'.
    <fs_component>-type ?= cl_abap_typedescr=>describe_by_name( 'XUCLASS' ).

    APPEND INITIAL LINE TO t_components ASSIGNING <fs_component>.
    <fs_component>-name = 'LOCK'.
    <fs_component>-type ?= cl_abap_typedescr=>describe_by_name( 'FC_BLIND' ).

    LOOP AT t_map_roles INTO DATA(s_map_role).
      APPEND INITIAL LINE TO t_components ASSIGNING <fs_component>.
      <fs_component>-name = s_map_role-colname.
      <fs_component>-type ?= cl_abap_typedescr=>describe_by_name( 'CHAR1' ).
    ENDLOOP.

    TRY.
        DATA(r_type) = NEW zcl_ul_rtts_services(  )->create_table( t_components ).
      CATCH zcx_ul_handle_errors INTO DATA(error).
        error->show_message(  ).
        LEAVE TO SCREEN 0.
    ENDTRY.

    CREATE DATA r_role TYPE HANDLE r_type.
    ASSIGN r_role->* TO <ft_data>.

    IF s_usgr IS NOT INITIAL.
      DATA user TYPE RANGE OF bname.
      SELECT FROM usgrp_user FIELDS 'I' AS sign, 'EQ' AS option, bname AS low WHERE usergroup IN @s_usgr
      INTO CORRESPONDING FIELDS OF TABLE @user.
      IF user IS INITIAL.
        MESSAGE 'No user selected!' TYPE 'S' DISPLAY LIKE 'E'. RETURN.
      ENDIF.
    ENDIF.

    LOOP AT t_map_roles ASSIGNING FIELD-SYMBOL(<fs_map_role>).

      CALL FUNCTION 'PRGN_1001_READ_USER_ASSIGNMENT'
        EXPORTING
          activity_group = <fs_map_role>-rolename
        TABLES
          i_agr_users    = t_users.

      IF s_user IS NOT INITIAL.
        DELETE t_users WHERE uname NOT IN s_user.
      ENDIF.

      IF user IS NOT INITIAL.
        DELETE t_users WHERE uname NOT IN user.
      ENDIF.

      LOOP AT t_users ASSIGNING FIELD-SYMBOL(<user>) WHERE to_dat >= sy-datum .

        CALL FUNCTION 'BAPI_USER_GET_DETAIL'
          EXPORTING
            username  = <user>-uname
          IMPORTING
            logondata = s_logondata
            address   = s_address
            islocked  = s_lock
          TABLES
            groups    = t_groups
            return    = t_ret.

        CHECK t_return IS INITIAL AND s_logondata-ustyp = 'A' AND ( s_logondata-gltgb IS INITIAL OR s_logondata-gltgb >= sy-datum ).

        READ TABLE <ft_data> ASSIGNING FIELD-SYMBOL(<data>) WITH KEY ('USER') = <user>-uname.
        IF sy-subrc IS NOT INITIAL.

          APPEND INITIAL LINE TO <ft_data> ASSIGNING <data>.
          ASSIGN COMPONENT 'USER' OF STRUCTURE <data> TO FIELD-SYMBOL(<value>).
          <value> = <user>-uname.
          ASSIGN COMPONENT 'USERNAME' OF STRUCTURE <data> TO <value>.
          <value> = s_address-fullname.

          IF t_groups IS NOT INITIAL.
            LOOP AT t_groups ASSIGNING FIELD-SYMBOL(<fs_group>).
              IF sy-tabix = 1 OR <fs_group>-usergroup = 'VH.KTTC'.
                ASSIGN COMPONENT 'GROUP1' OF STRUCTURE <data> TO <value>.
              ELSE.
                ASSIGN COMPONENT 'GROUP2' OF STRUCTURE <data> TO <value>.
              ENDIF.
              <value> = <fs_group>-usergroup.
            ENDLOOP.
          ENDIF.

          ASSIGN COMPONENT 'LOCK' OF STRUCTURE <data> TO <value>.
          <value> = COND #( WHEN s_lock-local_lock = 'L' THEN 'L'
                            WHEN s_lock-glob_lock  = 'L' THEN 'G'
                            WHEN s_lock-wrng_logon = 'L' THEN 'W'
                            WHEN s_lock-no_user_pw = 'L' THEN 'N'
                            ELSE space ).
          ASSIGN COMPONENT <fs_map_role>-colname OF STRUCTURE <data> TO FIELD-SYMBOL(<x>).
          MOVE 'X' TO <x>.

        ELSE.

          ASSIGN COMPONENT <fs_map_role>-colname OF STRUCTURE <data> TO <x>.
          MOVE 'X' TO <x>.

        ENDIF.

      ENDLOOP.

    ENDLOOP.

    zcl_ul_alv_adapter=>create( EXPORTING it_col_set = VALUE #( FOR s_map IN t_map_roles ( fieldname = s_map-colname reptext = s_map-rolename ) )
                                          iv_title = |Role Matrix: { lines( <ft_data> ) } Users - { lines( t_map_roles ) } Roles|
                                CHANGING  ct_table = <ft_data> ).

  ENDMETHOD.

  METHOD constructor.

    DATA t_ret TYPE TABLE OF bapiret2.
    username = iv_username.
    CALL FUNCTION 'BAPI_USER_GET_DETAIL'
      EXPORTING
        username       = username
      IMPORTING
        logondata      = s_logondata
        defaults       = s_defaults
        address        = s_address
        islocked       = s_islocked
        admindata      = s_admindata
      TABLES
        parameter      = t_parameters
        activitygroups = t_roles
        return         = t_ret
        addsmtp        = t_addsmtp.

    CHECK t_ret IS NOT INITIAL.
    LOOP AT t_ret ASSIGNING FIELD-SYMBOL(<fs_ret>).
      APPEND INITIAL LINE TO t_return ASSIGNING FIELD-SYMBOL(<fs_log>).
      <fs_log>-message = CORRESPONDING #( <fs_ret> ).
      <fs_log>-username = username.
      CLEAR username.
    ENDLOOP.

  ENDMETHOD.

  METHOD role_adjust.

    DATA t_adj_roles TYPE TABLE OF bapiagr.
    DATA r_composite_roles TYPE RANGE OF agr_name.
    DATA t_return2 TYPE bapiret2tab.

    CHECK username IS NOT INITIAL.

    IF p_add IS INITIAL.
      LOOP AT t_roles INTO DATA(s_role).
        SELECT SINGLE FROM agr_flags FIELDS flag_value WHERE agr_name = @s_role-agr_name AND flag_type = 'COLL_AGR' INTO @DATA(composite).
        IF composite = abap_true.
          APPEND s_role TO t_adj_roles.
          CONTINUE.
        ENDIF.
        IF line_exists( t_map_roles[ rolename = s_role-agr_name ] ).
        ELSE.
          APPEND s_role TO t_adj_roles.
        ENDIF.
      ENDLOOP.
    ELSE.
      t_adj_roles  = t_roles.
    ENDIF.

    IF p_delete IS NOT INITIAL.
      DATA(pattern) = |*{ p_delete }*|.
      DELETE t_adj_roles WHERE agr_name CP pattern.
    ENDIF.

    LOOP AT t_map_roles INTO DATA(s_map_role).
      ASSIGN COMPONENT s_map_role-colname OF STRUCTURE cs_data TO FIELD-SYMBOL(<value>).
      <value> = to_upper( <value> ).
      CASE <value>.
        WHEN 'A'.
          APPEND INITIAL LINE TO t_adj_roles ASSIGNING FIELD-SYMBOL(<fs_adj_role>).
          <fs_adj_role> = VALUE #( agr_name = s_map_role-rolename from_dat = sy-datum ).
        WHEN 'X'.
          APPEND INITIAL LINE TO t_adj_roles ASSIGNING <fs_adj_role>.
          TRY.
              s_role = t_roles[ agr_name = s_map_role-rolename ].
              <fs_adj_role> = CORRESPONDING #( s_role ).
            CATCH cx_sy_itab_line_not_found.
              <fs_adj_role> = VALUE #( agr_name = s_map_role-rolename from_dat = sy-datum ).
          ENDTRY.
        WHEN 'C'.
          IF line_exists( t_roles[ agr_name = s_map_role-rolename org_flag = 'C' ] ).
            s_role = t_roles[ agr_name = s_map_role-rolename org_flag = 'C' ].
            SELECT FROM agr_agrs2 FIELDS 'I' AS sign, 'EQ' AS option, agr_name AS low WHERE child_agr = @s_map_role-rolename INTO TABLE @r_composite_roles.
            DELETE t_adj_roles WHERE agr_name IN r_composite_roles.
          ENDIF.
      ENDCASE.
    ENDLOOP.

    CHECK t_adj_roles IS NOT INITIAL.
    CALL FUNCTION 'BAPI_USER_ACTGROUPS_ASSIGN'
      EXPORTING
        username       = username
      TABLES
        activitygroups = t_adj_roles
        return         = t_return2.

    LOOP AT t_return2 ASSIGNING FIELD-SYMBOL(<fs_return>).
      APPEND INITIAL LINE TO t_return ASSIGNING FIELD-SYMBOL(<fs_log>).
      <fs_log>-message = CORRESPONDING #( <fs_return> ).
      <fs_log>-username = username.
    ENDLOOP.

  ENDMETHOD.

  METHOD show_log.

    CHECK t_return IS NOT INITIAL.
    zcl_ul_alv_adapter=>create( EXPORTING ir_local_class = cl_abap_classdescr=>describe_by_name( 'LCL_EVENT' )
                                CHANGING ct_table = t_return ).

  ENDMETHOD.

  METHOD create_user.

    TYPES: BEGIN OF ty_data,
             user     TYPE sy-uname,
             username TYPE ad_namelas,
             password TYPE xuncode,
             mandt    TYPE sy-mandt,
           END OF ty_data.
    DATA: s_data TYPE ty_data.

    DATA: logondata TYPE bapilogond,
          defaults  TYPE bapidefaul,
          password  TYPE bapipwd,
          address   TYPE bapiaddr3,
          parameter TYPE TABLE OF bapiparam,
          role_add  TYPE TABLE OF bapiagr,
          group     TYPE TABLE OF bapigroups,
          return    TYPE TABLE OF bapiret2.

    TRY.
        DATA(t_dept) = NEW zcl_ul_rtts_services( iv_name = 'ZDD_POSGR' )->get_fix_values(  ).
      CATCH zcx_ul_handle_errors.
        RETURN.
    ENDTRY.

    TRY.
        address = VALUE #( lastname = p_name e_mail = p_email function = gt_position[ key = p_post ]-text
                           department = t_dept[ low = p_dept ]-ddtext ).
      CATCH cx_sy_itab_line_not_found.
    ENDTRY.

    CALL FUNCTION 'RSEC_GENERATE_PASSWORD'
      EXPORTING
        output_length = 10
      IMPORTING
        output        = password-bapipwd.

    defaults = VALUE #( timefm = 0 datfm = 1 langu = sy-langu ).
    logondata = VALUE #( gltgv = sy-datum ustyp = 'A' tzone = 'UTC+7' ).
    parameter = VALUE #( ( parid = 'FWS' parva = 'VND' )
                         ( parid = 'LND' parva = 'VN' )
                         ( parid = 'SPR' parva = 'EN' )
                         ( parid = 'ZPRINTPREVIEW' parva = 'X' ) ).

    SELECT FROM ztb_set_usgr FIELDS usergroup WHERE ( posid = @p_post OR posid = @p_dept ) INTO TABLE @DATA(t_group).
    group = VALUE #( FOR g IN t_group ( usergroup = g-usergroup ) ).


    CALL FUNCTION 'BAPI_USER_CREATE1'
      EXPORTING
        username  = p_user
        logondata = logondata
        password  = password
        defaults  = defaults
        address   = address
      TABLES
        parameter = parameter
        groups    = group
        return    = return.

    LOOP AT return ASSIGNING FIELD-SYMBOL(<fs_return>).
      APPEND INITIAL LINE TO t_return ASSIGNING FIELD-SYMBOL(<fs_log>).
      <fs_log>-message = CORRESPONDING #( <fs_return> ).
      <fs_log>-username = p_user.
    ENDLOOP.

    IF line_exists( return[ type = 'E' ] ).
      CALL FUNCTION 'BAPI_TRANSACTION_ROLLBACK'.
      show_log(  ). RETURN.
    ELSE.
      CALL FUNCTION 'BAPI_TRANSACTION_COMMIT' EXPORTING wait = abap_true.
    ENDIF.

    IF p_comm IS NOT INITIAL.
      DATA instance TYPE REF TO cl_identity.
      TRY.
          cl_identity=>retrieve_for_update( EXPORTING it_bname = VALUE #( ( bname = p_user ) )
                                            IMPORTING et_node_root = DATA(et_node_root) ).
          instance ?= et_node_root[ 1 ]-idref.
          instance->if_identity~set_documentation( is_docu = VALUE suid_st_node_docu( docu = p_comm ) ).
          instance->save( ).
        CATCH cx_suid_identity.
      ENDTRY.
    ENDIF.

    IF r_post IS NOT INITIAL.
      SELECT FROM ztb_set_roles FIELDS role WHERE posgr = @p_dept AND ( posid = @p_post OR posid = 'COMMON' ) INTO TABLE @DATA(t_roles).
      role_add = VALUE #( FOR s IN t_roles ( agr_name = s-role from_dat = sy-datum ) ).
    ELSE.
      CALL FUNCTION 'BAPI_USER_GET_DETAIL'
        EXPORTING
          username       = p_refus
        TABLES
          activitygroups = role_add
          return         = return.
      IF line_exists( return[ type = 'E' ] ).
        show_log(  ). RETURN.
      ENDIF.
    ENDIF.

    IF s_addrl IS NOT INITIAL.
      LOOP AT s_addrl[] INTO DATA(addrl).
        role_add = VALUE #( BASE role_add ( agr_name = addrl-low from_dat = sy-datum ) ).
      ENDLOOP.
    ENDIF.

    CALL FUNCTION 'BAPI_USER_ACTGROUPS_ASSIGN'
      EXPORTING
        username       = p_user
      TABLES
        activitygroups = role_add
        return         = return.

    LOOP AT return ASSIGNING <fs_return>.
      APPEND INITIAL LINE TO t_return ASSIGNING <fs_log>.
      <fs_log>-message = CORRESPONDING #( <fs_return> ).
      <fs_log>-username = p_user.
    ENDLOOP.

    IF line_exists( return[ type = 'E' ] ).
      CALL FUNCTION 'BAPI_TRANSACTION_ROLLBACK'.
      show_log(  ). RETURN.
    ELSE.
      CALL FUNCTION 'BAPI_TRANSACTION_COMMIT' EXPORTING wait = abap_true.

      " Send email
      s_data = VALUE #( user = p_user username = address-lastname password = password-bapipwd mandt = sy-mandt ).
      NEW zcl_ul_file_create( iv_template = 'SAP_User_Email.htm' )->execute( EXPORTING iv_action = zcl_ul_file_create=>mc_act_generate iv_input = /ui2/cl_json=>serialize( EXPORTING data = s_data ) IMPORTING et_html = DATA(html) ).

      TRY.
          DATA(email) = NEW zcl_ul_send_email( ).
          email->set_sender( internet_address = 'SAP@vinhomes.vn' ).
          email->set_receipients( internet_address = address-e_mail ).
          email->create_document( i_sensitivity = abap_true i_subject = '[SAP]Thông báo tài khoản mới'
                                  i_type = 'HTM' i_hex = html ).
          email->send_email( ).
          MESSAGE 'Email sent!' TYPE 'S'.
        CATCH zcx_ul_handle_errors INTO DATA(cx_error).
          cx_error->show_message(  ).
      ENDTRY.
      "show log
      show_log(  ).
    ENDIF.

  ENDMETHOD.

  METHOD change_user.

    DATA return TYPE TABLE OF bapiret2.
    DATA t_adj_roles TYPE TABLE OF bapiagr.

    LOOP AT s_user_c ASSIGNING FIELD-SYMBOL(<fs_user>).

      IF p_pass IS NOT INITIAL.

        DATA(password) = VALUE bapipwd( bapipwd = p_pass ).
        DATA(passwordx) = VALUE bapipwdx( bapipwd = abap_true ).

        CALL FUNCTION 'BAPI_USER_CHANGE'
          EXPORTING
            username       = <fs_user>-low
            password       = password
            passwordx      = passwordx
            productive_pwd = p_prod
          TABLES
            return         = return.

        LOOP AT return ASSIGNING FIELD-SYMBOL(<fs_return>).
          APPEND INITIAL LINE TO t_return ASSIGNING FIELD-SYMBOL(<fs_log>).
          <fs_log>-message = CORRESPONDING #( <fs_return> ).
          <fs_log>-username = <fs_user>-low.
        ENDLOOP.
      ENDIF.

      IF p_post_a IS NOT INITIAL.
        SELECT FROM ztb_set_roles FIELDS role WHERE posid = @p_post_a INTO TABLE @DATA(t_roles).
        t_adj_roles = VALUE #( FOR s IN t_roles ( agr_name = s-role from_dat = sy-datum ) ).
      ENDIF.

      IF s_role_a IS NOT INITIAL.
        LOOP AT s_role_a INTO DATA(sa).
          t_adj_roles = VALUE #( BASE t_adj_roles ( agr_name = sa-low from_dat = sy-datum ) ).
        ENDLOOP.
      ENDIF.

      IF t_adj_roles IS NOT INITIAL.

        APPEND LINES OF NEW lcl_user( <fs_user>-low )->t_roles TO t_adj_roles.
        SORT t_adj_roles ASCENDING BY agr_name.
        DELETE ADJACENT DUPLICATES FROM t_adj_roles COMPARING agr_name.

        CALL FUNCTION 'BAPI_USER_ACTGROUPS_ASSIGN'
          EXPORTING
            username       = <fs_user>-low
          TABLES
            activitygroups = t_adj_roles
            return         = return.

        LOOP AT return ASSIGNING <fs_return>.
          APPEND INITIAL LINE TO t_return ASSIGNING <fs_log>.
          <fs_log>-message = CORRESPONDING #( <fs_return> ).
          <fs_log>-username = <fs_user>-low.
        ENDLOOP.

        IF line_exists( t_return[ message-type = 'E' ] ).
          CALL FUNCTION 'BAPI_TRANSACTION_ROLLBACK'.
        ELSE.
          CALL FUNCTION 'BAPI_TRANSACTION_COMMIT' EXPORTING wait = abap_true.
        ENDIF.

      ENDIF.

    ENDLOOP.

    CHECK t_return IS NOT INITIAL.
    show_log(  ).

  ENDMETHOD.

  METHOD export_tcode_matrix.

    DATA t_map_roles TYPE tt_map_roles.
    DATA t_roles     TYPE TABLE OF agr_define.
    DATA t_components TYPE cl_abap_structdescr=>component_table.
    DATA t_tcodes TYPE TABLE OF agr_tcodes.
    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.

    IF s_role_1 IS INITIAL.
      MESSAGE 'Please fill at least one role!' TYPE 'I'.
      RETURN.
    ENDIF.

    t_map_roles = VALUE #( FOR role IN s_role_1[] INDEX INTO i ( colname = |R{ i }| rolename = role-low ) ).
    APPEND INITIAL LINE TO t_components ASSIGNING FIELD-SYMBOL(<fs_component>).
    <fs_component>-name = 'TCODE'.
    <fs_component>-type ?= cl_abap_typedescr=>describe_by_name( 'TCODE' ).

    APPEND INITIAL LINE TO t_components ASSIGNING <fs_component>.
    <fs_component>-name = 'TTEXT'.
    <fs_component>-type ?= cl_abap_typedescr=>describe_by_name( 'TTEXT_STCT' ).

    LOOP AT t_map_roles INTO DATA(s_map_role).
      APPEND INITIAL LINE TO t_components ASSIGNING <fs_component>.
      <fs_component>-name = s_map_role-colname.
      <fs_component>-type ?= cl_abap_typedescr=>describe_by_name( 'CHAR1' ).
    ENDLOOP.

    TRY.
        DATA(r_type) = NEW zcl_ul_rtts_services(  )->create_table( t_components ).
      CATCH zcx_ul_handle_errors INTO DATA(error).
        error->show_message(  ).
        RETURN.
    ENDTRY.

    CREATE DATA r_role TYPE HANDLE r_type.
    ASSIGN r_role->* TO <ft_data>.

    LOOP AT t_map_roles INTO s_map_role.

      REFRESH t_tcodes.
      CALL FUNCTION 'PRGN_READ_TRANSACTIONS_ONE_AGR'
        EXPORTING
          activity_group            = s_map_role-rolename
        TABLES
          transactions              = t_tcodes
        EXCEPTIONS
          activity_group_not_found  = 1
          no_transactions_available = 2
          error_message             = 3
          OTHERS                    = 4.

      IF sy-subrc IS NOT INITIAL.
        CONTINUE.
      ENDIF.

      IF s_tcode IS NOT INITIAL.
        DELETE t_tcodes WHERE tcode NOT IN s_tcode[].
      ENDIF.

      LOOP AT t_tcodes ASSIGNING FIELD-SYMBOL(<tcode>).
        READ TABLE <ft_data> ASSIGNING FIELD-SYMBOL(<data>) WITH KEY ('TCODE') = <tcode>-tcode.
        IF sy-subrc IS NOT INITIAL.
          APPEND INITIAL LINE TO <ft_data> ASSIGNING <data>.
          ASSIGN COMPONENT 'TCODE' OF STRUCTURE <data> TO FIELD-SYMBOL(<value>).
          <value> = <tcode>-tcode.
          ASSIGN COMPONENT 'TTEXT' OF STRUCTURE <data> TO <value>.
          SELECT SINGLE FROM tstct FIELDS ttext WHERE tcode = @<tcode>-tcode INTO @<value>.
          ASSIGN COMPONENT s_map_role-colname OF STRUCTURE <data> TO FIELD-SYMBOL(<x>).
          MOVE 'X' TO <x>.
        ELSE.
          ASSIGN COMPONENT s_map_role-colname OF STRUCTURE <data> TO <x>.
          MOVE 'X' TO <x>.
        ENDIF.
      ENDLOOP.

    ENDLOOP.

    zcl_ul_alv_adapter=>create( EXPORTING it_col_set = VALUE #( FOR s_map IN t_map_roles ( fieldname = s_map-colname reptext = s_map-rolename just = 'C' ) )
                                          iv_title = 'Tcode Matrix'
                                CHANGING ct_table = <ft_data> ).

  ENDMETHOD.

  METHOD reconstruct_role.

    DATA: s_data TYPE ztb_set_roles,
          t_data TYPE TABLE OF ztb_set_roles.

    get_file_data( ).
    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.
    ASSIGN r_role->* TO <ft_data>.

    LOOP AT <ft_data> ASSIGNING FIELD-SYMBOL(<fs_data>).

      ASSIGN COMPONENT 'USERNAME' OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<username>).
      CHECK <username> IS NOT INITIAL.
      CLEAR s_data.
      s_data-posgr = p_dept_n.
      s_data-posid = <username>.
      s_data-posname = SWITCH #( s_data-posid
                                    WHEN 'CFO'        THEN 'Giám đốc tài chính'
                                    WHEN 'CV_APVH'    THEN 'Chuyên viên kế toán phải trả vận hành'
                                    WHEN 'CV_APXD'    THEN 'Chuyên viên kế toán phải trả CĐT'
                                    WHEN 'CV_ARBĐS'   THEN 'Chuyên viên kế toán phải thu BĐS'
                                    WHEN 'CV_ARVH'    THEN 'Chuyên viên kế toán phải thu vận hành'
                                    WHEN 'CV_TH'      THEN 'Chuyên viên kế toán tổng hợp'
                                    WHEN 'CV_FC'      THEN 'Chuyên viên ngân sách'
                                    WHEN 'CV_MISNS'   THEN 'Chuyên viên MIS&ngân sách'
                                    WHEN 'KTT'        THEN 'Kế toán trưởng'
                                    WHEN 'PPKT_BĐS'   THEN 'Phó phòng kế toán BĐS'
                                    WHEN 'PPKT_VH'    THEN 'Phó phòng kế toán vận hành'
                                    WHEN 'PPKT_XD'    THEN 'Phó phòng kế toán xây dựng'
                                    WHEN 'TN_APVH'    THEN 'Trưởng nhóm phải trả vận hành'
                                    WHEN 'TN_APXD'    THEN 'Trưởng nhóm kế toán chủ đầu tư'
                                    WHEN 'TN_ARBĐS'   THEN 'Trưởng nhóm kế toán phải thu BĐS'
                                    WHEN 'TN_ARVH'    THEN 'Trưởng nhóm kế toán phải thu VH'
                                    WHEN 'TN_FC'      THEN 'Trưởng nhóm ngân sách'
                                    WHEN 'TN_TH'      THEN 'Trưởng nhóm tổng hợp'
                                    WHEN 'CV_CS'      THEN 'Chuyên viên chính sách'
                                    WHEN 'CG_CS'      THEN 'Chuyên gia chính sách'
                                    WHEN 'QL_CS'      THEN 'Chuyên viên chính sách'
                                    WHEN 'CV_HN'      THEN 'Chuyên viên hợp nhất'
                                    WHEN 'TN_HN'      THEN 'Trưởng nhóm hợp nhất' ).

      LOOP AT t_map_roles INTO DATA(s_map_role).
        ASSIGN COMPONENT s_map_role-colname OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<value>).
        <value> = to_upper( <value> ).
        IF <value> = 'X'.
          s_data-role = s_map_role-rolename.
          APPEND s_data TO t_data.
        ENDIF.
      ENDLOOP.

    ENDLOOP.

    CHECK t_data IS NOT INITIAL.
    MODIFY ztb_set_roles FROM TABLE t_data.
    CHECK sy-subrc IS INITIAL.
    MESSAGE 'Roles has been reconstructed!' TYPE 'I'.

  ENDMETHOD.

ENDCLASS.

CLASS lcl_event IMPLEMENTATION.

  METHOD mine_double_click.

    FIELD-SYMBOLS <ft_data> TYPE INDEX TABLE.
    ASSIGN mt_outtab->* TO <ft_data>.

    READ TABLE <ft_data> ASSIGNING FIELD-SYMBOL(<fs_data>) INDEX e_row.

    CHECK e_column-fieldname = 'USERNAME'.
    ASSIGN COMPONENT e_column-fieldname OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<field>).
    CHECK <field> IS NOT INITIAL.
    SET PARAMETER ID 'XUS' FIELD <field>.
    CALL TRANSACTION 'SU01' WITH AUTHORITY-CHECK AND SKIP FIRST SCREEN.


  ENDMETHOD.

ENDCLASS.
