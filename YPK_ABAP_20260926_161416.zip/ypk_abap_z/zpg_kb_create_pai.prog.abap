*&---------------------------------------------------------------------*
*&  Include           ZPG_KB_CREATE_PAI
*&---------------------------------------------------------------------*
AT SELECTION-SCREEN.

  CASE sscrfields-ucomm.

    WHEN 'FC01'.
      gv_mode = gc_mode_create.
      gv_mode_text = 'Create'.
      CALL SCREEN 8888.

    WHEN 'FC02'.
      gv_mode = gc_mode_change.
      gv_mode_text = 'Change'.
      IF p_noteid IS INITIAL.
        MESSAGE 'Please fill out a Note ID!' TYPE 'E'.
        RETURN.
      ENDIF.
      CALL SCREEN 8888.

    WHEN 'FC03' OR 'ONLI'.
      gv_mode = gc_mode_display.
      gv_mode_text = 'Display'.
      IF sscrfields-ucomm = 'ONLI'.
        GET PARAMETER ID 'ZREQID' FIELD p_noteid.
      ENDIF.
      IF p_noteid IS INITIAL.
        MESSAGE 'Please fill out a Note ID!' TYPE 'E'.
        RETURN.
      ENDIF.
      CALL SCREEN 8888.

  ENDCASE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_8888  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_8888 INPUT.

  CASE sy-ucomm.
    WHEN 'BACK'.
      app=>free( ).
      LEAVE TO SCREEN 0.
    WHEN 'LEAVE'.
      LEAVE PROGRAM.
    WHEN 'CHANGE'.
      gv_mode = SWITCH #( gv_mode WHEN gc_mode_display THEN gc_mode_change ELSE gc_mode_display ).
      gv_mode_text = SWITCH #( gv_mode WHEN gc_mode_display THEN 'Display' ELSE 'Change' ).
      app=>control->view->set_text_status( ).

    WHEN 'SAVE'.
      app=>save( ).
  ENDCASE.

ENDMODULE.
