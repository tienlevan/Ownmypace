*&---------------------------------------------------------------------*
*& Report zpg_fi_call_configuration
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zpg_fi_call_configuration.

PARAMETERS: p_config TYPE text10 OBLIGATORY.

START-OF-SELECTION.

  zcl_ul_dynamic_configuration=>call_configuration( configuration_group = p_config ).
