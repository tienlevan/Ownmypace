FUNCTION zfm_ins_get_status.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  EXPORTING
*"     REFERENCE(E_RELEASED) TYPE  CHAR1
*"     REFERENCE(E_STATUS) TYPE  CHAR2
*"----------------------------------------------------------------------

  CLEAR: e_released,
         e_status.
  e_released = gw_released.
  e_status = gw_status.

ENDFUNCTION.
