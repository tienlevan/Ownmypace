*&---------------------------------------------------------------------*
*& Include          ZFM_RELEASE_STRATEGY_TOP
*&---------------------------------------------------------------------*
TABLES: ztb_set_relgr, ztb_set_relstr, ztb_set_relcode.
CLASS lcl_alv_event DEFINITION DEFERRED.

DATA: gw_finish_rel TYPE string,
      gw_wait_rel   TYPE string,
      gw_un_release TYPE string,
      gw_release    TYPE string,
      gw_reject     TYPE string.

DATA: BEGIN OF gs_release_tab,
        frgco      TYPE zz_dd_frgco,
        frgco_name TYPE text50,
        status     TYPE iconname,
        function   TYPE iconname,
        flg_next   TYPE  char1,
      END OF gs_release_tab,
      gt_release_tab LIKE TABLE OF gs_release_tab.

DATA : container_rel   TYPE REF TO cl_gui_custom_container,
       grid_rel        TYPE REF TO zcl_ul_alv_adapter,
       gt_fieldcat_rel TYPE lvc_t_fcat,
       event_rel       TYPE REF TO lcl_alv_event,
       gv_objnr        TYPE swo_typeid.

DATA: gw_released TYPE char1,
      gw_status   TYPE char2,
      gw_url_only TYPE char1.
