*----------------------------------------------------------------------*
***INCLUDE LZFG_INS_ULI01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0101  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0101 INPUT.

  CASE ok_code.

    WHEN 'YES'.

      DATA key_exist TYPE boole_d.

      IF gw_url_only IS INITIAL.
        IF fcode = 'CNODE' OR fcode = 'CITEM'.
          " Get symbol
          IF ztb_treeload-n_image IS NOT INITIAL.
            tree_node-n_image   = ztb_treeload-n_image.
          ELSE.
            zcl_ul_tree_display=>set_default_text( EXPORTING iv_acc_type = ztb_treeload-acc_type
                                                   IMPORTING ev_symbol   = tree_node-n_image ).
          ENDIF.

          " Get text
          IF ztb_treeload-text IS NOT INITIAL.
            tree_node-text = ztb_treeload-text.
          ELSE.
            tree_node-text = zcl_ul_tree_display=>set_default_text( EXPORTING iv_acc_type = ztb_treeload-acc_type
                                                                    CHANGING  cv_value    = ztb_treeload-programname ).
          ENDIF.

          " Fill program name
          tree_node-programname = ztb_treeload-programname.
          " Check out node selected
          SELECT SINGLE FROM ztb_treeload
              FIELDS isfolder
              WHERE modulelo = @menu AND node_key = @node_key
              INTO @DATA(is_folder).

          IF is_folder IS INITIAL.
            MESSAGE 'Please choose a folder!' TYPE 'I'.
            RETURN.
          ENDIF.

          " Default value
          SELECT SINGLE FROM ztb_treeload
            FIELDS MAX( pos ) AS max_num
            WHERE modulelo = @menu
            INTO @DATA(max_mum).

          tree_node-pos       = max_mum + 1.
          tree_node-modulelo  = menu.
          tree_node-class     = 2.
          tree_node-relatkey  = node_key.
          tree_node-relatship = 6.

          IF fcode = 'CNODE'.
            tree_node-node_key = |NODE{ tree_node-pos }|.
            tree_node-isfolder = 'X'.
            tree_node-style = 2.
          ELSE.
            tree_node-node_key    = |ITEM{ tree_node-pos }|.
            tree_node-acc_type    = ztb_treeload-acc_type.
            tree_node-dragdropid  = 1.
          ENDIF.
          tree_node-length    = strlen( tree_node-text ).
          tree_node-created_by = sy-uname.
          tree_node-created_on = zcl_ul_abap=>encode_timestamp( ).

          MODIFY ztb_treeload FROM tree_node.

          DATA lt_treenode LIKE TABLE OF tree_node.
          lt_treenode = VALUE #( ( tree_node ) ).

          IF sy-subrc = 0.
            MESSAGE 'New entry has been created!' TYPE 'S'.
            _tree->create_int_tree( EXPORTING it_config  = lt_treenode
                                    IMPORTING et_nodetab = DATA(lt_node)
                                              et_item    = DATA(lt_item) ).
            _tree->ar_tree->add_nodes_and_items( node_table = lt_node item_table = lt_item item_table_structure_name = 'ZTB_TREELOAD' ).
            _tree->ar_tree->set_selected_node( tree_node-node_key ).
          ELSE.
            MESSAGE 'Failed to insert the entry' TYPE 'S' DISPLAY LIKE 'E'.
          ENDIF.
        ELSEIF fcode = 'XNODE' OR fcode = 'XITEM'.
          IF ztb_treeload-text IS INITIAL AND fcode = 'XITEM'.
            ztb_treeload-text = zcl_ul_tree_display=>set_default_text( EXPORTING iv_acc_type = ztb_treeload-acc_type
                                                                       IMPORTING ev_symbol   = ztb_treeload-n_image
                                                                       CHANGING  cv_value    = ztb_treeload-programname ).
          ENDIF.


          IF ztb_treeload-doctype IS NOT INITIAL.
            FREE key_exist.
            SELECT SINGLE FROM ztb_treeload FIELDS @abap_true WHERE doctype = @ztb_treeload-doctype AND docname NE @ztb_treeload-docname
             INTO @key_exist.
            IF key_exist = abap_true.
              zcx_ul_handle_errors=>raise_message( iv_msg_text = 'Mapping key has been existed!' ).
              RETURN.
            ENDIF.
          ENDIF.

          tree_node = CORRESPONDING #( ztb_treeload ).
          tree_node-text       = ztb_treeload-text.
          tree_node-length     = strlen( tree_node-text ).
          tree_node-changed_by = sy-uname.
          tree_node-changed_on = zcl_ul_abap=>encode_timestamp( ).

          MODIFY ztb_treeload FROM tree_node.
          CHECK sy-subrc = 0.
          MESSAGE 'The node/item has been changed' TYPE 'S'.
          lt_treenode = VALUE #( ( tree_node ) ).
          _tree->create_int_tree( EXPORTING it_config  = lt_treenode
                                  IMPORTING et_nodetab = lt_node
                                            et_item    = lt_item ).

          DATA: ls_upnode TYPE treev_unod,
                ls_upitem TYPE bdtreevupd,
                lt_upitem TYPE TABLE OF bdtreevupd.

          ls_upnode = CORRESPONDING #( lt_node[ 1 ] ).
          ls_upitem = CORRESPONDING #( lt_item[ 1 ] ).
          ls_upnode-u_all  = 'X'.
          ls_upitem-u_all  = 'X'.
          DATA(lt_upnode) = VALUE treev_upno( ( ls_upnode ) ).
          lt_upitem = VALUE #( ( ls_upitem ) ).
          _tree->ar_tree->update_nodes_and_items( node_table = lt_upnode item_table = lt_upitem item_table_structure_name = 'MTREEITM' ).
        ENDIF.
        CLEAR: lt_node, lt_item, lt_treenode, tree_node, ztb_treeload.
      ELSE.
        PERFORM create_url_item.
      ENDIF.

    WHEN 'NO'.

      CLEAR: ztb_treeload, tree_node.

  ENDCASE.

  CLEAR ok_code.
  LEAVE TO SCREEN 0.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0102  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0102 INPUT.

  CHECK ok_code = 'YES'.

  IF go_doc IS NOT BOUND AND _tree->ar_html IS BOUND.
    go_doc = NEW #( io_container = _tree->ar_html iv_obj_key = object_address ).
    _tree->av_doc_open = abap_true.
  ELSEIF go_doc IS NOT BOUND.
    go_doc = NEW #( iv_obj_key = object_address ).
  ENDIF.

  DATA(ls_node) = _tree->get_node_inf( _tree->get_selected_node( ) ).

  CASE file_meth.

    WHEN 'CNEW'.

      TRY.
          go_doc->av_first_save = abap_true.
          go_doc->create_document( iv_document_type = CONV #( ztb_treeload-doctype )
                                   iv_doc_name      = CONV #( ztb_treeload-text ) ).
        CATCH zcx_ul_handle_errors INTO cx_error.
          cx_error->show_message( ).
          RETURN.
      ENDTRY.

      _tree->add_document( go_doc ).
      _tree->set_visible( 'C_OI_CONTAINER_CONTROL_PROXY' ).

    WHEN 'UPLD'.

      DATA file_size TYPE i.
      LOOP AT gt_file_path INTO gs_file_path.
        IF strlen( gs_file_path-filename ) <= 128.
          CALL FUNCTION 'GUI_GET_FILE_INFO'
            EXPORTING
              fname     = CONV localfile( gs_file_path-filename )
            IMPORTING
              file_size = file_size.

          IF file_size > 50000000 AND sy-uname <> 'TIENLV1' AND sy-uname <> 'QUANGDV2' .
            MESSAGE |File { gs_file_path-filename } size is over than 50Mb. Can not upload!| TYPE 'I'.
            CONTINUE.
          ENDIF.
        ENDIF.

        REFRESH go_doc->at_doc_components.
        doc_id = go_doc->upload_document( iv_file_path = CONV #( gs_file_path-filename ) ).

        DATA(lt_config) = _tree->at_config.
        SORT lt_config DESCENDING BY pos.
        DATA lt_add_node TYPE TABLE OF ztb_treeload.

        IF ls_node-isfolder IS NOT INITIAL.
          CASE go_doc->at_doc_signatures[ prop_name = 'BDS_DOCUMENTCLASS' ]-prop_value.
            WHEN 'DOC' OR 'DOCX'.
              DATA(lv_image) = '@J7@'.
            WHEN 'XLS' OR 'XLSX'.
              lv_image =  '@J2@'.
            WHEN 'XLSM'.
              lv_image = '@J3@'.
            WHEN 'PPT' OR 'PPTX'.
              lv_image = '@J5@'.
            WHEN 'PDF'.
              lv_image = '@IT@'.
            WHEN 'MSG'.
              lv_image = '@J1'.
            WHEN 'JPG' OR 'PNG' OR 'GIF' OR 'TIF'.
              lv_image = '@JA@'.
            WHEN 'HTM' OR 'HTML'.
              lv_image = '@J4@'.
            WHEN 'RTF'.
              lv_image = 'J9'.
            WHEN 'TXT'.
              lv_image = 'JB'.
            WHEN 'LWP'.
              lv_image = 'JC'.
            WHEN '123'.
              lv_image = 'JD'.
            WHEN 'VSD'.
              lv_image = 'JE'.
            WHEN OTHERS.
              lv_image = '@OA@'.
          ENDCASE.

          lt_add_node = VALUE #( ( modulelo = _tree->av_module node_key = |ITEM{ lt_config[ 1 ]-pos + 1 }| n_image = lv_image
                                   text = go_doc->at_doc_signatures[ prop_name = 'DESCRIPTION' ]-prop_value created_by = sy-uname
                                   doctype = ztb_treeload-doctype docname = doc_id acc_type = '11' dragdropid = 1 created_on = zcl_ul_abap=>encode_timestamp( )
                                   pos = lt_config[ 1 ]-pos + 1 relatkey = ls_node-node_key relatship = 6 object_key = gv_key file_size = file_size
                                   length = strlen( go_doc->at_doc_signatures[ prop_name = 'DESCRIPTION' ]-prop_value ) ) ).

          _tree->add_nodes( it_nodes = lt_add_node ).
          MODIFY ztb_treeload FROM TABLE lt_add_node.
          _tree->ar_tree->set_selected_node( lt_add_node[ 1 ]-node_key ).
          MESSAGE 'New document is inserted!' TYPE 'S'.
        ELSE.
          DATA(lv_doc_name) = go_doc->at_doc_signatures[ 1 ]-doc_id.
          UPDATE ztb_treeload SET docname = lv_doc_name
                              WHERE modulelo = _tree->av_module
                              AND   node_key = ls_node-node_key.
          CHECK sy-subrc = 0.
          MESSAGE 'Document is applied for this node' TYPE 'S'.
        ENDIF.
      ENDLOOP.

    WHEN 'LINK'.

      lt_config = _tree->at_config.
      SORT lt_config DESCENDING BY pos.
*{   REPLACE        DECK937938                                        1
*\      lt_add_node = VALUE #( ( modulelo = _tree->av_module node_key = |ITEM{ lt_config[ 1 ]-pos + 1 }| n_image = '@Y3@'
      lt_add_node = VALUE #( ( modulelo = _tree->av_module node_key = |ITEM{ lt_config[ 1 ]-pos + 1 }| n_image = '@IZ@'
*}   REPLACE
                              text = ztb_treeload-text created_by = sy-uname length = strlen( ztb_treeload-text ) + 5
                              doctype = ztb_treeload-doctype docname = doc_id acc_type = '05' dragdropid = 1 created_on = zcl_ul_abap=>encode_timestamp( )
                              pos = lt_config[ 1 ]-pos + 1 relatkey = ls_node-node_key relatship = 6 object_key = gv_key
                              programname = file_link ) ).

      _tree->add_nodes( it_nodes = lt_add_node ).
      MODIFY ztb_treeload FROM TABLE lt_add_node.
      _tree->ar_tree->set_selected_node( lt_add_node[ 1 ]-node_key ).
      MESSAGE 'New document is inserted!' TYPE 'S'.

  ENDCASE.

  LEAVE TO SCREEN 0.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  EXIT  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE exit INPUT.

  CHECK ok_code = 'NO'.
  LEAVE TO SCREEN 0.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  DUMMY  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE dummy INPUT.
  "dummy
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0301  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0301 INPUT.

  CASE sy-ucomm.
    WHEN 'BACK' OR 'EXIT' OR 'CANCEL' OR 'TRRT'.
      CALL FUNCTION 'ZFM_ALV_CLEANUP'.
      IF zcl_ul_alv_adapter=>o_grid->o_splitter IS BOUND.
        zcl_ul_alv_adapter=>o_grid->o_splitter->free(  ).
        FREE zcl_ul_alv_adapter=>o_grid->o_splitter.
      ENDIF.
      zcl_ul_alv_adapter=>o_grid->mine_back_event( ).
    WHEN 'SAVE'.
      IF go_alv IS BOUND.
        go_alv->mine_save_event( ).
      ELSE.
        zcl_ul_alv_adapter=>o_grid->mine_save_event( ).
      ENDIF.
  ENDCASE.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0302  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0302 INPUT.

  CASE sy-ucomm.
    WHEN 'CLOSE' OR 'CONTI'.
      IF gv_input IS NOT INITIAL AND sy-ucomm = 'CONTI'.
        go_alv->check_changed_data( ).
      ENDIF.
      CALL FUNCTION 'ZFM_ALV_CLEANUP'.
      go_alv->mine_back_event( ).
    WHEN 'SUPPORT'.
      LEAVE TO SCREEN 0.
  ENDCASE.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0401  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0401 INPUT.

  CHECK sy-ucomm IS NOT INITIAL AND go_file IS BOUND.
  CLEAR gs_node.

  TRY .
      gs_node = go_file->get_node_inf( go_file->get_selected_node( ) ).
    CATCH zcx_ul_handle_errors INTO cx_error.
      RETURN.
  ENDTRY.

  IF sy-ucomm <> 'OPEN' AND go_file->ar_doi_doc IS NOT BOUND.
    TRY.
        go_file->ar_doi_doc = NEW #( iv_obj_key = gv_key  ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message( ).
        RETURN.
    ENDTRY.
  ENDIF.

  CASE sy-ucomm.

    WHEN 'UPLD'.

      IF gs_node-isfolder IS INITIAL.
        MESSAGE 'Please select a folder!' TYPE 'I'.
        RETURN.
      ENDIF.

      CALL FUNCTION 'ZFM_INS_DOI_CREATE'
        EXPORTING
          io_tree        = go_file
          iv_obj_address = gv_key
          iv_upload_only = abap_true.

    WHEN 'DOWN'.

      CHECK gs_node-acc_type EQ zcl_ul_tree_display=>c_node_doc.
      TRY.
          go_file->ar_doi_doc->download_document( iv_doc_id = gs_node-docname iv_treename = CONV #( gs_node-text ) ).
        CATCH zcx_ul_handle_errors INTO cx_error.
          cx_error->show_message( ).
      ENDTRY.

    WHEN 'OPEN'.

      IF gs_node-isfolder IS NOT INITIAL.
        MESSAGE 'Please select a file!' TYPE 'I'.
        RETURN.
      ENDIF.

      IF gs_node-acc_type EQ zcl_ul_tree_display=>c_node_weblink.
        cl_gui_frontend_services=>execute( EXPORTING document = CONV #( gs_node-programname )
                                           EXCEPTIONS error_execute_failed = 1 bad_parameter = 2 cntl_error = 3
                                                      error_no_gui = 4 file_extension_unknown = 5
                                                      file_not_found = 6 not_supported_by_gui = 7
                                                      path_not_found = 8 synchronous_failed = 9 OTHERS = 10 ).
        CHECK sy-subrc IS NOT INITIAL.
        zcx_ul_handle_errors=>raise_message( ).
      ELSE.
        CALL SCREEN 0402 STARTING AT 10 10.
      ENDIF.

    WHEN 'DELE'.

      IF gs_node-isfolder IS NOT INITIAL.
        MESSAGE 'Please select a file or a link!' TYPE 'I'.
        RETURN.
      ENDIF.

      IF sy-tcode NE 'ZMGT'.
        CHECK zcl_ul_abap=>popup_to_confirm('Confirm to delete this file or link?') = '1'.
      ENDIF.

      TRY .
          IF gs_node-docname IS NOT INITIAL.
            go_file->ar_doi_doc->delete_document( iv_doc_id = gs_node-docname ).
          ENDIF.
        CATCH zcx_ul_handle_errors INTO cx_error.
          " cx_error->show_message( ).
      ENDTRY.
      DELETE ztb_treeload FROM gs_node.
      go_file->ar_tree->delete_nodes( node_key_table = VALUE #( ( gs_node-node_key ) ) ).
      MESSAGE 'The file or link was deleted!' TYPE 'S'.


    WHEN 'INFO'.
      DATA lt_url_info TYPE TABLE OF zcl_ul_doi_usage=>ty_file_info.
      IF gs_node-acc_type = zcl_ul_tree_display=>c_node_weblink.  "URL
        CONVERT TIME STAMP gs_node-created_on TIME ZONE '' INTO DATE DATA(lv_date) TIME DATA(lv_time).
        DATA(lw_time) = |{ lv_date+6(2) }-{ lv_date+4(2) }-{ lv_date(4) } { lv_time(2) }:{ lv_time+2(2) }:{ lv_time+4(2) }|.

        lt_url_info = VALUE #( ( attribute = 'Description' value = gs_node-text )
                               ( attribute = 'URL' value =  gs_node-programname )
                               ( attribute = 'Created By'    value =  gs_node-created_by )
                               ( attribute = 'Created At'    value = lw_time ) ).
        zcl_ul_alv_adapter=>create( EXPORTING iv_popup   = abap_true
                                              it_col_set = VALUE #( ( fieldname = 'ATTRIBUTE' outputlen = 25 ) )
                                    CHANGING  ct_table   = lt_url_info ).
        CLEAR: lv_date,
               lv_time.
      ELSE.
        TRY .
            go_file->ar_doi_doc->show_file_info( iv_doc_id = gs_node-docname ).
          CATCH zcx_ul_handle_errors INTO cx_error.
            cx_error->show_message( ).
        ENDTRY.
      ENDIF.
      " Added by: Tienlv1 on 15.01.2025 12:17:45
      " Content: Add new function fast upload
    WHEN 'FUPLD'.
      PERFORM get_pc_file.
      CHECK gt_file_path IS NOT INITIAL.
      PERFORM upload_file.
      " End
  ENDCASE.

  CLEAR sy-ucomm.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0402  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0402 INPUT.

  CHECK sy-ucomm = 'CLOSE'.
  IF go_file->ar_doi_doc->ar_container IS BOUND.
    go_file->ar_doi_doc->ar_container->free( ).
  ENDIF.
  FREE go_file->ar_doi_doc.
  LEAVE TO SCREEN 0.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0601  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0601 INPUT.

  cl_gui_cfw=>dispatch( ).

  CASE ok_code.
    WHEN 'BACK'.
      o_configure->grid->mine_back_event(  ).
      IF o_configure->zif_configuration~has_parent IS INITIAL.
        o_configure->free( ).
        FREE: o_configure, zcl_ul_dynamic_configuration=>changed_protocol.
        LEAVE TO SCREEN 0.
      ENDIF.
    WHEN 'SAVE'.
      o_configure->save_data( ).
  ENDCASE.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  PAI_0501  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE pai_0501 INPUT.

  CASE sy-ucomm.

    WHEN 'REJECT'.

      DATA icon_release TYPE string.
      DATA t_history TYPE TABLE OF ztb_wf_history.

      CALL FUNCTION 'ICON_CREATE'
        EXPORTING
          name   = icon_set_state
          info   = 'Release'
        IMPORTING
          result = icon_release.

      READ TABLE gt_release_tab ASSIGNING FIELD-SYMBOL(<release_line>) WITH KEY function = icon_release.
      IF sy-subrc IS NOT INITIAL.
        zcx_ul_handle_errors=>raise_message( iv_msg_text = 'No release level exists!' ).
        RETURN.
      ENDIF.

      CONCATENATE gv_objnr <release_line>-frgco INTO gv_objnr.
      DATA(t_wi_status) = zcl_ul_workflow=>get_wi_status( CONV #( gv_objnr ) ).
      TRY.
          DATA(wi_id) = t_wi_status[ wi_type = 'W' ]-wi_id.
        CATCH cx_sy_itab_line_not_found.
          zcx_ul_handle_errors=>raise_message( iv_msg_text = 'No workitem found!' ). RETURN.
      ENDTRY.

      CALL FUNCTION 'SAP_WAPI_DECISION_COMPLETE'
        EXPORTING
          workitem_id  = wi_id
          decision_key = 2.

      DO 5 TIMES.
        t_wi_status = zcl_ul_workflow=>get_wi_status( CONV #( gv_objnr ) ).
        IF t_wi_status[ 1 ]-wi_stat IN zcl_ul_abap=>string_to_range( 'COMPLETED, ERROR, CANCELLED' ) .
          t_history = VALUE #( BASE t_history ( objnr = gv_objnr wi_id = t_wi_status[ 1 ]-wi_id wi_stat = t_wi_status[ 1 ]-wi_stat event_name = 'Rejected' uname = sy-uname utime = zcl_ul_abap=>encode_timestamp( ) frgco_name = <release_line>-frgco_name )
).
          MODIFY ztb_wf_history FROM TABLE t_history.
          EXIT.
        ELSE.
          WAIT UP TO 1 SECONDS.
        ENDIF.
      ENDDO.

      zcl_ul_workflow=>get_rel_tab( EXPORTING objkey = gv_objnr IMPORTING rel_tab = gt_release_tab ).
      grid_rel->refresh_table_display( ).

    WHEN 'HIS'.

      DATA(objnr) = |{ gv_objnr }%|.
      SELECT FROM ztb_wf_history FIELDS * WHERE objnr LIKE @objnr ORDER BY utime INTO CORRESPONDING FIELDS OF TABLE @t_history.
      zcl_ul_alv_adapter=>create( EXPORTING iv_auto_hide = abap_true
                                            iv_popup = abap_true
                                            iv_title = 'Workflow History'
                                            it_col_set = VALUE #( ( fieldname = 'UTIME' reptext = 'Time' col_pos = 1 )
                                                                  ( fieldname = 'FRGCO_NAME' reptext = 'Code Name' col_pos = 2 )
                                                                  ( fieldname = 'UNAME' reptext = 'User Name' col_pos = 3 )
                                                                  ( fieldname = 'EVENT_NAME' reptext = 'Action' col_pos = 4 )
                                                                  ( fieldname = 'WI_STAT' reptext = 'Status' col_pos = 5 ) )
                                  CHANGING ct_table = t_history ).


  ENDCASE.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0502  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0502 INPUT.

  IF sy-ucomm = 'CLOSE'.
    LEAVE TO SCREEN 0.
  ENDIF.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0103  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0103 INPUT.

  DATA c_index TYPE sy-tabix.

  IF sy-ucomm = 'CNL'.
    LEAVE TO SCREEN 0.
  ELSEIF c_index IS INITIAL.
    c_index = go_tree->find_node_key( iv_value = CONV #( gv_search_txt ) ).
  ELSEIF sy-ucomm = 'OK' AND c_index IS NOT INITIAL.
    c_index = go_tree->find_node_key( iv_value = CONV #( gv_search_txt ) iv_index = c_index ).
  ENDIF.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0403  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0403 INPUT.

  IF sy-ucomm = 'CONT' OR sy-ucomm = 'CANC'.
    LEAVE TO SCREEN 0.
  ENDIF.

ENDMODULE.
