class ZZ_FI_EXTENSION2 definition
  public
  final
  create public .

public section.

  interfaces IF_BADI_INTERFACE .
  interfaces IF_EX_ACC_DOCUMENT .

  methods FILL_VALUE_ASSIGNED
    importing
      !IS_SOURCE type ANY
    changing
      !CS_TARGET type ANY .
protected section.
private section.
ENDCLASS.



CLASS ZZ_FI_EXTENSION2 IMPLEMENTATION.


  method FILL_VALUE_ASSIGNED.

  DATA lr_rtti_struc TYPE REF TO cl_abap_structdescr.

   lr_rtti_struc ?= cl_abap_structdescr=>describe_by_data( is_source ).
   LOOP AT lr_rtti_struc->components ASSIGNING FIELD-SYMBOL(<fs_field>).
       ASSIGN COMPONENT <fs_field>-name OF STRUCTURE is_source TO FIELD-SYMBOL(<fv_s>).
         IF <fv_s> IS NOT INITIAL.
           ASSIGN COMPONENT <fs_field>-name OF STRUCTURE cs_target TO FIELD-SYMBOL(<fv_t>).
          IF <fv_t> IS ASSIGNED.
            <fv_t> = <fv_s>.
          ENDIF.
         ENDIF.
     ENDLOOP.
  endmethod.


  METHOD if_ex_acc_document~change.

*    DATA: lv_json TYPE string.
*
*    DATA: ls_hd TYPE acchd,
*          ls_it TYPE accit,
*          ls_fi TYPE accfi.
*
*    SORT: c_accit ASCENDING BY posnr,
*          c_acccr ASCENDING BY posnr,
*          c_accfi ASCENDING BY posnr.
*
*    LOOP AT c_extension2 ASSIGNING FIELD-SYMBOL(<fs_extension2>).
*
*      lv_json = <fs_extension2>.
*      CONDENSE lv_json.
*      DATA(len) = strlen( lv_json ) - 6.
*      lv_json = lv_json+6(len).
*
*      CASE <fs_extension2>-structure.
*
*        WHEN 'ACCHD'.
*          /ui2/cl_json=>deserialize( EXPORTING json = lv_json CHANGING data =  ls_hd  ).
*          fill_value_assigned( EXPORTING is_source = ls_hd  CHANGING cs_target = c_acchd ).
*        WHEN 'ACCIT'.
*          /ui2/cl_json=>deserialize( EXPORTING json = lv_json CHANGING data =  ls_it ).
*          LOOP AT c_accit ASSIGNING FIELD-SYMBOL(<fs_it>) WHERE posnr = ls_it-posnr.
*            fill_value_assigned( EXPORTING is_source = ls_it CHANGING cs_target = <fs_it> ).
*          ENDLOOP.
*        WHEN 'ACCFI'.
*          /ui2/cl_json=>deserialize( EXPORTING json = lv_json CHANGING data =  ls_fi ).
*          LOOP AT c_accfi ASSIGNING FIELD-SYMBOL(<fs_fi>) WHERE posnr = ls_fi-posnr.
*            fill_value_assigned( EXPORTING is_source =  ls_fi CHANGING cs_target = <fs_fi> ).
*          ENDLOOP.
*
*      ENDCASE.
*
*    ENDLOOP.


  ENDMETHOD.


  method IF_EX_ACC_DOCUMENT~FILL_ACCIT.
  endmethod.
ENDCLASS.
