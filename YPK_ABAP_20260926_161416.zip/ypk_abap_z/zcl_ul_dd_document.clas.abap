CLASS zcl_ul_dd_document DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    TYPES:
      BEGIN OF w3index,
        start_first  TYPE i,
        end_first    TYPE i,
        offset_first TYPE i,
        start_len    TYPE i,
        start_last   TYPE i,
        end_last     TYPE i,
        offset_last  TYPE i,
        end_len      TYPE i,
      END OF w3index .
    TYPES:
      w3heads TYPE TABLE OF w3head .

    DATA document TYPE REF TO cl_dd_document .
    DATA dialogbox TYPE REF TO cl_gui_dialogbox_container .
    DATA document_area TYPE REF TO cl_dd_area .

    METHODS constructor
      IMPORTING
        !iv_no_document TYPE boole_d DEFAULT abap_false
        !iv_no_dialog   TYPE boole_d DEFAULT abap_false
        !iv_background  TYPE i DEFAULT cl_dd_document=>col_textarea
        !iv_no_margins  TYPE sdydo_flag DEFAULT abap_false
        !iv_style       TYPE sdydo_attribute OPTIONAL
        !iv_use_jquery  TYPE boole_d OPTIONAL .
    METHODS add_table
      IMPORTING
        !it_table_style TYPE STANDARD TABLE OPTIONAL
        !it_col_header  TYPE ztb_ul_alv_col
      CHANGING
        !ct_table_value TYPE STANDARD TABLE .
    METHODS add_table_static_html
      IMPORTING
        !is_table_attribute TYPE w3html OPTIONAL
        !it_col_header      TYPE w3heads
      CHANGING
        !ct_table_value     TYPE STANDARD TABLE
      RETURNING
        VALUE(rt_html)      TYPE w3htmltab .
    METHODS add_graph
        IMPORTING
        !io_graph TYPE REF TO zcl_abap_graph .
    METHODS show
      IMPORTING
        !io_container TYPE REF TO cl_gui_container OPTIONAL .
    METHODS export_html
      RETURNING
        VALUE(rt_html_table) TYPE sdydo_html_table .
    METHODS change_document_attribute
      IMPORTING
        !iv_attribute TYPE string
        !iv_value     TYPE string .
    METHODS _get_tag_index
      IMPORTING
        !tag         TYPE string
      RETURNING
        VALUE(index) TYPE w3index .
    METHODS insert_html
      IMPORTING
        !iv_section      TYPE string OPTIONAL
        !iv_attributes   TYPE string OPTIONAL
        !iv_insert_index TYPE i OPTIONAL
        !iv_html         TYPE string
        !iv_force_last   TYPE boole_d OPTIONAL .
    METHODS insert_jquery_func
      IMPORTING
        !iv_function TYPE string .
  PROTECTED SECTION.
  PRIVATE SECTION.

    METHODS _handle_close
        FOR EVENT close OF cl_gui_dialogbox_container .
    METHODS _get_area_html .
    METHODS _insert_jquery_cdn .
ENDCLASS.



CLASS zcl_ul_dd_document IMPLEMENTATION.


  METHOD add_table.

    DATA: table   TYPE REF TO cl_dd_table_element,
          columns TYPE REF TO zcl_ul_alv_adapter,
          column  TYPE REF TO cl_dd_area,
          col_pos TYPE i.

    DATA: BEGIN OF s_column,
            col_name TYPE lvc_fname,
            col_obj  TYPE REF TO cl_dd_area,
          END OF s_column.

    DATA: t_column LIKE TABLE OF s_column.

    CREATE OBJECT columns.
    columns->lvc_fcat_from_itab( CHANGING ct_table = ct_table_value ).
    DATA(t_col) = columns->t_fcat.
    SORT t_col ASCENDING BY col_pos.

    document->add_table( EXPORTING  no_of_columns = lines( t_col )
                                    width         = '100%'
                                    with_heading  = abap_true
                                    cell_background_transparent = space
                         IMPORTING  table         = table  ).

    LOOP AT t_col ASSIGNING FIELD-SYMBOL(<fs_col>).
      CLEAR s_column.
      s_column-col_name = <fs_col>-fieldname.
      table->add_column(  EXPORTING heading = COND #( WHEN it_col_header IS INITIAL THEN <fs_col>-reptext
                                                      ELSE it_col_header[ fieldname = <fs_col>-fieldname ]-coltext )
                          IMPORTING column = s_column-col_obj ).
      table->set_column_style( EXPORTING col_no = <fs_col>-col_pos
                                         sap_color    = COND #( WHEN <fs_col>-key = abap_true THEN cl_dd_area=>list_key ELSE cl_dd_area=>col_textarea ) ).
      APPEND s_column TO t_column.
    ENDLOOP.

    LOOP AT ct_table_value ASSIGNING FIELD-SYMBOL(<fs_value>).
*      IF sy-tabix > 1.
      table->new_row( ).
*      ENDIF.
      LOOP AT t_col ASSIGNING <fs_col>.
        s_column = t_column[ col_name = <fs_col>-fieldname ].
        ASSIGN COMPONENT s_column-col_name OF STRUCTURE <fs_value> TO FIELD-SYMBOL(<val>).
        s_column-col_obj->add_text( text = CONV #( <val> ) ).
      ENDLOOP.
    ENDLOOP.


  ENDMETHOD.


  METHOD add_table_static_html.

    DATA t_fields TYPE TABLE OF w3fields. "Dummy

    CALL FUNCTION 'WWW_ITAB_TO_HTML'
      EXPORTING
        table_attributes = is_table_attribute
      TABLES
        itable           = ct_table_value
        row_header       = it_col_header
        fields           = t_fields
        html             = rt_html.

    CHECK rt_html IS NOT INITIAL.
    document->add_static_html( table_with_html = rt_html ).


  ENDMETHOD.


  METHOD change_document_attribute.

    _get_area_html(  ).
    FIND iv_attribute IN TABLE document_area->html_table RESPECTING CASE
    RESULTS DATA(attribute) IN CHARACTER MODE.

    IF sy-subrc IS INITIAL.
      READ TABLE document_area->html_table ASSIGNING FIELD-SYMBOL(<fs_html>) INDEX attribute-line.
      DATA(off_start) = attribute-length +  attribute-offset + 1.
      FIND FIRST OCCURRENCE OF REGEX '[";]' IN <fs_html>+off_start MATCH OFFSET DATA(off_len).
      REPLACE FIRST OCCURRENCE OF <fs_html>+off_start(off_len) IN <fs_html>+off_start WITH iv_value.
    ELSE.
      zcx_ul_handle_errors=>raise_message( iv_msg_text = |Attribute { iv_attribute } does not exist!| ).
    ENDIF.

  ENDMETHOD.


  METHOD constructor.

    IF iv_no_dialog IS INITIAL.
      CREATE OBJECT dialogbox EXPORTING width = 1200 height = 300 top = 50 left = 100.
      SET HANDLER _handle_close FOR dialogbox.
    ENDIF.

    IF iv_no_document IS INITIAL.
      CREATE OBJECT document EXPORTING background_color = iv_background no_margins = iv_no_margins style = iv_style.
      CHECK iv_use_jquery EQ abap_true.
      _insert_jquery_cdn( ).
    ENDIF.

  ENDMETHOD.


  METHOD export_html.

    _get_area_html(  ).
    rt_html_table = document_area->html_table.

  ENDMETHOD.


  METHOD insert_html.

    DATA(index) = _get_tag_index( iv_section )-end_last.
    IF iv_insert_index IS NOT INITIAL.
      index = iv_insert_index.
    ELSEIF iv_force_last = abap_true OR index IS INITIAL.
      index = lines( document->html_table ).
    ENDIF.

    IF iv_section IS NOT INITIAL.
      DATA(html) = |<{ iv_section }|.
      IF iv_attributes IS NOT INITIAL.
        html = |{ html } { iv_attributes }|.
      ENDIF.
      html = |{ html }> { iv_html } </{ iv_section }>|.
    ELSE.
      html = iv_html.
    ENDIF.

    index = index + 1.
    insert_html document->html_table html index.

  ENDMETHOD.


  METHOD insert_jquery_func.

    FIND 'End of funcs code' IN TABLE document->html_table IGNORING CASE MATCH LINE DATA(index).

    CHECK sy-subrc IS INITIAL.
    insert_html( iv_html = iv_function iv_insert_index = index - 1 ).

  ENDMETHOD.


  METHOD show.

    _get_area_html(  ).
    IF io_container IS NOT BOUND.
      document->display_document( EXPORTING parent = dialogbox ).
    ELSE.
      document->display_document( EXPORTING parent = io_container ).
    ENDIF.

  ENDMETHOD.


  METHOD _get_area_html.

    CHECK document_area IS NOT BOUND.
    document->merge_document(  ).
    document_area ?= document.

  ENDMETHOD.


  METHOD _get_tag_index.

    DATA(begin_tab) = |<{ tag }|.
    DATA(end_tab)   = |/{ tag }>|.

    FIND ALL OCCURRENCES OF begin_tab IN TABLE document->html_table IGNORING CASE RESULTS DATA(results).

    CHECK sy-subrc IS INITIAL.
    DATA(rows) = lines( results ).
    DATA(result) = results[ 1 ].
    index-start_first = result-line.
    index-offset_first = result-offset.
    index-start_len = result-length.
    IF rows > 1.
      result = results[ rows ].
      index-start_last  = result-line.
    ELSE.
      index-start_last  = result-line.
    ENDIF.

    FIND ALL OCCURRENCES OF end_tab IN TABLE document->html_table IGNORING CASE RESULTS results.
    CHECK sy-subrc IS INITIAL.
    rows = lines( results ).
    result = results[ 1 ].
    index-end_first = result-line.
    index-end_len = result-length.
    IF rows > 1.
      result = results[ rows ].
      index-end_last  = result-line.
      index-offset_last = result-offset.
    ELSE.
      index-end_last  = result-line.
      index-offset_last = result-offset.
    ENDIF.

  ENDMETHOD.


  METHOD _handle_close.

    dialogbox->free( ).
    FREE dialogbox.
    cl_gui_cfw=>flush( ).

  ENDMETHOD.


  METHOD _insert_jquery_cdn.

    DATA(index) = _get_tag_index( `style` ).
    READ TABLE document->html_table ASSIGNING FIELD-SYMBOL(<html>) INDEX index-end_last.
    DATA(offset) = index-offset_last + index-end_len.
    <html>+offset = space.
    insert_html( iv_html = `<script language="JavaScript">` iv_insert_index = index-end_last ).

    index = _get_tag_index( `head` ).
    DELETE document->html_table INDEX index-end_last + 1.
    READ TABLE document->html_table ASSIGNING <html> INDEX index-end_last.
    offset = index-offset_last - 1.
    <html>+offset = space.

    insert_html( iv_html = `<body>` iv_insert_index = index-end_last + 1 ).
    insert_html( iv_html = `</head>` iv_insert_index = index-end_last + 1 ).
    insert_html( iv_html = |<script |
                         && |src="https://code.jquery.com/jquery-3.6.1.min.js">|
                         && |</script> |
                 iv_insert_index = index-end_last + 1  ).
    insert_html( iv_html = |<script> $(document).ready(function() \{ | iv_insert_index = index-end_last + 2 ).
    insert_html( iv_html = |<!-- Start of funcs code -->| iv_insert_index = index-end_last + 3 ).
    insert_html( iv_html = |<!-- End of funcs code -->| iv_insert_index = index-end_last + 4 ).
    insert_html( iv_html = |\});| iv_insert_index = index-end_last + 5 ).
    insert_html( iv_html = |</script>| iv_insert_index = index-end_last + 6 ).

  ENDMETHOD.

  METHOD add_graph.

  ENDMETHOD.

ENDCLASS.
