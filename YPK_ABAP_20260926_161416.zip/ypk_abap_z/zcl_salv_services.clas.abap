CLASS zcl_salv_services DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    DATA mo_salv_table TYPE REF TO cl_salv_table .
    DATA cx_error TYPE REF TO zcx_ul_handle_errors .
    DATA mo_salv_columns TYPE REF TO cl_salv_columns_table .
    DATA mo_salv_aggregation TYPE REF TO cl_salv_aggregations .
    DATA mt_fcat_att TYPE lvc_t_fcat .
    DATA mo_container TYPE REF TO cl_gui_container .

    METHODS general_services
      IMPORTING
        !iv_list           TYPE sap_bool OPTIONAL
        !iv_title          TYPE lvc_title OPTIONAL
        !iv_layout         TYPE slis_vari DEFAULT 'X'
        !iv_optimized      TYPE sap_bool DEFAULT 'X'
        !iv_key_fix        TYPE sap_bool OPTIONAL
        !it_table_setting  TYPE ztb_alv_settings OPTIONAL
        !iv_selection_mode TYPE i OPTIONAL
        !iv_color          TYPE lvc_fname OPTIONAL
        !iv_container      TYPE c OPTIONAL
      CHANGING
        !co_container      TYPE REF TO cl_gui_container OPTIONAL
        !ct_table          TYPE table .
  PROTECTED SECTION.
  PRIVATE SECTION.

    DATA r_table TYPE REF TO data .
    DATA mt_hide_fileds TYPE lvc_t_fcat .

    METHODS columns_setting
      IMPORTING
        !iv_columnname TYPE lvc_fname
        !ir_columns    TYPE REF TO cl_salv_columns_table OPTIONAL
        !iv_checkbox   TYPE sap_bool OPTIONAL
        !iv_hostpot    TYPE sap_bool OPTIONAL
        !iv_hide       TYPE sap_bool OPTIONAL
        !iv_currency   TYPE lvc_curr OPTIONAL
        !iv_short      TYPE scrtext_s OPTIONAL
        !iv_medium     TYPE scrtext_m OPTIONAL
        !iv_long       TYPE scrtext_l OPTIONAL
        !iv_icon       TYPE sap_bool OPTIONAL
        !iv_tooltip    TYPE lvc_tip OPTIONAL
        !iv_lenght     TYPE lvc_outlen OPTIONAL
        !iv_position   TYPE i OPTIONAL
        !iv_exception  TYPE sap_bool
        !is_color      TYPE lvc_s_scol OPTIONAL .
    METHODS sort_setting
      IMPORTING
        !iv_sequence   TYPE salv_de_sort_sequence DEFAULT if_salv_c_sort=>sort_up
        !iv_obligatory TYPE sap_bool OPTIONAL
        !iv_group      TYPE salv_de_sort_group DEFAULT if_salv_c_sort=>group_none
        !iv_columnname TYPE lvc_fname OPTIONAL
        !iv_compress   TYPE sap_bool OPTIONAL
        !iv_position   TYPE i OPTIONAL
        !iv_subtotal   TYPE sap_bool OPTIONAL .
    METHODS error_reporting .
    METHODS on_double_click
          FOR EVENT double_click OF cl_salv_events_table
      IMPORTING
          !row
          !column .
ENDCLASS.



CLASS zcl_salv_services IMPLEMENTATION.


  METHOD columns_setting.

    DATA: lo_column TYPE REF TO cl_salv_column_table,
          lo_col    TYPE REF TO cl_salv_column,
          lo_aggrs  TYPE REF TO cl_salv_aggregations,
          lo_aggr   TYPE REF TO cl_salv_aggregation.

    TRY .
        lo_column ?= ir_columns->get_column( columnname = iv_columnname ).

        " Set lenght
        lo_column->set_output_length( iv_lenght ).

        " Set position
        ir_columns->set_column_position(  columnname = iv_columnname
                                          position   = iv_position ).

        " set icon
        lo_column->set_icon( iv_icon ).

        " Set currency
        lo_column->set_currency( iv_currency ).

        " Set description
        IF iv_short IS NOT INITIAL OR iv_medium IS NOT INITIAL OR iv_long IS NOT INITIAL.
          lo_column->set_short_text( iv_short ).
          lo_column->set_medium_text( iv_medium ).
          lo_column->set_long_text( iv_long ).
        ENDIF.

        " Set tooltip
        lo_column->set_tooltip( iv_tooltip ).

        " Set column type
        IF iv_checkbox IS NOT INITIAL .
          lo_column->set_cell_type(  if_salv_c_cell_type=>checkbox_hotspot ).
        ELSEIF iv_hostpot IS NOT INITIAL.
          lo_column->set_cell_type( if_salv_c_cell_type=>hotspot ).
        ENDIF.

        " Set exception: usage for exception with usage icon 1 or 2 ).
        IF iv_exception IS NOT INITIAL.
          ir_columns->set_exception_column( iv_columnname ).
        ENDIF.

        " Set color fill structure: is_color-fname for cell color other whole column
        "                           is_color-color-col = col_group .
        "                           is_color-color-int = 1.
        " Declare table type lvc_t_scol in final table
        IF is_color IS NOT INITIAL.
          ir_columns->set_color_column( iv_columnname ).
          lo_column->set_color( is_color-color ).
        ENDIF.

        " Set icon: Usage for column with icon type.
        IF iv_icon IS NOT INITIAL.
          lo_column->set_icon( ).
        ENDIF.

      CATCH: cx_salv_not_found,
             cx_salv_data_error
             INTO DATA(eo_col_error).
        cx_error->add_exception_object( eo_col_error ).
        cx_error->show_message( ).

    ENDTRY.
  ENDMETHOD.


  METHOD error_reporting.
*    DATA(ls_message) = mo_salv_error->get_message( ).
*
*    MESSAGE ID     ls_message-msgid
*            TYPE   'I'
*            NUMBER ls_message-msgno
*            WITH   ls_message-msgv1
*                   ls_message-msgv2
*                   ls_message-msgv3
*                   ls_message-msgv4.
  ENDMETHOD.


  METHOD general_services.

    DATA lo_column TYPE REF TO cl_salv_column_table.

    " If container used?
    IF iv_container IS NOT INITIAL AND co_container IS NOT BOUND.
      DATA(lo_cont) = NEW cl_gui_custom_container( container_name = iv_container ).
      mo_container = lo_cont.
    ELSEIF co_container IS BOUND.
      mo_container = co_container.
    ELSE.
      mo_container = cl_gui_container=>screen1.
    ENDIF.

    " Create object cx_error
    CREATE OBJECT cx_error.

    " Factory method
    TRY.
        cl_salv_table=>factory(
                    EXPORTING
                      list_display   = iv_list
                      r_container    = mo_container
                    IMPORTING
                      r_salv_table   = mo_salv_table
                    CHANGING
                      t_table        = ct_table ).

      CATCH cx_salv_msg INTO DATA(eo_salv_msg).
        cx_error->add_exception_object( eo_salv_msg ).
        cx_error->show_message( ).
        RETURN.

    ENDTRY.

    TRY.
        " Get instance of must-have object
        DATA lv_index TYPE i.
        mo_salv_columns = mo_salv_table->get_columns( ).
        mo_salv_aggregation = mo_salv_table->get_aggregations( ).
        mt_fcat_att = cl_salv_controller_metadata=>get_lvc_fieldcatalog( r_columns = mo_salv_columns r_aggregations = mo_salv_aggregation ).

        " Set auto-hided columns not be mentioned
        LOOP AT mt_fcat_att ASSIGNING FIELD-SYMBOL(<fs_fcat_att>).
          IF it_table_setting IS NOT INITIAL.
            IF line_exists( it_table_setting[ columnname = <fs_fcat_att>-fieldname ] ).
              CONTINUE.
            ELSE.
              APPEND <fs_fcat_att> TO mt_hide_fileds.
            ENDIF.
          ELSE.
            IF <fs_fcat_att>-fieldname = 'MANDT'.
              APPEND <fs_fcat_att> TO mt_hide_fileds.
              EXIT.
            ENDIF.
          ENDIF.
        ENDLOOP.

        LOOP AT mt_hide_fileds ASSIGNING FIELD-SYMBOL(<fs_hide>).
          lo_column ?= mo_salv_columns->get_column( columnname = <fs_hide>-fieldname ).
          lo_column->set_technical( 'X' ).
        ENDLOOP.


        " For general columns setting
        mo_salv_columns->set_optimize( iv_optimized ).
        mo_salv_columns->set_key_fixation( iv_key_fix ).
        IF iv_color IS NOT INITIAL.
          mo_salv_columns->set_color_column( iv_color ).
        ENDIF.

        " For specific columns setting
        LOOP AT it_table_setting ASSIGNING FIELD-SYMBOL(<fs_columns>) WHERE columnname IS NOT INITIAL.

          lv_index = lv_index + 1.

          " Set column setting
          columns_setting(   ir_columns    = mo_salv_columns
                             iv_columnname = <fs_columns>-columnname
                             iv_position   = lv_index
                             iv_lenght     = <fs_columns>-lenght
                             iv_short      = <fs_columns>-short_desc
                             iv_medium     = <fs_columns>-medium_desc
                             iv_long       = <fs_columns>-long_desc
                             iv_tooltip    = <fs_columns>-tooltip
                             iv_checkbox   = <fs_columns>-checkbox
                             iv_hostpot    = <fs_columns>-hostpost
                             iv_currency   = <fs_columns>-currency
                             iv_icon       = <fs_columns>-icon
                             iv_exception  = <fs_columns>-exception ).

          " Set sort setting
          IF <fs_columns>-sequence IS NOT INITIAL.
            sort_setting(  iv_columnname = <fs_columns>-columnname
                           iv_sequence   = <fs_columns>-sequence
                           iv_compress   = <fs_columns>-compress_subtotal
                           iv_group      = <fs_columns>-group
                           iv_obligatory = <fs_columns>-obligatory
                           iv_subtotal   = <fs_columns>-subtotal ).

          ENDIF.

          " Set total column
          IF <fs_columns>-total IS NOT INITIAL.
            mo_salv_aggregation->add_aggregation( columnname = <fs_columns>-columnname
                                                  aggregation = if_salv_c_aggregation=>total ).
          ENDIF.

        ENDLOOP.

        " Set selection
        IF iv_selection_mode IS NOT INITIAL.
          DATA(lo_selection) = mo_salv_table->get_selections( ).
          lo_selection->set_selection_mode( iv_selection_mode ).
        ENDIF.

        " Set layout
        IF iv_layout IS NOT INITIAL.
          DATA ls_key TYPE salv_s_layout_key.
          DATA(lo_layout) = mo_salv_table->get_layout( ).
          ls_key-report = sy-cprog.
          lo_layout->set_key( ls_key ).
          lo_layout->set_save_restriction( if_salv_c_layout=>restrict_none ).
          lo_layout->set_default( 'X' ).
          lo_layout->set_initial_layout( iv_layout ).
        ENDIF.

        " Set function
        mo_salv_table->get_functions( )->set_all( 'X' ).

        " Set display
        mo_salv_table->get_display_settings( )->set_list_header( iv_title ).

        " Set print
        DATA(lo_print) = mo_salv_table->get_print( ).
        lo_print->set_selectioninfo_on( 'X' ).
        lo_print->set_coverpage_on( 'X' ).
        lo_print->set_report_standard_header_on( 'X' ).

        " Fill some data for usage
        CREATE DATA r_table LIKE ct_table.
        ASSIGN r_table->* TO FIELD-SYMBOL(<ft_table>).
        <ft_table> = ct_table.
        " Auto set default useful double click function
        DATA(lo_event) = mo_salv_table->get_event( ).
        SET HANDLER me->on_double_click FOR lo_event.

        " Get report errors
      CATCH: cx_salv_not_found,
             cx_salv_existing
             cx_salv_data_error
             INTO DATA(eo_salv_error).
        cx_error->add_exception_object( eo_salv_error ).
        cx_error->show_message( ).
        RETURN.

    ENDTRY.

    mo_salv_table->display( ).

  ENDMETHOD.


  METHOD on_double_click.

    DATA: ls_dfies    TYPE dfies.
    DATA: ls_rseumod  TYPE rseumod.
    DATA: ld_timestmp TYPE cest1-timestmp.
    DATA: ld_date     TYPE sy-datum.
    DATA: ld_time     TYPE sy-uzeit.
    DATA: ls_detail TYPE se16n_selfields,
          lt_detail LIKE TABLE OF ls_detail.
    FIELD-SYMBOLS: <f>       TYPE any,
                   <g>       TYPE any,
                   <ft_data> TYPE STANDARD TABLE,           "1424238
                   <fs_data> TYPE any.

    ASSIGN r_table->* TO <ft_data>.

    DATA(lo_selection) = mo_salv_table->get_selections( ).
    DATA(lt_row) = lo_selection->get_selected_rows( ).

    READ TABLE <ft_data> ASSIGNING <fs_data> INDEX lt_row[ 1 ].

    CHECK: sy-subrc = 0.
    REFRESH lt_detail.

    LOOP AT mt_fcat_att ASSIGNING FIELD-SYMBOL(<fs_fieldcat>).
      CLEAR: ls_detail.
      ls_detail-scrtext_l = <fs_fieldcat>-reptext.
      ASSIGN COMPONENT <fs_fieldcat>-fieldname OF STRUCTURE <fs_data>
                       TO <f>.
      ls_detail-fieldname = <fs_fieldcat>-fieldname.
      ls_detail-tabname   = <fs_fieldcat>-ref_table.

      IF ls_dfies-datatype = 'CURR' AND
         ls_dfies-tabname = ls_dfies-reftable.
        ASSIGN COMPONENT ls_dfies-reffield OF STRUCTURE <fs_data>
                         TO <g>.
        WRITE <f> TO ls_detail-low CURRENCY <g> LEFT-JUSTIFIED.
      ELSE.

        IF ls_dfies-domname = 'RKE_TSTMP'.
          ld_timestmp = <f>.
          CALL FUNCTION 'RKE_TIMESTAMP_CONVERT_OUTPUT'
            EXPORTING
              i_dayst    = sy-dayst
              i_timestmp = ld_timestmp
              i_tzone    = sy-tzone
            IMPORTING
              e_date     = ld_date
              e_time     = ld_time.

          WRITE ld_date TO ls_detail-low(10).
          WRITE ld_time TO ls_detail-low+12(8).
        ELSE.
          WRITE <f> TO ls_detail-low LEFT-JUSTIFIED.
        ENDIF.
      ENDIF.

      SELECT SINGLE * FROM rseumod INTO ls_rseumod
                    WHERE uname = sy-uname.
      IF sy-subrc             = 0 AND
         ls_rseumod-tbconvert = 'X'.
        ls_detail-low_noconv = ls_detail-low.
      ELSE.
        ls_detail-low_noconv = <f>.
        SHIFT ls_detail-low_noconv LEFT DELETING LEADING space.
      ENDIF.
      APPEND ls_detail TO lt_detail.
    ENDLOOP.

    CALL FUNCTION 'TSWUSL_SHOW_DETAIL'
      TABLES
        it_selfields = lt_detail.

    IF sy-ucomm = 'CANC' OR sy-ucomm = 'ENTER'.
      RETURN.
    ENDIF.

  ENDMETHOD.


  METHOD sort_setting.

    DATA(lo_sort) = mo_salv_table->get_sorts( ).

    TRY .
        lo_sort->add_sort(
            columnname = iv_columnname
            position   = iv_position
            sequence   = iv_sequence
            subtotal   = iv_subtotal
            group      = iv_group  " 1-group with detail, 2-group only
            obligatory = iv_obligatory
            ).
        IF iv_compress IS NOT INITIAL.
          lo_sort->set_compressed_subtotal( iv_columnname ).
        ENDIF.

      CATCH: cx_salv_not_found,
             cx_salv_data_error,
             cx_salv_existing
             INTO DATA(eo_sort_error).
        cx_error->add_exception_object( eo_sort_error ).
        cx_error->show_message( ).

    ENDTRY.

  ENDMETHOD.
ENDCLASS.
