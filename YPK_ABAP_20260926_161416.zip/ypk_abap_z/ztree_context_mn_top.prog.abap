*&---------------------------------------------------------------------*
*&  Include           ZTREE_CONTEXT_MN_TOP
*&---------------------------------------------------------------------*
TABLES: ztb_treeload.

DATA: ok_code    TYPE sy-ucomm,
      fcode      TYPE sy-ucomm,
      node_key   TYPE tv_nodekey,
      menu       TYPE ztb_treeload-modulelo,
      tree_node  TYPE ztb_treeload,
      tree_nodes TYPE STANDARD TABLE OF ztb_treeload.

DATA: _tree TYPE REF TO zcl_ul_tree_display.
