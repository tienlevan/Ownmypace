
CLASS lcl_dragdropobject DEFINITION.
  PUBLIC SECTION.
    DATA: src_node_key TYPE tv_nodekey.
ENDCLASS.
