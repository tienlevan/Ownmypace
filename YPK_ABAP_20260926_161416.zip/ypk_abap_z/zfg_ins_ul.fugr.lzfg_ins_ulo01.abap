*----------------------------------------------------------------------*
***INCLUDE LZFG_INS_ULO01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_0101  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0101 OUTPUT.

  SET PF-STATUS 'MS101'.
  SET TITLEBAR  'MS101'.

  " Set value: style
  zcl_ul_tree_display=>build_acc_type( ).

  " Initial value
  IF ( fcode = 'XNODE' OR fcode = 'XITEM' ) AND tree_node IS INITIAL.
    SELECT SINGLE FROM ztb_treeload
      FIELDS * WHERE node_key = @node_key AND modulelo = @menu
      INTO CORRESPONDING FIELDS OF @tree_node.
    IF tree_node IS NOT INITIAL.
      ztb_treeload = CORRESPONDING #( tree_node ).
      IF ztb_treeload-programname IS INITIAL AND ztb_treeload-docname IS NOT INITIAL.
        ztb_treeload-programname = ztb_treeload-docname.
      ENDIF.
    ENDIF.

  ENDIF.

  " Valid screen
  LOOP AT SCREEN.

    IF ( screen-name = 'ZTB_TREELOAD-ACC_TYPE' OR screen-name = 'ZTB_TREELOAD-PROGRAMNAME'
        OR screen-name = 'ACESS_TYPE' OR screen-name = 'ACCESS_ID' )
    AND ( ( fcode = 'CNODE' OR fcode ='XNODE' ) OR ztb_treeload-acc_type EQ zcl_ul_tree_display=>c_node_code ).
      screen-active = 0.
    ENDIF.

    IF screen-name = 'ZTB_TREELOAD-N_IMAGE'
    AND ( ( ( fcode = 'CITEM' OR fcode ='XITEM' ) AND ( ztb_treeload-acc_type EQ zcl_ul_tree_display=>c_node_doc
    OR ztb_treeload-acc_type EQ zcl_ul_tree_display=>c_node_code ) ) ).
      screen-active = 0.
    ENDIF.

    IF screen-name = 'ZTB_TREELOAD-DOCTYPE' AND ztb_treeload-acc_type NE zcl_ul_tree_display=>c_node_doc .
      screen-active = 0.
    ENDIF.

    IF ( screen-name = 'ZTB_TREELOAD-ACC_TYPE' OR screen-name = 'ZTB_TREELOAD-PROGRAMNAME' ) AND ztb_treeload-acc_type EQ zcl_ul_tree_display=>c_node_doc.
      screen-input = 0.
    ENDIF.

    MODIFY SCREEN.

  ENDLOOP.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  STATUS_0102  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0102 OUTPUT.

  SET PF-STATUS 'MS102'.
  SET TITLEBAR  'MS102'.

  " Set support office doc creation
  DATA(lt_drog_val) = VALUE vrm_values( ( key = 'DOCX' text = 'MS Word' )
                                        ( key = 'XLSX' text = 'MS Excel' )
                                        ( key = 'PPTX' text = 'MS PowerPoint' )
                                        ( key = 'VSD'  text = 'MS Visio' )
                                        ( key = 'TXT'  text = 'Text' ) ).
  CALL FUNCTION 'VRM_SET_VALUES'
    EXPORTING
      id     = 'ZTB_TREELOAD-DOCTYPE'
      values = lt_drog_val.

  zcl_ul_abap=>set_dynpro_drop( iv_id     = 'FILE_METH'
                                it_values = VALUE #( ( key = 'CNEW' text = 'Create Document' )
                                                     ( key = 'UPLD' text = 'Upload Document' )
                                                     ( key = 'LINK' text = 'Link Document' ) ) ).


ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  GET_FILE  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE get_file INPUT.

  DATA lv_rc         TYPE i.

  cl_gui_frontend_services=>file_open_dialog( EXPORTING window_title      = 'Select files'
                                                        initial_directory = initial_path
                                                        multiselection    = abap_true
                                              CHANGING  file_table        = gt_file_path
                                                        rc                = lv_rc ).

  IF gt_file_path IS INITIAL.
    MESSAGE 'No file was selected!' TYPE 'I'. RETURN.
  ENDIF.


  LOOP AT gt_file_path INTO DATA(gs_file_path).
    IF lines( gt_file_path ) = 1.
      file_path = gs_file_path-filename.
    ELSE.
      file_path = SWITCH #( sy-tabix WHEN 1 THEN |"{ gs_file_path-filename }"| ELSE |{ file_path } "{ gs_file_path-filename }"| ).
    ENDIF.
    FIND ALL OCCURRENCES OF '\' IN gs_file_path-filename RESULTS DATA(t_result).
    CHECK t_result IS NOT INITIAL.
    SORT t_result DESCENDING BY offset.
    DATA(offset) = t_result[ 1 ]-offset.
    initial_path = gs_file_path-filename(offset).
  ENDLOOP.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  MODIFY_SCREEN  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE modify_screen OUTPUT.

  LOOP AT SCREEN.

    CASE file_meth.
      WHEN 'CNEW'.
        IF screen-group1 NE 'FUL'.
          screen-active = 0.
        ENDIF.
      WHEN 'UPLD'.
        IF screen-group1 NE 'UPL'.
          screen-active = 0.
        ENDIF.
      WHEN 'LINK'.
        IF screen-group1 NE 'LNK' AND screen-group2 NE 'LNK'.
          screen-active = 0.
        ENDIF.
      WHEN OTHERS.
        IF screen-group1 NE 'MTH'.
          screen-active = 0.
        ENDIF.
    ENDCASE.

    IF screen-group1 EQ 'MTH'.
      screen-active = 1.
    ENDIF.

    MODIFY SCREEN.

  ENDLOOP.

ENDMODULE.
*&---------------------------------------------------------------------*
*& Module STATUS_0301 OUTPUT
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
MODULE status_0301 OUTPUT.

  SET PF-STATUS 'ZST_0301'.
  SET TITLEBAR  'TITLE' WITH gv_title.

  IF go_alv IS NOT BOUND.

    IF sy-batch IS INITIAL.
      DATA(splitter)  = NEW cl_gui_splitter_container( parent = cl_gui_container=>screen0 rows = 2 columns = 1 ).
      DATA(cont_header) = splitter->get_container( row = 1 column = 1 ).
      DATA(cont_alv) = splitter->get_container( row = 2 column = 1 ).
      DATA(cont_log) = splitter->get_container( row = 3 column = 1 ).
      splitter->set_row_height( id = 1 height = 0 ).
      splitter->set_row_height( id = 3 height = 0 ).
      splitter->set_row_sash( id = 1 type = cl_gui_splitter_container=>type_sashvisible value = cl_gui_splitter_container=>false ).
      splitter->set_row_sash( id = 3 type = cl_gui_splitter_container=>type_sashvisible value = cl_gui_splitter_container=>false ).
    ENDIF.

    IF gr_class IS BOUND.
      DATA lo_local TYPE REF TO object.
      DATA(lv_sublcass_abs_name) = gr_class->absolute_name.
      CREATE OBJECT lo_local TYPE (lv_sublcass_abs_name)
        EXPORTING
          io_parent   = cont_alv
          io_log      = cont_log.

      go_alv ?= lo_local.
    ELSE.
      go_alv = zcl_ul_alv_adapter=>create( io_parent = cont_alv io_log = cont_log ).
    ENDIF.

    " External use alv object
    zcl_ul_alv_adapter=>o_grid = go_alv.
    go_alv->parent->set_visible( '1' ).
    zcl_ul_alv_adapter=>o_grid->o_splitter = splitter.
    gt_alv = VALUE #( BASE gt_alv ( index = lines( gt_alv ) + 1 alv = go_alv ) ).

    IF gt_tool_add IS NOT INITIAL.
      go_alv->t_toolbar_add = gt_tool_add.
    ENDIF.

    IF gs_layout IS NOT INITIAL.
      go_alv->s_layout = gs_layout.
    ENDIF.

    IF gv_title IS NOT INITIAL.
      go_alv->v_title = gv_title.
    ENDIF.

    IF gt_dropval IS NOT INITIAL.
      go_alv->set_drop_down_table( it_drop_down = gt_dropval ).
    ENDIF.

    ASSIGN gr_data->* TO <ft_table>.
    go_alv->t_sort = gt_sort.
    CHECK <ft_table> IS ASSIGNED.
    TRY.
        go_alv->display( EXPORTING iv_tabname   = gv_tabname
                                   it_col_set   = gt_col_set
                                   iv_auto_hide = gv_autohide
                                   iv_input     = gv_input
                                   it_hyperlinks = gt_hyperlinks
                         CHANGING  ct_data      = <ft_table> ).
      CATCH zcx_ul_handle_errors INTO DATA(cx_error).
        cx_error->show_message( ).
    ENDTRY.

  ELSE.

    go_alv->refresh_table_display( ).

  ENDIF.

ENDMODULE.
*&---------------------------------------------------------------------*
*& Module STATUS_0302 OUTPUT
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
MODULE status_0302 OUTPUT.

  SET TITLEBAR  'ZTT_0302' WITH gv_title.

  go_parent = CAST #( NEW cl_gui_custom_container( container_name = zcl_ul_alv_adapter=>cv_ccname ) ).
  IF gr_class IS BOUND.
    lv_sublcass_abs_name = gr_class->absolute_name.
    CREATE OBJECT lo_local TYPE (lv_sublcass_abs_name)
      EXPORTING
        io_parent   = go_parent.
    go_alv ?= lo_local.
  ELSE.
    go_alv = zcl_ul_alv_adapter=>create( io_parent = go_parent ).
  ENDIF.

  " External use alv object
  zcl_ul_alv_adapter=>o_grid = go_alv.
  gt_alv = VALUE #( BASE gt_alv ( index = lines( gt_alv ) + 1 alv = go_alv ) ).
  DATA(object) = cl_abap_classdescr=>describe_by_object_ref( go_alv ).
  IF object->absolute_name CS 'CLASS-POOL=ZCX_UL_HANDLE_ERRORS'.
    SET PF-STATUS 'ZST_0302'.
  ELSE.
    SET PF-STATUS 'ZST_0302' EXCLUDING 'SUPPORT'.
  ENDIF.

  IF gt_tool_add IS NOT INITIAL.
    go_alv->t_toolbar_add = gt_tool_add.
  ENDIF.

  ASSIGN gr_data->* TO <ft_table>.
  go_alv->t_sort = gt_sort.
  CHECK <ft_table> IS ASSIGNED.
  go_alv->s_layout = gs_layout.
  IF gt_dropval IS NOT INITIAL.
    go_alv->set_drop_down_table( it_drop_down = gt_dropval ).
  ENDIF.
  TRY.
      go_alv->display( EXPORTING iv_tabname   = gv_tabname
                                 it_col_set   = gt_col_set
                                 iv_auto_hide = gv_autohide
                                 it_hyperlinks = gt_hyperlinks
                       CHANGING  ct_data      = <ft_table> ).
      go_alv->set_ready_for_input( gv_input ).
    CATCH zcx_ul_handle_errors INTO cx_error.
      cx_error->show_message( ).
  ENDTRY.
*  ENDIF.


ENDMODULE.
*&---------------------------------------------------------------------*
*& Module STATUS_0401 OUTPUT
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
MODULE status_0401 OUTPUT.

  CHECK gv_supplied IS NOT INITIAL.

  " Check exists memu
  IF gv_key IS INITIAL.
    MESSAGE 'Please save the data first!' TYPE 'I'.
    RETURN.
  ENDIF.

  CLEAR gv_exist.
  SELECT SINGLE @abap_true FROM ztb_treeload WHERE modulelo = @gv_module AND object_key = @gv_key INTO @gv_exist.
  IF gv_exist IS INITIAL.
    SELECT FROM ztb_file_folder FIELDS * WHERE obj_type = @gv_object_type AND obj_address = @gv_object_address INTO TABLE @DATA(gt_folder).
    IF gt_folder IS NOT INITIAL.
      gt_tree_load = VALUE #( FOR gs_folder IN gt_folder INDEX INTO index ( modulelo = gv_module node_key = |NODE{ index }| text = gs_folder-folder_name length = strlen( gs_folder-folder_name ) + 5
                                                                            object_key = gv_key isfolder = 'X' pos = index class = 2 created_on = zcl_ul_abap=>encode_timestamp( ) created_by = sy-uname ) ).
    ELSE.
      gt_tree_load = VALUE #( ( modulelo = gv_module node_key = 'NODE1' text = 'Attachment Files' length = 20 object_key = gv_key
                                isfolder = abap_true pos = sy-tabix class = 2 created_on = zcl_ul_abap=>encode_timestamp( ) created_by = sy-uname ) ).
    ENDIF.
    MODIFY ztb_treeload FROM TABLE gt_tree_load.
  ENDIF.

  IF go_file IS NOT BOUND.
    go_file = NEW #(
      iv_module          = gv_module
      iv_objectkey       = gv_key
      iv_redifined_event = abap_false
      io_container       = NEW cl_gui_custom_container( container_name = 'CC_0401' ) ).
    go_file->tree_display( ).
    go_file->at_node_key = VALUE #( FOR s_node_key IN go_file->at_node WHERE ( isfolder = abap_true ) ( s_node_key-node_key ) ).
    go_file->ar_tree->expand_nodes( go_file->at_node_key ).
    go_file->ar_tree->set_selected_node( go_file->at_node_key[ 1 ] ).
    gv_key_old = gv_key.
  ELSE.
    go_file->ar_tree->set_screen_update( abap_true ).
  ENDIF.

ENDMODULE.
*&---------------------------------------------------------------------*
*& Module STATUS_0402 OUTPUT
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
MODULE status_0402 OUTPUT.

  SET PF-STATUS 'ZST_0402'.
  SET TITLEBAR  'ZTT_0402' WITH gs_node-text.

  CHECK go_file IS BOUND.
  IF go_file->ar_doi_doc IS NOT BOUND.
    "OR ( go_file->ar_doi_doc IS BOUND AND go_file->ar_doi_doc->ar_control IS NOT BOUND ).
    TRY.
        go_file->ar_doi_doc = NEW zcl_ul_doi_usage( io_container = NEW cl_gui_custom_container( container_name = 'CC_0402' )
                                                    iv_obj_key   = gv_key ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message( ).
        RETURN.
    ENDTRY.
  ENDIF.

  go_file->ar_doi_doc->open_document( iv_doc_id       = gs_node-docname
                                      io_tree_display = go_file
                                      iv_inplace      = abap_true
                                      iv_read_only    = abap_true
                                      iv_doc_title    = abap_true
                                      iv_protect_doc  = abap_true ).


ENDMODULE.
*&---------------------------------------------------------------------*
*& Module SET_SCREEN_0401 OUTPUT
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
MODULE set_screen_0401 OUTPUT.
  PERFORM set_screen_0401.
ENDMODULE.
*&---------------------------------------------------------------------*
*& Module SET_SCREEN_101 OUTPUT
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
MODULE set_screen_101 OUTPUT.
  PERFORM set_screen_101.
ENDMODULE.
*&---------------------------------------------------------------------*
*& Module PBO_0501 OUTPUT
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
MODULE pbo_0501 OUTPUT.

  PERFORM set_screen.
  PERFORM prepare_alv.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  STATUS_0601  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0601 OUTPUT.

  SET PF-STATUS 'STATUS_0601'.

  IF o_configure IS NOT BOUND.
    o_configure = NEW zcl_ul_dynamic_configuration( iv_configuration_id = configuration_id iv_configuration_group = configuration_group ).
  ELSE.
    o_configure->update_screen( ).
  ENDIF.

  IF zcl_ul_dynamic_configuration=>changed_protocol IS NOT BOUND
  OR ( zcl_ul_dynamic_configuration=>changed_protocol IS BOUND AND zcl_ul_dynamic_configuration=>changed_protocol->mt_protocol IS INITIAL ).
    o_configure->get_data( ).
  ENDIF.

  CHECK o_configure->t_configuration_group IS NOT INITIAL.
  DATA(configuration_text) = o_configure->t_configuration_group[ 1 ]-configuration_group_txt.
  SET TITLEBAR  'TITLE_0601' WITH configuration_text.


ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  STATUS_0502  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0502 OUTPUT.
  SET PF-STATUS 'STATUS_0502'.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  STATUS_0103  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0103 OUTPUT.
  SET PF-STATUS 'STATUS_0103'.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  STATUS_0403  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0403 OUTPUT.

  SET PF-STATUS 'STATUS_0403'.
  SET TITLEBAR  'TITLE_0403'.

ENDMODULE.
