*----------------------------------------------------------------------*
***INCLUDE ZINS_UL_TABLE_MANAGER_USER_I01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0100  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0100 INPUT.
CASE sy-ucomm .
  WHEN 'BACK'.
    grid->ao_alv->free( ).
    CLEAR: grid->ar_data.
    FREE: grid. CLEAR grid.
    LEAVE TO SCREEN 1000.
  WHEN 'DIS'.
    IF mode = 'B2'.
      sy-ucomm = 'B1'.
    ELSEIF mode = 'B1'.
      sy-ucomm  = 'B2'.
    ENDIF.
  WHEN 'DEL'.
    lcl_ap=>del_data( ).
  WHEN 'SAV'.
    lcl_ap=>save_data( ).
  WHEN 'SEND'.
    CALL SCREEN 1001.
ENDCASE.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_1001  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_1001 INPUT.
CASE sy-ucomm.
  WHEN 'SEND'.
    DATA: text_tab TYPE soli_tab,
          lv_sub   TYPE string.

    r_contents->get_text_as_r3table( IMPORTING table = text_tab ).
    lv_sub = subject.
    grid->send_data_email( i_recipients = recipients
                           i_subject    = lv_sub
                           i_text       = text_tab ).
    MESSAGE 'Send email successfully!' TYPE 'S'.
    LEAVE TO SCREEN 0.
  WHEN OTHERS.
    LEAVE TO SCREEN 0.
ENDCASE.
ENDMODULE.
