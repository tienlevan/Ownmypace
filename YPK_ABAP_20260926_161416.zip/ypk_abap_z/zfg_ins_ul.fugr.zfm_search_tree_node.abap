FUNCTION zfm_search_tree_node.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IO_TREE) TYPE REF TO  ZCL_UL_TREE_DISPLAY
*"----------------------------------------------------------------------

  CHECK io_tree IS BOUND.
  go_tree = io_tree.
  CALL SCREEN 103 STARTING AT 40 2.

ENDFUNCTION.
