*&---------------------------------------------------------------------*
*&  Include           ZPG_KB_CREATE_PBO
*&---------------------------------------------------------------------*
AT SELECTION-SCREEN OUTPUT.

  APPEND 'ONLI' TO gt_excludes.
  CALL FUNCTION 'RS_SET_SELSCREEN_STATUS'
    EXPORTING
      p_status  = ' '
      p_program = sy-repid
    TABLES
      p_exclude = gt_excludes.
*&---------------------------------------------------------------------*
*&      Module  STATUS_8888  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_8888 OUTPUT.

  SET TITLEBAR  'TITLE' WITH gv_mode_text.

  FREE gt_excludes.
  IF gv_mode = gc_mode_create.
    APPEND 'CHANGE' TO gt_excludes.
  ELSEIF gv_mode = gc_mode_display.
    APPEND 'SAVE' TO gt_excludes.
  ENDIF.

  LOOP AT SCREEN.
    screen-input  = SWITCH #( gv_mode WHEN  gc_mode_display THEN 0 ELSE 1 ).
    MODIFY SCREEN.
  ENDLOOP.

  SET PF-STATUS 'STATUS' EXCLUDING gt_excludes.
  app=>start( ).


ENDMODULE.
