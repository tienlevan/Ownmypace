*"* use this source file for any macro definitions you need
*"* in the implementation part of the class
  DEFINE htmlt.
    ls_data_table = &1.
    append ls_data_table to lt_data_table.
  END-OF-DEFINITION.

  DEFINE htmlp.
    ls_data_pic = &1.
    append ls_data_pic to lt_data_pic.
  END-OF-DEFINITION.

  DEFINE htmlo.
    ls_data_table = &1.
    append ls_data_table to lt_data_table.
  END-OF-DEFINITION.

 DEFINE htmlpog.
    ls_data_table = &1.
    append ls_data_table to lt_data_table.
  END-OF-DEFINITION.
