*&---------------------------------------------------------------------*
*&  Include           ZINS_UL_TABLE_MANAGER_USER_TOP
*&---------------------------------------------------------------------*

TABLES: sscrfields.
DATA: grid TYPE REF TO zcl_ul_table_manager.
FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.
DATA: mode TYPE syst_ucomm.

SELECTION-SCREEN BEGIN OF BLOCK bb WITH FRAME TITLE TEXT-100.
SELECTION-SCREEN SKIP 1.
PARAMETERS: viewname TYPE dd02l-tabname,
            variant  TYPE slis_vari,
            maxsel   TYPE i.
SELECTION-SCREEN: FUNCTION KEY 1,
                  FUNCTION KEY 2,
                  FUNCTION KEY 3,
                  FUNCTION KEY 4.
SELECTION-SCREEN SKIP 1.
SELECTION-SCREEN BEGIN OF LINE.
SELECTION-SCREEN PUSHBUTTON 20(10) TEXT-101 USER-COMMAND b1. "Display
SELECTION-SCREEN PUSHBUTTON 36(10) TEXT-102 USER-COMMAND b2. "Change
SELECTION-SCREEN PUSHBUTTON 52(10) TEXT-103 USER-COMMAND b3. "Upload
SELECTION-SCREEN END OF LINE.
SELECTION-SCREEN END OF BLOCK bb.


" Send email data
DATA: subject    TYPE char255,
      recipients TYPE char255,
      r_contents TYPE REF TO cl_gui_textedit.

** Pop-up upload selection screen
*SELECTION-SCREEN BEGIN OF SCREEN 1001 TITLE TEXT-sl0.
*SELECTION-SCREEN BEGIN OF BLOCK blk02 WITH FRAME TITLE TEXT-103.
*PARAMETERS: p_file LIKE rlgrap-filename OBLIGATORY.
*PARAMETERS: replace AS CHECKBOX.
*SELECTION-SCREEN END OF BLOCK blk02.
*SELECTION-SCREEN END OF SCREEN 1001.
*
*
** Pop-up for remote control
*SELECTION-SCREEN BEGIN OF SCREEN 1003 TITLE TEXT-sl2.
*PARAMETERS: rfcport TYPE rfcdest .
*SELECTION-SCREEN END OF SCREEN 1003.
