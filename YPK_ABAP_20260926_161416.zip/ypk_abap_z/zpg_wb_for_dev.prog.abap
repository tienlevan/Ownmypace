*&---------------------------------------------------------------------*
*& Report zpg_wb_for_dev
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zpg_wb_for_dev.

INCLUDE zpg_wb_for_dev_top.
INCLUDE zpg_wb_for_dev_cls.
INCLUDE zpg_wb_for_dev_status_9999o01.
INCLUDE zpg_wb_for_dev_user_commandi01.

START-OF-SELECTION.
  SET SCREEN 9999.
