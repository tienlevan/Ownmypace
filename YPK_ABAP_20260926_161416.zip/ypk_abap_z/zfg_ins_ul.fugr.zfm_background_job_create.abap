FUNCTION ZFM_BACKGROUND_JOB_CREATE.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IM_DATA) TYPE  TEXT50
*"----------------------------------------------------------------------

WRITE: /5 |{ im_data }|.



ENDFUNCTION.
