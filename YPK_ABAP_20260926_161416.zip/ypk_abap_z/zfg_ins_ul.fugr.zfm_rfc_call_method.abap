FUNCTION zfm_rfc_call_method.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_CLASS) TYPE  SEOCLSNAME
*"     VALUE(IV_METHOD) TYPE  SEOCPDNAME
*"     VALUE(IV_EXCEPTIONS) TYPE  STRING OPTIONAL
*"  CHANGING
*"     VALUE(CV_PARAMETERS) TYPE  STRING OPTIONAL
*"  EXCEPTIONS
*"      NOT_VALID_METHOD
*"      DYNAMIC_CALL_ERROR
*"----------------------------------------------------------------------

  DATA: ptab    TYPE abap_parmbind_tab,
        etab    TYPE abap_excpbind_tab,
        o_class TYPE REF TO object.

  CALL TRANSFORMATION id SOURCE XML cv_parameters
                        RESULT  mydata = ptab.

  CALL TRANSFORMATION id SOURCE XML iv_exceptions
                          RESULT  mydata = etab.

  SELECT SINGLE FROM seocompodf FIELDS mtddecltyp WHERE clsname = @iv_class AND cmpname = @iv_method AND exposure = '2'
    INTO @DATA(type).

  IF sy-subrc IS NOT INITIAL.
    RAISE not_valid_method.
  ENDIF.

  IF type = '0'.
    CREATE OBJECT o_class TYPE (iv_class).
    TRY .
        CALL METHOD o_class->(iv_method)
          PARAMETER-TABLE ptab
          EXCEPTION-TABLE etab.
      CATCH cx_sy_dyn_call_error INTO DATA(oref).
        RAISE dynamic_call_error.
    ENDTRY.
  ELSE.
    TRY .
        CALL METHOD (iv_class)=>(iv_method)
          PARAMETER-TABLE ptab
          EXCEPTION-TABLE etab.
      CATCH cx_sy_dyn_call_error INTO oref.
        RAISE dynamic_call_error.
    ENDTRY.
  ENDIF.

  CALL TRANSFORMATION id SOURCE mydata = ptab
                         RESULT XML cv_parameters.

ENDFUNCTION.
