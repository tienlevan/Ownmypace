*&---------------------------------------------------------------------*
*& Report ZPG_INS_USER_ROLES
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zpg_ins_user_roles.

INCLUDE zpg_ins_user_roles_top.
INCLUDE zpg_ins_user_roles_cls.

AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  lcl_user=>get_file(  ).

AT SELECTION-SCREEN OUTPUT.
  zcl_ul_abap=>set_dynpro_drop( iv_id = 'P_ACTION'
                                it_values = VALUE #( ( key = gc_act_role   text = 'Role Adjustment' )
                                                     ( key = gc_act_change text = 'Mass Change User' )
                                                     ( key = gc_act_matrix text = 'Role Matrix' )
                                                     ( key = gc_act_create text = 'Create New User' )
                                                     ( key = gc_act_tcode  text = 'Tcode Matrix' )
                                                     ( key = gc_act_restr  text = 'Reconstruct Roles' ) ) ).
  CASE p_action.

    WHEN gc_act_create.

      SELECT FROM ztb_set_roles FIELDS posid AS key, posname AS text WHERE posgr = @p_dept ORDER BY key INTO CORRESPONDING FIELDS OF TABLE @gt_position.
      DELETE ADJACENT DUPLICATES FROM gt_position COMPARING ALL FIELDS.
      zcl_ul_abap=>set_dynpro_drop( iv_id = 'P_POST'
                                    it_values = gt_position ).

    WHEN gc_act_change.

      SELECT FROM ztb_set_roles FIELDS posid AS key, posname AS text  ORDER BY key INTO CORRESPONDING FIELDS OF TABLE @gt_position.
      DELETE ADJACENT DUPLICATES FROM gt_position COMPARING ALL FIELDS.
      zcl_ul_abap=>set_dynpro_drop( iv_id = 'P_POST_A'
                                    it_values = gt_position ).

  ENDCASE.

  LOOP AT SCREEN.

    CASE p_action.

      WHEN gc_act_role.
        IF screen-group1 EQ 'M1' OR screen-group1 = 'FM'
        OR screen-name = '%B002003_BLOCK_1000'.
          screen-active   = 1.
        ELSE.
          screen-active = 0.
        ENDIF.
      WHEN gc_act_create.
        IF r_refus IS NOT INITIAL.
          IF screen-group1 = 'M4'
          OR screen-group1 = 'M2'
          OR screen-name = '%B003008_BLOCK_1000'.
            screen-active = 1.
          ELSE.
            screen-active = 0.
          ENDIF.
        ELSE.
          IF screen-group1 = 'M5'
          OR screen-group1 = 'M2'
          OR screen-name = '%B003008_BLOCK_1000'.
            screen-active = 1.
          ELSE.
            screen-active = 0.
          ENDIF.
        ENDIF.
      WHEN gc_act_matrix.
        IF screen-group1 = 'M3'
        OR screen-name = '%B004020_BLOCK_1000'.
          screen-active = 1.
        ELSE.
          screen-active = 0.
        ENDIF.
      WHEN gc_act_change.
        IF screen-group1 = 'M6'
        OR screen-name = '%B005025_BLOCK_1000'.
          screen-active = 1.
        ELSE.
          screen-active = 0.
        ENDIF.
      WHEN gc_act_tcode.
        IF screen-group1 = 'M7'
          OR screen-name = '%B006032_BLOCK_1000'.
          screen-active = 1.
        ELSE.
          screen-active = 0.
        ENDIF.
      WHEN gc_act_restr.
        IF screen-group1 = 'M8' OR screen-group1 = 'FM'
        OR screen-name  = '%B008036_BLOCK_1000'.
          screen-active = 1.
        ELSE.
          screen-active = 0.
        ENDIF.
      WHEN OTHERS.
        screen-active = 0.
    ENDCASE.

    IF screen-name = '%B001000_BLOCK_1000'
    OR screen-group1 = 'M0'.
      screen-active = 1.
    ENDIF.

    MODIFY SCREEN.

  ENDLOOP.

START-OF-SELECTION.
  CASE p_action.
    WHEN gc_act_role.
      lcl_user=>role_adjustment( ).
    WHEN gc_act_matrix.
      lcl_user=>export_role_matrix( ).
    WHEN gc_act_create.
      lcl_user=>create_user( ).
    WHEN gc_act_change.
      lcl_user=>change_user( ).
    WHEN gc_act_tcode.
      lcl_user=>export_tcode_matrix( ).
    WHEN gc_act_restr.
      lcl_user=>reconstruct_role( ).
    WHEN OTHERS.
      MESSAGE 'Not implement yet!' TYPE 'I'.
  ENDCASE.
