FUNCTION zfm_ins_file_attachment.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IS_DATA) TYPE  ANY
*"     REFERENCE(IV_OBJECT_TYPE) TYPE  ZACC_TYPE DEFAULT '02'
*"     REFERENCE(IV_OBJECT_ADDRESS) TYPE  CHAR100 OPTIONAL
*"     REFERENCE(IV_MODULE) TYPE  CHAR12
*"  EXPORTING
*"     REFERENCE(EO_FILE) TYPE REF TO  ZCL_UL_TREE_DISPLAY
*"----------------------------------------------------------------------

  gv_object_type    = iv_object_type.
  gv_object_address = iv_object_address.
  gv_key = zcl_ul_abap=>build_key( is_data = is_data iv_add_client = abap_false ).
  gv_module = iv_module.
  CLEAR: gt_status, gv_status.
  SELECT FROM ztb_file_status FIELDS * WHERE modulelo = @gv_module INTO TABLE @gt_status.
  IF gt_status IS NOT INITIAL.
    DATA(ls_status) = gt_status[ 1 ].
    ASSIGN COMPONENT ls_status-status_field OF STRUCTURE is_data TO FIELD-SYMBOL(<fv_value>).
    IF sy-subrc IS INITIAL.
      READ TABLE gt_status WITH KEY status_field = ls_status-status_field screen_value = <fv_value> TRANSPORTING NO FIELDS.
      IF sy-subrc IS INITIAL.
        gv_status = <fv_value>.
      ENDIF.
    ENDIF.
  ENDIF.

  IF gv_supplied IS INITIAL AND is_data IS NOT INITIAL.
    gv_supplied = abap_true.
  ENDIF.

  IF gv_key <> gv_key_old AND go_file IS BOUND.
    go_file->ar_tree->delete_all_nodes( ).
    go_file->ar_tree_cont->free( ).
    CLEAR go_file.
  ENDIF.

  CHECK go_file IS BOUND.
  eo_file = go_file.

ENDFUNCTION.
