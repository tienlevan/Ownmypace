*----------------------------------------------------------------------*
***INCLUDE LZFG_INS_ULF01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*& Form set_screen_0401
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM set_screen_0401 .

  IF gv_status IS NOT INITIAL.
    LOOP AT SCREEN.
      READ TABLE gt_status WITH KEY screen_name = screen-name screen_value = gv_status INTO DATA(gs_status).
      CHECK sy-subrc IS INITIAL.
      IF gs_status-field_active IS NOT INITIAL.
        screen-active = 0.
      ELSEIF gs_status-field_disable IS NOT INITIAL.
        screen-input = 0.
      ENDIF.
      MODIFY SCREEN.
    ENDLOOP.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form check_file_size
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      <-- LW_ERR_SIZE
*&---------------------------------------------------------------------*
FORM check_file_size  CHANGING lpw_err_size TYPE char1
                               lpw_file_size TYPE i.
  DATA: lw_file_size TYPE i,
        lw_file_path TYPE rlgrap-filename.
  CLEAR: lpw_err_size,
         lpw_file_size.

  lw_file_path = file_path.
* get file size current
  CALL FUNCTION 'GUI_GET_FILE_INFO'
    EXPORTING
      fname     = lw_file_path
    IMPORTING
      file_size = lw_file_size.
  lpw_file_size = lw_file_size.
* get data stored
  SELECT *
    FROM ztb_treeload
    INTO TABLE @DATA(lt_tree_load)
    WHERE object_key = @gv_key.

  LOOP AT lt_tree_load INTO DATA(ls_tree_load).
    lw_file_size = lw_file_size + ls_tree_load-file_size.
  ENDLOOP.
  IF lw_file_size > 50000000 AND sy-uname <> 'TIENLV1' AND sy-uname <> 'QUANGDV2' .
    lpw_err_size = 'X'.
    MESSAGE 'Total file size is over than 50Mb. Please check again or use URL upload function.' TYPE 'E'.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form create_url_item
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM create_url_item .
  TRY.
      DATA(ls_node) = _tree->get_node_inf( _tree->get_selected_node( ) ).
    CATCH zcx_ul_handle_errors.
  ENDTRY.
  DATA(lt_config) = _tree->at_config.
  SORT lt_config DESCENDING BY pos.
  DATA lt_add_node TYPE TABLE OF ztb_treeload.
* image
  zcl_ul_tree_display=>set_default_text( EXPORTING iv_acc_type = ztb_treeload-acc_type
                                         IMPORTING ev_symbol   = DATA(lw_inmage) ).
*  text
  IF ztb_treeload-text IS NOT INITIAL.
    DATA(lw_text) = ztb_treeload-text.
  ELSE.
    lw_text = zcl_ul_tree_display=>set_default_text( EXPORTING iv_acc_type = ztb_treeload-acc_type
                                                     CHANGING  cv_value    = ztb_treeload-programname ).
  ENDIF.

  lt_add_node = VALUE #( ( modulelo = _tree->av_module node_key = |ITEM{ lt_config[ 1 ]-pos + 1 }| n_image = lw_inmage
                           text = lw_text created_by = sy-uname acc_type = '05' dragdropid = 1 created_on = zcl_ul_abap=>encode_timestamp( )
                           programname = ztb_treeload-programname class = 2
                           pos = lt_config[ 1 ]-pos + 1 relatkey = ls_node-node_key relatship = 6 object_key = gv_key
                           length = strlen( lw_text ) + 3 ) ).

  _tree->add_nodes( it_nodes = lt_add_node ).
  MODIFY ztb_treeload FROM TABLE lt_add_node.
  _tree->ar_tree->set_selected_node( lt_add_node[ 1 ]-node_key ).
  MESSAGE 'New entry has been created!' TYPE 'S'.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form set_screen_101
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM set_screen_101 .
  CHECK sy-tcode CS 'ZRE100' OR sy-tcode CS 'ZRE200'.
  ztb_treeload-acc_type = '05'.
  LOOP AT SCREEN.
    IF screen-group1 = 'HID'.
      screen-active = 0.
      MODIFY SCREEN.
    ENDIF.
  ENDLOOP.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form get_dom_value
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*&      --> LW_STATUS
*&      <-- LW_STATUS_TXT
*&---------------------------------------------------------------------*
FORM get_dom_value  USING    lpw_status TYPE char2
                    CHANGING lpw_status_txt TYPE val_text.
  DATA: lt_idd07v TYPE TABLE OF  dd07v WITH HEADER LINE.
  CLEAR lpw_status_txt.
  CALL FUNCTION 'DD_DOMVALUES_GET'
    EXPORTING
      domname        = 'ZDO_RE_PRICE_STATUS'   "<-- Your Domain Here
      text           = 'X'
      langu          = sy-langu
    TABLES
      dd07v_tab      = lt_idd07v
    EXCEPTIONS
      wrong_textflag = 1
      OTHERS         = 2.

  READ TABLE lt_idd07v WITH KEY domvalue_l = lpw_status.
  IF sy-subrc IS INITIAL.
    lpw_status_txt = lt_idd07v-ddtext.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form init_icon
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM init_icon .
* Finish release
  CALL FUNCTION 'ICON_CREATE'
    EXPORTING
      name   = icon_checked
      info   = 'Finished release'
    IMPORTING
      result = gw_finish_rel.

* Wait release
  CALL FUNCTION 'ICON_CREATE'
    EXPORTING
      name   = icon_led_yellow
      info   = 'Wait release'
    IMPORTING
      result = gw_wait_rel.

* Undo release
  CALL FUNCTION 'ICON_CREATE'
    EXPORTING
      name   = icon_system_undo
      info   = 'Undo release'
    IMPORTING
      result = gw_un_release.

* Release
  CALL FUNCTION 'ICON_CREATE'
    EXPORTING
      name   = icon_set_state
      info   = 'Release'
    IMPORTING
      result = gw_release.
* Reject
  CALL FUNCTION 'ICON_CREATE'
    EXPORTING
      name   = icon_reject
      info   = 'Reject'
    IMPORTING
      result = gw_reject.
ENDFORM.
*&---------------------------------------------------------------------*
*& Form prepare_alv
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM prepare_alv .

  IF container_rel IS NOT BOUND.

    CREATE OBJECT event_rel.
    CREATE OBJECT container_rel
      EXPORTING
        container_name = 'CONTAINER_REL'.
    CREATE OBJECT grid_rel
      EXPORTING
        io_parent = container_rel.
    grid_rel->s_layout = VALUE #( no_toolbar = abap_true ).

    TRY.
        grid_rel->display( EXPORTING iv_auto_hide = abap_true
                                     it_col_set   = VALUE #( ( fieldname = 'FRGCO' outputlen = 15 )
                                                             ( fieldname = 'FRGCO_NAME' reptext = 'Description' outputlen = 30 )
                                                             ( fieldname = 'STATUS' reptext = 'Status' outputlen = 10 )
                                                             ( fieldname = 'FUNCTION' reptext = 'Function' hotspot = abap_true outputlen = 10 ) )
                           CHANGING  ct_data      = gt_release_tab ).

        SET HANDLER event_rel->handle_single_click FOR grid_rel.
      CATCH zcx_ul_handle_errors INTO DATA(cx_error).
        zcx_ul_handle_errors=>raise_message( io_msg_object = cx_error ).
    ENDTRY.

  ELSE.

    grid_rel->refresh_table_display( ).

  ENDIF.


ENDFORM.
*&---------------------------------------------------------------------*
*& Form set_screen
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM set_screen .

  CHECK gv_objnr IS NOT INITIAL.
  zcl_ul_workflow=>get_rel_tab( EXPORTING objkey = gv_objnr IMPORTING rel_tab = gt_release_tab ).

  CHECK ztb_set_relgr-frggr IS INITIAL.
  ztb_set_relgr-frggr = gv_objnr(2).
  SELECT SINGLE FROM ztb_set_relgr FIELDS frggr_name WHERE frggr = @ztb_set_relgr-frggr INTO @ztb_set_relgr-frggr_name.
  ztb_set_relstr-frgsx = gv_objnr+2(2).
  SELECT SINGLE FROM ztb_set_relstr FIELDS frgsx_name WHERE frggr = @ztb_set_relgr-frggr AND frgsx = @ztb_set_relstr-frgsx INTO @ztb_set_relstr-frgsx_name.

ENDFORM.

*&---------------------------------------------------------------------*
*& Form set_screen
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM get_pc_file.

  DATA lv_rc         TYPE i.

  cl_gui_frontend_services=>file_open_dialog( EXPORTING window_title      = 'Select files'
                                                        initial_directory = initial_path
                                                        multiselection    = abap_true
                                              CHANGING  file_table        = gt_file_path
                                                        rc                = lv_rc ).

  IF gt_file_path IS INITIAL.
    MESSAGE 'No file was selected!' TYPE 'I'. RETURN.
  ENDIF.

  LOOP AT gt_file_path INTO DATA(gs_file_path).
    IF lines( gt_file_path ) = 1.
      file_path = gs_file_path-filename.
    ELSE.
      file_path = SWITCH #( sy-tabix WHEN 1 THEN |"{ gs_file_path-filename }"| ELSE |{ file_path } "{ gs_file_path-filename }"| ).
    ENDIF.
    FIND ALL OCCURRENCES OF '\' IN gs_file_path-filename RESULTS DATA(t_result).
    CHECK t_result IS NOT INITIAL.
    SORT t_result DESCENDING BY offset.
    DATA(offset) = t_result[ 1 ]-offset.
    initial_path = gs_file_path-filename(offset).
  ENDLOOP.

ENDFORM.

FORM upload_file.

  IF gs_node-isfolder IS INITIAL.
    SELECT FROM ztb_file_folder FIELDS * WHERE obj_type = @gv_object_type AND obj_address = @gv_object_address INTO TABLE @DATA(lt_folder).
    IF sy-subrc IS NOT INITIAL.
      MESSAGE 'No configuration!' TYPE 'I'.
      RETURN.
    ELSEIF lines( lt_folder ) > 1.
      MESSAGE 'Please select a folder!' TYPE 'I'.
      RETURN.
    ELSE.
      DATA(ls_folder) = lt_folder[ 1 ].
      go_file->ar_tree->set_selected_node( go_file->at_node[ isfolder = abap_true ]-node_key ).
    ENDIF.
  ENDIF.

  TRY.
      IF go_doc IS NOT BOUND AND go_file->ar_html IS BOUND.
        go_doc = NEW #( io_container = go_file->ar_html iv_obj_key = gv_key ).
        go_file->av_doc_open = abap_true.
      ELSEIF go_doc IS NOT BOUND.
        go_doc = NEW #( iv_obj_key = gv_key ).
      ENDIF.

      DATA(ls_node) = go_file->get_node_inf( go_file->get_selected_node( ) ).

    CATCH zcx_ul_handle_errors INTO DATA(cx_error).
      cx_error->show_message( ). RETURN.
  ENDTRY.

  LOOP AT gt_file_path INTO gs_file_path.
    TRY.
        IF strlen( gs_file_path-filename ) <= 128.
          CALL FUNCTION 'GUI_GET_FILE_INFO'
            EXPORTING
              fname     = CONV localfile( gs_file_path-filename )
            IMPORTING
              file_size = file_size.

          IF file_size > 50000000 AND sy-uname NOT IN zcl_ul_abap=>get_stvarv_val( 'ZTABM_SUPERUSER' ) .
            MESSAGE |File { gs_file_path-filename } size is over than 50Mb. Can not upload!| TYPE 'I'.
            CONTINUE.
          ENDIF.
        ENDIF.

      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message( ). CONTINUE.
    ENDTRY.

    REFRESH go_doc->at_doc_components.
    doc_id = go_doc->upload_document( iv_file_path = CONV #( gs_file_path-filename ) ).

    DATA(lt_config) = go_file->at_config.
    SORT lt_config DESCENDING BY pos.
    DATA lt_add_node TYPE TABLE OF ztb_treeload.

    IF ls_node-isfolder IS NOT INITIAL.

      CASE go_doc->at_doc_signatures[ prop_name = 'BDS_DOCUMENTCLASS' ]-prop_value.
        WHEN 'DOC' OR 'DOCX'.
          DATA(lv_image) = '@J7@'.
        WHEN 'XLS' OR 'XLSX'.
          lv_image =  '@J2@'.
        WHEN 'XLSM'.
          lv_image = '@J3@'.
        WHEN 'PPT' OR 'PPTX'.
          lv_image = '@J5@'.
        WHEN 'PDF'.
          lv_image = '@IT@'.
        WHEN 'MSG'.
          lv_image = '@J1'.
        WHEN 'JPG' OR 'PNG' OR 'GIF' OR 'TIF'.
          lv_image = '@JA@'.
        WHEN 'HTM' OR 'HTML'.
          lv_image = '@J4@'.
        WHEN 'RTF'.
          lv_image = 'J9'.
        WHEN 'TXT'.
          lv_image = 'JB'.
        WHEN 'LWP'.
          lv_image = 'JC'.
        WHEN '123'.
          lv_image = 'JD'.
        WHEN 'VSD'.
          lv_image = 'JE'.
        WHEN OTHERS.
          lv_image = '@OA@'.
      ENDCASE.

      lt_add_node = VALUE #( ( modulelo = go_file->av_module node_key = |ITEM{ lt_config[ 1 ]-pos + 1 }| n_image = lv_image
                               text = go_doc->at_doc_signatures[ prop_name = 'DESCRIPTION' ]-prop_value created_by = sy-uname
                               doctype = ztb_treeload-doctype docname = doc_id acc_type = '11' dragdropid = 1 created_on = zcl_ul_abap=>encode_timestamp( )
                               pos = lt_config[ 1 ]-pos + 1 relatkey = ls_node-node_key relatship = 6 object_key = gv_key file_size = file_size
                               length = strlen( go_doc->at_doc_signatures[ prop_name = 'DESCRIPTION' ]-prop_value ) ) ).

      go_file->add_nodes( it_nodes = lt_add_node ).
      MODIFY ztb_treeload FROM TABLE lt_add_node.
      go_file->ar_tree->set_selected_node( lt_add_node[ 1 ]-node_key ).
      MESSAGE 'New document is inserted!' TYPE 'S'.

    ELSE.

      DATA(lv_doc_name) = go_doc->at_doc_signatures[ 1 ]-doc_id.
      UPDATE ztb_treeload SET docname = lv_doc_name
                          WHERE modulelo = go_file->av_module
                          AND   node_key = ls_node-node_key.
      CHECK sy-subrc = 0.
      MESSAGE 'Document is applied for this node' TYPE 'S'.

    ENDIF.

  ENDLOOP.

ENDFORM.
