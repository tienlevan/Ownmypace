FUNCTION zfm_ins_create_url.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IO_TREE) TYPE REF TO  ZCL_UL_TREE_DISPLAY
*"     REFERENCE(IV_URL_ONLY) TYPE  BOOLEAN DEFAULT ABAP_FALSE
*"     REFERENCE(IV_OBJ_ADDRESS) TYPE  SBDST_OBJECT_KEY OPTIONAL
*"  EXPORTING
*"     REFERENCE(EO_DOCUMENT) TYPE REF TO  ZCL_UL_DOI_USAGE
*"     REFERENCE(EV_DOC_ID) TYPE  BDS_DOCID
*"----------------------------------------------------------------------

  _tree = io_tree.
  object_address = iv_obj_address.

  IF iv_url_only IS NOT INITIAL.
    gw_url_only = 'X'.
  ENDIF.

  CALL SCREEN 101 STARTING AT 5 5.

  eo_document = go_doc.
  ev_doc_id   = doc_id.
  CLEAR gw_url_only.

ENDFUNCTION.
