*&---------------------------------------------------------------------*
*&  Include           ZDOI_CREATE_TOP
*&---------------------------------------------------------------------*

DATA file_path TYPE string.
DATA initial_path TYPE string VALUE `\`.
DATA gt_file_path TYPE filetable.
DATA upload    TYPE char1.
DATA upld_only  TYPE boolean.
DATA go_doc TYPE REF TO zcl_ul_doi_usage.
DATA doc_id TYPE bds_docid.
DATA object_address TYPE sbdst_object_key.
DATA file_meth TYPE char4.
DATA file_url  TYPE string.
DATA file_link TYPE string.
