CLASS zcl_m_derived_role DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    TYPES: BEGIN OF ty_data,
             role   TYPE agr_name,
             desc   TYPE agr_title,
             parent TYPE par_agr,
             org_1  TYPE agrorgvar,
             val_1  TYPE agval,
             org_2  TYPE agrorgvar,
             val_2  TYPE agval,
             org_3  TYPE agrorgvar,
             val_3  TYPE agval,
             org_4  TYPE agrorgvar,
             val_4  TYPE agval,
             org_5  TYPE agrorgvar,
             val_5  TYPE agval,
             error  TYPE icon_d,
           END OF ty_data.

    DATA mt_data TYPE TABLE OF ty_data.
    DATA cx_error TYPE REF TO zcx_ul_handle_errors.

    INTERFACES zif_data_migration .

  PROTECTED SECTION.
  PRIVATE SECTION.

ENDCLASS.



CLASS ZCL_M_DERIVED_ROLE IMPLEMENTATION.


  METHOD zif_data_migration~convert_to_itab.

  ENDMETHOD.


  METHOD zif_data_migration~get_data_external.

    CREATE OBJECT cx_error.

    TRY .
        DATA(excel) = NEW zcl_ul_doi_usage( ).

        excel->read_excel_data( EXPORTING iv_file_location = CONV #( file_location )
                                          is_select_range = VALUE #( row = 2 rows = 1000 column = 1 columns = 20 )
                                IMPORTING et_data = mt_data ).

      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message(  ).
    ENDTRY.

    LOOP AT mt_data ASSIGNING FIELD-SYMBOL(<fs_data>).
      <fs_data>-error = icon_led_inactive.
    ENDLOOP.

    CHECK mt_data IS NOT INITIAL.
    CREATE DATA zif_data_migration~r_data TYPE TABLE OF ty_data.
    ASSIGN zif_data_migration~r_data->* TO FIELD-SYMBOL(<ft_data>).
    <ft_data> = mt_data.

  ENDMETHOD.


  METHOD zif_data_migration~get_data_system.
  ENDMETHOD.


  METHOD zif_data_migration~grid_double_click.

  ENDMETHOD.


  METHOD zif_data_migration~grid_hotspot_click.

    DATA bdc_tab TYPE TABLE OF bdcdata.

    FIELD-SYMBOLS <ft_data> LIKE mt_data.
    ASSIGN zif_data_migration~r_data->* TO <ft_data>.
    READ TABLE <ft_data> ASSIGNING FIELD-SYMBOL(<fs_data>) INDEX e_row_id-index.

    bdc_tab = VALUE #( ( dynbegin = abap_true dynpro = '0121' program = 'SAPLPRGN_TREE' )
                       ( fnam = 'AGR_NAME_NEU' fval = <fs_data>-role )
                       ( fnam = 'BDC_OKCODE' fval = 'ANZE' ) ).

    CALL TRANSACTION 'PFCG' USING bdc_tab MODE 'E'.

  ENDMETHOD.


  METHOD zif_data_migration~grid_user_command.

  ENDMETHOD.


  METHOD zif_data_migration~prepare_display.

    col_tab = VALUE #( ( fieldname = 'ROLE' reptext = 'Role' col_pos = 2 hotspot = abap_true )
                       ( fieldname = 'DESC' reptext = 'Description' )
                       ( fieldname = 'PARENT' reptext = 'Parent Role' )
                       ( fieldname = 'ORG_1' reptext = 'Organization Field 1' )
                       ( fieldname = 'VAL_1' reptext = 'Value' )
                       ( fieldname = 'ORG_2' reptext = 'Organization Field 2' )
                       ( fieldname = 'VAL_2' reptext = 'Value' )
                       ( fieldname = 'ORG_3' reptext = 'Organization Field 3' )
                       ( fieldname = 'VAL_3' reptext = 'Value' )
                       ( fieldname = 'ORG_4' reptext = 'Organization Field 4' )
                       ( fieldname = 'VAL_4' reptext = 'Value' )
                       ( fieldname = 'ORG_5' reptext = 'Organization Field 5' )
                       ( fieldname = 'VAL_5' reptext = 'Value' )
                       ( fieldname = 'ERROR' reptext = 'Status' icon = abap_true col_pos = 1 ) ).

  ENDMETHOD.


  METHOD zif_data_migration~process_data.

    DATA return TYPE TABLE OF bapiret2.

    LOOP AT mt_data ASSIGNING FIELD-SYMBOL(<fs_data>).

      CALL FUNCTION 'PRGN_RFC_CREATE_ACTIVITY_GROUP'
        EXPORTING
          activity_group      = <fs_data>-role
          activity_group_text = <fs_data>-desc
          parent_role         = <fs_data>-parent
        TABLES
          return              = return.

      DELETE return WHERE ( id = '5@' AND number = '053' )
                    OR ( id = 'S#' AND number = '409' )
                    OR ( id = 'S#' AND number = '210' ).
      IF line_exists( return[ type = 'E' ] ).
        cx_error->add_bapiret2_table( return ).
        <fs_data>-error = icon_led_red.
        CONTINUE.
      ENDIF.

      TRY.
          cl_pfcg_role=>retrieve_for_update( EXPORTING it_pfcg_role = VALUE #( ( role = <fs_data>-role ) )
                                             IMPORTING et_node_root = DATA(t_role) ).
          t_role[ 1 ]-role_ref->if_pfcg_role_authorization~get_org_values( IMPORTING et_org_values = DATA(t_orgs) ).
          cl_pfcg_role=>retrieve( EXPORTING it_pfcg_role = VALUE #( ( role = <fs_data>-parent ) )
                                             IMPORTING et_node_root = DATA(t_parent_role) ).
          t_parent_role[ 1 ]-role_ref->if_pfcg_role_authorization~get_org_values( IMPORTING et_org_values = DATA(t_parent_orgs) ).
          t_parent_role[ 1 ]-role_ref->if_pfcg_role_authorization~get_auths( IMPORTING et_auth_auths = DATA(t_auths) ).

          DO 5 TIMES.
            DATA(field) = condense( |ORG_{ sy-index }| ).
            DATA(value) = condense( |VAL_{ sy-index }| ).
            ASSIGN COMPONENT field OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fv_org>).
            ASSIGN COMPONENT value OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fv_val>).

            CHECK <fv_org> IS NOT INITIAL.
            LOOP AT t_orgs ASSIGNING FIELD-SYMBOL(<fs_org>) WHERE varbl = <fv_org>.
              <fs_org>-change_mode = 'D'.
            ENDLOOP.
            APPEND INITIAL LINE TO t_orgs ASSIGNING <fs_org>.
            <fs_org>-varbl = <fv_org>.
            <fs_org>-low = <fv_val>.
            <fs_org>-change_mode = 'I'.
          ENDDO.

          LOOP AT t_parent_orgs INTO DATA(s_parent_org) WHERE low IS NOT INITIAL.
            READ TABLE t_orgs ASSIGNING <fs_org> WITH KEY varbl = s_parent_org-varbl low = s_parent_org-low.
            IF sy-subrc IS NOT INITIAL.
              APPEND INITIAL LINE TO t_orgs ASSIGNING <fs_org>.
              <fs_org>-varbl = s_parent_org-varbl.
              <fs_org>-low = s_parent_org-low.
              <fs_org>-change_mode = 'I'.
            ELSE.
              <fs_org>-change_mode = 'I'.
            ENDIF.
          ENDLOOP.

          LOOP AT t_auths INTO DATA(s_auth).
            t_parent_role[ 1 ]-role_ref->if_pfcg_role_authorization~get_values_for_auth( EXPORTING is_auth = s_auth
                                                                                  IMPORTING et_auth_values = DATA(t_auth_vals) ).
            CHECK t_auth_vals IS NOT INITIAL.
            LOOP AT t_auth_vals ASSIGNING FIELD-SYMBOL(<auth_val>).
              <auth_val>-change_mode = 'I'.
            ENDLOOP.
            t_role[ 1 ]-role_ref->if_pfcg_role_authorization~add_manual_auth( EXPORTING iv_object = s_auth-object
                                                                              IMPORTING es_auth_auths = DATA(auth) ).
            t_role[ 1 ]-role_ref->if_pfcg_role_authorization~set_values_for_auth( is_auth = auth
                                                                                  it_auth_values = t_auth_vals ).

            CLEAR t_auth_vals.
          ENDLOOP.

          t_role[ 1 ]-role_ref->if_pfcg_role_authorization~set_org_values( it_org_values = t_orgs ).
          cl_pfcg_role=>do_save( ).
          <fs_data>-error = icon_led_green.
          COMMIT WORK AND WAIT.

        CATCH cx_pfcg_role INTO DATA(error).
          cx_error->add_exception_object( error ).
          ROLLBACK WORK.
          <fs_data>-error = icon_led_red.
      ENDTRY.

    ENDLOOP.

    CREATE DATA zif_data_migration~r_data TYPE TABLE OF ty_data.
    FIELD-SYMBOLS: <ft_data> LIKE mt_data.
    ASSIGN zif_data_migration~r_data->* TO <ft_data>.
    <ft_data> = mt_data.

    DATA roles TYPE TABLE OF agr_st_name.
    LOOP AT <ft_data> ASSIGNING <fs_data> WHERE error = icon_led_green.
      roles = VALUE #( BASE roles ( agr_name = <fs_data>-role ) ).
    ENDLOOP.

    CALL FUNCTION 'PRGN_GEN_PROFILES_FOR_ROLES'
      EXPORTING
        iv_usercompare = abap_true
      TABLES
        it_roles       = roles.

    CHECK cx_error->has_messages(  ) IS NOT INITIAL.
    cx_error->show_message(  ).

  ENDMETHOD.
ENDCLASS.
