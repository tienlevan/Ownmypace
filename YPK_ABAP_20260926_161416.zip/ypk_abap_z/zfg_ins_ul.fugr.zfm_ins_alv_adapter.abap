FUNCTION ZFM_INS_ALV_ADAPTER.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IV_SCREEN) TYPE  DYNNR
*"     REFERENCE(IT_COL_SET) TYPE  ZTB_UL_ALV_COL OPTIONAL
*"     REFERENCE(IV_TABNAME) TYPE  TABNAME OPTIONAL
*"     REFERENCE(IS_LAYOUT) TYPE  LVC_S_LAYO OPTIONAL
*"     REFERENCE(IO_LOCAL) TYPE REF TO  OBJECT OPTIONAL
*"     REFERENCE(IT_SORT) TYPE  LVC_T_SORT OPTIONAL
*"     REFERENCE(IV_AUTO_HIDE) TYPE  BOOLEAN OPTIONAL
*"     REFERENCE(IR_LOCAL_CLASS) TYPE REF TO  CL_ABAP_TYPEDESCR
*"       OPTIONAL
*"     REFERENCE(IT_TOOLBAR_ADD) TYPE  TTB_BUTTON OPTIONAL
*"     REFERENCE(IT_DROPVAL) TYPE  LVC_T_DROP OPTIONAL
*"     REFERENCE(IT_HYPERLINKS) TYPE  LVC_T_HYPE OPTIONAL
*"     VALUE(IV_TITLE) TYPE  LVC_TITLE OPTIONAL
*"     REFERENCE(IV_INPUT) TYPE  INT4 OPTIONAL
*"     REFERENCE(IV_POPUP_START) TYPE  I OPTIONAL
*"     REFERENCE(IV_POPUP_END) TYPE  I OPTIONAL
*"  EXPORTING
*"     REFERENCE(EO_ALV) TYPE REF TO  ZCL_UL_ALV_ADAPTER
*"  CHANGING
*"     REFERENCE(R_DATA) TYPE REF TO  DATA
*"----------------------------------------------------------------------
  gt_col_set    = it_col_set.
  gv_tabname    = iv_tabname.
  gt_sort       = it_sort.
  gv_autohide   = iv_auto_hide.
  gr_data       = r_data.
  gv_title      = iv_title.
  gt_tool_add   = it_toolbar_add.
  gs_layout     = is_layout.
  gr_class      = ir_local_class.
  gv_input      = iv_input.
  gt_hyperlinks = it_hyperlinks.
  gt_dropval    = it_dropval.

  IF go_alv IS BOUND.
    FREE go_alv.
  ENDIF.

  IF iv_screen = '0302'.
    IF iv_popup_start IS NOT INITIAL OR iv_popup_end IS NOT INITIAL.
      DATA(colstart) = COND int2( WHEN iv_popup_start IS NOT INITIAL THEN iv_popup_start ELSE 10 ).
      DATA(colend) = COND int2( WHEN iv_popup_end IS NOT INITIAL THEN iv_popup_end ELSE 20 ).
      CALL SCREEN iv_screen STARTING AT 10 colstart ENDING AT 85 colend.
    ELSE.
      CALL SCREEN iv_screen STARTING AT 10 10.
    ENDIF.
  ELSE.
    CALL SCREEN iv_screen.
  ENDIF.

  IF sy-batch = abap_false.
    IF sy-ucomm = 'SUPPORT'.
      zcl_ul_alv_adapter=>o_grid->mine_support_event( ).
    ENDIF.
    eo_alv = zcl_ul_alv_adapter=>o_grid.
  ENDIF.

ENDFUNCTION.
