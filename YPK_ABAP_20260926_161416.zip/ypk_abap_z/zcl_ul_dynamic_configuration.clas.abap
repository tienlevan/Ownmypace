CLASS zcl_ul_dynamic_configuration DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES zif_configuration .

    ALIASES data
      FOR zif_configuration~data .
    ALIASES t_col_set
      FOR zif_configuration~t_col_set .
    ALIASES t_tree
      FOR zif_configuration~t_tree .
    ALIASES event_data_changed
      FOR zif_configuration~event_data_changed .
    ALIASES event_data_saved
      FOR zif_configuration~event_data_saved .
    ALIASES event_node_changed
      FOR zif_configuration~event_node_changed .
    ALIASES read_access
      FOR zif_configuration~register_interface .

    TYPES:
      BEGIN OF ty_configuration_group,
        configuration_group     TYPE char10,
        configuration_group_txt TYPE text50,
      END OF ty_configuration_group .
    TYPES:
      BEGIN OF ty_dynamic_configuration,
        configuration_group          TYPE char10,
        configuration_id             TYPE char20,
        configuration_txt            TYPE text50,
        configuration_id_parent      TYPE text20,
        configuration_type           TYPE tabname16,
        configuration_type_txt       TYPE as4text,
        configuration_class          TYPE seoclsname,
        configuration_class_txt      TYPE seodescr,
        transport_flag               TYPE flag,
        log_flag                     TYPE flag,
        backup_flag                  TYPE flag,
      END OF ty_dynamic_configuration .
    TYPES:
      BEGIN OF ty_configuration_set,
        configuration_group TYPE char10,
        configuration_id    TYPE char20,
        fieldname           TYPE fieldname,
        col_pos             TYPE lvc_colpos,
        reptext             TYPE reptext,
        textfield           TYPE flag,
        texttab             TYPE tabname,
        masterfield         TYPE fieldname,
        dbclick             TYPE flag,
        objecttype          TYPE zacc_type,
        styletab            TYPE lvc_t_styl,
      END OF ty_configuration_set .

    CLASS-DATA input TYPE int4 .
    CLASS-DATA configuration_id TYPE text20 .
    CLASS-DATA splitter_h TYPE REF TO cl_gui_splitter_container .
    DATA configuration TYPE REF TO zif_configuration .
    DATA:
      t_configuration_group TYPE TABLE OF ty_configuration_group .
    DATA:
      t_configuration TYPE TABLE OF ty_dynamic_configuration .
    DATA:
      t_configuration_set TYPE TABLE OF ty_configuration_set .
    CLASS-DATA app_event TYPE boole_d .
    CLASS-DATA changed_protocol TYPE REF TO cl_alv_changed_data_protocol .
    CLASS-DATA tree TYPE REF TO cl_gui_simple_tree .
    CLASS-DATA grid TYPE REF TO zcl_ul_alv_adapter .

    METHODS write_change_log
      IMPORTING
        !it_data        TYPE INDEX TABLE
        !iv_tabname     TYPE tabname
        !iv_no_all      TYPE boole_d OPTIONAL
      RETURNING
        VALUE(rv_error) TYPE boole_d .
    CLASS-METHODS call_configuration
      IMPORTING
        !configuration_group TYPE text10 OPTIONAL
        !configuration_id    TYPE text10 OPTIONAL .
    METHODS show_in_grid
      CHANGING
        !ct_data TYPE ANY TABLE .
    METHODS constructor
      IMPORTING
        !iv_event               TYPE boole_d DEFAULT abap_false
        !iv_configuration_group TYPE text10 OPTIONAL
        !iv_configuration_id    TYPE text20 OPTIONAL .
    METHODS get_data
      RAISING
        zcx_ul_handle_errors .
    METHODS free .
    METHODS update_screen .
    METHODS save_data .
    METHODS set_initial
      IMPORTING
        !iv_configuration_group TYPE text10 OPTIONAL
        !iv_configuration_id    TYPE text20 OPTIONAL .
    CLASS-METHODS create_class_with_interface
      IMPORTING
        !classname TYPE seoclsname
        !interface TYPE seoclsname .
  PRIVATE SECTION.

    DATA _error TYPE REF TO zcx_ul_handle_errors .
    DATA _container TYPE REF TO cl_gui_container .
    DATA _splitter_v TYPE REF TO cl_gui_splitter_container .

    METHODS _transport
      IMPORTING
        !tabname          TYPE tabname16 OPTIONAL
        !data_tab         TYPE STANDARD TABLE OPTIONAL
        !configuration_id TYPE text20 OPTIONAL .
    METHODS _get_nodekey .
ENDCLASS.



CLASS zcl_ul_dynamic_configuration IMPLEMENTATION.


  METHOD call_configuration.

    FREE: app_event, splitter_h.

    CALL FUNCTION 'ZFM_INS_CALL_CONFIGURATION'
      EXPORTING
        iv_configuration_group = configuration_group
        iv_configuration_id    = configuration_id.

  ENDMETHOD.


  METHOD constructor.

    CREATE OBJECT _error.
    configuration = me.

    IF iv_event = abap_false.

      DATA o_event TYPE REF TO object.

      set_initial( iv_configuration_group = iv_configuration_group
                   iv_configuration_id    = iv_configuration_id ).

      configuration->register_interface(  ).
      _container = cl_gui_container=>screen0.

      _splitter_v  = NEW cl_gui_splitter_container( parent = _container rows = 1 columns = 2 ).
      DATA(_tree_cont)  = _splitter_v->get_container( row = 1 column = 1 ).
      splitter_h  = NEW #( parent = _splitter_v->get_container( row = 1 column = 2 ) rows = 2 columns = 1 ).
      splitter_h->set_row_height( id = 2 height = 0 ).
      DATA(cont_alv) = splitter_h->get_container( row = 1 column = 1 ).
      DATA(cont_err) = splitter_h->get_container( row = 2 column = 1 ).
      tree = NEW #( parent = _tree_cont node_selection_mode = cl_gui_simple_tree=>node_sel_mode_single ).

      CREATE OBJECT o_event TYPE ('LCL_EVENT')
        EXPORTING
        io_parent   = cont_alv
        io_log      = cont_err.

      grid ?= o_event.
      splitter_h->set_row_sash( id = 2 type = cl_gui_splitter_container=>type_sashvisible value = CONV #( cl_gui_splitter_container=>visible_false ) ).

      IF lines( t_tree ) > 1.
        _splitter_v->set_column_width( id = 1 width = 15 ).
        tree->add_nodes( node_table = t_tree table_structure_name = 'ZTB_TREELOAD' ).
        tree->expand_root_nodes(  ).
        tree->set_registered_events( events = VALUE #( ( eventid = cl_gui_simple_tree=>eventid_selection_changed appl_event = abap_true ) ) ).
        tree->set_selected_node( node_key = CONV #( configuration_id ) ).
        SET HANDLER event_node_changed FOR tree.
      ELSE.
        _splitter_v->set_column_width( id = 1 width = 0 ).
        _splitter_v->set_column_sash( id = 1 type = cl_gui_splitter_container=>type_sashvisible value = CONV #( cl_gui_splitter_container=>visible_false ) ).
      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD create_class_with_interface.

    DATA: t_class_description TYPE  TABLE OF seoclasstx,
          class               TYPE vseoclass,
          t_implementings     TYPE seor_implementings_r,
          korrnum             TYPE trkorr.

    t_class_description = VALUE #( ( clsname = classname langu = sy-langu descript = classname ) ).
    class = VALUE #( clsname = classname author = sy-uname changedby = sy-uname changedon = sy-datum chgdanyon = sy-datum createdon = sy-datum
                   exposure = seoc_exposure_public state = seoc_state_implemented clsfinal = abap_true unicode = abap_true fixpt = abap_true ).
    t_implementings = VALUE #( ( clsname = classname refclsname = interface state = seoc_state_implemented ) ).

    CALL FUNCTION 'TRINT_CORR_INSERT'
      EXPORTING
        iv_order = korrnum
        is_ko200 = VALUE ko200( pgmid = 'R3TR' object = 'CLAS' obj_name = classname operation = 'I' )
      IMPORTING
        we_task  = korrnum.

    CALL FUNCTION 'SEO_CLASS_CREATE_COMPLETE'
      EXPORTING
        corrnr                     = korrnum
        version                    = seoc_version_inactive
        genflag                    = seox_true
        suppress_method_generation = seox_false
        authority_check            = seox_true
        suppress_corr              = abap_false
      TABLES
        class_descriptions         = t_class_description
      CHANGING
        class                      = class
        implementings              = t_implementings
      EXCEPTIONS
        existing                   = 1
        is_interface               = 2
        db_error                   = 3
        component_error            = 4
        no_access                  = 5
        other                      = 6
        OTHERS                     = 7.

    IF sy-subrc IS NOT INITIAL.
      zcx_ul_handle_errors=>raise_message( ).
    ELSE.
      zcx_ul_handle_errors=>raise_message( iv_msg_text = |Class { classname } was created!| iv_msg_type = zcx_ul_handle_errors=>msgtype-success ).
    ENDIF.

  ENDMETHOD.


  METHOD free.

    tree->free( ).

    CHECK _splitter_v IS BOUND.
    _splitter_v->free( ).

    CHECK zcl_ul_dynamic_configuration=>changed_protocol IS BOUND.
    zcl_ul_dynamic_configuration=>changed_protocol->free(  ).

  ENDMETHOD.


  METHOD get_data.

    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.
    ASSIGN data->* TO <ft_data>.

    IF _error->has_messages(  ) IS NOT INITIAL.
      _error->show_message( ). LEAVE TO SCREEN 0.
    ENDIF.

    _get_nodekey( ).

    READ TABLE t_configuration INTO DATA(s_configuration) WITH KEY configuration_id = configuration_id.
    IF s_configuration-configuration_type IS NOT INITIAL.
      SELECT FROM (s_configuration-configuration_type) FIELDS * INTO TABLE @<ft_data>.
    ELSE.
      IF configuration_id IS INITIAL OR configuration_id NOT IN zcl_ul_abap=>string_to_range( 'CONFIG_GRP, CONFIG_ID, CONFIG_SET' ).
        CREATE OBJECT configuration TYPE (s_configuration-configuration_class).
        configuration->sender = me.
        configuration->register_interface(  ).
        ASSIGN configuration->data->* TO <ft_data>.
      ENDIF.
      zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = configuration_id
                                    IMPORTING e_data = <ft_data> ).
    ENDIF.

    show_in_grid( CHANGING ct_data = <ft_data> ).

  ENDMETHOD.


  METHOD save_data.

    IF grid->is_ready_for_input( ) IS INITIAL.
      zcx_ul_handle_errors=>raise_message( iv_msg_text = 'No data needs to save!' ).
      RETURN.
    ENDIF.

    grid->check_changed_data( IMPORTING e_valid = DATA(valid) ).
    IF valid IS INITIAL OR ( changed_protocol IS BOUND AND changed_protocol->mt_protocol IS NOT INITIAL ).
      zcx_ul_handle_errors=>raise_message( iv_msg_text = 'Please fix errors before saving data!' ).
      RETURN.
    ENDIF.

    TRY.
        configuration->event_data_saved( grid->r_table ).
        MESSAGE 'Data saved successfully!' TYPE 'S'.
      CATCH zcx_ul_handle_errors INTO DATA(error).
        error->show_message(  ).
    ENDTRY.

  ENDMETHOD.


  METHOD set_initial.

    IF iv_configuration_group IS INITIAL AND iv_configuration_id IS INITIAL.
      configuration_id = 'CONFIG_GRP'.
      FREE: t_configuration_group, t_configuration.
    ELSEIF iv_configuration_group IS NOT INITIAL.
      zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_GRP'
                                    IMPORTING e_data = t_configuration_group ).
      DELETE t_configuration_group WHERE configuration_group NE iv_configuration_group.
      IF t_configuration_group IS INITIAL.
        zcx_ul_handle_errors=>raise_message( iv_msg_text = |Configuration group { iv_configuration_group } does not exist!| ).
        LEAVE TO SCREEN 0.
      ENDIF.
      zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_ID'
                                    IMPORTING e_data = t_configuration ).
      DELETE t_configuration WHERE configuration_group  NE iv_configuration_group.
      IF t_configuration IS INITIAL.
        zcx_ul_handle_errors=>raise_message( iv_msg_text = |No configuration id exists in group { iv_configuration_group }!| ).
        LEAVE TO SCREEN 0.
      ENDIF.
      configuration_id = t_configuration[ 1 ]-configuration_id.
    ELSE.
      configuration_id = iv_configuration_id.
      zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_ID'
                                    IMPORTING e_data = t_configuration ).
      IF configuration_id NE 'CONFIG_ID' AND configuration_id NE 'CONFIG_GRP'.
        DELETE t_configuration WHERE configuration_id NE configuration_id.
      ENDIF.
      IF t_configuration IS INITIAL.
        zcx_ul_handle_errors=>raise_message( iv_msg_text = |Configuration { iv_configuration_id } does not exist!| ).
        LEAVE TO SCREEN 0.
      ENDIF.
    ENDIF.

  ENDMETHOD.


  METHOD show_in_grid.

    TRY.
        DATA(type) =  NEW zcl_ul_rtts_services( iv_data = ct_data ).
      CATCH zcx_ul_handle_errors INTO _error.
        _error->show_message(  ).
    ENDTRY.

    type->get_table_inf( IMPORTING et_ddic_fields = DATA(t_ddic_fields) ).
    IF t_ddic_fields IS NOT INITIAL.
      zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_SET'
                              IMPORTING e_data = t_configuration_set ).
      DELETE t_configuration_set WHERE configuration_id NE configuration_id.
      DATA(tabname) = t_ddic_fields[ 1 ]-tabname.
      grid->lvc_fcat_from_itab( CHANGING ct_table = ct_data  ).
      grid->v_full_display = abap_true.
      grid->set_fieldtext( tabname  ).
      LOOP AT grid->t_fcat ASSIGNING FIELD-SYMBOL(<fs_fcat>).
        READ TABLE t_col_set ASSIGNING FIELD-SYMBOL(<fs_col_set>) WITH KEY fieldname = <fs_fcat>-fieldname.
        IF sy-subrc IS NOT INITIAL.
          APPEND INITIAL LINE TO t_col_set ASSIGNING <fs_col_set>.
          READ TABLE t_ddic_fields ASSIGNING FIELD-SYMBOL(<fs_ddic_field>) WITH KEY fieldname = <fs_fcat>-fieldname.
          IF sy-subrc IS INITIAL.
            <fs_col_set> = CORRESPONDING #( <fs_ddic_field> ).
            <fs_col_set>-col_pos = <fs_fcat>-col_pos.
            <fs_col_set>-outputlen = COND #( WHEN <fs_col_set>-outputlen > <fs_fcat>-outputlen THEN <fs_col_set>-outputlen ELSE <fs_fcat>-outputlen ).
            <fs_col_set>-reptext = <fs_fcat>-reptext.
            <fs_col_set>-ref_table = <fs_fcat>-ref_table.
            <fs_col_set>-ref_field = <fs_fcat>-ref_field.
          ELSE.
            <fs_col_set> = CORRESPONDING #( <fs_fcat> ).
            <fs_col_set>-outputlen = COND #( WHEN <fs_fcat>-outputlen > <fs_fcat>-dd_outlen THEN <fs_fcat>-outputlen ELSE <fs_fcat>-dd_outlen ).
          ENDIF.
          <fs_col_set>-edit = abap_true.
          IF <fs_col_set>-datatype = 'CHAR' AND <fs_ddic_field>-outputlen = 1
            AND ( <fs_col_set>-domname IS INITIAL OR <fs_col_set>-domname = 'XFELD' OR <fs_col_set>-domname = 'FLAG' ).
            <fs_col_set>-checkbox = abap_true.
          ENDIF.
        ENDIF.
        READ TABLE t_configuration_set INTO DATA(s_configuration_set) WITH KEY fieldname = <fs_fcat>-fieldname.
        IF sy-subrc IS INITIAL.
          IF s_configuration_set-textfield IS NOT INITIAL.
            <fs_col_set>-edit = abap_false.
          ENDIF.
          IF s_configuration_set-col_pos IS NOT INITIAL.
            <fs_col_set>-col_pos = s_configuration_set-col_pos.
          ENDIF.
          IF s_configuration_set-reptext IS NOT INITIAL.
            <fs_col_set>-reptext = s_configuration_set-reptext.
          ENDIF.
        ENDIF.
      ENDLOOP.
    ENDIF.

    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_ID'
                                  IMPORTING e_data = t_configuration  ).

    IF configuration_id NE 'CONFIG_GRP' AND configuration_id NE 'CONFIG_ID'.
      IF line_exists( t_configuration[ configuration_id_parent = configuration_id ] ).
        DATA(keyhot) = abap_true.
      ENDIF.
    ELSE.
      keyhot = abap_true.
    ENDIF.

    " Special case
    IF configuration_id = 'CONFIG_GRP'.
      DELETE grid->t_filter WHERE fieldname = 'CONFIGURATION_ID'.
    ENDIF.

    TRY.
        input = 0.
        IF grid->t_filter IS INITIAL.
          grid->get_filter_criteria( IMPORTING et_filter = grid->t_filter ).
        ENDIF.
        LOOP AT grid->t_filter ASSIGNING FIELD-SYMBOL(<fs_filter>).
          DATA(i) = sy-tabix.
          IF line_exists( grid->t_fcat[ fieldname = <fs_filter>-fieldname ] ).
          ELSE.
            DELETE grid->t_filter INDEX i.
          ENDIF.
        ENDLOOP.
        grid->s_layout = VALUE #( detailinit = abap_true no_merging = abap_true keyhot = keyhot cwidth_opt = abap_true ).
        grid->t_toolbar_add = VALUE #( ( icon = icon_change      function = 'CHANGE' text = 'Change<->Display' ) ).
        IF line_exists( t_configuration[ configuration_id = configuration_id log_flag = abap_true ] ).
          grid->t_toolbar_add = VALUE #( BASE grid->t_toolbar_add ( icon = icon_protocol function = 'LOG' text = 'Change Log' ) ).
        ENDIF.

        grid->display( EXPORTING iv_input = input
                                 it_col_set = configuration->t_col_set
                        CHANGING ct_data = ct_data ).

      CATCH zcx_ul_handle_errors INTO _error.
        _error->show_message(  ).
    ENDTRY.

  ENDMETHOD.


  METHOD update_screen.

    read_access( ).

*    CHECK tree IS BOUND AND app_event IS INITIAL.
*
*    IF t_tree IS NOT INITIAL.
*      _splitter_v->set_column_width( id = 1 width = 20 ).
*      _splitter_v->set_column_sash( id = 1 type = cl_gui_splitter_container=>type_sashvisible value = CONV #( cl_gui_splitter_container=>visible_true ) ).
*      tree->delete_all_nodes( ).
*      tree->add_nodes( EXPORTING node_table = t_tree table_structure_name = 'ZTB_TREELOAD' ).
*      tree->set_screen_update( abap_true ).
*      tree->set_selected_node( node_key = t_tree[ 1 ]-node_key ).
*      tree->expand_root_nodes( ).
*      configuration->event_node_changed( node_key = t_tree[ 1 ]-node_key ).
*    ELSE.
*      _splitter_v->set_column_width( id = 1 width = 0 ).
*      _splitter_v->set_column_sash( id = 1 type = cl_gui_splitter_container=>type_sashvisible value = CONV #( cl_gui_splitter_container=>visible_false ) ).
*    ENDIF.

  ENDMETHOD.


  METHOD write_change_log.

    TYPES: BEGIN OF ty_s_clause,
             line(72) TYPE c,
           END OF ty_s_clause.

    DATA: lr_data_new   TYPE REF TO data,
          lr_data_old   TYPE REF TO data,
          lr_t_data_old TYPE REF TO data,
          lr_t_data     TYPE REF TO data.

    DATA: lt_condtab      TYPE TABLE OF hrcond,
          lt_whereclauses TYPE TABLE OF ty_s_clause,
          lt_tabfield     TYPE ddfields,
          lv_objectid     TYPE cdobjectv,
          ls_data_log     TYPE zst_cdhdr,
          new             TYPE cdfldvaln,
          old             TYPE cdfldvalo,
          subrc           TYPE sy-subrc.

    FIELD-SYMBOLS: <fs_data_old> TYPE any,
                   <fs_data_new> TYPE any,
                   <ft_data_old> TYPE INDEX TABLE,
                   <ft_data_new> TYPE INDEX TABLE.

    TRY.
        DATA(type) =  NEW zcl_ul_rtts_services( iv_name = iv_tabname ).
        type->get_struct_inf( IMPORTING et_ddic_fields = lt_tabfield ).
      CATCH zcx_ul_handle_errors INTO DATA(error).
        error->show_message(  ). rv_error = abap_true. RETURN.
    ENDTRY.


    CREATE DATA lr_t_data TYPE TABLE OF (iv_tabname).
    ASSIGN lr_t_data->* TO <ft_data_new>.
    CREATE DATA lr_t_data_old TYPE TABLE OF (iv_tabname).
    ASSIGN lr_t_data_old->* TO <ft_data_old>.
    CREATE DATA lr_data_old TYPE (iv_tabname).
    ASSIGN lr_data_old TO <fs_data_old>.
    CREATE DATA lr_data_new TYPE (iv_tabname).
    ASSIGN lr_data_new TO <fs_data_new>.

    ls_data_log = VALUE #( tcode = sy-tcode udate = sy-datum utime = sy-uzeit username = sy-uname ).

    <ft_data_new> = it_data.
    LOOP AT <ft_data_new> ASSIGNING <fs_data_new>.

      CLEAR: lt_condtab, lt_whereclauses, lv_objectid.
      LOOP AT lt_tabfield INTO DATA(ls_tabfield) WHERE keyflag IS NOT INITIAL.
        CHECK ls_tabfield-fieldname NE 'MANDT' AND ls_tabfield-fieldname NE 'CLIENT'.
        ASSIGN COMPONENT ls_tabfield-fieldname OF STRUCTURE <fs_data_new> TO FIELD-SYMBOL(<fv_value>).
        lv_objectid = |{ lv_objectid }{ <fv_value> }|.
        lt_condtab = VALUE #( BASE lt_condtab ( field = ls_tabfield-fieldname opera = 'EQ' low = <fv_value> ) ).
      ENDLOOP.

      CALL FUNCTION 'RH_DYNAMIC_WHERE_BUILD'
        EXPORTING
          dbtable      = space
        TABLES
          condtab      = lt_condtab
          where_clause = lt_whereclauses.

      CHECK lt_whereclauses IS NOT INITIAL.
      SELECT FROM (iv_tabname) FIELDS * WHERE (lt_whereclauses) INTO TABLE @<ft_data_old>.
      IF sy-subrc IS NOT INITIAL.
        ls_data_log-item = VALUE #( BASE ls_data_log-item ( chngind = 'I' tabkey = lv_objectid data = /ui2/cl_json=>serialize( data = <fs_data_new> ) ) ).
      ELSE.
        READ TABLE <ft_data_old> ASSIGNING <fs_data_old> INDEX 1.
        LOOP AT lt_tabfield INTO ls_tabfield WHERE keyflag IS INITIAL.
          ASSIGN COMPONENT ls_tabfield-fieldname OF STRUCTURE <fs_data_new> TO FIELD-SYMBOL(<new>).
          ASSIGN COMPONENT ls_tabfield-fieldname OF STRUCTURE <fs_data_old> TO FIELD-SYMBOL(<old>).
          IF <new> NE <old>.
            IF ls_tabfield-datatype = 'CURR' AND ls_tabfield-reffield IS NOT INITIAL.
              ASSIGN COMPONENT ls_tabfield-reffield OF STRUCTURE <fs_data_new> TO FIELD-SYMBOL(<newref>).
              ASSIGN COMPONENT ls_tabfield-reffield OF STRUCTURE <fs_data_old> TO FIELD-SYMBOL(<oldref>).
              WRITE <new> TO new CURRENCY <newref>.
              WRITE <old> TO old CURRENCY <oldref>.
              CONDENSE: new, old.
              CONCATENATE new <newref> INTO new SEPARATED BY space.
              CONCATENATE old <oldref> INTO old SEPARATED BY space.
            ELSEIF ls_tabfield-convexit IS NOT INITIAL.
              DATA(func) = |CONVERSION_EXIT_{ ls_tabfield-convexit }_OUTPUT|.
              CALL FUNCTION func
                EXPORTING
                  input  = <new>
                IMPORTING
                  output = new.
              CALL FUNCTION func
                EXPORTING
                  input  = <old>
                IMPORTING
                  output = old.
            ELSE.
              new = <new>. old = <old>.
              CONDENSE: new, old.
            ENDIF.

            ls_data_log-item = VALUE #(
                               BASE ls_data_log-item (
                               chngind = 'U' tabkey = lv_objectid fname = ls_tabfield-fieldname ftext = ls_tabfield-fieldtext
                               value_new = new value_old = old ) ).
          ENDIF.
        ENDLOOP.
      ENDIF.

    ENDLOOP.

    IF iv_no_all IS INITIAL.
      SELECT FROM (iv_tabname) FIELDS * INTO TABLE @<ft_data_old>.
      LOOP AT <ft_data_old> ASSIGNING <fs_data_old>.
        CLEAR: lt_condtab, lt_whereclauses, lv_objectid.
        LOOP AT lt_tabfield INTO ls_tabfield WHERE keyflag IS NOT INITIAL.
          CHECK ls_tabfield-fieldname NE 'MANDT' AND ls_tabfield-fieldname NE 'CLIENT'.
          ASSIGN COMPONENT ls_tabfield-fieldname OF STRUCTURE <fs_data_old> TO <fv_value>.
          lv_objectid = |{ lv_objectid }{ <fv_value> }|.
          lt_condtab = VALUE #( BASE lt_condtab ( field = ls_tabfield-fieldname opera = 'EQ' low = <fv_value> ) ).
        ENDLOOP.

        CALL FUNCTION 'RH_DYNAMIC_WHERE_BUILD'
          EXPORTING
            dbtable      = space
          TABLES
            condtab      = lt_condtab
            where_clause = lt_whereclauses.

        DELETE <ft_data_new> WHERE (lt_whereclauses).
        IF sy-subrc IS NOT INITIAL.
          ls_data_log-item = VALUE #( BASE ls_data_log-item ( chngind = 'D' tabkey = lv_objectid data = /ui2/cl_json=>serialize( data = <fs_data_old> ) ) ).
        ENDIF.
      ENDLOOP.
    ENDIF.

    IF ls_data_log-item IS NOT INITIAL.
      zcl_ul_data_layer=>write_data( is_data = ls_data_log
      is_key = VALUE #( application = 'TBLOGGER' main_key = iv_tabname sub_key = zcl_ul_abap=>encode_timestamp( ) ) ).
    ENDIF.

  ENDMETHOD.


  METHOD zif_configuration~event_data_changed.

    LOOP AT ir_data_changed->mt_mod_cells ASSIGNING FIELD-SYMBOL(<fs_mod_cell>).

      CHECK <fs_mod_cell>-value IS NOT INITIAL.
      DATA(value) = |{ <fs_mod_cell>-value CASE = UPPER }|.

      zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_SET'
                                        IMPORTING e_data = t_configuration_set ).
      DELETE t_configuration_set WHERE configuration_id NE configuration_id.

      LOOP AT t_configuration_set INTO DATA(s_config_set) WHERE masterfield = <fs_mod_cell>-fieldname.
        DATA text TYPE text200.
        TRY.
            DATA(t_fcat) = NEW zcl_ul_rtts_services( iv_name = |{ s_config_set-texttab }| )->get_struct_inf(  ).
            IF line_exists( t_fcat[ name = 'SPRAS' ] ) AND s_config_set-textfield = abap_true.
              DATA(whereclause) = |SPRAS = '{ sy-langu }' and { <fs_mod_cell>-fieldname } = '{ value }'|.
            ELSE.
              whereclause = |{ <fs_mod_cell>-fieldname } = '{ value }'|.
            ENDIF.
          CATCH zcx_ul_handle_errors.
        ENDTRY.
        SELECT SINGLE FROM (s_config_set-texttab) FIELDS (s_config_set-fieldname) WHERE (whereclause)
        INTO @text.
        ir_data_changed->modify_cell( i_fieldname = s_config_set-fieldname i_row_id = <fs_mod_cell>-row_id i_value = text ).
      ENDLOOP.

      CASE <fs_mod_cell>-fieldname.

        WHEN 'CONFIGURATION_TYPE'.
          SELECT SINGLE FROM dd02l AS a INNER JOIN dd02t AS b
          ON a~tabname = b~tabname AND a~as4local = b~as4local
          AND a~as4vers = b~as4vers
          FIELDS b~ddtext
          WHERE a~tabname = @value AND a~as4local = 'A'
          AND a~tabclass = 'TRANSP' AND b~ddlanguage = 'E'
          INTO @DATA(tabname).
          IF sy-subrc IS INITIAL.
            ir_data_changed->modify_cell( i_fieldname = 'CONFIGURATION_TYPE_TXT' i_row_id = <fs_mod_cell>-row_id i_value = tabname ).
          ELSE.
            ir_data_changed->add_protocol_entry( i_fieldname = 'CONFIGURATION_TYPE' i_msgty = 'E' i_msgid = 'E4' i_msgno = '000' i_row_id = <fs_mod_cell>-row_id
                                                 i_msgv1 = 'Table' i_msgv2 = value i_msgv3 = 'does not exist or activate!' ).
          ENDIF.
        WHEN 'CONFIGURATION_CLASS'.
          DATA class TYPE vseoclass.
          CALL FUNCTION 'SEO_CLASS_GET'
            EXPORTING
              clskey       = VALUE seoclskey( clsname = value )
            IMPORTING
              class        = class
            EXCEPTIONS
              deleted      = 1
              is_interface = 2
              model_only   = 3
              not_existing = 4.
          IF sy-subrc IS NOT INITIAL.
            ir_data_changed->add_protocol_entry( i_fieldname = 'CONFIGURATION_CLASS' i_msgty = 'E' i_msgid = sy-msgid i_msgno = sy-msgno i_row_id = <fs_mod_cell>-row_id
                                                 i_msgv1 = sy-msgv1 i_msgv2 = sy-msgv2 i_msgv3 = sy-msgv3 i_msgv4 = sy-msgv4 ).
            ir_data_changed->modify_cell( i_fieldname = 'CONFIGURATION_CLASS_TXT' i_row_id = <fs_mod_cell>-row_id
                                          i_value = space ).
          ELSE.
            ir_data_changed->modify_cell( i_fieldname = 'CONFIGURATION_CLASS_TXT' i_row_id = <fs_mod_cell>-row_id
                                          i_value = class-descript ).
          ENDIF.
*        WHEN 'TEXTFIELD'.
*          IF value IS NOT INITIAL.
*            ir_data_changed->ms_layout-stylefname = 'STYLETAB'.
*            ir_data_changed->modify_style( i_fieldname = 'TEXTTAB' i_row_id = <fs_mod_cell>-row_id i_style = zcl_ul_alv_adapter=>mc_style_enabled ).
*            ir_data_changed->modify_style( i_fieldname = 'MASTERFIELD' i_row_id = <fs_mod_cell>-row_id i_style = zcl_ul_alv_adapter=>mc_style_enabled ).
*          ELSE.
*            ir_data_changed->modify_style( i_fieldname = 'TEXTTAB' i_row_id = <fs_mod_cell>-row_id i_style = zcl_ul_alv_adapter=>mc_style_disabled ).
*            ir_data_changed->modify_style( i_fieldname = 'MASTERFIELD' i_row_id = <fs_mod_cell>-row_id i_style = zcl_ul_alv_adapter=>mc_style_disabled ).
*          ENDIF.
        WHEN 'DBCLICK'.
          IF value IS NOT INITIAL.
            ir_data_changed->ms_layout-stylefname = 'STYLETAB'.
            ir_data_changed->modify_style( i_fieldname = 'OBJECTTYPE' i_row_id = <fs_mod_cell>-row_id i_style = zcl_ul_alv_adapter=>mc_style_enabled ).
            ir_data_changed->modify_style( i_fieldname = 'OBJECTNAME' i_row_id = <fs_mod_cell>-row_id i_style = zcl_ul_alv_adapter=>mc_style_enabled ).
          ELSE.
            ir_data_changed->modify_style( i_fieldname = 'OBJECTTYPE' i_row_id = <fs_mod_cell>-row_id i_style = zcl_ul_alv_adapter=>mc_style_disabled ).
            ir_data_changed->modify_style( i_fieldname = 'OBJECTNAME' i_row_id = <fs_mod_cell>-row_id i_style = zcl_ul_alv_adapter=>mc_style_disabled ).
          ENDIF.

      ENDCASE.
    ENDLOOP.

    changed_protocol = ir_data_changed.

  ENDMETHOD.


  METHOD zif_configuration~event_data_saved.

    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.
    FIELD-SYMBOLS <ft_old_data> TYPE STANDARD TABLE.
    DATA lr_old_data TYPE REF TO data.
    DATA cross_client TYPE ccnocliind.

    grid->check_changed_data( ).
    CALL FUNCTION 'TR_SYS_PARAMS'
      IMPORTING
        sys_cliinddep_edit = cross_client.

    ASSIGN ir_data->* TO <ft_data>.
    IF <ft_data> IS ASSIGNED.

      READ TABLE t_configuration INTO DATA(s_configuration) WITH KEY configuration_id = configuration_id.
      IF s_configuration-transport_flag IS NOT INITIAL OR ( s_configuration IS INITIAL AND cross_client NE '2' ).
        _transport( tabname = s_configuration-configuration_type data_tab = <ft_data> configuration_id = configuration_id  ).
        IF _error->has_messages( ) IS NOT INITIAL.
          RAISE EXCEPTION _error.
        ENDIF.
      ENDIF.

      IF s_configuration-configuration_type IS NOT INITIAL.

        IF s_configuration-backup_flag IS NOT INITIAL OR s_configuration-log_flag IS NOT INITIAL.
          CREATE DATA lr_old_data TYPE TABLE OF (s_configuration-configuration_type).
          ASSIGN lr_old_data->* TO <ft_old_data>.
          SELECT FROM (s_configuration-configuration_type) FIELDS * INTO TABLE @<ft_old_data>.
          IF s_configuration-backup_flag IS NOT INITIAL AND <ft_data> NE <ft_old_data>.
            zcl_ul_data_layer=>write_data( is_data = <ft_old_data> is_key = VALUE #( application = 'TBBACKUP' main_key = s_configuration-configuration_type
                                                                                     sub_key = |{ zcl_ul_abap=>encode_timestamp( ) }| ) ).
          ENDIF.
          IF s_configuration-log_flag IS NOT INITIAL.
            IF write_change_log( iv_tabname = CONV #( s_configuration-configuration_type ) it_data = <ft_data> ) IS NOT INITIAL.
              _error->add_text( iv_message = 'No data saved!' ).
              RAISE EXCEPTION _error.
            ENDIF.
          ENDIF.
        ENDIF.

        DELETE FROM (s_configuration-configuration_type).
        MODIFY (s_configuration-configuration_type) FROM TABLE <ft_data>.
        IF sy-subrc IS NOT INITIAL.
          _error->add_system_message(  ).
          RAISE EXCEPTION _error.
        ELSE.
          COMMIT WORK AND WAIT.
        ENDIF.

      ELSE.

        zcl_ul_data_layer=>write_data( is_data = <ft_data> is_key = VALUE #( application = 'DYNAMICSET' main_key = configuration_id ) ).

      ENDIF.

      IF sy-subrc IS NOT INITIAL.
        _error->add_system_message(  ).
        RAISE EXCEPTION _error.
      ENDIF.

    ELSE.

      _error->add_text( iv_message = 'No data saved!' ).
      RAISE EXCEPTION _error.

    ENDIF.

  ENDMETHOD.


  METHOD zif_configuration~event_double_click.

    ASSIGN COMPONENT fieldname OF STRUCTURE data TO FIELD-SYMBOL(<value>).

    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_SET'
                                         IMPORTING e_data = t_configuration_set ).
    DELETE t_configuration_set WHERE configuration_id NE configuration_id.
    READ TABLE t_configuration_set INTO DATA(s_config_set) WITH KEY fieldname = fieldname.
    CHECK sy-subrc IS INITIAL.
    IF s_config_set-objecttype = zcl_ul_tree_display=>c_node_txtedit.
      DATA t_text TYPE hrpad_t_texteditor.
      DATA changed TYPE flag.
      zcl_ul_abap=>string_to_text_table( EXPORTING iv_string = CONV #( <value> )
                                         IMPORTING et_text   = t_text ).
      CALL FUNCTION 'HR_CALL_TEXTEDITOR'
        IMPORTING
          change_made = changed
        CHANGING
          editor_text = t_text
        EXCEPTIONS
          OTHERS      = 1.
      IF sy-subrc IS NOT INITIAL.
        zcx_ul_handle_errors=>raise_message( ).
      ENDIF.
      IF changed IS NOT INITIAL AND input = 1.
        DATA ftext TYPE string.
        CALL FUNCTION 'SCMS_FTEXT_TO_STRING'
          EXPORTING
            length    = 999999
          IMPORTING
            ftext     = ftext
          TABLES
            ftext_tab = t_text.
        <value> = ftext.
      ENDIF.
    ELSEIF s_config_set-objecttype IS NOT INITIAL.
      zcl_ul_tree_display=>navigate_to_object( iv_access_type = s_config_set-objecttype iv_object = CONV #( <value> ) ).
      RETURN.
    ENDIF.

    CASE fieldname.
      WHEN 'CONFIGURATION_CLASS'.
        IF /bobf/cl_conf_toolbox=>class_exists( <value> ) = abap_false.
          CHECK zcl_ul_abap=>popup_to_confirm( |Class { <value> } does not exist! Do you want to create?| ) = '1'.
          create_class_with_interface( classname = <value> interface = 'ZIF_CONFIGURATION' ).
        ELSE.
          CALL FUNCTION 'RS_TOOL_ACCESS'
            EXPORTING
              operation           = 'SHOW'
              object_name         = <value>
              object_type         = 'CLAS'
            EXCEPTIONS
              not_executed        = 1
              invalid_object_type = 2
              OTHERS              = 3.
          IF sy-subrc IS NOT INITIAL.
            zcx_ul_handle_errors=>raise_message( ).
          ENDIF.
        ENDIF.
      WHEN 'CONFIGURATION_TYPE'.
        CALL FUNCTION 'RS_DD_FIEL_SHOW'
          EXPORTING
            objname              = CONV ddobjname( <value> )
          EXCEPTIONS
            not_executed         = 1
            object_not_found     = 2
            object_not_specified = 3
            permission_failure   = 4
            OTHERS               = 5.
        IF sy-subrc IS NOT INITIAL.
          zcx_ul_handle_errors=>raise_message( ).
        ENDIF.
    ENDCASE.

  ENDMETHOD.


  METHOD zif_configuration~event_node_changed.

    DATA: configure    TYPE REF TO zif_configuration,
          handle_class TYPE REF TO object.

    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.
    FREE grid->t_filter.
    grid->set_filter_criteria( grid->t_filter ).
    ASSIGN data->* TO <ft_data>.

    _get_nodekey( ).
    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_ID'
                                  IMPORTING e_data = t_configuration  ).
    READ TABLE t_configuration INTO DATA(ls_configuration) WITH KEY configuration_id = node_key.

    IF ls_configuration-configuration_class IS NOT INITIAL.
      CREATE OBJECT handle_class TYPE (ls_configuration-configuration_class).
      ASSIGN handle_class->('ZIF_CONFIGURATION~SENDER') TO FIELD-SYMBOL(<me>).
      <me> = me.
      CALL METHOD handle_class->('ZIF_CONFIGURATION~REGISTER_INTERFACE').
      ASSIGN handle_class->('ZIF_CONFIGURATION~DATA->*') TO <ft_data>.
      configuration ?= handle_class.
    ELSEIF ls_configuration-configuration_type IS NOT INITIAL.
      CREATE DATA data TYPE TABLE OF (ls_configuration-configuration_type).
    ELSE.
      configuration->register_interface(  ).
      configuration->sender = me.
    ENDIF.

    app_event = abap_true.

  ENDMETHOD.


  METHOD zif_configuration~register_interface.

    REFRESH t_col_set.
    IF configuration_id = 'CONFIG_ID'.
      CREATE DATA data TYPE STANDARD TABLE OF ty_dynamic_configuration.
      t_col_set = VALUE #( ( fieldname = 'CONFIGURATION_GROUP'       reptext = 'Configuration Group'        key = abap_true   edit = abap_true )
                           ( fieldname = 'CONFIGURATION_ID'          reptext = 'Configuration ID'           key = abap_true   edit = abap_true )
                           ( fieldname = 'CONFIGURATION_TXT'         reptext = 'Configuration Description'                    edit = abap_true )
                           ( fieldname = 'CONFIGURATION_ID_PARENT'   reptext = 'Configuration Parent'                         edit = abap_true )
                           ( fieldname = 'CONFIGURATION_TYPE'        reptext = 'Configuration Table'                          edit = abap_true )
                           ( fieldname = 'CONFIGURATION_TYPE_TXT'    reptext = 'Configuration Table Description'  )
                           ( fieldname = 'CONFIGURATION_CLASS'       reptext = 'Configuration Handling Class'                 edit = abap_true )
                           ( fieldname = 'CONFIGURATION_CLASS_TXT'   reptext = 'Configuration Class Description' )
                           ( fieldname = 'TRANSPORT_FLAG'            reptext = 'Transport'  checkbox = abap_true               edit = abap_true )
                           ( fieldname = 'BACKUP_FLAG'               reptext = 'Backup'     checkbox = abap_true               edit = abap_true )
                           ( fieldname = 'LOG_FLAG'                  reptext = 'Write Log'  checkbox = abap_true               edit = abap_true )
                           ).
    ELSEIF configuration_id = 'CONFIG_GRP'.
      CREATE DATA data TYPE STANDARD TABLE OF ty_configuration_group.
      t_col_set = VALUE #( ( fieldname = 'CONFIGURATION_GROUP'       reptext = 'Configuration Group'        key = abap_true   edit = abap_true )
                           ( fieldname = 'CONFIGURATION_GROUP_TXT'   reptext = 'Configuration Description'                    edit = abap_true ) ).
    ELSEIF configuration_id = 'CONFIG_SET'.
      CREATE DATA data TYPE STANDARD TABLE OF ty_configuration_set.
      t_col_set = VALUE #( ( fieldname = 'CONFIGURATION_GROUP'       reptext = 'Configuration Group'        key = abap_true   edit = abap_true )
                           ( fieldname = 'CONFIGURATION_ID'          reptext = 'Configuration ID'           key = abap_true   edit = abap_true )
                           ( fieldname = 'FIELDNAME'                 reptext = 'Field Name'                 key = abap_true   edit = abap_true )
                           ( fieldname = 'COL_POS'                   reptext = 'Column Position'                              edit = abap_true )
                           ( fieldname = 'REPTEXT'                   reptext = 'Field Description'                            edit = abap_true )
                           ( fieldname = 'TEXTFIELD'                 reptext = 'Text Field'                 checkbox = abap_true  edit = abap_true )
                           ( fieldname = 'TEXTTAB'                   reptext = 'Reference Table'            edit = abap_true )
                           ( fieldname = 'MASTERFIELD'               reptext = 'Master Field'               edit = abap_true )
                           ( fieldname = 'DBCLICK'                   reptext = 'Double Click'               checkbox = abap_true  edit = abap_true )
                           ( fieldname = 'OBJECTTYPE'                reptext = 'Navigation Type'            drdn_alias = abap_true drdn_hndl = '1'  ) ).
      TRY.
          DATA(t_objects) = NEW zcl_ul_rtts_services( iv_name = 'ZACC_TYPE' )->get_fix_values(  ).
          DATA(t_dral) = VALUE lvc_t_dral( FOR s_object IN t_objects ( handle = '1' int_value = s_object-low value = |{ s_object-low } { s_object-ddtext }| ) ).
        CATCH zcx_ul_handle_errors.
      ENDTRY.
      grid->set_drop_down_table( it_drop_down_alias = t_dral ).
    ELSE.
      DATA(s_configuration) = t_configuration[ configuration_id = configuration_id ].
      IF s_configuration-configuration_type IS INITIAL.
        IF s_configuration-configuration_class IS INITIAL.
          zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = configuration_id
                                        IMPORTING e_data = t_configuration_set ).
          IF t_configuration_set IS INITIAL.
            zcx_ul_handle_errors=>raise_message( iv_msg_text = 'Please using a handling class or setting display option!' ).
            RETURN.
          ELSE.
            t_col_set = VALUE #( FOR s_config_set IN t_configuration_set ( fieldname = s_config_set-fieldname reptext = s_config_set-reptext ) ).
          ENDIF.
        ENDIF.
      ELSE.
        TRY.
            CREATE DATA data TYPE TABLE OF (s_configuration-configuration_type).
          CATCH cx_sy_create_data_error INTO DATA(cx_data_error).
            _error->add_exception_object( cx_data_error ).
        ENDTRY.
      ENDIF.
    ENDIF.

    CHECK t_tree IS INITIAL.
    IF t_configuration_group IS NOT INITIAL.
      LOOP AT t_configuration ASSIGNING FIELD-SYMBOL(<fs_configuration>).
        IF line_exists( t_configuration[ configuration_id_parent = <fs_configuration>-configuration_id ] ).
          DATA(is_folder) = abap_true.
          DATA(n_image)   = icon_folder.
        ELSE.
          is_folder = abap_false.
          n_image   = icon_execute_object.
        ENDIF.
        t_tree = VALUE #( BASE t_tree ( node_key = <fs_configuration>-configuration_id relatkey = <fs_configuration>-configuration_id_parent
                                        text = <fs_configuration>-configuration_txt isfolder = is_folder n_image = n_image ) ).
      ENDLOOP.
    ELSEIF t_configuration IS INITIAL.
      t_tree = VALUE #( ( node_key = 'CONFIG_GRP' text = 'Configuration Group' isfolder = abap_true )
                        ( node_key = 'CONFIG_ID' relatkey = 'CONFIG_GRP' text = 'Configuration ID' isfolder = abap_true n_image = icon_folder )
                        ( node_key = 'CONFIG_SET' relatkey = 'CONFIG_ID' text = 'Configuration Setting' n_image = icon_execute_object  )    ).
    ENDIF.

  ENDMETHOD.


  METHOD _get_nodekey.

    IF tree IS BOUND.
      cl_gui_cfw=>flush( ).
      tree->get_selected_node( IMPORTING node_key = DATA(node_key) ).
      IF node_key IS NOT INITIAL.
        configuration_id = node_key.
      ENDIF.
    ENDIF.

  ENDMETHOD.


  METHOD _transport.

    DATA t_e071  TYPE tr_objects.
    DATA t_e071k TYPE tr_keys.
    DATA request_type TYPE c LENGTH 2.
    DATA cross_client TYPE ccnocliind.

    IF tabname IS NOT INITIAL.
      LOOP AT data_tab ASSIGNING FIELD-SYMBOL(<data>).
        DATA(tab_key) = zcl_ul_abap=>build_key( iv_add_client = abap_true is_data = <data> ).
        IF t_e071 IS INITIAL.
          DATA(s_e071) = VALUE e071( pgmid = 'R3TR' object = 'TABU' obj_name = tabname objfunc = 'K' ).
          APPEND s_e071 TO t_e071.
        ENDIF.
        t_e071k = VALUE #( BASE t_e071k ( mastertype = s_e071-object mastername = s_e071-obj_name pgmid = 'R3TR' object = 'TABU' objname = s_e071-obj_name tabkey = tab_key ) ).
      ENDLOOP.
    ELSE.
      SELECT SINGLE FROM ztb_data_layer FIELDS * WHERE application = 'DYNAMICSET' AND main_key = @configuration_id INTO @DATA(s_data).
      IF s_data IS NOT INITIAL.
        tab_key = zcl_ul_abap=>build_key( iv_add_client = abap_true is_data = s_data ).
      ELSE.
        tab_key = |{ sy-mandt }DYNAMICSET{ configuration_id }|.
      ENDIF.
      s_e071 = VALUE e071( pgmid = 'R3TR' object = 'TABU' obj_name = 'ZTB_DATA_LAYER' objfunc = 'K' ).
      APPEND s_e071 TO t_e071.
      t_e071k = VALUE #( BASE t_e071k ( mastertype = s_e071-object mastername = s_e071-obj_name pgmid = 'R3TR' object = 'TABU' objname = s_e071-obj_name tabkey = tab_key ) ).
    ENDIF.

    CALL FUNCTION 'TR_SYS_PARAMS'
      IMPORTING
        sys_cliinddep_edit = cross_client.
    request_type = SWITCH #( cross_client WHEN '' THEN 'K' WHEN '2' THEN 'W' ELSE 'WK' ).

    CALL FUNCTION 'TR_REQUEST_CHOICE'
      EXPORTING
        iv_request_types     = request_type
        it_e071              = t_e071
        it_e071k             = t_e071k
        iv_title             = 'Transport data'
      EXCEPTIONS
        invalid_request      = 1
        invalid_request_type = 2
        user_not_owner       = 3
        no_objects_appended  = 4
        enqueue_error        = 5
        cancelled_by_user    = 6
        recursive_call       = 7
        OTHERS               = 8.

    IF sy-subrc <> 0.
      _error->add_system_message( ).
    ELSE.
      MESSAGE 'Create transport objects sucessfully!' TYPE 'S'.
    ENDIF.

  ENDMETHOD.
ENDCLASS.
