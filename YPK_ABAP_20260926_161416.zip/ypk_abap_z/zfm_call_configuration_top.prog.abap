*&---------------------------------------------------------------------*
*&  Include           ZFM_CALL_CONFIGURATION_TOP
*&---------------------------------------------------------------------*

DATA: configuration_group TYPE text10,
      configuration_id    TYPE text20,
      o_configure   TYPE REF TO zcl_ul_dynamic_configuration,
      o_container   TYPE REF TO cl_gui_container.
