*&---------------------------------------------------------------------*
*& Report ZPG_KB_CREATE
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zpg_kb_create.

INCLUDE zpg_kb_create_top.
INCLUDE zpg_kb_create_cls.
INCLUDE zpg_kb_create_pbo.
INCLUDE zpg_kb_create_pai.

INITIALIZATION.
  gs_fcode = VALUE #( icon_id = icon_create icon_text = 'Create' ).
  sscrfields-functxt_01 = gs_fcode.
  gs_fcode = VALUE #( icon_id = icon_change icon_text = 'Change' ).
  sscrfields-functxt_02 = gs_fcode.
  gs_fcode = VALUE #( icon_id = icon_display icon_text = 'Display' ).
  sscrfields-functxt_03 = gs_fcode.
