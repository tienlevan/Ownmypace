*&---------------------------------------------------------------------*
*&  Include           ZPG_INS_USER_ROLES_TOP
*&---------------------------------------------------------------------*
TABLES: usgrp_user.
CONSTANTS: gc_act_create TYPE char2 VALUE '01',
           gc_act_change TYPE char2 VALUE '02',
           gc_act_role   TYPE char2 VALUE '03',
           gc_act_matrix TYPE char2 VALUE '04',
           gc_act_tcode  TYPE char2 VALUE '05',
           gc_act_restr  TYPE char2 VALUE '06'.

DATA: gv_role     TYPE agr_name,
      gt_position TYPE vrm_values.

SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
PARAMETERS: p_action TYPE char2 AS LISTBOX OBLIGATORY VISIBLE LENGTH 20 USER-COMMAND act MODIF ID m0.
SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-002.
PARAMETERS: p_file TYPE rlgrap-filename MODIF ID fm.
PARAMETERS: p_delete TYPE char10 MODIF ID m1,
            p_add    TYPE checkbox AS CHECKBOX MODIF ID m1.
SELECTION-SCREEN END OF BLOCK b2.

SELECTION-SCREEN BEGIN OF BLOCK b3 WITH FRAME TITLE TEXT-003.
PARAMETERS: p_user  TYPE sy-uname OBLIGATORY MODIF ID m2,
            p_name  TYPE ad_namelas OBLIGATORY MODIF ID m2,
            p_email TYPE ad_smtpadr OBLIGATORY MODIF ID m2,
            p_comm  TYPE text100 MODIF ID m2,
            r_refus TYPE flag_co RADIOBUTTON GROUP r1 MODIF ID m2 DEFAULT 'X' USER-COMMAND c1,
            r_post  TYPE flag_co RADIOBUTTON GROUP r1 MODIF ID m2,
            p_refus TYPE sy-uname MODIF ID m4,
            p_dept  TYPE zdd_posgr MODIF ID m5,
            p_post  TYPE ztb_set_roles-posid AS LISTBOX VISIBLE LENGTH 30 MODIF ID m5.
SELECT-OPTIONS: s_addrl FOR gv_role NO INTERVALS MODIF ID m5.
SELECTION-SCREEN END OF BLOCK b3.

SELECTION-SCREEN BEGIN OF BLOCK b4 WITH FRAME TITLE TEXT-004.
SELECT-OPTIONS: s_role FOR gv_role NO INTERVALS MODIF ID m3,
                s_user FOR sy-uname NO INTERVALS MODIF ID m3,
                s_usgr FOR usgrp_user-usergroup NO INTERVALS MODIF ID m3.
SELECTION-SCREEN END OF BLOCK b4.

SELECTION-SCREEN BEGIN OF BLOCK b5 WITH FRAME TITLE TEXT-005.
SELECT-OPTIONS: s_user_c FOR sy-uname NO INTERVALS MODIF ID m6.
PARAMETERS: p_pass   TYPE xuncode MODIF ID m6,
            p_prod   TYPE checkbox AS CHECKBOX MODIF ID m6,
            p_post_a TYPE ztb_set_roles-posid AS LISTBOX VISIBLE LENGTH 30 MODIF ID m6.
SELECT-OPTIONS: s_role_a FOR gv_role NO INTERVALS MODIF ID m6.
SELECTION-SCREEN END OF BLOCK b5.

SELECTION-SCREEN BEGIN OF BLOCK b6 WITH FRAME TITLE TEXT-006.
SELECT-OPTIONS: s_role_1 FOR gv_role  NO INTERVALS MODIF ID m7,
                s_tcode  FOR sy-tcode NO INTERVALS MODIF ID m7.
SELECTION-SCREEN END OF BLOCK b6.

SELECTION-SCREEN BEGIN OF BLOCK b7 WITH FRAME TITLE TEXT-008.
PARAMETERS: p_dept_n  TYPE zdd_posgr OBLIGATORY MODIF ID m8.
SELECTION-SCREEN END OF BLOCK b7.
