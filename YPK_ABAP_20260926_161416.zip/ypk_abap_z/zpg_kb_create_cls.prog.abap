*&---------------------------------------------------------------------*
*&  Include  zpg_kb_create_cls
*&---------------------------------------------------------------------*
CLASS v_alv DEFINITION INHERITING FROM zcl_ul_alv_adapter.

  PROTECTED SECTION.
    METHODS: mine_double_click REDEFINITION,
      mine_data_changed REDEFINITION.

ENDCLASS.

CLASS view DEFINITION.
  PUBLIC SECTION.
    DATA: v_symp   TYPE REF TO cl_gui_textedit,
          v_resol  TYPE REF TO cl_gui_textedit,
          v_impact TYPE REF TO v_alv.

    METHODS: constructor,
      set_text_status.

ENDCLASS.

CLASS model DEFINITION.
  PUBLIC SECTION.
    DATA t_impacts TYPE TABLE OF ztb_kb_impact.
    METHODS: constructor.

ENDCLASS.


CLASS control DEFINITION.
  PUBLIC SECTION.
    DATA: view  TYPE REF TO view,
          model TYPE REF TO model.

    METHODS: constructor.

ENDCLASS.

CLASS app DEFINITION.
  PUBLIC SECTION.
    CLASS-DATA: control TYPE REF TO control.
    CLASS-METHODS: start, save, free.

ENDCLASS.

CLASS v_alv IMPLEMENTATION.

  METHOD mine_double_click.

    FIELD-SYMBOLS <ft_data> LIKE gt_impacts.

    CHECK e_column-fieldname = 'OBJVALUE'.
    ASSIGN mt_outtab->* TO <ft_data>.
    READ TABLE <ft_data> ASSIGNING FIELD-SYMBOL(<fs_data>) INDEX e_row-index.
    zcl_ul_tree_display=>navigate_to_object( iv_access_type = <fs_data>-acc_type iv_object = CONV #( <fs_data>-objvalue ) iv_line = <fs_data>-line ).

  ENDMETHOD.

  METHOD mine_data_changed.

    FIELD-SYMBOLS <ft_mod> LIKE gt_impacts.
    DATA objvalue TYPE text255.
    ASSIGN er_data_changed->mp_mod_rows->* TO <ft_mod>.

    LOOP AT <ft_mod> ASSIGNING FIELD-SYMBOL(<fs_mod>).

      IF <fs_mod>-acc_type IS INITIAL.
        er_data_changed->refresh_protocol( ).
      ENDIF.

      IF <fs_mod>-acc_type IS NOT INITIAL AND <fs_mod>-objvalue IS NOT INITIAL.
        objvalue = <fs_mod>-objvalue.
        <fs_mod>-objdesc = zcl_ul_tree_display=>set_default_text( EXPORTING iv_acc_type = <fs_mod>-acc_type
                                                                  CHANGING  cv_value = objvalue ).
        er_data_changed->modify_cell( i_fieldname = 'OBJDESC' i_value = <fs_mod>-objdesc i_row_id = er_data_changed->mt_mod_cells[ 1 ]-row_id ).
      ENDIF.

    ENDLOOP.

  ENDMETHOD.

ENDCLASS.


CLASS view IMPLEMENTATION.

  METHOD constructor.

    v_symp = NEW #( parent = CAST #( NEW cl_gui_custom_container( container_name = 'CON_SYMP' ) )
                    wordwrap_mode = cl_gui_textedit=>wordwrap_at_windowborder
                    wordwrap_to_linebreak_mode = cl_gui_textedit=>true ).
    v_symp->set_toolbar_mode( 0 ).
    v_symp->set_statusbar_mode( 0 ).
    v_symp->set_readonly_mode( SWITCH #( gv_mode WHEN gc_mode_display THEN 1 ELSE 0 ) ).
    v_symp->set_textstream( gs_note-symptom ).

    v_resol = NEW #( parent = CAST #( NEW cl_gui_custom_container( container_name = 'CON_RESOL' ) )
                    wordwrap_mode = cl_gui_textedit=>wordwrap_at_windowborder
                    wordwrap_to_linebreak_mode = cl_gui_textedit=>true ).
    v_resol->set_toolbar_mode( 0 ).
    v_resol->set_statusbar_mode( 0 ).
    v_resol->set_readonly_mode( SWITCH #( gv_mode WHEN gc_mode_display THEN 1 ELSE 0 ) ).
    v_resol->set_textstream( gs_note-resolution ).

    v_impact ?= v_alv=>create( EXPORTING io_parent = CAST #( NEW cl_gui_custom_container( container_name = 'CON_IMPC' ) )
                                                      ir_local_class = cl_abap_classdescr=>describe_by_name( 'V_ALV' ) ).
    v_impact->s_layout = VALUE #( no_vgridln = abap_true ).
    TRY.
        v_impact->display( EXPORTING iv_auto_hide = abap_true
                                     iv_input = SWITCH #( gv_mode WHEN gc_mode_display THEN 0 ELSE 1 )
                                     it_col_set = VALUE #( ( fieldname = 'ACC_TYPE' outputlen = 10 edit = abap_true )
                                                           ( fieldname = 'OBJVALUE' reptext = 'Object' outputlen = 30 edit = abap_true )
                                                           ( fieldname = 'OBJDESC'  reptext = 'Name' outputlen = 30 )
                                                           ( fieldname = 'LINE'     reptext = 'Line' edit = abap_true ) )
                          CHANGING ct_data = gt_impacts ).
      CATCH zcx_ul_handle_errors INTO DATA(cx_error).
        cx_error->show_message( ).
    ENDTRY.

  ENDMETHOD.

  METHOD set_text_status.

    v_symp->set_readonly_mode( SWITCH #( gv_mode WHEN gc_mode_display THEN 1 ELSE 0 ) ).
    v_resol->set_readonly_mode( SWITCH #( gv_mode WHEN gc_mode_display THEN 1 ELSE 0 ) ).
    v_impact->set_ready_for_input( SWITCH #( gv_mode WHEN gc_mode_display THEN 0 ELSE 1 ) ).

  ENDMETHOD.

ENDCLASS.

CLASS control IMPLEMENTATION.

  METHOD constructor.

    CREATE OBJECT model.
    CREATE OBJECT view.

  ENDMETHOD.

ENDCLASS.

CLASS model IMPLEMENTATION.

  METHOD constructor.

    CHECK gv_mode NE gc_mode_create.
    SELECT SINGLE FROM ztb_kb_notes FIELDS * WHERE noteid = @p_noteid INTO CORRESPONDING FIELDS OF @gs_note.
    IF sy-subrc IS NOT INITIAL.
      MESSAGE |Note { p_noteid } does not exist!| TYPE 'S' DISPLAY LIKE 'E'.
      LEAVE TO SCREEN 0.
    ENDIF.

    SELECT FROM ztb_kb_impact FIELDS * WHERE noteid = @p_noteid INTO CORRESPONDING FIELDS OF TABLE @gt_impacts.


  ENDMETHOD.

ENDCLASS.

CLASS app IMPLEMENTATION.

  METHOD start.

    CHECK control IS NOT BOUND.
    CREATE OBJECT control.

  ENDMETHOD.

  METHOD save.

    DATA t_string TYPE TABLE OF string.

    TRY.
        IF gs_note-noteid IS INITIAL.
          gs_note-noteid = zcl_ul_abap=>get_next_number( iv_number_range = '99' iv_object = 'ZREQID' ).
          gs_note-created_by = sy-uname.
          gs_note-created_on = zcl_ul_abap=>encode_timestamp( ).
        ELSE.
          gs_note-changed_by = sy-uname.
          gs_note-changed_on = zcl_ul_abap=>encode_timestamp( ).
        ENDIF.

        control->view->v_symp->get_textstream( IMPORTING text = gs_note-symptom ).
        control->view->v_resol->get_textstream( IMPORTING text = gs_note-resolution ).
        cl_gui_cfw=>flush( ).

        MODIFY ztb_kb_notes FROM gs_note.

        LOOP AT gt_impacts ASSIGNING FIELD-SYMBOL(<fs_impact>).
          <fs_impact>-item = sy-tabix.
          <fs_impact>-noteid = gs_note-noteid.
        ENDLOOP.

        DELETE FROM ztb_kb_impact WHERE noteid = gs_note-noteid.
        MODIFY ztb_kb_impact FROM TABLE gt_impacts.

        CHECK sy-subrc IS INITIAL.
        MESSAGE |Note { gs_note-noteid } was saved!| TYPE 'S'.

      CATCH zcx_ul_handle_errors INTO DATA(cx_error).
        cx_error->show_message( ).
    ENDTRY.

  ENDMETHOD.

  METHOD free.

    app=>control->view->v_symp->parent->free( ).
    app=>control->view->v_resol->parent->free( ).
    app=>control->view->v_impact->parent->free( ).

    FREE app=>control.
    FREE gs_note.
    FREE gt_impacts.

  ENDMETHOD.

ENDCLASS.
