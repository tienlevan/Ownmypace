*&---------------------------------------------------------------------*
*& Include          ZFM_INS_FILE_ATTACHMENT_TOP
*&---------------------------------------------------------------------*
DATA: gv_key TYPE /plmb/swo_typeid,
      gv_key_old TYPE /plmb/swo_typeid,
      gv_object_type TYPE zacc_type,
      gv_object_address TYPE char100,
      gs_node TYPE ztb_treeload,
      gv_supplied TYPE boolean,
      gv_module TYPE tl12,
      gv_status TYPE char2,
      gt_status TYPE TABLE OF ztb_file_status,
      gv_exist TYPE boolean.

DATA: go_file TYPE REF TO zcl_ul_tree_display,
      gt_tree_load TYPE TABLE OF ztb_treeload.
