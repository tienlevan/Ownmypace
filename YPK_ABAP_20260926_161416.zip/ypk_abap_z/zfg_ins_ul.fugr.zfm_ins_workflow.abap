FUNCTION zfm_ins_workflow.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IV_OBJNR) TYPE  SWO_TYPEID
*"     REFERENCE(IV_POPUP) TYPE  BOOLE_D OPTIONAL
*"----------------------------------------------------------------------

  gv_objnr = iv_objnr.

  IF iv_popup IS NOT INITIAL.
    CALL SCREEN '0502' STARTING AT 5 5.
  ENDIF.


ENDFUNCTION.
