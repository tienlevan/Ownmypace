class ZCL_UL_DATA_LAYER definition
  public
  final
  create protected
  shared memory enabled

  global friends ZCB_UL_DATA_LAYER .

public section.

  interfaces IF_OS_STATE .
  interfaces IF_SHM_BUILD_INSTANCE .

  aliases GET
    for IF_OS_STATE~GET .
  aliases HANDLE_EXCEPTION
    for IF_OS_STATE~HANDLE_EXCEPTION .
  aliases INIT
    for IF_OS_STATE~INIT .
  aliases INVALIDATE
    for IF_OS_STATE~INVALIDATE .
  aliases SET
    for IF_OS_STATE~SET .
  aliases CHANGED
    for IF_OS_STATE~CHANGED .
  aliases READ_ACCESS
    for IF_OS_STATE~READ_ACCESS .
  aliases WRITE_ACCESS
    for IF_OS_STATE~WRITE_ACCESS .

  methods GET_APPLICATION
    returning
      value(RESULT) type ZZ_DD_APP
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_DATA
    returning
      value(RESULT) type CRMT_TEXT_VALUE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_MAIN_KEY
    returning
      value(RESULT) type TEXT20
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods GET_SUB_KEY
    returning
      value(RESULT) type TEXT40
    raising
      CX_OS_OBJECT_NOT_FOUND .
  methods SET_DATA
    importing
      !I_DATA type CRMT_TEXT_VALUE
    raising
      CX_OS_OBJECT_NOT_FOUND .
  class-methods READ_DATA
    importing
      !IV_APPLICATION type ZTB_DATA_LAYER-APPLICATION
      !IV_MAINKEY type ZTB_DATA_LAYER-MAIN_KEY optional
      !IV_SUBKEY type ZTB_DATA_LAYER-SUB_KEY optional
      !IV_SKIP_MESSAGE type BOOLE_D default ABAP_TRUE
    exporting
      !E_DATA type ANY
    returning
      value(RV_DATA) type STRING .
  class-methods WRITE_DATA
    importing
      !IS_KEY type ZTB_DATA_LAYER
      !IS_DATA type ANY optional .
  class-methods DELETE_DATA
    importing
      !IV_APPLICATION type ZTB_DATA_LAYER-APPLICATION
      value(IV_MAINKEY) type ZTB_DATA_LAYER-MAIN_KEY
      value(IV_SUBKEY) type ZTB_DATA_LAYER-SUB_KEY optional .
  methods WRITE_BUFFER
    importing
      !IV_DATA type STRING .
  methods READ_BUFFER
    exporting
      !EV_DATA type STRING .
  class-methods WRITE_TO_SMA
    importing
      !I_DATA type ANY .
  class-methods READ_FROM_SMA
    exporting
      !E_DATA type ANY .
  class-methods READ_MULTIPLE_DATA
    importing
      !IV_SKIP_MESSAGE type BOOLE_D default ABAP_TRUE
      !IV_APPLICATION type ZTB_DATA_LAYER-APPLICATION
      !IV_MAINKEY type ZTB_DATA_LAYER-MAIN_KEY optional
      !IV_SUBKEY type ZTB_DATA_LAYER-SUB_KEY optional
    exporting
      !ET_DATA type STANDARD TABLE .
protected section.

  data APPLICATION type ZZ_DD_APP .
  data MAIN_KEY type TEXT20 .
  data SUB_KEY type TEXT40 .
  data DATA type CRMT_TEXT_VALUE .
private section.
ENDCLASS.



CLASS ZCL_UL_DATA_LAYER IMPLEMENTATION.


  METHOD delete_data.

    TRY.
        DATA(agent) =  zca_ul_data_layer=>agent.
        agent->delete_persistent( i_application = iv_application i_main_key = iv_mainkey  i_sub_key = iv_subkey ).
      CATCH cx_os_object_not_existing.
        RETURN.
    ENDTRY.

    COMMIT WORK.

  ENDMETHOD.


  method GET_APPLICATION.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute APPLICATION
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = APPLICATION.

           " GET_APPLICATION
  endmethod.


  method GET_DATA.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute DATA
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = DATA.

           " GET_DATA
  endmethod.


  method GET_MAIN_KEY.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute MAIN_KEY
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = MAIN_KEY.

           " GET_MAIN_KEY
  endmethod.


  method GET_SUB_KEY.
***BUILD 090501
     " returning RESULT
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Get Attribute SUB_KEY
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, result is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
************************************************************************

* * Inform class agent and handle exceptions
  state_read_access.

  result = SUB_KEY.

           " GET_SUB_KEY
  endmethod.


  method IF_OS_STATE~GET.
***BUILD 090501
     " returning result type ref to object
************************************************************************
* Purpose        : Get state.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : -
*
* OO Exceptions  : -
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
************************************************************************
* GENERATED: Do not modify
************************************************************************

  data: STATE_OBJECT type ref to CL_OS_STATE.

  create object STATE_OBJECT.
  call method STATE_OBJECT->SET_STATE_FROM_OBJECT( ME ).
  result = STATE_OBJECT.

  endmethod.


  method IF_OS_STATE~HANDLE_EXCEPTION.
***BUILD 090501
     " importing I_EXCEPTION type ref to IF_OS_EXCEPTION_INFO optional
     " importing I_EX_OS type ref to CX_OS_OBJECT_NOT_FOUND optional
************************************************************************
* Purpose        : Handles exceptions during attribute access.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : -
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : If an exception is raised during attribut access,
*                  this method is called and the exception is passed
*                  as a paramater. The default is to raise the exception
*                  again, so that the caller can handle the exception.
*                  But it is also possible to handle the exception
*                  here in the callee.
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
* - 2000-08-02   : (SB)  OO Exceptions
************************************************************************
* Modify if you like
************************************************************************

  if i_ex_os is not initial.
    raise exception i_ex_os.
  endif.

  endmethod.


  method IF_OS_STATE~INIT.
***BUILD 090501
"#EC NEEDED
************************************************************************
* Purpose        : Initialisation of the transient state partition.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : Transient state is initial.
*
* OO Exceptions  : -
*
* Implementation : Caution!: Avoid Throwing ACCESS Events.
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
************************************************************************
* Modify if you like
************************************************************************

  endmethod.


  method IF_OS_STATE~INVALIDATE.
***BUILD 090501
"#EC NEEDED
************************************************************************
* Purpose        : Do something before all persistent attributes are
*                  cleared.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : -
*
* OO Exceptions  : -
*
* Implementation : Whatever you like to do.
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
************************************************************************
* Modify if you like
************************************************************************

  endmethod.


  method IF_OS_STATE~SET.
***BUILD 090501
     " importing I_STATE type ref to object
************************************************************************
* Purpose        : Set state.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : -
*
* OO Exceptions  : -
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-07   : (BGR) Initial Version 2.0
************************************************************************
* GENERATED: Do not modify
************************************************************************

  data: STATE_OBJECT type ref to CL_OS_STATE.

  STATE_OBJECT ?= I_STATE.
  call method STATE_OBJECT->SET_OBJECT_FROM_STATE( ME ).

  endmethod.


  METHOD if_shm_build_instance~build.

    DATA: area TYPE REF TO zshma_data_layer,
          data TYPE REF TO zcl_ul_data_layer.

    DATA: lv_data TYPE string.

    TRY .
        area = zshma_data_layer=>attach_for_write( ).
      CATCH:cx_shm_exclusive_lock_active
            cx_shm_version_limit_exceeded
            cx_shm_change_lock_active
            cx_shm_parameter_error
            cx_shm_pending_lock_removed
      INTO DATA(error).
        zcx_ul_handle_errors=>raise_message( io_msg_object = error ).
    ENDTRY.

    CREATE OBJECT data AREA HANDLE area.
    data->write_buffer( lv_data ).
    area->set_root( data ).
    area->detach_commit( ).

  ENDMETHOD.


  METHOD read_buffer.

    ev_data = data.

  ENDMETHOD.


  METHOD read_data.

    CLEAR e_data.
    DATA(agent) = zca_ul_data_layer=>agent.
    TRY.
        DATA(o_data) = agent->get_persistent( i_application = iv_application i_main_key = iv_mainkey i_sub_key = iv_subkey ).
        rv_data = o_data->get_data( ).
        IF e_data IS SUPPLIED.
          /ui2/cl_json=>deserialize( EXPORTING json = rv_data
                                     CHANGING  data = e_data ).
        ENDIF.
      CATCH cx_os_object_not_found INTO DATA(error).
        CHECK iv_skip_message = abap_false.
        zcx_ul_handle_errors=>raise_message( io_msg_object = error ).
    ENDTRY.

  ENDMETHOD.


  METHOD read_from_sma.

    TRY .
        DATA(lo_area) = zshma_data_layer=>attach_for_read( inst_name = CONV #( sy-uname ) ).

      CATCH:cx_shm_inconsistent,
            cx_shm_no_active_version,
            cx_shm_read_lock_active,
            cx_shm_exclusive_lock_active,
            cx_shm_parameter_error,
            cx_shm_change_lock_active
            INTO DATA(lo_error).
        zcx_ul_handle_errors=>raise_message( io_msg_object = lo_error ).
        RETURN.
    ENDTRY.

    lo_area->root->read_buffer( IMPORTING ev_data = DATA(lv_data) ).
    /ui2/cl_json=>deserialize( EXPORTING json = lv_data
                               CHANGING  data = e_data ).
    lo_area->detach( ).
    lo_area->free_instance( inst_name = CONV #( sy-uname ) ).

  ENDMETHOD.


  METHOD read_multiple_data.

    DATA: rt_data TYPE REF TO data,
          rs_data TYPE REF TO data,
          so_data TYPE REF TO zcl_ul_data_layer.

    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.

    DATA(agent) = zca_ul_data_layer=>agent.

    DATA(query) = `APPLICATION = PAR1`.
    DATA(sort)  = `MAIN_KEY ASCENDING SUB_KEY DESCENDING`.
    IF iv_mainkey IS NOT INITIAL.
      CONCATENATE query `AND MAIN_KEY = PAR2` INTO query SEPARATED BY space.
    ENDIF.
    IF iv_subkey IS NOT INITIAL.
      CONCATENATE query `AND SUB_KEY = PAR3` INTO query SEPARATED BY space.
    ENDIF.

    TRY.
        DATA(o_data) = agent->if_os_ca_persistency~get_persistent_by_query( i_par1 = iv_application i_par2 = iv_mainkey i_par3 = iv_subkey
                                                                            i_query = cl_os_system=>get_query_manager( )->create_query( i_filter  = query
                                                                                                                                        i_ordering = sort )  ).
        CREATE DATA rt_data LIKE et_data.
        ASSIGN rt_data->* TO <ft_data>.
        CREATE DATA rs_data LIKE LINE OF et_data.
        ASSIGN rs_data->* TO FIELD-SYMBOL(<fs_data>).
        LOOP AT o_data INTO DATA(s_data).
          so_data ?= s_data.
          /ui2/cl_json=>deserialize( EXPORTING json = so_data->get_data( )
                                     CHANGING  data = <fs_data> ).
          APPEND <fs_data> TO <ft_data>.
        ENDLOOP.
        et_data = <ft_data>.
      CATCH: cx_os_object_not_found,
             cx_os_query_error
      INTO DATA(error).
        CHECK iv_skip_message = abap_false.
        zcx_ul_handle_errors=>raise_message( io_msg_object = error ).
    ENDTRY.

  ENDMETHOD.


  method SET_DATA.
***BUILD 090501
     " importing I_DATA
     " raising CX_OS_OBJECT_NOT_FOUND
************************************************************************
* Purpose        : Set attribute DATA
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : The object state is loaded, attribute is set
*
* OO Exceptions  : CX_OS_OBJECT_NOT_FOUND
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 2000-03-14   : (BGR) Version 2.0
* - 2000-07-28   : (SB)  OO Exceptions
* - 2000-10-04   : (SB)  Namespaces
************************************************************************

* * Inform class agent and handle exceptions
  state_write_access.

  if ( I_DATA <> DATA ).

    DATA = I_DATA.

*   * Inform class agent and handle exceptions
    state_changed.

  endif. "( I_DATA <> DATA )

           " GET_DATA
  endmethod.


  METHOD write_buffer.

    data = iv_data.

  ENDMETHOD.


  METHOD write_data.

    DATA(agent) = zca_ul_data_layer=>agent.

    TRY.
        DATA(o_data) = agent->get_persistent( i_application = is_key-application i_main_key = is_key-main_key i_sub_key = is_key-sub_key ).
      CATCH cx_os_object_not_found.
        o_data = agent->create_persistent( i_application = is_key-application i_main_key = is_key-main_key i_sub_key = is_key-sub_key ).
    ENDTRY.

    IF is_data IS SUPPLIED.
      o_data->set_data( i_data = zcl_ul_abap=>to_json( EXPORTING im_data = is_data iv_pure = abap_true ) ).
    ELSE.
      o_data->set_data( i_data = is_key-data ).
    ENDIF.

    COMMIT WORK AND WAIT.

  ENDMETHOD.


  METHOD write_to_sma.

    DATA:lo_area TYPE REF TO zshma_data_layer,
         lo_data TYPE REF TO zcl_ul_data_layer.

    TRY.
        zshma_data_layer=>build( ).
      CATCH: cx_shma_not_configured,
             cx_shm_inconsistent,
             cx_shm_build_failed
             INTO DATA(lo_error).
        zcx_ul_handle_errors=>raise_message( io_msg_object = lo_error ).
        RETURN.
    ENDTRY.

    TRY.
        IF zshma_data_layer=>get_instance_infos( inst_name = CONV #( sy-uname ) ) IS NOT INITIAL .
          lo_area = zshma_data_layer=>attach_for_update( inst_name = CONV #( sy-uname ) ).
        ELSE.
          lo_area = zshma_data_layer=>attach_for_write( inst_name = CONV #( sy-uname ) ).
        ENDIF.
      CATCH:  cx_shm_inconsistent
              cx_shm_no_active_version
              cx_shm_exclusive_lock_active
              cx_shm_version_limit_exceeded
              cx_shm_change_lock_active
              cx_shm_parameter_error
              cx_shm_pending_lock_removed
        INTO DATA(lo_error1).
        zcx_ul_handle_errors=>raise_message( io_msg_object = lo_error1 ).
        RETURN.
    ENDTRY.

    lo_data ?= lo_area->get_root( ).
    IF lo_data IS INITIAL.
      CREATE OBJECT lo_data AREA HANDLE lo_area.
    ENDIF.

    DATA(lv_data) = /ui2/cl_json=>serialize( data = i_data ).
    lo_data->write_buffer( lv_data ).
    lo_area->set_root( lo_data ).
    lo_area->detach_commit( ).

  ENDMETHOD.
ENDCLASS.
