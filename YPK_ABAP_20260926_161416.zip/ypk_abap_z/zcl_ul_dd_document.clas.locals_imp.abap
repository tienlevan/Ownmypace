*"* use this source file for the definition and implementation of
*"* local helper classes, interface definitions and type
*"* declarations

DEFINE insert_html.
  INSERT &2 INTO &1 INDEX &3.
END-OF-DEFINITION.
