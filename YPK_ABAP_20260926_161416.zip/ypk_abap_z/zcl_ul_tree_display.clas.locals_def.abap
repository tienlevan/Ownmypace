*"* use this source file for any type of declarations (class
*"* definitions, interfaces or type declarations) you need for
*"* components in the private section
CLASS lcl_dragdropdataobject DEFINITION.
  PUBLIC SECTION.
    DATA: src_node_key TYPE tv_nodekey.
ENDCLASS.
