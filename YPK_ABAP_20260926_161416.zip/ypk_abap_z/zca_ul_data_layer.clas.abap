class ZCA_UL_DATA_LAYER definition
  public
  inheriting from ZCB_UL_DATA_LAYER
  final
  create private .

public section.

  class-data AGENT type ref to ZCA_UL_DATA_LAYER read-only .

  class-methods CLASS_CONSTRUCTOR .
protected section.
private section.
ENDCLASS.



CLASS ZCA_UL_DATA_LAYER IMPLEMENTATION.


  method CLASS_CONSTRUCTOR.
***BUILD 090501
************************************************************************
* Purpose        : Initialize the 'class'.
*
* Version        : 2.0
*
* Precondition   : -
*
* Postcondition  : Singleton is created.
*
* OO Exceptions  : -
*
* Implementation : -
*
************************************************************************
* Changelog:
* - 1999-09-20   : (OS) Initial Version
* - 2000-03-06   : (BGR) 2.0 modified REGISTER_CLASS_AGENT
************************************************************************
* GENERATED: Do not modify
************************************************************************

  create object AGENT.

  call method AGENT->REGISTER_CLASS_AGENT
    exporting
      I_CLASS_NAME          = 'ZCL_UL_DATA_LAYER'
      I_CLASS_AGENT_NAME    = 'ZCA_UL_DATA_LAYER'
      I_CLASS_GUID          = '005056BD6D5D1EDD85F256FE65F7C221'
      I_CLASS_AGENT_GUID    = '005056BD6D5D1EDD85F256FE65F84221'
      I_AGENT               = AGENT
      I_STORAGE_LOCATION    = 'ZTB_DATA_LAYER'
      I_CLASS_AGENT_VERSION = '2.0'.

           "CLASS_CONSTRUCTOR
  endmethod.
ENDCLASS.
