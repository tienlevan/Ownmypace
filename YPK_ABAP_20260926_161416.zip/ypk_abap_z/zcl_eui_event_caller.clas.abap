CLASS zcl_eui_event_caller DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
    TYPE-POOLS abap .

    METHODS add_handler
      IMPORTING
        !io_handler      TYPE REF TO object
        !iv_handlers_map TYPE csequence OPTIONAL
        !iv_first        TYPE abap_bool DEFAULT abap_false
        !iv_activate     TYPE abap_bool DEFAULT abap_true
      RAISING
        zcx_eui_exception .
    METHODS call_handlers
      IMPORTING
        !iv_of_class     TYPE abap_classname
        !iv_for_event    TYPE abap_evntname
        !iv_param_nam_00 TYPE csequence OPTIONAL
        !iv_param_val_00 TYPE any OPTIONAL
        !iv_param_nam_01 TYPE csequence OPTIONAL
        !iv_param_val_01 TYPE any OPTIONAL
        !iv_param_nam_02 TYPE csequence OPTIONAL
        !iv_param_val_02 TYPE any OPTIONAL
        !iv_param_nam_03 TYPE csequence OPTIONAL
        !iv_param_val_03 TYPE any OPTIONAL
        !iv_param_nam_04 TYPE csequence OPTIONAL
        !iv_param_val_04 TYPE any OPTIONAL
        !iv_param_nam_05 TYPE csequence OPTIONAL
        !iv_param_val_05 TYPE any OPTIONAL
        !iv_param_nam_06 TYPE csequence OPTIONAL
        !iv_param_val_06 TYPE any OPTIONAL
        !iv_param_nam_07 TYPE csequence OPTIONAL
        !iv_param_val_07 TYPE any OPTIONAL
        !iv_param_nam_08 TYPE csequence OPTIONAL
        !iv_param_val_08 TYPE any OPTIONAL
        !iv_param_nam_09 TYPE csequence OPTIONAL
        !iv_param_val_09 TYPE any OPTIONAL
        !iv_param_nam_10 TYPE csequence OPTIONAL
        !iv_param_val_10 TYPE any OPTIONAL
        !iv_param_nam_11 TYPE csequence OPTIONAL
        !iv_param_val_11 TYPE any OPTIONAL
        !iv_param_nam_12 TYPE csequence OPTIONAL
        !iv_param_val_12 TYPE any OPTIONAL
        !iv_param_nam_13 TYPE csequence OPTIONAL
        !iv_param_val_13 TYPE any OPTIONAL
        !iv_param_nam_14 TYPE csequence OPTIONAL
        !iv_param_val_14 TYPE any OPTIONAL .
    METHODS has_handler
      IMPORTING
        !iv_of_class  TYPE abap_classname
        !iv_for_event TYPE abap_evntname
      RETURNING
        VALUE(rv_ok)  TYPE abap_bool .
  PROTECTED SECTION.
  PRIVATE SECTION.

    TYPES:
      BEGIN OF ts_listener,
        listener    TYPE REF TO object,
        t_methdescr TYPE abap_methdescr_tab,
        t_friend    TYPE abap_frndtypes_tab,
      END OF ts_listener .
    TYPES:
      tt_listener TYPE STANDARD TABLE OF ts_listener WITH DEFAULT KEY .

    DATA mt_listener TYPE tt_listener .
ENDCLASS.



CLASS zcl_eui_event_caller IMPLEMENTATION.


  METHOD add_handler.
    DATA:
      lt_event        TYPE STANDARD TABLE OF abap_methname,
      lo_object_descr TYPE REF TO cl_abap_classdescr,
      lv_tabix        TYPE sytabix,
      ls_method       TYPE REF TO abap_methdescr,
      ls_item         LIKE LINE OF mt_listener.
    FIELD-SYMBOLS:
       <ls_event> LIKE LINE OF lt_event.

    " No need to call anything
    CHECK io_handler IS NOT INITIAL.

    " Deactivate
    IF iv_activate <> abap_true.
      DELETE mt_listener WHERE listener = io_handler.
      RETURN.
    ENDIF.

    " Already exist ?
    READ TABLE mt_listener TRANSPORTING NO FIELDS
     WITH KEY listener = io_handler.
    CHECK sy-subrc <> 0.

    " Call public methods of ...
    ls_item-listener = io_handler.

    " Get all handler methods
    lo_object_descr ?= cl_abap_objectdescr=>describe_by_object_ref( ls_item-listener ).
    ls_item-t_methdescr = lo_object_descr->methods.
    ls_item-t_friend    = lo_object_descr->get_friend_types( ).
    DELETE ls_item-t_methdescr WHERE for_event IS INITIAL.

    " Exact only specefic methods
    IF iv_handlers_map IS NOT INITIAL.
      SPLIT iv_handlers_map AT ';' INTO TABLE lt_event.

      " Check declared or not
      LOOP AT lt_event ASSIGNING <ls_event>.
        READ TABLE ls_item-t_methdescr TRANSPORTING NO FIELDS
         WITH TABLE KEY name = <ls_event>.
        CHECK sy-subrc <> 0.

        MESSAGE s007(zeui_message) WITH <ls_event> INTO sy-msgli.
        zcx_eui_exception=>raise_sys_error( ).
      ENDLOOP.

      " Could be many similar EVENT handlers
      SORT lt_event BY table_line.
      LOOP AT ls_item-t_methdescr REFERENCE INTO ls_method.
        lv_tabix = sy-tabix.

        " Delete unnecessary
        READ TABLE lt_event TRANSPORTING NO FIELDS BINARY SEARCH
         WITH KEY table_line = ls_method->name.
        CHECK sy-subrc <> 0.

        DELETE ls_item-t_methdescr INDEX lv_tabix.
      ENDLOOP.
    ENDIF.

    " More proiority
    IF iv_first = abap_true.
      INSERT ls_item INTO mt_listener INDEX 1.
    ELSE.
      APPEND ls_item TO mt_listener.
    ENDIF.
  ENDMETHOD.


  METHOD call_handlers.
    DATA:
      lt_param_input TYPE abap_parmbind_tab,
      lt_param_call  LIKE lt_param_input,
      ls_param       TYPE abap_parmbind,
      lo_error       TYPE REF TO cx_sy_dyn_call_error,
      lv_is_friend   TYPE abap_bool.
    FIELD-SYMBOLS:
      <ls_param>     LIKE LINE OF lt_param_input,
      <ls_methdescr> TYPE abap_methdescr,
      <ls_parameter> LIKE LINE OF <ls_methdescr>-parameters,
      <ls_item>      LIKE LINE OF mt_listener.


**********************************************************************
    DATA          lv_index   TYPE numc2.
    DATA          lv_name    TYPE string.
    FIELD-SYMBOLS <lv_name>  TYPE csequence.
    FIELD-SYMBOLS <lv_value> TYPE any.

    DO 15 TIMES.
      " get next parameter
      lv_index = sy-index - 1.
      CONCATENATE 'IV_PARAM_NAM_' lv_index INTO lv_name.
      ASSIGN (lv_name) TO <lv_name>.

      " Stop no params
      IF <lv_name> IS INITIAL.
        EXIT.
      ENDIF.

      CONCATENATE 'IV_PARAM_VAL_' lv_index INTO lv_name.
      ASSIGN (lv_name) TO <lv_value>.

      ls_param-name = <lv_name>.
      ls_param-kind = cl_abap_objectdescr=>exporting.
      GET REFERENCE OF <lv_value> INTO ls_param-value.

      INSERT ls_param INTO TABLE lt_param_input.
    ENDDO.
**********************************************************************

    LOOP AT mt_listener ASSIGNING <ls_item>.
      " Public or friend
      lv_is_friend = abap_false.
      READ TABLE <ls_item>-t_friend TRANSPORTING NO FIELDS
       WITH KEY table_line->absolute_name = '\CLASS=ZCL_EUI_EVENT_CALLER'.
      IF sy-subrc = 0.
        lv_is_friend = abap_true.
      ENDIF.

      LOOP AT <ls_item>-t_methdescr ASSIGNING <ls_methdescr>
         WHERE of_class  = iv_of_class
           AND for_event = iv_for_event.

        " Make method public!
        IF <ls_methdescr>-visibility <> cl_abap_objectdescr=>public AND lv_is_friend <> abap_true.
          MESSAGE s008(zeui_message) WITH <ls_methdescr>-name INTO sy-msgli.
          zcx_eui_exception=>raise_dump( iv_message = sy-msgli ).
        ENDIF.

        " Fill each time
        CLEAR lt_param_call.
        LOOP AT <ls_methdescr>-parameters ASSIGNING <ls_parameter>.
          " If have decalaration in method
          READ TABLE lt_param_input ASSIGNING <ls_param>
           WITH TABLE KEY name = <ls_parameter>-name.
          CHECK sy-subrc = 0.

          INSERT <ls_param> INTO TABLE lt_param_call.
        ENDLOOP.

        TRY.
            CALL METHOD <ls_item>-listener->(<ls_methdescr>-name)
              PARAMETER-TABLE
              lt_param_call.
          CATCH cx_sy_dyn_call_error INTO lo_error.
            zcx_eui_exception=>raise_dump( io_error = lo_error ).
        ENDTRY.
      ENDLOOP.
    ENDLOOP.
  ENDMETHOD.


  METHOD has_handler.
    FIELD-SYMBOLS <ls_item> LIKE LINE OF mt_listener.

    rv_ok = abap_false.
    LOOP AT mt_listener ASSIGNING <ls_item>.
      READ TABLE <ls_item>-t_methdescr TRANSPORTING NO FIELDS
        WITH KEY of_class  = iv_of_class
                 for_event = iv_for_event.

      " Use the method for express test
      CHECK sy-subrc = 0.
      rv_ok = abap_true.
      RETURN.
    ENDLOOP.
  ENDMETHOD.
ENDCLASS.
