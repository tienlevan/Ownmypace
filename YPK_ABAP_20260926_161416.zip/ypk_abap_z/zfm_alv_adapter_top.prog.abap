*&---------------------------------------------------------------------*
*& Include          ZFM_ALV_ADAPTER_TOP
*&---------------------------------------------------------------------*
TYPES: BEGIN OF ty_alv,
         index TYPE i,
         alv   TYPE REF TO zcl_ul_alv_adapter,
       END OF ty_alv.

DATA: go_alv TYPE REF TO zcl_ul_alv_adapter.

DATA: gr_class      TYPE REF TO cl_abap_typedescr,
      gv_tabname    TYPE tabname,
      gv_autohide   TYPE boolean,
      go_parent     TYPE REF TO cl_gui_container,
      gt_col_set    TYPE ztb_ul_alv_col,
      gt_sort       TYPE lvc_t_sort,
      gt_tool_add   TYPE ttb_button,
      gv_title      TYPE text100,
      gv_input      TYPE int4,
      gs_layout     TYPE lvc_s_layo,
      gt_alv        TYPE TABLE OF ty_alv,
      gt_hyperlinks TYPE lvc_t_hype,
      gt_dropval    TYPE lvc_t_drop,
      gr_data       TYPE REF TO data.

FIELD-SYMBOLS: <ft_table> TYPE STANDARD TABLE.
