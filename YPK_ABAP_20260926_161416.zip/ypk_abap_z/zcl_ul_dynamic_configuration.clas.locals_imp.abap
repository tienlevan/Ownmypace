*"* use this source file for the definition and implementation of
*"* local helper classes, interface definitions and type
*"* declarations

CLASS lcl_event DEFINITION INHERITING FROM zcl_ul_alv_adapter.

  PUBLIC SECTION.
    METHODS mine_back_event REDEFINITION.

  PROTECTED SECTION.
    METHODS: mine_data_changed REDEFINITION,
      mine_user_command REDEFINITION,
      mine_hotspot_click REDEFINITION,
      mine_double_click REDEFINITION.

  PRIVATE SECTION.
    METHODS: _get_configuration RETURNING VALUE(configuration) TYPE REF TO zif_configuration,
      _is_permit_change IMPORTING is_transport      TYPE boole_d
                        RETURNING VALUE(is_changed) TYPE boole_d,
      _display_log_change.

ENDCLASS.

CLASS lcl_event IMPLEMENTATION.

  METHOD mine_data_changed.

    TRY.
        _get_configuration(  )->event_data_changed( ir_data_changed = er_data_changed ).
      CATCH cx_sy_ref_is_initial.
    ENDTRY.

    IF er_data_changed->mt_protocol IS NOT INITIAL.
      er_data_changed->display_protocol( i_optimize_columns = abap_true ).
      o_splitter = zcl_ul_dynamic_configuration=>splitter_h.
      show_applog( ).
    ELSE.
      zcl_ul_dynamic_configuration=>splitter_h->set_row_height( id = 2 height = 0 ).
      er_data_changed->refresh_protocol(  ).
    ENDIF.

  ENDMETHOD.

  METHOD _get_configuration.

    DATA t_configuration TYPE TABLE OF zcl_ul_dynamic_configuration=>ty_dynamic_configuration.
    IF zcl_ul_dynamic_configuration=>configuration_id NOT IN zcl_ul_abap=>string_to_range( 'CONFIG_ID, CONFIG_GRP, CONFIG_SET' ).
      zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_ID'
                                    IMPORTING e_data = t_configuration  ).
      IF t_configuration IS NOT INITIAL.
        TRY.
            DATA(configuration_class) = t_configuration[ configuration_id = zcl_ul_dynamic_configuration=>configuration_id ]-configuration_class.
            configuration_class = COND #( WHEN configuration_class IS NOT INITIAL THEN configuration_class ELSE 'ZCL_UL_DYNAMIC_CONFIGURATION' ).
            IF configuration_class NE 'ZCL_UL_DYNAMIC_CONFIGURATION'.
              CREATE OBJECT configuration TYPE (configuration_class).
            ELSE.
              configuration = NEW zcl_ul_dynamic_configuration( iv_event = abap_true iv_configuration_id = zcl_ul_dynamic_configuration=>configuration_id )->configuration.
            ENDIF.
          CATCH cx_sy_itab_line_not_found.
        ENDTRY.
      ELSE.
        zcx_ul_handle_errors=>raise_message( iv_msg_text = 'No configuration data!' ).
      ENDIF.
    ELSE.
      configuration = NEW zcl_ul_dynamic_configuration( iv_event = abap_true iv_configuration_id = zcl_ul_dynamic_configuration=>configuration_id )->configuration.
    ENDIF.

  ENDMETHOD.

  METHOD mine_user_command.

    DATA: t_configuration TYPE TABLE OF zcl_ul_dynamic_configuration=>ty_dynamic_configuration,
          tabkey          TYPE vim_enqkey,
          returncode      TYPE char1,
          datakey         TYPE rstable-varkey,
          t_delta         TYPE lvc_t_modi,
          t_fields        TYPE TABLE OF sval.

    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.

    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_ID'
                                  IMPORTING e_data = t_configuration ).
    READ TABLE t_configuration INTO DATA(s_configuration) WITH KEY configuration_id = zcl_ul_dynamic_configuration=>configuration_id.
    s_configuration-configuration_type = COND #( WHEN s_configuration-configuration_type IS NOT INITIAL THEN s_configuration-configuration_type ELSE 'ZTB_DATA_LAYER' ).

    CASE e_ucomm.

      WHEN 'CHANGE'.
        IF _is_permit_change( s_configuration-transport_flag ) = abap_true.
          zcl_ul_dynamic_configuration=>input = SWITCH #( zcl_ul_dynamic_configuration=>input WHEN 1 THEN 0 ELSE 1 ).
          IF s_configuration-configuration_type = 'ZTB_DATA_LAYER'.
            tabkey = zcl_ul_abap=>build_key( is_data = VALUE ztb_data_layer( application = 'DYNAMICSET' main_key = s_configuration-configuration_id )
                                             iv_add_client = abap_true ).
          ENDIF.
          IF zcl_ul_dynamic_configuration=>input = 1.
            CALL FUNCTION 'ENQUEUE_E_TABLE'
              EXPORTING
                tabname        = CONV rstable-tabname( s_configuration-configuration_type )
                varkey         = tabkey
              EXCEPTIONS
                foreign_lock   = 1
                system_failure = 2
                error_message  = 3
                OTHERS         = 4.
            IF sy-subrc IS NOT INITIAL.
              zcx_ul_handle_errors=>raise_message(  ).
              zcl_ul_dynamic_configuration=>input = 0.
            ELSE.
              get_frontend_layout( IMPORTING es_layout = s_layout ).
              get_filter_criteria( IMPORTING et_filter = t_filter ).
              s_layout-keyhot = abap_false.
              s_layout-cwidth_opt = abap_true.
              ASSIGN mt_outtab->* TO <ft_data>.
              DATA(t_col_set) = CORRESPONDING ztb_ul_alv_col( t_fcat ).
              t_toolbar_add = VALUE #( BASE t_toolbar_add ( icon = icon_mass_change function = 'MASS' text = 'Mass Change' ) ).
              DELETE t_toolbar_add WHERE function = 'LOG'.
              TRY.
                  display( EXPORTING iv_input = 1
                                     it_col_set = t_col_set
                           CHANGING ct_data = <ft_data> ).
                CATCH zcx_ul_handle_errors INTO DATA(error).
                  error->show_message( ).
              ENDTRY.
            ENDIF.
          ELSE.
            CALL FUNCTION 'DEQUEUE_E_TABLE'
              EXPORTING
                tabname = CONV rstable-tabname( s_configuration-configuration_type ).
            IF s_configuration-configuration_id IS INITIAL.
              s_layout-keyhot = SWITCH #( zcl_ul_dynamic_configuration=>configuration_id WHEN 'CONFIG_GRP' THEN abap_true ELSE abap_false ).
            ELSE.
              IF line_exists( t_configuration[ configuration_id_parent = s_configuration-configuration_id ] ).
                s_layout-keyhot = abap_true.
              ELSE.
                s_layout-keyhot = abap_false.
              ENDIF.
            ENDIF.
            IF s_configuration-log_flag IS NOT INITIAL.
              t_toolbar_add = VALUE #( BASE t_toolbar_add ( icon = icon_protocol function = 'LOG' text = 'Change Log' ) ).
            ENDIF.
            DELETE t_toolbar_add WHERE icon = icon_mass_change.
            get_filter_criteria( IMPORTING et_filter = t_filter ).
            ASSIGN mt_outtab->* TO <ft_data>.
            t_col_set = CORRESPONDING #( t_fcat ).
            TRY.
                display( EXPORTING iv_input = 0
                                   it_col_set = t_col_set
                         CHANGING ct_data = <ft_data> ).
              CATCH zcx_ul_handle_errors INTO error.
                error->show_message( ).
            ENDTRY.
          ENDIF.
        ELSE.
          zcx_ul_handle_errors=>raise_message( iv_msg_text = 'The system does not permit to change data!' ).
        ENDIF.

      WHEN 'MASS'.

        get_selected_columns( IMPORTING et_index_columns = DATA(t_selected_cols) ).

        IF t_selected_cols IS INITIAL.
          zcx_ul_handle_errors=>raise_message( iv_msg_text = 'Please select a column!' ).
        ELSEIF lines( t_selected_cols ) > 1.
          zcx_ul_handle_errors=>raise_message( iv_msg_text = 'Please select only one column!' ).
        ELSE.

          ASSIGN mt_outtab->* TO <ft_data>.
          READ TABLE t_selected_cols INTO DATA(s_selected_col) INDEX 1.
          APPEND INITIAL LINE TO t_fields ASSIGNING FIELD-SYMBOL(<fs_field>).
          <fs_field>-tabname = s_configuration-configuration_type.
          <fs_field>-fieldname = s_selected_col-fieldname.
          <fs_field>-field_attr = '00'.
          <fs_field>-fieldtext = mt_info[ fieldname = s_selected_col-fieldname ]-text.
          get_filtered_entries( IMPORTING et_filtered_entries = DATA(t_filter_entries) ).
          get_selected_rows( IMPORTING et_row_no = DATA(t_selected_rows) ).

          CALL FUNCTION 'POPUP_GET_VALUES'
            EXPORTING
              popup_title = 'Mass Column Change'
            IMPORTING
              returncode  = returncode
            TABLES
              fields      = t_fields.

          CHECK returncode NE 'A'.

          LOOP AT <ft_data> ASSIGNING FIELD-SYMBOL(<fs_data>).

            DATA(row_id) = sy-tabix.

            IF t_filter_entries IS NOT INITIAL.
              READ TABLE t_filter_entries WITH KEY table_line = row_id TRANSPORTING NO FIELDS.
              IF sy-subrc IS INITIAL.
                CONTINUE.
              ENDIF.
            ENDIF.

            IF t_selected_rows IS NOT INITIAL.
              READ TABLE t_selected_rows WITH KEY row_id = row_id TRANSPORTING NO FIELDS.
              IF sy-subrc IS NOT INITIAL.
                CONTINUE.
              ENDIF.
            ENDIF.

            ASSIGN COMPONENT s_selected_col-fieldname OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<val>).
            IF sy-subrc IS INITIAL.
              APPEND INITIAL LINE TO t_delta ASSIGNING FIELD-SYMBOL(<fs_delta>).
              <fs_delta>-fieldname = s_selected_col-fieldname.
              <fs_delta>-row_id = row_id.
              <fs_delta>-value = t_fields[ 1 ]-value.
            ENDIF.

          ENDLOOP.

          CHECK t_delta IS NOT INITIAL.
          set_delta_cells( EXPORTING it_delta_cells = t_delta i_modified = abap_true i_frontend_only = abap_true ).
          check_changed_data( ).

        ENDIF.

      WHEN 'LOG'.

        _display_log_change( ).

    ENDCASE.

  ENDMETHOD.

  METHOD mine_double_click.

    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.
    ASSIGN mt_outtab->* TO <ft_data>.
    READ TABLE <ft_data> ASSIGNING FIELD-SYMBOL(<fs_data>) INDEX e_row-index.

    TRY.
        _get_configuration(  )->event_double_click( EXPORTING fieldname = e_column-fieldname
                                                    CHANGING  data = <fs_data> ).
       refresh(  ).
      CATCH cx_sy_ref_is_initial.
    ENDTRY.

  ENDMETHOD.

  METHOD mine_hotspot_click.

    DATA t_configuration TYPE TABLE OF zcl_ul_dynamic_configuration=>ty_dynamic_configuration.
    DATA t_filter TYPE lvc_t_filt.
    DATA data TYPE REF TO data.
    DATA handle_class TYPE REF TO object.
    DATA s_selfield TYPE slis_selfield.
    DATA t_sfcat TYPE slis_t_fieldcat_alv.
    DATA t_excludes TYPE slis_t_extab.
    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.

    FREE zcl_ul_dynamic_configuration=>grid->t_filter.
    ASSIGN mt_outtab->* TO <ft_data>.
    READ TABLE <ft_data> ASSIGNING FIELD-SYMBOL(<fs_data>) INDEX e_row_id-index.

    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_ID'
                                  IMPORTING e_data = t_configuration  ).
    IF zcl_ul_dynamic_configuration=>configuration_id NE 'CONFIG_GRP' AND zcl_ul_dynamic_configuration=>configuration_id NE 'CONFIG_ID'.
      DATA(t_children) = t_configuration.
      DELETE t_children WHERE configuration_id_parent NE zcl_ul_dynamic_configuration=>configuration_id.
      IF lines( t_children ) = 1.
        DATA(s_configuration) = t_configuration[ configuration_id_parent = zcl_ul_dynamic_configuration=>configuration_id ].
      ELSE.
        DATA(alv) = NEW zcl_ul_alv_adapter( ).
        alv->lvc_fcat_from_itab( CHANGING ct_table = t_children ).
        t_sfcat = CORRESPONDING #( alv->t_fcat ).
        LOOP AT t_sfcat ASSIGNING FIELD-SYMBOL(<fs_sfcat>).
          IF <fs_sfcat>-fieldname = 'CONFIGURATION_TXT'.
            <fs_sfcat>-seltext_l ='Configuration Node'.
          ELSE.
            <fs_sfcat>-tech = abap_true.
          ENDIF.
        ENDLOOP.
        t_excludes = VALUE #( ( fcode = '&ILT' )
                       ( fcode = '&OUP' )
                       ( fcode = '&ODN' )
                       ( fcode = '&OL0' )
                       ( fcode = '%SC'  )
                       ( fcode = '%SC+' )
                       ( fcode = '&ETA' ) ).
        CALL FUNCTION 'REUSE_ALV_POPUP_TO_SELECT'
          EXPORTING
            i_title      = 'Select a subnode'
            i_tabname    = ''
            it_fieldcat  = t_sfcat
            it_excluding = t_excludes
          IMPORTING
            es_selfield  = s_selfield
          TABLES
            t_outtab     = t_children.
        IF s_selfield IS NOT INITIAL.
          s_configuration = t_children[ configuration_txt = s_selfield-value ].
        ELSE.
          RETURN.
        ENDIF.
      ENDIF.
    ELSE.
      s_configuration-configuration_id = SWITCH #( zcl_ul_dynamic_configuration=>configuration_id
                                                   WHEN 'CONFIG_GRP' THEN 'CONFIG_ID'
                                                   WHEN 'CONFIG_ID'  THEN 'CONFIG_SET' ).
    ENDIF.

    DATA(root_class) = NEW zcl_ul_dynamic_configuration( iv_event = abap_true ).
    root_class->configuration_id = s_configuration-configuration_id.
    root_class->t_configuration = t_configuration.
    root_class->tree->set_selected_node( CONV #( s_configuration-configuration_id ) ).
    IF s_configuration-configuration_class IS NOT INITIAL.
      CREATE OBJECT handle_class TYPE (s_configuration-configuration_class).
      ASSIGN handle_class->('ZIF_CONFIGURATION~SENDER') TO FIELD-SYMBOL(<me>).
      <me> = root_class.
      CALL METHOD handle_class->('ZIF_CONFIGURATION~REGISTER_INTERFACE').
      ASSIGN handle_class->('ZIF_CONFIGURATION~DATA->*') TO <ft_data>.
      ASSIGN handle_class->('ZIF_CONFIGURATION~T_COL_SET') TO FIELD-SYMBOL(<ft_col_set>).
      root_class->t_col_set = <ft_col_set>.
      zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = s_configuration-configuration_id
                                    IMPORTING e_data = <ft_data> ).
    ELSEIF s_configuration-configuration_type IS NOT INITIAL.
      CREATE DATA data TYPE TABLE OF (s_configuration-configuration_type).
      ASSIGN data->* TO <ft_data>.
      SELECT FROM (s_configuration-configuration_type) FIELDS * INTO TABLE @<ft_data>.
    ELSE.
      root_class->configuration->register_interface(  ).
      ASSIGN root_class->configuration->data->* TO <ft_data>.
      zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = s_configuration-configuration_id
                                    IMPORTING e_data = <ft_data> ).
    ENDIF.

    LOOP AT t_fcat INTO DATA(s_fcat) WHERE key = abap_true.
      ASSIGN COMPONENT s_fcat-fieldname OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<value>).
      root_class->grid->t_filter = VALUE #( BASE zcl_ul_dynamic_configuration=>grid->t_filter ( sign = 'I' option = 'EQ' fieldname = s_fcat-fieldname low = <value> ) ).
    ENDLOOP.
    root_class->show_in_grid( CHANGING ct_data = <ft_data> ).

  ENDMETHOD.

  METHOD _is_permit_change.

    DATA state   TYPE t000-cccategory.

    IF is_transport IS INITIAL AND ( zcl_ul_dynamic_configuration=>configuration_id NE 'CONFIG_ID' OR zcl_ul_dynamic_configuration=>configuration_id NE 'CONFIG_GROUP' ).
      is_changed = abap_true.
      RETURN.
    ENDIF.

    CALL FUNCTION 'VIEW_GET_CLIENT_STATE'
      IMPORTING
        client_state = state.

    CHECK state EQ 'C'.
    is_changed = abap_true.

  ENDMETHOD.

  METHOD mine_back_event.

    DATA t_configuration TYPE TABLE OF zcl_ul_dynamic_configuration=>ty_dynamic_configuration.
    DATA handle_class TYPE REF TO object.
    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.
    DATA data TYPE REF TO data.

    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_ID'
                                    IMPORTING e_data = t_configuration ).
    READ TABLE t_configuration INTO DATA(s_configuration) WITH KEY configuration_id = zcl_ul_dynamic_configuration=>configuration_id.
    s_configuration-configuration_type = COND #( WHEN s_configuration-configuration_type IS NOT INITIAL THEN s_configuration-configuration_type ELSE 'ZTB_DATA_LAYER' ).

    CALL FUNCTION 'DEQUEUE_E_TABLE'
      EXPORTING
        tabname = CONV rstable-tabname( s_configuration-configuration_type ).

    IF zcl_ul_dynamic_configuration=>configuration_id = 'CONFIG_GRP'.
      CLEAR s_configuration-configuration_type.
    ELSEIF zcl_ul_dynamic_configuration=>configuration_id = 'CONFIG_ID'
    OR zcl_ul_dynamic_configuration=>configuration_id = 'CONFIG_SET'.
      s_configuration-configuration_id_parent = SWITCH #( zcl_ul_dynamic_configuration=>configuration_id
                                                         WHEN 'CONFIG_ID'  THEN 'CONFIG_GRP'
                                                         WHEN 'CONFIG_SET' THEN 'CONFIG_ID' ).
      CLEAR s_configuration-configuration_type.
    ENDIF.

    DATA(root_class) = NEW zcl_ul_dynamic_configuration( iv_event = abap_true ).

    IF s_configuration-configuration_id_parent IS NOT INITIAL.

      root_class->zif_configuration~has_parent = abap_true.
      root_class->configuration_id = s_configuration-configuration_id_parent.
      root_class->tree->set_selected_node( CONV #( s_configuration-configuration_id_parent ) ).
      IF s_configuration-configuration_class IS NOT INITIAL.
        CREATE OBJECT handle_class TYPE (s_configuration-configuration_class).
        ASSIGN handle_class->('ZIF_CONFIGURATION~SENDER') TO FIELD-SYMBOL(<me>).
        <me> = root_class.
        CALL METHOD handle_class->('ZIF_CONFIGURATION~REGISTER_INTERFACE').
        ASSIGN handle_class->('ZIF_CONFIGURATION~DATA->*') TO <ft_data>.
        ASSIGN handle_class->('ZIF_CONFIGURATION~T_COL_SET') TO FIELD-SYMBOL(<ft_col_set>).
        root_class->t_col_set = <ft_col_set>.
        zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = root_class->configuration_id
                                      IMPORTING e_data = <ft_data> ).
      ELSEIF s_configuration-configuration_type IS NOT INITIAL.
        CREATE DATA data TYPE TABLE OF (s_configuration-configuration_type).
        ASSIGN data->* TO <ft_data>.
        SELECT FROM (s_configuration-configuration_type) FIELDS * INTO TABLE @<ft_data>.
      ELSE.
        root_class->configuration->register_interface(  ).
        ASSIGN root_class->configuration->data->* TO <ft_data>.
        zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = root_class->configuration_id
                                      IMPORTING e_data = <ft_data> ).
      ENDIF.

      CLEAR root_class->grid->t_filter.
      root_class->grid->set_filter_criteria( it_filter =  root_class->grid->t_filter ).
      root_class->show_in_grid( CHANGING ct_data = <ft_data> ).

    ELSE.

      root_class->zif_configuration~has_parent = abap_false.

    ENDIF.

  ENDMETHOD.

  METHOD _display_log_change.

    DATA: t_logs          TYPE TABLE OF zst_cdhdr,
          t_configuration TYPE TABLE OF zcl_ul_dynamic_configuration=>ty_dynamic_configuration,
          t_log_display   TYPE TABLE OF cdred.

    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_ID'
                                   IMPORTING e_data = t_configuration ).
    READ TABLE t_configuration INTO DATA(s_configuration) WITH KEY configuration_id = zcl_ul_dynamic_configuration=>configuration_id.
    s_configuration-configuration_type = COND #( WHEN s_configuration-configuration_type IS NOT INITIAL THEN s_configuration-configuration_type ELSE 'ZTB_DATA_LAYER' ).
    zcl_ul_data_layer=>read_multiple_data( EXPORTING iv_application = 'TBLOGGER' iv_mainkey = CONV #( s_configuration-configuration_type )
                                           IMPORTING et_data = t_logs ).

    IF t_logs IS INITIAL.
      zcx_ul_handle_errors=>raise_message( iv_msg_text = 'No log found' ). RETURN.
    ENDIF.

    LOOP AT t_logs ASSIGNING FIELD-SYMBOL(<fs_log>).
      LOOP AT <fs_log>-item ASSIGNING FIELD-SYMBOL(<fs_item>).
        APPEND INITIAL LINE TO t_log_display ASSIGNING FIELD-SYMBOL(<fs_log_display>).
        <fs_log_display> = VALUE #( objectid = s_configuration-configuration_type udate = <fs_log>-udate utime = <fs_log>-utime username = <fs_log>-username
                                    tabname = s_configuration-configuration_type tabkey = <fs_item>-tabkey chngind = <fs_item>-chngind ).
        IF <fs_item>-chngind = 'U'.
          <fs_log_display>-fname = <fs_item>-fname.
          <fs_log_display>-ftext = <fs_item>-ftext.
          <fs_log_display>-f_old = <fs_item>-value_old.
          <fs_log_display>-f_new = <fs_item>-value_new.
        ENDIF.
      ENDLOOP.
    ENDLOOP.

    DATA(lt_col_set) = VALUE ztb_ul_alv_col( ( fieldname = 'UDATE' col_pos = 1 scrtext_m = 'Changed Date' )
                                             ( fieldname = 'UTIME' col_pos = 2 outputlen = 10 scrtext_m = 'Changed Time' )
                                             ( fieldname = 'USERNAME' col_pos = 3 scrtext_m = 'User name' )
                                             ( fieldname = 'CHNGIND' outputlen = 8 col_pos = 4 )
                                             ( fieldname = 'TABKEY' outputlen = 15 col_pos = 6 scrtext_m = 'Table Key' )
                                             ( fieldname = 'FTEXT' col_pos = 7 outputlen = 15 scrtext_m = 'Changed Field' )
                                             ( fieldname = 'F_OLD' col_pos = 8 outputlen = 40 scrtext_m = 'Old Value' )
                                             ( fieldname = 'F_NEW' col_pos = 9 outputlen = 40 scrtext_m = 'New Value') ).

    DATA(lt_sort) = VALUE lvc_t_sort( ( fieldname = 'UDATE' spos = 1 down = abap_true )
                                      ( fieldname = 'UTIME' spos = 2 down = abap_true ) ).

    zcl_ul_alv_adapter=>create( EXPORTING iv_popup     = abap_true
                                          it_col_set   = lt_col_set
                                          it_sort      = lt_sort
                                          iv_auto_hide = abap_true
                               CHANGING   ct_table     = t_log_display ).

  ENDMETHOD.

ENDCLASS.
