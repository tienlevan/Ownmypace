*&---------------------------------------------------------------------*
*&  Include           ZINS_UL_TABLE_MANAGER_USER_CL
*&---------------------------------------------------------------------*
CLASS lcl_ap DEFINITION.
  PUBLIC SECTION.
  CLASS-DATA: auth_tb TYPE zcl_ul_table_manager=>t_auth,
              er_del_data TYPE REF TO data.
  CLASS-METHODS: auth_check,
                 build_variant RETURNING VALUE(rs_variant) TYPE disvariant,
                 build_layout  RETURNING VALUE(rs_layout) TYPE lvc_s_layo,
                 build_catalog RETURNING VALUE(rt_catalog) TYPE lvc_t_fcat,
                 save_data     RETURNING VALUE(rv_result) TYPE char1,
                 del_data,
                 hide_func     RETURNING VALUE(rt_ex_func) TYPE ui_functions,
                 func_code.

 METHODS: on_user_command FOR EVENT user_command OF cl_gui_alv_grid
                                 IMPORTING e_ucomm.
ENDCLASS.

CLASS lcl_ap IMPLEMENTATION.
  METHOD auth_check.
    CHECK sy-ucomm IS NOT INITIAL.
    " Set up authorization object
    IF auth_tb IS INITIAL.
    auth_tb = VALUE #( ( ok_code = 'B1'   field1 = 'TABLE' value1 = viewname field2 = 'ACTVT' value2 = '03' acttext = 'Display' )
                       ( ok_code = 'B2'   field1 = 'TABLE' value1 = viewname field2 = 'ACTVT' value2 = '02' acttext = 'Modification')
                       ( ok_code = 'B3'   field1 = 'TABLE' value1 = viewname field2 = 'ACTVT' value2 = '60' acttext = 'Uploading')
                       ( ok_code = 'DEL'  field1 = 'TABLE' value1 = viewname field2 = 'ACTVT' value2 = '06' acttext = 'Deletion')
                       ( ok_code = 'NEW'  field1 = 'TABLE' value1 = viewname field2 = 'ACTVT' value2 = '01' acttext = 'Creation')
                       ( ok_code = 'CHG'  field1 = 'TABLE' value1 = viewname field2 = 'ACTVT' value2 = '02' acttext = 'Modification')
                       ( ok_code = 'SAV'  field1 = 'TABLE' value1 = viewname field2 = 'ACTVT' value2 = '09' acttext = 'Save')
                       ( ok_code = 'OPT1' field1 = 'TABLE' value1 = viewname field2 = 'ACTVT' value2 = '09' acttext = 'Save')
                       ( ok_code = 'OPT2' field1 = 'TABLE' value1 = viewname field2 = 'ACTVT' value2 = '09' acttext = 'Cancel' )
                       ( ok_code = 'DIS'  field1 = 'TABLE' value1 = viewname field2 = 'ACTVT' value2 = '02' acttext = 'Change Mode' ) ).
    ENDIF.
   " Check authorization
    zcl_ul_table_manager=>check_authorization( iv_obj = 'ZTABM' it_auth = auth_tb ).
 ENDMETHOD.

 METHOD build_variant.

   CHECK variant IS NOT INITIAL.
   rs_variant = VALUE #( report = sy-repid username = sy-uname variant = variant ).

 ENDMETHOD.

METHOD build_layout.

  rs_layout = VALUE #( sel_mode = 'A' zebra = 'X' col_opt = 'X' grid_title = |{ auth_tb[ ok_code = sy-ucomm ]-acttext } For Table { viewname } Data| ).

ENDMETHOD.

METHOD build_catalog.

  rt_catalog = zcl_ul_table_manager=>get_field_catalog( CHANGING ct_data = <ft_data> ).

  LOOP AT rt_catalog ASSIGNING FIELD-SYMBOL(<fs_catalog>).

    IF ( sy-ucomm = 'CHG' OR sy-ucomm = 'B2' OR sy-ucomm = 'DEL' ) AND <fs_catalog>-key = space.
      <fs_catalog>-edit = abap_true.
    ELSEIF sy-ucomm = 'NEW' OR sy-ucomm = 'B3'.
      <fs_catalog>-edit = abap_true.
    ELSEIF ( sy-ucomm = 'B1' OR sy-ucomm = 'SAV' ) AND <fs_catalog>-edit = abap_true.
      <fs_catalog>-edit = abap_false.
    ENDIF.

    IF <fs_catalog>-reptext IS INITIAL.
      <fs_catalog>-reptext = <fs_catalog>-fieldname.
    ENDIF.

    IF <fs_catalog>-fieldname = 'MANDT'.
      <fs_catalog>-tech = 'X'.
    ENDIF.

  ENDLOOP.

  ENDMETHOD.

  METHOD save_data.

  " Lock the table
      CALL FUNCTION 'ENQUEUE_E_TABLE'
        EXPORTING
          mode_rstable   = 'E'
          tabname        = viewname
        EXCEPTIONS
          foreign_lock   = 1
          system_failure = 2
          OTHERS         = 3.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      ENDIF.

    grid->ao_alv->check_changed_data( ).

    "Standard Table Update
  DATA(cf) = c_utils=>popup_to_confirm( id_caption = 'Confirm to Save Changes?' id_message = 'Are U sure to save these changes?' ).
  IF cf = '1'.
    IF grid->ar_mod_rows IS NOT INITIAL.
    FIELD-SYMBOLS <ft_data_changed> TYPE STANDARD TABLE.
    ASSIGN grid->ar_mod_rows->* TO <ft_data_changed>.
    MODIFY (viewname) FROM TABLE <ft_data_changed>.
    IF mode = 'B3'.
      grid->write_change_log( iv_mode = zcl_ul_table_manager=>log_mode-insert ).
    ELSE.
      grid->write_change_log( ).
    ENDIF.
   ENDIF.

   IF er_del_data IS NOT INITIAL.
   FIELD-SYMBOLS: <ft_data_del> TYPE STANDARD TABLE.
   ASSIGN er_del_data->* TO <ft_data_del>.
   DELETE (viewname) FROM TABLE <ft_data_del>.
   grid->write_change_log( iv_mode = zcl_ul_table_manager=>log_mode-delete ).
   ENDIF.

   CHECK sy-subrc IS INITIAL.

   MESSAGE 'Changes have been save!' TYPE 'S'.

   CALL FUNCTION 'DEQUEUE_E_TABLE'
      EXPORTING
        mode_rstable = 'E'
        tabname      = viewname.

   CLEAR: er_del_data.

  ELSE.

      MESSAGE 'No Change has been save!' TYPE 'W' DISPLAY LIKE 'S'.
      RETURN.

  ENDIF.

  ENDMETHOD.

METHOD del_data.

  FIELD-SYMBOLS: <fs_del_data> TYPE any,
                 <ft_del_data> TYPE STANDARD TABLE.
  grid->ao_alv->get_selected_rows( IMPORTING et_row_no = DATA(del_rows) ).
  CHECK del_rows IS NOT INITIAL.
  IF er_del_data IS INITIAL.
  CREATE DATA er_del_data TYPE TABLE OF (viewname).
  ENDIF.
  ASSIGN er_del_data->* TO <ft_del_data>.
  LOOP AT del_rows ASSIGNING FIELD-SYMBOL(<fs_del>) .
     READ TABLE <ft_data> ASSIGNING <fs_del_data> INDEX <fs_del>-row_id.
     APPEND <fs_del_data> TO <ft_del_data>.
     IF sy-tabix = 1.
       DELETE <ft_data> INDEX <fs_del>-row_id.
     ELSE.
       DELETE <ft_data> INDEX <fs_del>-row_id - 1.
     ENDIF.
  ENDLOOP.

  grid->ar_del_data = er_del_data.

ENDMETHOD.

METHOD func_code.

  sscrfields-functxt_01 = 'Select Options'.
  sscrfields-functxt_02 = 'Dynamic Report'.

  CASE sscrfields-ucomm.
    WHEN 'FC01'.
      zcl_ul_table_manager=>dynamic_select( EXPORTING iv_tabname  = viewname ).
    WHEN OTHERS.
  ENDCASE.

ENDMETHOD.

METHOD hide_func.

 rt_ex_func = VALUE #( ( cl_gui_alv_grid=>mc_fc_loc_append_row )
                       ( cl_gui_alv_grid=>mc_fc_loc_copy )
                       ( cl_gui_alv_grid=>mc_fc_loc_copy_row )
                       ( cl_gui_alv_grid=>mc_fc_loc_cut )
                       ( cl_gui_alv_grid=>mc_fc_loc_delete_row )
                       ( cl_gui_alv_grid=>mc_fc_loc_insert_row )
                       ( cl_gui_alv_grid=>mc_fc_loc_move_row ) ).

ENDMETHOD.

METHOD on_user_command.

  CASE e_ucomm.
    WHEN 'SEND'.
      CALL SCREEN 1001 STARTING AT 5 5.
    WHEN OTHERS.
  ENDCASE.

ENDMETHOD.

ENDCLASS.
