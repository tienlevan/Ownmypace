class ZCL_UL_DOI_USAGE definition
  public
  create public .

public section.

  types:
    BEGIN OF ty_file_info,
        attribute TYPE ech_pla_attribute_desc,
        value     TYPE epd_value,
      END OF ty_file_info .

  data AT_DOC_URIS type SBDST_URI .
  data AT_DOC_SIGNATURES type SBDST_SIGNATURE .
  data AT_DOC_COMPONENTS type SBDST_COMPONENTS .
  data AV_DOC_TYPE type SOI_DOCUMENT_TYPE .
  data AV_FIRST_SAVE type ABAP_BOOL .
  data AR_CONTROL type ref to I_OI_CONTAINER_CONTROL .
  data AR_VIEWER type ref to I_OI_DOCUMENT_VIEWER .
  data AR_CONTAINER type ref to CL_GUI_CONTAINER .
  data AR_TEXT_VIEWER type ref to CL_GUI_TEXTEDIT .

  class-methods GET_DOCID
    importing
      !IV_MAPKEY type ZTB_TREELOAD-DOCTYPE optional
      !IV_DOCNAME type STRING optional
    returning
      value(RV_DOCID) type BDS_DOCID .
  methods CONSTRUCTOR
    importing
      !IO_CONTAINER type ref to CL_GUI_CONTAINER optional
      !IV_OBJ_KEY type SBDST_OBJECT_KEY optional
    raising
      ZCX_UL_HANDLE_ERRORS .
  methods CREATE_DOCUMENT
    importing
      !IV_DOCUMENT_TYPE type SOI_DOCUMENT_TYPE
      !IV_DOCUMENT_FORMAT type SOI_DOCUMENT_TYPE default 'OLE'
      !IV_DOC_NAME type STRING
      !IV_CLASS_NAME type SBDST_CLASSNAME default 'SOFFICEINTEGRATION'
      !IV_CLASS_TYPE type SBDST_CLASSTYPE default 'OT'
    raising
      ZCX_UL_HANDLE_ERRORS .
  methods SAVE_DOCUMENT
    importing
      !IV_CLASS_NAME type SBDST_CLASSNAME default 'SOFFICEINTEGRATION'
      !IV_CLASS_TYPE type SBDST_CLASSTYPE default 'OT'
      !IV_OBJ_KEY type SBDST_OBJECT_KEY default 'DOI'
      !IV_DOC_ID type SBDST_DOC_ID optional
      !IV_VER_NO type SBDST_DOC_VER_NO optional
      !IV_DOC_VAR_ID type SBDST_DOC_VAR_ID optional
    raising
      ZCX_UL_HANDLE_ERRORS .
  methods CHANGE_DOCUMENT
    importing
      !IV_CLASS_NAME type SBDST_CLASSNAME
      !IV_CLASS_TYPE type SBDST_CLASSTYPE
      !IV_OBJ_KEY type SBDST_OBJECT_KEY
      !IV_DOC_ID type SBDST_DOC_ID optional
      !IV_VER_NO type SBDST_DOC_VER_NO optional
      !IV_DOC_VAR_ID type SBDST_DOC_VAR_ID optional
    raising
      ZCX_UL_HANDLE_ERRORS .
  methods OPEN_DOCUMENT
    importing
      !IV_CLASS_NAME type SBDST_CLASSNAME default 'SOFFICEINTEGRATION'
      !IV_CLASS_TYPE type SBDST_CLASSTYPE default 'OT'
      !IV_OBJ_KEY type SBDST_OBJECT_KEY default 'DOI'
      !IV_DOC_ID type BDS_DOCID
      !IV_DOCUMENT_FORMAT type SOI_DOCUMENT_TYPE default 'NATIVE'
      !IO_TREE_DISPLAY type ref to ZCL_UL_TREE_DISPLAY optional
      !IV_READ_ONLY type BOOLEAN default ABAP_FALSE
      !IV_INPLACE type BOOLEAN default ABAP_TRUE
      !IV_DOC_TITLE type BOOLEAN default ABAP_FALSE
      !IV_PROTECT_DOC type BOOLEAN default ABAP_FALSE .
  methods CLOSE_DOCUMENT
    returning
      value(RV_RETCODE) type SOI_RET_STRING .
  methods DELETE_DOCUMENT
    importing
      !IV_CLASS_NAME type SBDST_CLASSNAME default 'SOFFICEINTEGRATION'
      !IV_CLASS_TYPE type SBDST_CLASSTYPE default 'OT'
      !IV_OBJ_KEY type SBDST_OBJECT_KEY default 'DOI'
      !IV_DOC_ID type BDS_DOCID
    raising
      ZCX_UL_HANDLE_ERRORS .
  methods UPLOAD_DOCUMENT
    importing
      !IV_CLASS_NAME type SBDST_CLASSNAME default 'SOFFICEINTEGRATION'
      !IV_CLASS_TYPE type SBDST_CLASSTYPE default 'OT'
      !IV_FILE_PATH type STRING
    changing
      !CV_OBJ_KEY type SBDST_OBJECT_KEY default 'DOI'
      !CT_FILES type SBDST_FILES optional
    returning
      value(RV_DOC_ID) type BDS_DOCID .
  methods DOWNLOAD_DOCUMENT
    importing
      !IV_DOC_ID type BDS_DOCID
      !IV_CLASS_NAME type BDS_CLNAME default 'SOFFICEINTEGRATION'
      !IV_CLASS_TYPE type BDS_CLSTYP default 'OT'
      !IV_OBJ_KEY type BDS_TYPEID default 'DOI'
      !IV_TREENAME type STRING optional
    raising
      ZCX_UL_HANDLE_ERRORS .
  methods GET_APPLICATION
    importing
      !IV_DOCTYPE type SAEDOKTYP optional
      !IV_MIMETYPE type W3CONTTYPE optional
    returning
      value(RV_APPLTYPE) type SAEAPPLTYPE .
  methods SHOW_FILE_INFO
    importing
      !IV_CLASS_NAME type SBDST_CLASSNAME default 'SOFFICEINTEGRATION'
      !IV_CLASS_TYPE type SBDST_CLASSTYPE default 'OT'
      !IV_OBJ_KEY type SBDST_OBJECT_KEY default 'DOI'
      !IV_DOC_ID type BDS_DOCID
    raising
      ZCX_UL_HANDLE_ERRORS .
  methods GET_CONTENT
    importing
      !IV_CLASS type SDOK_CLASS default 'BDS_POC2'
      !IV_DOC_ID type BDS_DOCID
    exporting
      !EV_AS_STRING type STRING
      !EV_AS_XSTRING type XSTRING
      !EV_AS_RAW type STRING .
  methods TRANSPORT_DOCUMENT
    importing
      !IV_CLASS_NAME type SBDST_CLASSNAME default 'SOFFICEINTEGRATION'
      !IV_CLASS_TYPE type SBDST_CLASSTYPE default 'OT'
      !IV_OBJ_KEY type SBDST_OBJECT_KEY optional
      !IV_DOC_ID type BDS_DOCID .
  class-methods GET_FILE_NAME
    importing
      !IV_DOCID type BDS_DOCID
    returning
      value(RV_FILE_NAME) type STRING .
  methods READ_EXCEL_DATA
    importing
      !IV_SHEET_NAME type STRING optional
      !IS_SELECT_RANGE type SOI_DIMENSION_ITEM optional
      !IV_ACCEPT_NULL type BOOLE_D optional
      !IV_FILE_LOCATION type STRING optional
    exporting
      !ET_DATA type STANDARD TABLE
    returning
      value(RT_DATA) type SOI_GENERIC_TABLE
    raising
      ZCX_UL_HANDLE_ERRORS .
  class-methods DOWNLOAD_TEMPLATE
    importing
      !IV_MAPKEY type ZTB_TREELOAD-DOCTYPE .
  PROTECTED SECTION.
private section.

  data CX_ERROR type ref to ZCX_UL_HANDLE_ERRORS .
  data AR_BDS_INSTANCE type ref to CL_BDS_DOCUMENT_SET .
  data AR_PROXY type ref to I_OI_DOCUMENT_PROXY .
  data AV_DOC_URL type BAPIURI-URI .
  data AV_OBJ_KEY type SBDST_OBJECT_KEY value 'DOI' ##NO_TEXT.
  data AT_DOC_COMPONENTS2 type SBDST_COMPONENTS2 .

  methods CHECK_DOCUMENT_EXIST
    importing
      !IV_CLASS_NAME type SBDST_CLASSNAME default 'SOFFICEINTEGRATION'
      !IV_CLASS_TYPE type SBDST_CLASSTYPE default 'OT'
      !IV_OBJ_KEY type SBDST_OBJECT_KEY default 'DOI'
      !IV_DOC_ID type BDS_DOCID optional
    raising
      ZCX_UL_HANDLE_ERRORS .
  methods FILE_SEPARATOR
    importing
      !IV_FILE_PATH type STRING
    exporting
      !EV_FILE_NAME type BAPIFILES-FILENAME
      !EV_FILE_DIRECTORY type BAPIFILES-DIRECTORY .
ENDCLASS.



CLASS ZCL_UL_DOI_USAGE IMPLEMENTATION.


  METHOD change_document.

    CLEAR: at_doc_uris.

    ar_bds_instance->update_with_url( EXPORTING  classname       = iv_class_name
                                                 classtype       = iv_class_type
                                                 object_key      = iv_obj_key
                                                 doc_id          = at_doc_signatures[ 1 ]-doc_id
                                                 doc_ver_no      = at_doc_signatures[ 1 ]-doc_ver_no
                                                 doc_var_id      = at_doc_signatures[ 1 ]-doc_var_id
                                                 x_force_update  = abap_true
                                      CHANGING   components      = at_doc_components
                                                 uris            = at_doc_uris
                                                 signature       = at_doc_signatures
                                      EXCEPTIONS nothing_found   = 1
                                                 error_kpro      = 2
                                                 internal_error  = 3
                                                 parameter_error = 4
                                                 not_authorized  = 5
                                                 not_allowed     = 6 ).

    IF sy-subrc NE 0 AND sy-subrc NE 1 AND sy-subrc NE 6.
      cx_error->add_message_and_text_var( iv_id = 'DEMOOFFICEINTEGRATIO' iv_number = '016' ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    IF sy-subrc = 1.
      cx_error->add_message_and_text_var( iv_id = 'DEMOOFFICEINTEGRATIO' iv_number = '017' ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    IF sy-subrc = 6.
      cx_error->add_message_and_text_var( iv_id = 'DEMOOFFICEINTEGRATIO' iv_number = '018' ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    av_doc_url  = at_doc_uris[ 1 ]-uri.

  ENDMETHOD.


  METHOD check_document_exist.

    REFRESH: at_doc_signatures, at_doc_components.

    IF iv_doc_id IS NOT INITIAL.
      at_doc_signatures = VALUE #( ( doc_id = iv_doc_id ) ).
    ENDIF.

    CHECK ar_bds_instance IS BOUND.
    ar_bds_instance->get_info( EXPORTING  classname           = iv_class_name
                                          classtype           = iv_class_type
                                          object_key          = av_obj_key
                               IMPORTING  extended_components = at_doc_components2
                               CHANGING   components          = at_doc_components
                                          signature           = at_doc_signatures
                               EXCEPTIONS nothing_found       = 1
                                          error_kpro          = 2
                                          internal_error      = 3
                                          parameter_error     = 4
                                          not_authorized      = 5
                                          not_allowed         = 6 ).

    IF sy-subrc NE 0 AND sy-subrc NE 1.
      cx_error->add_message_and_text_var( iv_id = 'DEMOOFFICEINTEGRATIO' iv_number = '016' ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    IF sy-subrc = 1.
      cx_error->add_message_and_text_var( iv_id = 'DEMOOFFICEINTEGRATIO' iv_number = '017' ).
      RAISE EXCEPTION cx_error.
    ENDIF.

  ENDMETHOD.


  METHOD close_document.

    IF ar_proxy IS BOUND .
      ar_proxy->release_document( IMPORTING retcode = rv_retcode ).
      CHECK rv_retcode EQ c_oi_errors=>ret_ok.
      ar_proxy->close_document( EXPORTING do_save = abap_false
                                IMPORTING retcode = rv_retcode ).
    ELSE.
      rv_retcode = c_oi_errors=>ret_document_not_open.
    ENDIF.

  ENDMETHOD.


  METHOD constructor.

    DATA b_has_activex.

    CREATE OBJECT cx_error.

    CALL FUNCTION 'GUI_HAS_ACTIVEX'
      IMPORTING
        return = b_has_activex.

    IF b_has_activex IS INITIAL.
      cx_error->add_message_and_text_var( iv_id = 'DEMOOFFICEINTEGRATIO' iv_number = '007' ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    IF iv_obj_key IS NOT INITIAL.
      av_obj_key = iv_obj_key.
    ENDIF.

    CREATE OBJECT ar_bds_instance.

    CHECK io_container IS BOUND.
    ar_container = io_container.
    c_oi_container_control_creator=>get_container_control( IMPORTING control = ar_control ).
    c_oi_container_control_creator=>get_document_viewer( IMPORTING viewer = ar_viewer ).
    ar_viewer->init_viewer( EXPORTING parent = ar_container  ).

    CHECK ar_control IS BOUND.
    ar_control->init_control( r3_application_name      = 'DOI Framework'
                              inplace_enabled          = abap_true
                              inplace_scroll_documents = abap_true
                              inplace_resize_documents = abap_true
                              parent                   = ar_container ).

  ENDMETHOD.


  METHOD create_document.

    IF ar_proxy IS BOUND.
      close_document( ).
    ENDIF.

    IF ar_control IS NOT BOUND.
      cx_error->add_text( iv_message = 'This function is not supported!' ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    ar_control->get_document_proxy( EXPORTING document_type   = CONV #( get_application( iv_doctype = CONV #( iv_document_type ) ) )
                                              document_format = iv_document_format
                                    IMPORTING document_proxy  = ar_proxy
                                              retcode         = DATA(retcode) ).
    IF retcode NE c_oi_errors=>ret_ok.
      cx_error->add_text( iv_message = CONV #( retcode ) ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    ar_control->set_focus( ).
    ar_proxy->create_document( EXPORTING create_view_data = abap_false
                                         open_inplace     = abap_true
                               IMPORTING retcode          = retcode ).

    IF retcode NE c_oi_errors=>ret_ok.
      cx_error->add_text( iv_message = CONV #( retcode ) ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    DATA lv_mime_type TYPE bds_mimetp.
    SELECT SINGLE FROM toadd FIELDS mimetype WHERE doc_type = @iv_document_type INTO @lv_mime_type.

    at_doc_components = VALUE #( ( doc_count = 1 mimetype  = lv_mime_type comp_id = |{ iv_doc_name }.{ to_lower( iv_document_type ) }| ) ).
    at_doc_signatures = VALUE #( ( doc_count = 1 prop_name = 'DESCRIPTION' prop_value = iv_doc_name )
                                 ( doc_count = 1 prop_name = 'BDS_DOCUMENTCLASS' prop_value = iv_document_type ) ).

    ar_bds_instance->create_with_url( EXPORTING  classname       = iv_class_name
                                                 classtype       = iv_class_type
                                      CHANGING   components      = at_doc_components
                                                 signature       = at_doc_signatures
                                                 uris            = at_doc_uris
                                                 object_key      = av_obj_key
                                      EXCEPTIONS error_kpro      = 1
                                                 internal_error  = 2
                                                 parameter_error = 3
                                                 not_authorized  = 4
                                                 not_allowed     = 5 ).
    IF sy-subrc NE 0 AND sy-subrc NE 5.
      cx_error->add_message_and_text_var( iv_id = 'DEMOOFFICEINTEGRATIO' iv_number = '016' ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    IF sy-subrc = 5.
      cx_error->add_message_and_text_var( iv_id = 'DEMOOFFICEINTEGRATIO' iv_number = '018' ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    av_doc_url  = at_doc_uris[ 1 ]-uri.
    av_doc_type = iv_document_type.

    TRY.
        save_document( ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message( ).
    ENDTRY.

  ENDMETHOD.


  METHOD delete_document.

    CLEAR: at_doc_components, at_doc_signatures, at_doc_uris.

    TRY.
        check_document_exist( ).
      CATCH zcx_ul_handle_errors INTO DATA(cx_err).
        cx_error->add_exception_object( cx_err ).
        RAISE EXCEPTION cx_error.
    ENDTRY.

    DELETE at_doc_signatures WHERE doc_id <> iv_doc_id.

    CHECK at_doc_signatures IS NOT INITIAL.

    ar_bds_instance->delete( EXPORTING classname      = iv_class_name
                                       classtype      = iv_class_type
                                       object_key     = av_obj_key
                                       x_force_delete = abap_true
                             CHANGING  signature      = at_doc_signatures ).

  ENDMETHOD.


  METHOD download_document.

    DATA: lt_file       TYPE STANDARD TABLE OF bapifiles,
          lv_local_path TYPE string,
          lt_filetab    TYPE filetable,
          lv_extension  TYPE char10,
          lv_rc         TYPE i,
          lv_user_act   TYPE i.

    CLEAR: at_doc_components, at_doc_signatures.

    at_doc_signatures = VALUE #( ( doc_count = 1 doc_id = iv_doc_id doc_ver_no = 1 doc_var_id = 1 doc_var_tg = 'OR' comp_count = 1 ) ).

    CALL FUNCTION 'BDS_BUSINESSDOCUMENT_GET_INFO'
      EXPORTING
        classname       = iv_class_name
        classtype       = iv_class_type
        object_key      = av_obj_key
        all             = 'X'
      TABLES
        components      = at_doc_components
        signature       = at_doc_signatures
      EXCEPTIONS
        nothing_found   = 1
        parameter_error = 2
        not_allowed     = 3
        error_kpro      = 4
        internal_error  = 5
        not_authorized  = 6
        OTHERS          = 7.
    IF sy-subrc <> 0.
      cx_error->add_system_message( ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    CALL FUNCTION 'WS_QUERY'
      EXPORTING
        query          = 'CD'
      IMPORTING
        return         = lv_local_path
      EXCEPTIONS
        inv_query      = 1
        no_batch       = 2
        frontend_error = 3
        OTHERS         = 4.
    IF sy-subrc <> 0.
      cx_error->add_system_message( ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    CALL FUNCTION 'SA_KW_RFC_FILENAME_EXT_GET'
      EXPORTING
        mimetype  = at_doc_components[ 1 ]-mimetype
      IMPORTING
        extension = lv_extension.

    IF lv_extension IS NOT INITIAL.
      IF iv_treename IS NOT INITIAL.
        DATA(lv_file_name) = |{ iv_treename }.{ lv_extension }|.
      ELSE.
        SELECT SINGLE FROM ztb_treeload FIELDS text WHERE docname = @iv_doc_id INTO @lv_file_name.
        lv_file_name = |{ at_doc_signatures[ prop_name = 'DESCRIPTION' ]-prop_value }.{ lv_extension }|.
      ENDIF.
    ELSE.
      lv_file_name = at_doc_components[ 1 ]-comp_id.
    ENDIF.

    cl_gui_frontend_services=>file_save_dialog( EXPORTING window_title      = 'Select a directory'
                                                          initial_directory = lv_local_path
                                                          default_file_name = lv_file_name
                                                CHANGING  filename          = lv_file_name
                                                          path              = lv_local_path
                                                          fullpath          = lv_local_path
                                                          user_action       = lv_user_act ).

    IF sy-subrc <> 0.
      cx_error->add_system_message( ).
      RAISE EXCEPTION cx_error.
    ENDIF.


    lt_file = VALUE #( FOR ls_component IN at_doc_components ( doc_count = ls_component-doc_count comp_count = ls_component-comp_count
*                                                             filename = |{ lv_file_name }.{ lv_extension }|
                                                               filename = lv_file_name
                                                               directory = lv_local_path mimetype = ls_component-mimetype comp_id = ls_component-comp_id ) ).

    CALL FUNCTION 'BDS_BUSINESSDOCUMENT_GET_FILES'
      EXPORTING
        classname       = iv_class_name
        classtype       = iv_class_type
        object_key      = av_obj_key
      TABLES
        files           = lt_file
        signature       = at_doc_signatures
      EXCEPTIONS
        nothing_found   = 1
        parameter_error = 2
        not_allowed     = 3
        error_kpro      = 4
        internal_error  = 5
        not_authorized  = 6
        OTHERS          = 7.

    IF sy-subrc <> 0.
      cx_error->add_system_message( ).
      RAISE EXCEPTION cx_error.
    ENDIF.

  ENDMETHOD.


  METHOD download_template.

    SELECT SINGLE FROM ztb_treeload FIELDS docname WHERE doctype = @iv_mapkey INTO @DATA(docid).
    IF docid IS INITIAL.
      zcx_ul_handle_errors=>raise_message( iv_msg_text = 'No templated!' ).
      RETURN.
    ENDIF.

    TRY.
        NEW zcl_ul_doi_usage( )->download_document( iv_doc_id = docid ).
      CATCH zcx_ul_handle_errors INTO DATA(error).
        zcx_ul_handle_errors=>raise_message( io_msg_object = error ).
    ENDTRY.

  ENDMETHOD.


  METHOD file_separator.

    DATA: lv_save_offset TYPE i.

    ev_file_name = iv_file_path.

    DO.
      IF ev_file_name CS '\'.
        DATA(lv_new_offset) = sy-fdpos + 1.
        ev_file_name = ev_file_name+lv_new_offset(*).
        ADD lv_new_offset TO lv_save_offset.
      ELSE.
        EXIT.
      ENDIF.
    ENDDO.

    ev_file_directory = iv_file_path(lv_save_offset).

  ENDMETHOD.


  METHOD get_application.

    IF iv_doctype IS NOT INITIAL.
      SELECT SINGLE FROM toadd FIELDS appl_type
         WHERE doc_type = @iv_doctype INTO @rv_appltype.
    ELSE.
      SELECT SINGLE FROM toadd FIELDS appl_type
         WHERE mimetype = @iv_mimetype INTO @rv_appltype.
    ENDIF.

    IF sy-subrc NE 0.
      rv_appltype = 'SAPHTML'.
    ENDIF.

  ENDMETHOD.


  METHOD get_content.

    DATA:
      ls_object_id TYPE sdokobject,
      lt_info      TYPE STANDARD TABLE OF sdokfilaci,
      ls_info      TYPE REF TO sdokfilaci,
      lt_text      TYPE STANDARD TABLE OF sdokcntasc,
      lt_bin       TYPE STANDARD TABLE OF sdokcntbin,
      lv_file_size TYPE i.
    FIELD-SYMBOLS:
     <lt_table>   TYPE STANDARD TABLE.

    CLEAR ev_as_string.
    CLEAR ev_as_xstring.
    ls_object_id = iv_doc_id.
    ls_object_id-class = iv_class.

    CALL FUNCTION 'SDOK_PHIO_LOAD_CONTENT'
      EXPORTING
        object_id           = ls_object_id
        text_as_stream      = abap_true
      TABLES
        file_access_info    = lt_info
        file_content_ascii  = lt_text
        file_content_binary = lt_bin
      EXCEPTIONS
        OTHERS              = 5.
    IF sy-subrc <> 0.
      cx_error->add_system_message( ).
      cx_error->show_message( ).
    ENDIF.

    READ TABLE lt_info REFERENCE INTO ls_info INDEX 1.
    CHECK sy-subrc = 0.

    " Text or binary
    IF lt_bin[] IS NOT INITIAL.
      ASSIGN lt_bin  TO <lt_table>.
    ELSE.
      ASSIGN lt_text TO <lt_table>.
    ENDIF.

    " Detect file size
    lv_file_size = ls_info->file_size.

    " Result as a xstring
    IF ev_as_xstring IS REQUESTED.
      ev_as_xstring = zcl_ul_abap=>binary_to_xstring(
        it_table  = <lt_table>
        iv_length = lv_file_size ).
    ENDIF.

    " Result as a string. if ev_as_STRING Is Requested
    IF ev_as_string IS REQUESTED.
      ev_as_string = zcl_ul_abap=>binary_to_string(
        it_table  = <lt_table>
        iv_length = lv_file_size ).
    ENDIF.

    "Get raw data
    ev_as_raw = concat_lines_of( table = <lt_table> sep = cl_abap_char_utilities=>newline ).

  ENDMETHOD.


  METHOD get_docid.

    DATA lt_components TYPE sbdst_components.
    DATA lt_signatures TYPE sbdst_signature.

    IF iv_mapkey IS NOT INITIAL.
      SELECT SINGLE FROM ztb_treeload FIELDS docname WHERE doctype = @iv_mapkey INTO @rv_docid .
    ELSEIF iv_docname IS NOT INITIAL.
      cl_bds_document_set=>get_info( EXPORTING classname  = 'SOFFICEINTEGRATION'
                                               classtype  = 'OT'
                                               object_key = 'DOI'
                                     CHANGING  components = lt_components
                                               signature  = lt_signatures ).
      TRY.
          DATA(lv_doc_count) = lt_components[ comp_id = iv_docname ]-doc_count.
          rv_docid = lt_signatures[ doc_count = lv_doc_count ]-doc_id.
        CATCH cx_sy_itab_line_not_found INTO DATA(cx_error).
          zcx_ul_handle_errors=>raise_message( io_msg_object = cx_error ).
      ENDTRY.
    ENDIF.

  ENDMETHOD.


  METHOD get_file_name.

    DATA lt_components TYPE sbdst_components.
    DATA lt_signatures TYPE sbdst_signature.

    lt_signatures = VALUE #( ( doc_id = iv_docid ) ).

    cl_bds_document_set=>get_info( EXPORTING classname  = 'SOFFICEINTEGRATION'
                                             classtype  = 'OT'
                                             object_key = 'DOI'
                                   CHANGING  components = lt_components
                                             signature  = lt_signatures ).

*    DELETE lt_signatures WHERE doc_id NE iv_docid.

    TRY.
        DATA(lv_doc_count) = lt_signatures[ 1 ]-doc_count.
        rv_file_name = lt_components[ doc_count = lv_doc_count ]-comp_id.
        FIND '.' IN rv_file_name.
        CHECK sy-subrc IS NOT INITIAL.
        READ TABLE lt_signatures INTO DATA(ls_signature) WITH KEY prop_name = 'BDS_DOCUMENTCLASS'.
        CHECK sy-subrc IS INITIAL.
        DATA(ext) = to_lower( ls_signature-prop_value ).
        CONCATENATE rv_file_name ext INTO rv_file_name SEPARATED BY '.'.
      CATCH cx_sy_itab_line_not_found INTO DATA(cx_error).
        zcx_ul_handle_errors=>raise_message( io_msg_object = cx_error ).
    ENDTRY.

  ENDMETHOD.


  METHOD open_document.

    CLEAR: at_doc_components, at_doc_uris, at_doc_signatures, at_doc_components2.

    close_document( ).

    TRY.
        check_document_exist( iv_class_name = iv_class_name
                              iv_class_type = iv_class_type
                              iv_obj_key    = av_obj_key
                              iv_doc_id     = iv_doc_id ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message( ).
        RETURN.
    ENDTRY.

*    DELETE at_doc_signatures WHERE doc_id <> iv_doc_id.
*    DELETE at_doc_components WHERE doc_count <> at_doc_signatures[ 1 ]-doc_count.

    IF at_doc_signatures IS NOT INITIAL.

      ar_bds_instance->get_with_url( EXPORTING classname  = iv_class_name
                                               classtype  = iv_class_type
                                               object_key = av_obj_key
                                               url_lifetime = 'T'
                                     CHANGING  uris       = at_doc_uris
                                               signature  = at_doc_signatures ).

      av_doc_url = at_doc_uris[ 1 ]-uri.
      DATA(lv_doc_name) = at_doc_signatures[ 1 ]-doc_id.

    ELSE.

      MESSAGE 'No document is existed' TYPE 'I'.
      RETURN.

    ENDIF.

    DATA(lv_app) = get_application( iv_doctype = CONV #( at_doc_signatures[ prop_name = 'BDS_DOCUMENTCLASS' ]-prop_value ) ).

    IF lv_app = 'OUTLOOK'.

      DATA: lv_type TYPE sdok_prv_m.
      lv_type = at_doc_signatures[ prop_name = 'BDS_DOCUMENTCLASS' ]-prop_value.
      CALL FUNCTION 'BDS_OBJECT_DISPLAY_INTERN'
        EXPORTING
          classname      = iv_class_name
          classtype      = iv_class_type
          object_key     = av_obj_key "iv_obj_key
          bds_contrep    = 'BDS_DB2_R'
          bds_docuclass  = lv_type
        TABLES
          signature      = at_doc_signatures
        EXCEPTIONS
          error_kpro     = 1
          internal_error = 2
          OTHERS         = 3.

      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
         WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      ENDIF.

    ELSEIF lv_app = 'SAPHTML'.

      DATA: guiversion TYPE filetable, rc TYPE i.
      cl_gui_frontend_services=>get_gui_version( CHANGING version_table = guiversion rc = rc ).

      IF guiversion[ 1 ]-filename CP '8*' OR guiversion[ 1 ]-filename CP '77*'.
        IF io_tree_display->ar_html_control IS NOT BOUND.
          io_tree_display->ar_html_control = NEW #( parent = io_tree_display->ar_html lifetime = cl_gui_html_viewer=>lifetime_dynpro ).
        ENDIF.

        DATA(lv_alignment) = io_tree_display->ar_html_control->align_at_left +
                             io_tree_display->ar_html_control->align_at_right +
                             io_tree_display->ar_html_control->align_at_top +
                             io_tree_display->ar_html_control->align_at_bottom.

        io_tree_display->ar_html_control->set_alignment( alignment = lv_alignment ).
        DATA(filename) = get_file_name( iv_docid = at_doc_signatures[ 1 ]-doc_id ).
        DATA(file) = NEW zcl_xtt_file_oaor( iv_classname = iv_class_name iv_classtype = iv_class_type
                                            iv_object_key = iv_obj_key iv_filename = get_file_name( iv_docid = at_doc_signatures[ 1 ]-doc_id ) ).
        IF filename CP '*.HTM*'.
          file->zif_xtt_file~get_content( IMPORTING et_as_text = DATA(t_data) ).
*          zcl_ul_abap=>xstring_to_binary( EXPORTING iv_xstring = zcl_ul_abap=>string_to_xstring( EXPORTING iv_string = raw_data )
*                                          IMPORTING et_table = DATA(t_data) ev_length = DATA(size) ).
          io_tree_display->ar_html_control->load_data( EXPORTING type = 'text' subtype = 'html'
                                                       IMPORTING assigned_url = av_doc_url
                                                       CHANGING data_table = t_data ).
          io_tree_display->ar_html_control->show_url( url = av_doc_url ).
          io_tree_display->set_visible_object( io_tree_display->ar_html_control ).
        ELSE.
          io_tree_display->ar_html_control->show_url( url = av_doc_url ).
          io_tree_display->set_visible_object( io_tree_display->ar_html_control ).
        ENDIF.
      ELSE.
        IF io_tree_display->ar_doi_doc->ar_viewer IS BOUND.
          io_tree_display->ar_doi_doc->ar_viewer->view_document_from_url( document_url = av_doc_url show_inplace = abap_false ).
        ENDIF.
      ENDIF.

      cl_gui_cfw=>flush( ).

    ELSEIF lv_app = 'NOTEPAD'.

      file = NEW zcl_xtt_file_oaor( iv_classname = iv_class_name iv_classtype = iv_class_type
                                      iv_object_key = iv_obj_key iv_filename = get_file_name( iv_docid = at_doc_signatures[ 1 ]-doc_id ) ).
      file->zif_xtt_file~get_content( IMPORTING ev_as_raw = DATA(raw_data) ).
      ar_text_viewer = NEW cl_gui_textedit( parent = io_tree_display->ar_doi_doc->ar_container ).
      ar_text_viewer->set_textstream( raw_data ).
      ar_text_viewer->set_enable( enable = abap_true ).
      io_tree_display->set_visible_object( ar_text_viewer ).

    ELSE.

      CHECK ar_control IS BOUND.
      ar_control->get_document_proxy( EXPORTING document_type   = lv_app
                                                document_format = iv_document_format
                                      IMPORTING document_proxy  = ar_proxy
                                                retcode         = DATA(lv_retcode)
                                                error           = DATA(lo_error) ).

      IF lv_retcode NE c_oi_errors=>ret_ok.
        lo_error->raise_message( EXPORTING type = 'I' ).
        RETURN.
      ENDIF.

      ar_proxy->open_document( EXPORTING document_url     = av_doc_url
                                         open_inplace     = iv_inplace
                                         open_readonly    = iv_read_only
                                         document_title   = iv_doc_title
                                         protect_document = iv_protect_doc ).

      CHECK io_tree_display->ar_html IS BOUND.
      io_tree_display->set_visible( 'C_OI_CONTAINER_CONTROL_PROXY' ).
      ar_control->set_focus( ).

    ENDIF.

  ENDMETHOD.


  METHOD read_excel_data.

    DATA: spreadsheet TYPE REF TO i_oi_spreadsheet,
          error       TYPE REF TO i_oi_error,
          table       TYPE REF TO zcl_ul_alv_adapter,
          lr_data     TYPE REF TO data,
          lr_line     TYPE REF TO data.

    DATA: data_range TYPE soi_dimension_table,
          sheetname  TYPE text100,
          ranges     TYPE soi_range_list.

    FIELD-SYMBOLS: <ft_data> TYPE STANDARD TABLE,
                   <fs_data> TYPE any.

    IF ar_proxy IS NOT BOUND.
      c_oi_container_control_creator=>get_container_control( IMPORTING control = ar_control ).
      ar_control->init_control( inplace_enabled = abap_true  r3_application_name = 'EXCEL CONTAINER' parent = cl_gui_container=>screen2 ).
      ar_control->get_document_proxy( EXPORTING document_type   = soi_doctype_excel_sheet
                                      IMPORTING document_proxy  = ar_proxy
                                                error           = error  ).
      IF error->has_failed = abap_true.
        error->get_message( IMPORTING message_id = sy-msgid message_number = sy-msgno param1 = sy-msgv1
                            param2 = sy-msgv2 param3 = sy-msgv3 param4 = sy-msgv4 ).
        cx_error->add_system_message( ).
        RAISE EXCEPTION cx_error.
      ENDIF.
      ar_proxy->open_document( EXPORTING document_url = |FILE://{ iv_file_location }|
                                         open_inplace = abap_true ).
      IF error->has_failed = abap_true.
        error->get_message( IMPORTING message_id = sy-msgid message_number = sy-msgno param1 = sy-msgv1
                            param2 = sy-msgv2 param3 = sy-msgv3 param4 = sy-msgv4 ).
        cx_error->add_system_message( ).
        RAISE EXCEPTION cx_error.
      ENDIF.
    ENDIF.

    ar_proxy->get_spreadsheet_interface( IMPORTING sheet_interface = spreadsheet
                                                   error = error ).
    IF error->has_failed = abap_true.
      error->get_message( IMPORTING message_id = sy-msgid message_number = sy-msgno param1 = sy-msgv1
                            param2 = sy-msgv2 param3 = sy-msgv3 param4 = sy-msgv4 ).
      cx_error->add_system_message( ).
      RAISE EXCEPTION cx_error.
    ELSE.
      IF iv_sheet_name IS INITIAL.
        spreadsheet->get_active_sheet( IMPORTING sheetname = sheetname ).
      ELSE.
        spreadsheet->get_sheets( IMPORTING sheets = DATA(sheets) ).
        IF line_exists( sheets[ sheet_name = iv_sheet_name ] ).
          sheetname = iv_sheet_name.
        ELSE.
          cx_error->add_text( iv_message = 'Sheet &1 does not exist!' iv_variable_1 = CONV #( iv_sheet_name ) ).
          RAISE EXCEPTION cx_error.
        ENDIF.

      ENDIF.
      spreadsheet->select_sheet( EXPORTING name = sheetname
                                 IMPORTING error = error ).

      IF error->has_failed = abap_true.
        error->get_message( IMPORTING message_id = sy-msgid message_number = sy-msgno param1 = sy-msgv1
                            param2 = sy-msgv2 param3 = sy-msgv3 param4 = sy-msgv4 ).
        cx_error->add_system_message( ).
        RAISE EXCEPTION cx_error.
      ENDIF.

      spreadsheet->set_selection( EXPORTING top  = is_select_range-row left = is_select_range-column
                                            rows = is_select_range-rows columns = is_select_range-columns ).

      APPEND is_select_range TO data_range.
      spreadsheet->get_ranges_data( EXPORTING rangesdef = data_range
                                    IMPORTING contents  = rt_data
                                              error     = error
                                    CHANGING  ranges    = ranges ).
      IF error->has_failed = abap_true.
        error->get_message( IMPORTING message_id = sy-msgid message_number = sy-msgno param1 = sy-msgv1
                            param2 = sy-msgv2 param3 = sy-msgv3 param4 = sy-msgv4 ).
        cx_error->add_system_message( ).
        RAISE EXCEPTION cx_error.
      ENDIF.

      IF iv_accept_null IS INITIAL.
        DELETE rt_data WHERE value IS INITIAL.
      ENDIF.

    ENDIF.

    CHECK rt_data IS NOT INITIAL AND et_data IS REQUESTED.
    CREATE OBJECT table.
    table->lvc_fcat_from_itab( CHANGING ct_table = et_data ).
    DATA(t_table) = table->t_fcat.
    CREATE DATA lr_data LIKE et_data.
    ASSIGN lr_data->* TO <ft_data>.
    CREATE DATA lr_line LIKE LINE OF et_data.
    ASSIGN lr_line->* TO <fs_data>.

    LOOP AT rt_data ASSIGNING FIELD-SYMBOL(<gr_data>) GROUP BY <gr_data>-row ASSIGNING FIELD-SYMBOL(<row>).
      LOOP AT GROUP <row> ASSIGNING FIELD-SYMBOL(<data>).
        DATA(col_name) = t_table[ col_pos = <data>-column ]-fieldname.
        DATA(col_type) = t_table[ col_pos = <data>-column ]-datatype.
        IF col_type = 'DATS' AND strlen( <data>-value ) = 10.
          REPLACE ALL OCCURRENCES OF '/' IN <data>-value WITH '.' IN CHARACTER MODE.
          IF NEW ycl_abap_date( )->check_date_format( CONV #( <data>-value ) ) IS INITIAL.
            CALL FUNCTION 'CONVERT_DATE_TO_INTERNAL'
              EXPORTING
                accept_initial_date = abap_true
                date_external       = <data>-value
              IMPORTING
                date_internal       = <data>-value.
          ENDIF.
        ENDIF.
        ASSIGN COMPONENT col_name OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<val>).
        <val> = <data>-value.
      ENDLOOP.
      APPEND <fs_data> TO <ft_data>.
      CLEAR <fs_data>.
    ENDLOOP.

    IF cx_error->has_messages( ) IS NOT INITIAL.
      RAISE EXCEPTION cx_error.
    ENDIF.

    et_data = <ft_data>.

    ar_proxy->close_document( ).

  ENDMETHOD.


  METHOD save_document.

    IF ar_proxy IS BOUND.

      cl_gui_cfw=>dispatch( ).
      IF av_first_save IS NOT INITIAL.

        ar_proxy->save_document_to_url( url = av_doc_url ).
        CALL METHOD ar_bds_instance->confirm_create
          EXPORTING
            classname       = iv_class_name
            classtype       = iv_class_type
            object_key      = av_obj_key
            x_force_confirm = abap_true
          CHANGING
            signature       = at_doc_signatures
            uris            = at_doc_uris
            components      = at_doc_components
          EXCEPTIONS
            nothing_found   = 1
            error_kpro      = 2
            error_dp        = 3
            internal_error  = 4
            parameter_error = 5
            not_authorized  = 6
            not_allowed     = 7.

      ELSE.

        change_document( iv_class_name = iv_class_name
                         iv_class_type = iv_class_type
                         iv_obj_key    = av_obj_key ).

        ar_proxy->save_document_to_url( url = av_doc_url ).

        CALL METHOD ar_bds_instance->confirm_update
          EXPORTING
            classname       = iv_class_name
            classtype       = iv_class_type
            object_key      = av_obj_key
            x_force_confirm = abap_true
          CHANGING
            signature       = at_doc_signatures
            uris            = at_doc_uris
            components      = at_doc_components
          EXCEPTIONS
            nothing_found   = 1
            error_kpro      = 2
            error_dp        = 3
            internal_error  = 4
            parameter_error = 5
            not_authorized  = 6
            not_allowed     = 7.

      ENDIF.

      IF sy-subrc NE 0 AND sy-subrc NE 1 AND sy-subrc NE 7.
        cx_error->add_message_and_text_var( iv_id = 'DEMOOFFICEINTEGRATIO' iv_number = '016' ).
        RAISE EXCEPTION cx_error.
      ENDIF.

      IF sy-subrc = 1.
        cx_error->add_message_and_text_var( iv_id = 'DEMOOFFICEINTEGRATIO' iv_number = '017' ).
        RAISE EXCEPTION cx_error.
      ENDIF.

      IF sy-subrc = 7.
        cx_error->add_message_and_text_var( iv_id = 'DEMOOFFICEINTEGRATIO' iv_number = '018' ).
        RAISE EXCEPTION cx_error.
      ENDIF.

*    IF av_first_save = abap_false.
*      CHECK zcl_ul_abap=>popup_to_confirm( 'Transport the document?' ) = '1'.
*      transport_document( iv_class_name = iv_class_name iv_class_type = iv_class_type iv_doc_id = iv_doc_id iv_obj_key = iv_obj_key ).
*    ENDIF.

      av_first_save = abap_false.

    ELSEIF ar_text_viewer IS BOUND.

      DATA: lt_text      TYPE STANDARD TABLE OF sdokcntasc,
            lt_info      TYPE STANDARD TABLE OF sdokfilaci,
            lv_text      TYPE string,
            ls_object_id TYPE sdokobject.
      cl_gui_cfw=>flush( ).
      ar_text_viewer->get_text_as_stream( IMPORTING is_modified = DATA(ischanged)
                                                    text        = lt_text ).
      IF ischanged IS NOT INITIAL.
        ls_object_id-objid = at_doc_components2[ 1 ]-objid.
        ls_object_id-class = at_doc_components2[ 1 ]-class.
        CALL FUNCTION 'SDOK_PHIO_LOAD_CONTENT'
          EXPORTING
            object_id        = ls_object_id
            text_as_stream   = abap_true
          TABLES
            file_access_info = lt_info.
        CALL FUNCTION 'SDOK_PHIO_UNPROTECT'
          EXPORTING
            object_id = ls_object_id.
        CALL FUNCTION 'SDOK_PHIO_STORE_CONTENT'
          EXPORTING
            object_id          = ls_object_id
            text_as_stream     = abap_on
          TABLES
            file_access_info   = lt_info
            file_content_ascii = lt_text.
        CALL FUNCTION 'SDOK_PHIO_PROTECT'
          EXPORTING
            object_id = ls_object_id.
      ELSE.
        MESSAGE 'Saving is not required' TYPE 'S'.
      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD show_file_info.

    DATA lt_file_info TYPE TABLE OF ty_file_info.

    CLEAR: at_doc_components, at_doc_uris, at_doc_signatures.

    TRY.
        check_document_exist( iv_class_name = iv_class_name
                              iv_class_type = iv_class_type
                              iv_obj_key    = iv_obj_key ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message( ).
        RETURN.
    ENDTRY.

    DELETE at_doc_signatures WHERE doc_id <> iv_doc_id.

    IF at_doc_signatures IS NOT INITIAL.
      lt_file_info = VALUE #( ( attribute = 'Document Name' value = at_doc_signatures[ prop_name = 'DESCRIPTION' ]-prop_value )
                              ( attribute = 'Document Type' value = at_doc_signatures[ prop_name = 'BDS_DOCUMENTCLASS' ]-prop_value )
                              ( attribute = 'Created By'    value = at_doc_signatures[ prop_name = 'CREATED_BY' ]-prop_value )
                              ( attribute = 'Created At'    value = zcl_ul_abap=>convert_timestamp( iv_input = abap_false iv_timestamp = CONV #( at_doc_signatures[ prop_name = 'CREATED_AT' ]-prop_value ) ) ) ).
    ELSE.
      cx_error->add_text( iv_type = 'I' iv_message = 'The document does not exist or not validate!' ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    zcl_ul_alv_adapter=>create( EXPORTING iv_popup   = abap_true
                                          it_col_set = VALUE #( ( fieldname = 'ATTRIBUTE' outputlen = 25 ) )
                                CHANGING  ct_table   = lt_file_info ).


  ENDMETHOD.


  METHOD transport_document.

    DATA lt_commfile_entries TYPE TABLE OF bapicomfil.
    DATA lt_e071 TYPE tr_objects.
    DATA lt_e071k TYPE tr_keys.

    DATA(lv_object_key) = COND #( WHEN iv_obj_key IS NOT INITIAL THEN iv_obj_key ELSE av_obj_key ).
    REFRESH: at_doc_components, at_doc_signatures.

    CALL FUNCTION 'BDS_BUSINESSDOCUMENT_GET_INFO'
      EXPORTING
        classname       = iv_class_name
        classtype       = iv_class_type
        object_key      = lv_object_key
        all             = 'X'
      TABLES
        components      = at_doc_components
        signature       = at_doc_signatures
      EXCEPTIONS
        nothing_found   = 1
        parameter_error = 2
        not_allowed     = 3
        error_kpro      = 4
        internal_error  = 5
        not_authorized  = 6
        OTHERS          = 7.

    CHECK zcx_ul_handle_errors=>raise_message( ) IS INITIAL.
    DELETE at_doc_signatures WHERE doc_id NE iv_doc_id.
    DATA(lv_doc_count) = at_doc_signatures[ 1 ]-doc_count.
    DELETE at_doc_components WHERE doc_count NE lv_doc_count.

    CALL FUNCTION 'BDS_BUSINESSDOCUMENT_GET_TP'
      EXPORTING
        classname        = iv_class_name
        classtype        = iv_class_type
        client           = sy-mandt
        object_key       = lv_object_key
      TABLES
        signature        = at_doc_signatures
        commfile_entries = lt_commfile_entries
      EXCEPTIONS
        nothing_found    = 1
        error_kpro       = 2
        internal_error   = 3
        not_authorized   = 4
        parameter_error  = 5
        not_allowed      = 6
        OTHERS           = 7.

    CHECK zcx_ul_handle_errors=>raise_message( ) IS INITIAL.

    lt_e071 = CORRESPONDING #( lt_commfile_entries ).
    DELETE ADJACENT DUPLICATES FROM lt_e071 COMPARING ALL FIELDS.
    SELECT SINGLE FROM ztb_treeload FIELDS * WHERE docname = @iv_doc_id INTO @DATA(ls_node).
    DATA(lv_tab_key) = zcl_ul_abap=>build_key( iv_add_client = abap_true is_data = ls_node ).
    DATA(ls_e071) = VALUE e071( pgmid = 'R3TR' object = 'TABU' obj_name = 'ZTB_TREELOAD' objfunc = 'K' ).
    APPEND ls_e071 TO lt_e071.
    lt_e071k = VALUE #( ( mastertype = ls_e071-object mastername = ls_e071-obj_name pgmid = 'R3TR' object = 'TABU' objname = 'ZTB_TREELOAD' tabkey = lv_tab_key ) ).
    SELECT SINGLE FROM ztb_tree_rtcode FIELDS * WHERE modulelo = @ls_node-modulelo AND node_key = @ls_node-node_key INTO @DATA(ls_tree_code).
    IF sy-subrc IS INITIAL.
      lv_tab_key = zcl_ul_abap=>build_key( iv_add_client = abap_true is_data = ls_tree_code ).
      ls_e071 = VALUE #( pgmid = 'R3TR' object = 'TABU' obj_name = 'ZTB_TREE_RTCODE' objfunc = 'K' ).
      APPEND ls_e071 TO lt_e071.
      lt_e071k = VALUE #( BASE lt_e071k ( mastertype = ls_e071-object mastername = ls_e071-obj_name pgmid = 'R3TR' object = 'TABU' objname = 'ZTB_TREE_RTCODE' tabkey = lv_tab_key ) ).
    ENDIF.

    CALL FUNCTION 'TR_REQUEST_CHOICE'
      EXPORTING
        iv_request_types     = 'K'
        it_e071              = lt_e071
        it_e071k             = lt_e071k
        iv_title             = 'Transport document'
      EXCEPTIONS
        invalid_request      = 1
        invalid_request_type = 2
        user_not_owner       = 3
        no_objects_appended  = 4
        enqueue_error        = 5
        cancelled_by_user    = 6
        recursive_call       = 7
        OTHERS               = 8.

    IF sy-subrc <> 0.
      zcx_ul_handle_errors=>raise_message( ).
      RETURN.
    ENDIF.

    DATA(lv_doc_name) = at_doc_components[ 1 ]-comp_id.
    zcx_ul_handle_errors=>raise_message( iv_msg_type = zcx_ul_handle_errors=>msgtype-information
                                         iv_msg_text = |File { lv_doc_name } was added to transport!| ).


  ENDMETHOD.


  METHOD upload_document.

    DATA: lv_obj_key TYPE sbdst_object_key,
          ls_file    LIKE LINE OF ct_files.

    DATA: lv_name   TYPE string,
          lv_ext    TYPE string,
          lt_offset TYPE match_result_tab.

    file_separator( EXPORTING iv_file_path      = iv_file_path
                    IMPORTING ev_file_directory = ls_file-directory
                              ev_file_name      = ls_file-filename ).

    CALL FUNCTION 'SKWF_MIMETYPE_OF_FILE_GET'
      EXPORTING
        filename = ls_file-filename
      IMPORTING
        mimetype = ls_file-mimetype.

    ls_file-doc_count = 1.

    APPEND ls_file TO ct_files.
    FIND ALL OCCURRENCES OF '.' IN ls_file-filename RESULTS lt_offset IN CHARACTER MODE.
    SORT lt_offset DESCENDING BY offset.
    DATA(offset) = lt_offset[ 1 ]-offset + 1.
    lv_ext = ls_file-filename+offset.
    DATA(len) = strlen( ls_file-filename ) - strlen( lv_ext ) - 1.
    lv_name = ls_file-filename(len).

    at_doc_signatures = VALUE #( ( doc_count = 1  prop_name = 'BDS_DOCUMENTCLASS' prop_value = to_upper( lv_ext ) )
                                 ( doc_count = 1  prop_name = 'DESCRIPTION'       prop_value = lv_name ) ).

    ar_bds_instance->create_with_files( EXPORTING  classname       = iv_class_name
                                                   classtype       = iv_class_type
                                        CHANGING   files           = ct_files
                                                   object_key      = av_obj_key
                                                   signature       = at_doc_signatures
                                        EXCEPTIONS internal_error  = 1
                                                   error_kpro      = 2
                                                   parameter_error = 3
                                                   not_allowed     = 4
                                                   not_authorized  = 5
                                                   nothing_found   = 6
                                                   OTHERS          = 7 ).

    IF sy-subrc <> 0.
      c_oi_errors=>show_message( type = 'E' ).
    ELSE.
      rv_doc_id = at_doc_signatures[ 1 ]-doc_id.
    ENDIF.

  ENDMETHOD.
ENDCLASS.
