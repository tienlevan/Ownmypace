FUNCTION zfm_alv_cleanup.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"----------------------------------------------------------------------

  READ TABLE gt_alv INTO DATA(gs_alv) WITH KEY alv = go_alv.
  IF sy-subrc IS INITIAL.
    IF go_alv->parent IS BOUND.
      go_alv->free( ).
    ENDIF.
    IF go_parent IS BOUND.
      go_parent->free( ).
      FREE go_parent.
    ENDIF.
    DELETE gt_alv INDEX gs_alv-index.
    IF lines( gt_alv ) > 0.
      zcl_ul_alv_adapter=>o_grid = go_alv = gt_alv[ gs_alv-index - 1 ]-alv.
    ENDIF.
  ENDIF.

ENDFUNCTION.
