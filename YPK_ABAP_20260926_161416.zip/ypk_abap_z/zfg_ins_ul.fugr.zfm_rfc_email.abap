FUNCTION ZFM_RFC_EMAIL.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     VALUE(IV_EMAIL) TYPE  STRING
*"----------------------------------------------------------------------

  DATA email TYPE REF TO zcl_ul_send_email.

*  CALL TRANSFORMATION id_indent SOURCE XML iv_email RESULT o_email = email.
*  email->send_email( ).

ENDFUNCTION.
