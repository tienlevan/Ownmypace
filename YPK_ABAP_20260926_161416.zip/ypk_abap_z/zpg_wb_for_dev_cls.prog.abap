*&---------------------------------------------------------------------*
*&  Include  zpg_wb_for_dev_cls
*&---------------------------------------------------------------------*

CLASS lcl_toolbar DEFINITION.

  PUBLIC SECTION.
    CLASS-DATA: enable_wb        TYPE boole_d,
                tool_selected    TYPE char40,
                adapter_selected TYPE char40.

    METHODS: constructor IMPORTING container_box     TYPE REF TO cl_gui_container
                                   adapter_box       TYPE REF TO cl_gui_container
                                   container_toolbar TYPE REF TO cl_gui_container.

    METHODS: load_toolbar IMPORTING toolbar TYPE char40,
      add_second_toolbar, hide_button IMPORTING fcode TYPE ui_func,
      add_tree_button IMPORTING hide TYPE boole_d.

  PRIVATE SECTION.
    DATA: _toolbar          TYPE REF TO cl_gui_toolbar,
          _combobox         TYPE REF TO cl_gui_combobox,
          _combobox_adapter TYPE REF TO cl_gui_combobox.

    METHODS: _handle_combobox_selected FOR EVENT selected OF cl_gui_combobox
      IMPORTING key,
      _handle_adapter_selected FOR EVENT selected OF cl_gui_combobox
        IMPORTING key,
      _handle_button_click FOR EVENT function_selected OF cl_gui_toolbar
        IMPORTING fcode.

    METHODS: _call_tree_api.

ENDCLASS.

CLASS lcl_screen_display DEFINITION.

  PUBLIC SECTION.
    DATA: screen TYPE REF TO cl_gui_container,
          text   TYPE REF TO cl_gui_textedit.
    CLASS-DATA: alv TYPE REF TO zcl_salv_services.
    METHODS: constructor IMPORTING splitter TYPE REF TO cl_gui_splitter_container,
      hide_screen, check_screen_active RETURNING VALUE(result) TYPE i,
      active_screen, display_alv IMPORTING title TYPE lvc_title
                                           t_setting  TYPE ztb_alv_settings
                                 CHANGING ct_data TYPE ANY TABLE.

    METHODS: display_template IMPORTING tree_node   TYPE ztb_treeload
                              CHANGING  ct_code_run TYPE soli_tab,
      display_screen_out, display_text.

  PRIVATE SECTION.
    DATA: _splitter TYPE REF TO cl_gui_splitter_container.

ENDCLASS.

CLASS lcl_tree DEFINITION.

  PUBLIC SECTION.
    DATA text TYPE REF TO cl_gui_textedit.
    METHODS: constructor IMPORTING container_tree TYPE REF TO cl_gui_container
                                   container_main TYPE REF TO cl_gui_container
                                   splitter       TYPE REF TO cl_gui_splitter_container.

    METHODS: update_tree IMPORTING tree TYPE char40,
      call_wb IMPORTING reload_code TYPE soli_tab OPTIONAL, enable_wb IMPORTING enable TYPE boole_d,
      get_editor_content RETURNING VALUE(t_codes) TYPE soli_tab,
      get_node RETURNING VALUE(rs_node) TYPE ztb_treeload,
      pretty_editor_content CHANGING  ct_codes        TYPE soli_tab
                            RETURNING VALUE(is_error) TYPE boole_d,
      get_textedit_content RETURNING VALUE(rv_text) TYPE string,
      save_editor_content IMPORTING wb_type TYPE char40,
      call_tree_api IMPORTING it_tree TYPE zcl_ul_tree_display=>tb_treeload,
      get_tree_object RETURNING VALUE(ro_tree) TYPE REF TO zcl_ul_tree_display,
      save_tree_width.

    METHODS: transport, hide_tree, add_tree_button, call_text, suppress,
      generated_template CHANGING ct_code_run TYPE soli_tab.


  PRIVATE SECTION.
    CLASS-DATA _tree_width TYPE i.
    DATA: _tree     TYPE REF TO zcl_ul_tree_display,
          _splitter TYPE REF TO cl_gui_splitter_container.

    METHODS _get_configuration EXPORTING VALUE(et_tree) TYPE zcl_ul_tree_display=>tb_treeload.


ENDCLASS.

CLASS lcl_adapter DEFINITION.

  PUBLIC SECTION.
    DATA: t_code_generated TYPE soli_tab,
          text_in          TYPE string,
          text_out         TYPE string,
          client_state     TYPE cccategory.

    METHODS: constructor.
    METHODS: load_code IMPORTING code TYPE char3,
      get_editor_code, pretty_code RETURNING VALUE(error) TYPE boole_d, run_code.
    METHODS: save IMPORTING wb_type TYPE char40.
    METHODS: settings, call_api_adapter.

  PRIVATE SECTION.
    DATA: _t_code_run       TYPE soli_tab.

ENDCLASS.

CLASS lcl_alv DEFINITION INHERITING FROM zcl_ul_alv_adapter.

  PUBLIC SECTION.
    TYPES: BEGIN OF ty_tms,
             sysnam      TYPE tmssysnam,
             systxt      TYPE as4text,
             dev_flag    TYPE flag,
             qas_flag    TYPE flag,
             prd_flag    TYPE flag,
             sync_client TYPE mandt,
           END OF ty_tms.

    CLASS-DATA: t_tms TYPE TABLE OF ty_tms.

    METHODS: mine_save_event REDEFINITION.

ENDCLASS.

CLASS lcl_screen_display IMPLEMENTATION.

  METHOD constructor.

    _splitter = splitter.
    screen   = _splitter->get_container( row = 1 column = 3 ).
    hide_screen(  ).

  ENDMETHOD.

  METHOD hide_screen.

    _splitter->set_column_width( id = 3 width = 0 ).
*    _splitter->set_column_width( id = 1 width = 15 ).
    _splitter->set_border( gfw_false ).

  ENDMETHOD.

  METHOD check_screen_active.

    _splitter->get_column_width( EXPORTING id = 3 IMPORTING result = result ).
    cl_gui_cfw=>flush(  ).

  ENDMETHOD.

  METHOD active_screen.

    _splitter->set_column_width( EXPORTING id = 3 width = 35 ).
    go_toolbar->add_second_toolbar(  ).

    IF lcl_toolbar=>adapter_selected(3) = 'CON'.
      _splitter->set_column_width( EXPORTING id = 3 width = 50 ).
    ENDIF.

  ENDMETHOD.

  METHOD display_alv.

    IF check_screen_active(  ) IS INITIAL.
      active_screen(  ).
    ENDIF.

    IF alv IS BOUND.
      TRY.
          alv->mo_salv_table->set_data( CHANGING t_table = ct_data  ).
        CATCH cx_salv_no_new_data_allowed.
      ENDTRY.
      alv->mo_salv_table->get_display_settings(  )->set_list_header( title ).
      alv->mo_salv_table->refresh( refresh_mode = if_salv_c_refresh=>full ).
      cl_gui_cfw=>flush( ).
      RETURN.
    ENDIF.

    IF alv IS NOT BOUND.
      CREATE OBJECT alv.
    ENDIF.

    alv->general_services( EXPORTING iv_title          = title
                                     it_table_setting  = t_setting
                           CHANGING  co_container      = screen
                                     ct_table          = ct_data ).

  ENDMETHOD.



  METHOD display_template.

    DATA runtime TYPE bwsd_runtime.

    DATA(lo_file) = NEW zcl_ul_file_create( iv_template  = zcl_ul_doi_usage=>get_file_name( tree_node-docname )
                                            io_container = screen ).

    MESSAGE |Processing time: { lo_file->execute( EXPORTING is_node    = tree_node
                                                  CHANGING  ct_wb_code = ct_code_run ) } ms!| TYPE 'S'.

    IF check_screen_active(  ) IS INITIAL.
      active_screen(  ).
    ENDIF.

  ENDMETHOD.

  METHOD display_screen_out.

    LOOP AT screen->children ASSIGNING FIELD-SYMBOL(<child>).
      <child>->free(  ).
    ENDLOOP.

    IF check_screen_active(  ) IS INITIAL.
      active_screen(  ).
    ENDIF.

  ENDMETHOD.

  METHOD display_text.

    IF check_screen_active(  ) IS INITIAL.
      active_screen(  ).
    ENDIF.

    IF text IS BOUND.
      text->free(  ).
      CLEAR go_adapter->text_out.
    ENDIF.

    text = NEW #( parent = screen lifetime = cl_gui_container=>lifetime_dynpro ).
    text->set_textstream( go_adapter->text_out ).
    cl_gui_cfw=>flush( ).
    text->set_readonly_mode( 1 ).


  ENDMETHOD.

ENDCLASS.

CLASS lcl_tree IMPLEMENTATION.

  METHOD constructor.

    _splitter = splitter.
    _tree = NEW #( iv_module = sy-uname io_container = container_tree io_browser = container_main iv_redifined_screen = abap_false ).
*    _tree->tree_display(  ).
*    _splitter->get_column_width( EXPORTING id = 1 IMPORTING result = _tree_width ).

  ENDMETHOD.

  METHOD update_tree.

    DATA: tree_module TYPE ztb_treeload-modulelo.

    _tree->ar_tree->free(  ).
    FREE _tree->ar_tree.

    CASE tree.
      WHEN gc_tool_abap.
        tree_module = 'WB_TREE' ##NO_TEXT.
      WHEN gc_tool_stms.
        tree_module = 'WB_STMS' ##NO_TEXT.
      WHEN gc_tool_temp.
        tree_module = 'WB_TEMP' ##NO_TEXT.
      WHEN gc_tool_cfg.
        tree_module = 'WB_CFGR' ##NO_TEXT.
        _get_configuration( IMPORTING et_tree = DATA(t_group) ).
      WHEN OTHERS.
        tree_module = tree.
    ENDCASE.

    save_tree_width(  ).
    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'WB_DEV' iv_mainkey = CONV #( sy-uname ) iv_subkey = tree
                                  IMPORTING e_data = _tree_width ).
    IF _tree_width = 0.
      _tree_width = 30.
    ENDIF.

    _splitter->set_column_width( id = 1 width = _tree_width ).

    _tree = NEW #( iv_module = tree_module io_container = _tree->ar_tree_cont io_browser = _tree->ar_html iv_redifined_screen = abap_false
                   iv_img_bds = SWITCH #( tree WHEN gc_tool_abap THEN 'ZWBX_ABAP' WHEN gc_tool_stms THEN 'ZWBX_STMS' WHEN gc_tool_temp THEN 'ZWBX_TEMPLATE' ) ).
    _tree->tree_display( t_group ).

  ENDMETHOD.

  METHOD call_wb.

    IF _tree->ar_editor IS BOUND.
      _tree->ar_editor->free(  ).
      FREE _tree->ar_editor.
    ENDIF.

    REFRESH go_adapter->t_code_generated.
    lcl_toolbar=>enable_wb = abap_true.
    go_adapter->load_code( 'CMT' ).

    TRY.
        DATA(s_node_key) = _tree->get_node_inf( _tree->get_selected_node(  ) ).
      CATCH zcx_ul_handle_errors.
        zcx_ul_handle_errors=>raise_message( iv_msg_text = 'No support for this function!' ).
        RETURN.
    ENDTRY.

    IF lcl_toolbar=>tool_selected = gc_tool_temp AND sy-ucomm NE 'EXELS'.

      IF reload_code IS INITIAL.


        SELECT SINGLE FROM ztb_tree_rtcode
            FIELDS rt_code
            WHERE modulelo = @_tree->av_module
            AND   node_key = @s_node_key-node_key
            INTO @DATA(lv_code).

        IF lv_code IS INITIAL.
          SELECT SINGLE FROM ztb_tree_rtcode
              FIELDS rt_code
              WHERE modulelo = @_tree->av_module
              AND   node_key = @s_node_key-relatkey
              INTO @lv_code.
        ENDIF.

        SPLIT lv_code AT cl_abap_char_utilities=>cr_lf
                      INTO TABLE DATA(t_code).
        APPEND LINES OF t_code TO go_adapter->t_code_generated.

      ELSE.

        APPEND LINES OF reload_code TO go_adapter->t_code_generated.

      ENDIF.

    ELSE.

      IF s_node_key-acc_type = zcl_ul_tree_display=>c_node_code.

        SELECT SINGLE FROM ztb_tree_rtcode
            FIELDS rt_code
            WHERE modulelo = @_tree->av_module
            AND   node_key = @s_node_key-node_key
            INTO @lv_code.

        SPLIT lv_code AT cl_abap_char_utilities=>cr_lf
                       INTO TABLE t_code.
        APPEND LINES OF t_code TO go_adapter->t_code_generated.

      ELSE.

        DATA t_cached_code LIKE go_adapter->t_code_generated.
        zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'WB_DEV' iv_mainkey = 'LAST_RUN' iv_subkey = CONV #( sy-uname )
                                      IMPORTING e_data = t_cached_code ).
        APPEND LINES OF t_cached_code TO go_adapter->t_code_generated.

      ENDIF.

    ENDIF.

    _tree->editor_call(  ).
    _tree->ar_editor->set_text( table = go_adapter->t_code_generated ).
    enable_wb( lcl_toolbar=>enable_wb ).

  ENDMETHOD.

  METHOD get_editor_content.

    CHECK _tree->ar_editor IS BOUND.
    _tree->ar_editor->get_text( IMPORTING table = t_codes[]
                                EXCEPTIONS error_dp = 1 ).


  ENDMETHOD.

  METHOD pretty_editor_content.

    CALL FUNCTION 'PRETTY_PRINTER'
      EXPORTING
        inctoo = ' '
      TABLES
        ntext  = ct_codes
        otext  = ct_codes.

    TRY.
        _tree->ar_editor->set_text( EXPORTING table = ct_codes ).
      CATCH cx_sy_ref_is_initial INTO DATA(cx_error).
        zcx_ul_handle_errors=>raise_message( io_msg_object = cx_error ).
        is_error = abap_true.
    ENDTRY.

  ENDMETHOD.

  METHOD enable_wb.

    CHECK _tree->ar_editor IS BOUND.

    TRY.
        IF enable = abap_true AND ( go_adapter->client_state = 'C' OR sy-uname IN zcl_ul_abap=>get_stvarv_val( 'ZTABM_SUPERUSER' ) ).
          _tree->ar_editor->set_readonly_mode( _tree->ar_editor->false ).
        ELSE.
          _tree->ar_editor->set_readonly_mode( _tree->ar_editor->true ).
        ENDIF.
      CATCH zcx_ul_handle_errors INTO DATA(error).
        zcx_ul_handle_errors=>raise_message( io_msg_object = error ).
        _tree->ar_editor->set_readonly_mode( _tree->ar_editor->true ).
    ENDTRY.


  ENDMETHOD.

  METHOD save_editor_content.

    DATA code_str TYPE string.

    TRY.
        DATA(node_selected) = _tree->get_node_inf( _tree->get_selected_node(  ) ).
      CATCH zcx_ul_handle_errors INTO DATA(cx_error).
        cx_error->raise_message(  ).
    ENDTRY.

    LOOP AT get_editor_content(  ) ASSIGNING FIELD-SYMBOL(<fs_curqur>) WHERE line(1) NE '*'.
      CONCATENATE code_str <fs_curqur> cl_abap_char_utilities=>cr_lf
       INTO code_str.
    ENDLOOP.

    CASE wb_type.

      WHEN gc_tool_abap.

        IF  node_selected-acc_type NE zcl_ul_tree_display=>c_node_code.
          IF node_selected-isfolder IS INITIAL.
            zcx_ul_handle_errors=>raise_message( iv_msg_text = 'Please select a folder!' ).
            RETURN.
          ENDIF.

          SORT _tree->at_config DESCENDING BY pos.
          DATA(pos) = _tree->at_config[ 1 ]-pos + 1.
          _tree->add_nodes( it_nodes = VALUE #( ( modulelo = _tree->av_module node_key = |ITEM{ pos }|
                                                  n_image = '@6X@' text = 'Describe me...' pos = _tree->at_config[ 1 ]-pos + 1
                                                  relatkey = node_selected-node_key relatship = 6 acc_type = '10' dragdropid = 1
                                                  created_on = zcl_ul_abap=>encode_timestamp(  ) created_by = sy-uname length = 15 ) ) ).

          DATA(s_code_str) = VALUE ztb_tree_rtcode( modulelo = _tree->av_module node_key = |ITEM{ pos }|  rt_code = code_str ).

        ELSE.

          s_code_str = VALUE ztb_tree_rtcode( modulelo = _tree->av_module node_key = node_selected-node_key  rt_code = code_str ).

        ENDIF.

      WHEN gc_tool_temp.

        IF node_selected-acc_type NE zcl_ul_tree_display=>c_node_doc AND node_selected-isfolder = abap_false.
          zcx_ul_handle_errors=>raise_message( iv_msg_text = 'Please select a correct node for saving your development!' ).
          RETURN.
        ENDIF.

        s_code_str = VALUE ztb_tree_rtcode( modulelo = _tree->av_module node_key = node_selected-node_key  rt_code = code_str ).

      WHEN gc_tool_api.
        IF lcl_toolbar=>adapter_selected(3) = 'API'.
          IF node_selected-isfolder IS INITIAL.
            zcx_ul_handle_errors=>raise_message( iv_msg_text = 'Please select a folder!' ).
            RETURN.
          ENDIF.
          SORT _tree->at_config DESCENDING BY pos.
          pos = _tree->at_config[ 1 ]-pos + 1.
          _tree->add_nodes( it_nodes = VALUE #( ( modulelo = 'APIREQUEST' node_key = |ITEM{ pos }|
                                                  n_image = '@6X@' text = 'Describe me...' pos = _tree->at_config[ 1 ]-pos + 1
                                                  relatkey = node_selected-node_key relatship = 6 acc_type = '16' dragdropid = 1
                                                  created_on = zcl_ul_abap=>encode_timestamp(  ) created_by = sy-uname length = 15 ) ) ).
          go_tree->text->get_textstream( IMPORTING text = code_str ).
          cl_gui_cfw=>flush( ).
          s_code_str = VALUE ztb_tree_rtcode( modulelo = 'APIREQUEST' node_key = |ITEM{ pos }|  rt_code = code_str ).
        ENDIF.

    ENDCASE.

    IF _tree->av_doc_open IS INITIAL AND code_str IS NOT INITIAL.
      MODIFY ztb_tree_rtcode FROM s_code_str.
      CHECK sy-subrc IS INITIAL.
      MESSAGE 'Your code has been saved!' TYPE 'S'.
    ELSE.
      TRY.
          _tree->ar_doi_doc->save_document( iv_doc_id = node_selected-docname ).
          MESSAGE 'Your template has been saved!' TYPE 'S'.
        CATCH zcx_ul_handle_errors INTO cx_error.
          zcx_ul_handle_errors=>raise_message( io_msg_object = cx_error ).
      ENDTRY.
    ENDIF.

    _tree->ar_tree->set_selected_node( node_key = node_selected-node_key ).

  ENDMETHOD.

  METHOD transport.

    _tree->transport_menu(  ).

  ENDMETHOD.

  METHOD get_tree_object.
    ro_tree = _tree.
  ENDMETHOD.

  METHOD generated_template.

    TRY .
        DATA(tree_node) = _tree->get_node_inf( iv_nodekey = _tree->get_selected_node( ) ).
      CATCH zcx_ul_handle_errors INTO DATA(cx_error).
        zcx_ul_handle_errors=>raise_message( io_msg_object = cx_error ).
        RETURN.
    ENDTRY.

    IF tree_node-acc_type NE zcl_ul_tree_display=>c_node_doc.
      zcx_ul_handle_errors=>raise_message( iv_msg_text = 'Please select a document!'  ).
      RETURN.
    ENDIF.

    go_screen_display->display_template( EXPORTING tree_node = tree_node
                                         CHANGING  ct_code_run = ct_code_run ).

  ENDMETHOD.

  METHOD hide_tree.

    cl_gui_cfw=>flush(  ).
    _tree_width = COND #( WHEN _tree_width > 0 THEN 0 ELSE 20 ).
    _splitter->set_column_width( id = 1 width = _tree_width ).
    _splitter->set_border( gfw_false ).
    go_toolbar->load_toolbar( lcl_toolbar=>tool_selected ).

  ENDMETHOD.

  METHOD add_tree_button.

    IF _tree_width = 0.
      _splitter->set_column_width( id = 1 width = 0 ).
    ENDIF.

    cl_gui_cfw=>flush(  ).
    go_toolbar->add_tree_button( hide = COND #( WHEN _tree_width > 0 THEN abap_true ELSE abap_false ) ).

  ENDMETHOD.

  METHOD _get_configuration.

    DATA t_group TYPE TABLE OF zcl_ul_dynamic_configuration=>ty_configuration_group.

    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_GRP'
                                    IMPORTING e_data = t_group  ).

    SORT t_group ASCENDING BY configuration_group.
    et_tree = VALUE #( FOR s_group IN t_group INDEX INTO i ( node_key = |ITEM{ i }| text = s_group-configuration_group_txt pos = i + 2
                                                             n_image = icon_status_best class = 2 length = strlen( s_group-configuration_group_txt )
                                                             acc_type = zcl_ul_tree_display=>c_node_dycf programname = s_group-configuration_group
                                                             relatkey = 'NODE0001' relatship = 6 ) ).
    APPEND INITIAL LINE TO et_tree ASSIGNING FIELD-SYMBOL(<fs_tree>).
    <fs_tree> = VALUE #( node_key = 'NODE0001' pos = 1 isfolder = abap_true n_image = icon_configuration style = 1 class = 2
                         length = 30 text = 'Configuration' expander = abap_true ).
    APPEND INITIAL LINE TO et_tree ASSIGNING <fs_tree>.
    <fs_tree> = VALUE #( node_key = 'ITEM9999' pos = 2 n_image = icon_adjust_configuration class = 2
                         length = 30 text = 'Define Configuration' relatkey = 'NODE0001' relatship = 6 acc_type = zcl_ul_tree_display=>c_node_dycf ).
    SORT et_tree ASCENDING BY pos.

  ENDMETHOD.

  METHOD call_text.

    IF _tree->ar_textedit IS BOUND.
      _tree->ar_textedit->free(  ).
      CLEAR go_adapter->text_in.
      FREE: text, _tree->ar_textedit.
    ENDIF.

    _tree->textedit_call(  ).
    text = _tree->ar_textedit.

    SELECT SINGLE FROM ztb_wb_api FIELDS input_flag WHERE kind = @lcl_toolbar=>adapter_selected(3) INTO @DATA(input_flag).
    IF input_flag IS INITIAL.
      text->set_readonly_mode( text->true ).
    ELSE.
      text->set_readonly_mode( text->false ).
    ENDIF.

  ENDMETHOD.

  METHOD get_textedit_content.

  ENDMETHOD.

  METHOD suppress.

    _splitter->set_column_width( id = 1 width = 0 ).
    _splitter->set_border( gfw_false ).

  ENDMETHOD.

  METHOD get_node.

    TRY.
        rs_node = _tree->get_node_inf( _tree->get_selected_node(  ) ).
      CATCH zcx_ul_handle_errors INTO DATA(cx_error).
        cx_error->show_message(  ).
    ENDTRY.

  ENDMETHOD.

  METHOD call_tree_api.

    _tree->ar_tree->free(  ).
    FREE _tree->ar_tree.

    _tree = NEW #( iv_module = 'APIREQUEST' io_container = _tree->ar_tree_cont io_browser = _tree->ar_html iv_redifined_screen = abap_false iv_redifined_event = abap_false ).
    _tree->tree_display( it_tree ).
    _splitter->set_column_width( id = 1 width = _tree_width ).

  ENDMETHOD.

  METHOD save_tree_width.

    CHECK go_toolbar IS BOUND.
    _splitter->get_column_width( EXPORTING id = 1 IMPORTING result = DATA(save_width) ).
    cl_gui_cfw=>flush( ).
    CHECK save_width > 0.
    zcl_ul_data_layer=>write_data( is_key = VALUE #( application = 'WB_DEV' main_key = sy-uname sub_key = lcl_toolbar=>tool_selected )
                                   is_data = save_width ).

  ENDMETHOD.

ENDCLASS.


CLASS lcl_toolbar IMPLEMENTATION.

  METHOD constructor.

    DATA key TYPE char40.

    _toolbar  = NEW #( container_toolbar ).
    _toolbar->set_registered_events( EXPORTING events = VALUE #( ( eventid = cl_gui_toolbar=>m_id_function_selected appl_event = abap_true ) ) ).
    SET HANDLER _handle_button_click FOR _toolbar.

    _combobox = NEW #( parent = container_box label_text = 'Workbench:' label_width = 10 ) ##NO_TEXT.
    _combobox->set_items( item_tab = VALUE #( ( key = gc_tool_abap text = 'ABAP Toolkit' )
                                              ( key = gc_tool_stms text = 'Transport Management' )
                                              ( key = gc_tool_temp text = 'Template Management' )
                                              ( key = gc_tool_cfg  text = 'Dynamic Configuration'  )
                                              ( key = gc_tool_api  text = 'API Toolkit' )
                                              ( key = sy-uname     text = 'User Menu' ) ) ).

    SET HANDLER _handle_combobox_selected FOR _combobox.
    _combobox->activate_selection_event( ).

    _combobox_adapter = NEW #( parent = adapter_box label_text = 'Adapter:' label_width = 10 ) ##NO_TEXT.
    SELECT FROM ztb_wb_api_cls FIELDS kind, adapter, description INTO TABLE @DATA(t_adapters).

    _combobox_adapter->set_items( item_tab = VALUE #( FOR adapter IN t_adapters ( key = |{ adapter-kind }_{ adapter-adapter }|
                                                                                  text = adapter-description ) ) ).
    SET HANDLER _handle_adapter_selected FOR _combobox_adapter.
    _combobox_adapter->activate_selection_event(  ).

    tool_selected = zcl_ul_data_layer=>read_data( iv_application = 'WB_DEV' iv_mainkey = CONV #( sy-uname ) ).
    IF tool_selected IS INITIAL OR tool_selected = gc_tool_user.
      key  = sy-uname.
    ELSE.
      key = tool_selected.
    ENDIF.
    _combobox->set_selected_item( key ).
    _handle_combobox_selected( key ).

  ENDMETHOD.

  METHOD load_toolbar.

    _toolbar->delete_all_buttons(  ).
    DATA(disable) = SWITCH boole_d( go_adapter->client_state WHEN 'C' THEN abap_false ELSE abap_true ).


    CASE toolbar.

      WHEN gc_tool_abap.

        _toolbar->add_button_group( data_table = VALUE #( ( icon = icon_abap text = 'Call WB' function = 'CALLWB' )
                                                          ( icon = icon_execute_object text = 'Execution' function = 'EXECU' )
                                                          ( icon = icon_open text = 'Load previous run' function = 'EXELS' ) ) ).
        IF disable = abap_false.
          _toolbar->add_button_group( data_table = VALUE #( ( icon = icon_toggle_display_change text = 'Change<=>Display' function = 'CHANGE' )
                                                            ( icon = icon_qualify text = 'Pretty Print' function = 'FORMAT' ) ) ).
        ENDIF.
      WHEN gc_tool_temp.
        _toolbar->add_button_group( data_table = VALUE #( ( icon = icon_abap text = 'Call WB' function = 'CALLWB' )
                                                          ( icon = icon_generate text = 'Generate File' function = 'EXECU' ) ) ).
        IF disable = abap_false.
          _toolbar->add_button_group( data_table = VALUE #( ( icon = icon_toggle_display_change text = 'Change<=>Display' function = 'CHANGE' )
                                                            ( icon = icon_qualify text = 'Pretty Print' function = 'FORMAT' ) ) ).
        ENDIF.
      WHEN gc_tool_stms.
        IF disable = abap_false.
          _toolbar->add_button_group( data_table = VALUE #( ( icon = icon_transportation_mode text = 'My Own TR State' function = 'TRSTATE' )
                                                            ( icon = icon_settings text = 'Settings' function = 'SETTINGS' ) ) ).
        ENDIF.
      WHEN gc_tool_api.
        _toolbar->add_button_group( data_table = VALUE #( ( icon = icon_execute_object text = 'Execution' function = 'EXEAD' ) ) ).
    ENDCASE.

    IF disable = abap_false.
      _toolbar->add_button( butn_type = cntb_btype_button icon = icon_transport text = 'Transport' fcode = 'TRANS' ).
    ENDIF.

    IF go_screen_display->check_screen_active(  ) IS NOT INITIAL.
      add_second_toolbar(  ).
    ENDIF.

    IF go_toolbar IS BOUND.
      go_tree->add_tree_button(  ).
    ELSE.
      add_tree_button( abap_true ).
    ENDIF.

  ENDMETHOD.

  METHOD add_second_toolbar.
    _toolbar->add_button_group( EXPORTING data_table = VALUE #( ( butn_type = cntb_btype_check text = 'Hide Second Screen' function = 'HIDE' icon = icon_graphics  ) )
                                EXCEPTIONS cntb_error_fcode = 1 dp_error = 2 OTHERS = 3 ). " state to avoid dumping
  ENDMETHOD.

  METHOD add_tree_button.
    _toolbar->add_button( icon = icon_display_tree butn_type = cntb_btype_button text = SWITCH #( hide WHEN abap_true THEN 'Hide Tree' ELSE 'Open Tree' )  fcode = 'HTREE' ).
  ENDMETHOD.

  METHOD hide_button.
    _toolbar->delete_button( fcode = fcode ).
  ENDMETHOD.

  METHOD _handle_combobox_selected.

    go_tree->update_tree( key ).
    load_toolbar( key ).
    tool_selected = key.
    go_screen_display->hide_screen(  ).
    zcl_ul_data_layer=>write_data( is_data = lcl_toolbar=>tool_selected is_key = VALUE #( application = 'WB_DEV' main_key = sy-uname ) ).

    IF tool_selected NE gc_tool_api.
      _combobox_adapter->set_visible( abap_false ).
    ELSE.
      _combobox_adapter->set_visible( abap_true ).
      IF adapter_selected IS NOT INITIAL.
        _handle_adapter_selected( adapter_selected ).
      ENDIF.
    ENDIF.

  ENDMETHOD.

  METHOD _handle_button_click.

    CASE fcode.
      WHEN 'CALLWB'.
        go_tree->call_wb(  ).
      WHEN 'HIDE'.
        go_screen_display->hide_screen(  ).
        go_toolbar->hide_button( fcode ).
      WHEN 'HTREE'.
        go_tree->hide_tree(  ).
      WHEN 'FORMAT'.
        go_adapter->pretty_code(  ).
      WHEN 'EXECU'.
        go_adapter->run_code(  ).
      WHEN 'CHANGE'.
        lcl_toolbar=>enable_wb = SWITCH #( lcl_toolbar=>enable_wb WHEN abap_true THEN abap_false ELSE abap_true ).
        go_tree->enable_wb( lcl_toolbar=>enable_wb ).
      WHEN 'TRANS'.
        go_tree->transport(  ).
      WHEN 'TRSTATE'.
        ycl_abap_transport=>compare_tr_system(  ).
      WHEN 'SETTINGS'.
        go_adapter->settings(  ).
      WHEN 'EXELS'.
        go_tree->call_wb(  ).
      WHEN 'EXEAD'.
        go_adapter->call_api_adapter(  ).
    ENDCASE.
  ENDMETHOD.

  METHOD _handle_adapter_selected.

    adapter_selected = key.
    _call_tree_api(  ).
    go_tree->call_text(  ).
    go_screen_display->display_text(  ).

  ENDMETHOD.

  METHOD _call_tree_api.

    DATA adapter TYPE REF TO zif_ul_wb_adapter.
    DATA object TYPE REF TO object.

    SELECT SINGLE FROM ztb_wb_api FIELDS class, tree_flag WHERE kind = @lcl_toolbar=>adapter_selected(3) INTO ( @DATA(class), @DATA(tree_flag) ).
    CREATE OBJECT object TYPE (class).
    adapter ?= object.

    IF tree_flag IS NOT INITIAL.
      adapter->api_tree( IMPORTING et_tree_data = DATA(t_tree_data) ).
      CHECK t_tree_data IS NOT INITIAL.
      go_tree->call_tree_api( t_tree_data ).
    ELSE.
      go_tree->suppress(  ).
    ENDIF.

  ENDMETHOD.

ENDCLASS.

CLASS lcl_adapter IMPLEMENTATION.

  METHOD constructor.

    CALL FUNCTION 'VIEW_GET_CLIENT_STATE'
      IMPORTING
        client_state = client_state.

    DATA(o_spliter) = NEW cl_gui_splitter_container( parent = cl_gui_container=>default_screen rows = 2 columns = 1 ).
    o_spliter->set_row_height( id = 1 height = 3 ).
    o_spliter->set_row_sash( id = 1 type = cl_gui_splitter_container=>type_sashvisible value = cl_gui_splitter_container=>false  ).
    DATA(o_cont_tool)    = o_spliter->get_container( row = 1 column = 1 ).
    DATA(o_cont_main)    = o_spliter->get_container( row = 2 column = 1 ).
    DATA(o_spliter_tool) = NEW cl_gui_splitter_container( parent = o_cont_tool  rows = 1 columns = 3 ).
    o_spliter_tool->set_column_sash( id = 1 type = cl_gui_splitter_container=>type_sashvisible value = cl_gui_splitter_container=>false  ).
    DATA(o_spliter_main) = NEW cl_gui_splitter_container( parent = o_cont_main rows = 1 columns = 3 ).
*    o_spliter_main->set_column_width( id = 1 width = 15 ).
    o_spliter_tool->set_column_width( id = 1 width = 18 ).
    o_spliter_tool->set_column_width( id = 3 width = 30 ).

    go_tree    = NEW #( container_tree = o_spliter_main->get_container( row = 1 column = 1 )
                        container_main = o_spliter_main->get_container( row = 1 column = 2 )
                        splitter = o_spliter_main ).

    go_screen_display = NEW #( o_spliter_main ).
    go_toolbar = NEW #( container_box = o_spliter_tool->get_container( row = 1 column = 1 )
                        adapter_box = o_spliter_tool->get_container( row = 1 column = 3 )
                        container_toolbar = o_spliter_tool->get_container( row = 1 column = 2 ) ).


  ENDMETHOD.

  METHOD load_code.

    CASE code.

      WHEN 'CMT'.
        CASE lcl_toolbar=>tool_selected.
          WHEN gc_tool_abap.
            t_code_generated = VALUE #( BASE t_code_generated
                                        ( line = |***************************************************************************************| )
                                        ( line = |* Welcome to Online-Dev Tool| )
                                        ( line = |* This tool helps you try-out a piece of code for online results! | )
                                        ( line = |* Tool also have a built-in function support for building a only query with ABAP,| )
                                        ( line = |* Just define any kind of table with name 'RESULTS' for output and see a magic!!!| )
                                        ( line = |***************************************************************************************| ) ).
          WHEN gc_tool_temp.
            t_code_generated = VALUE #( ( line = |***************************************************************************************| )
                                        ( line = |* Welcome to data processing for document tool| )
                                        ( line = |* Please keep in your mind that data object 'm_data' must be declared to process data.| )
                                        ( line = |* If use input data to process logic, you can use 'input' with a json string.| )
                                        ( line = |***************************************************************************************| ) ).
        ENDCASE.
      WHEN 'TOP'.
        CASE lcl_toolbar=>tool_selected.
          WHEN gc_tool_abap.
            t_code_generated = VALUE #( BASE t_code_generated ( line = | PROGRAM SUBPOOL. | )
                                                 ( line = | LOAD-OF-PROGRAM. | )
                                                 ( line = | FORM run CHANGING fo_result TYPE REF TO data |
                                                        & |                   alv_settings TYPE ztb_alv_settings |
                                                        & |                   screen_out TYPE REF TO cl_gui_container |
                                                        & |                   runtime TYPE bwsd_runtime|
                                                        & |                   count TYPE i. | )
                                                 ( line = | DATA: w_timestart type timestampl,| )
                                                 ( line = |       w_timeend type timestampl. | )
                                                 ( line = | GET TIME STAMP FIELD w_timestart. | ) ).
          WHEN gc_tool_temp.
            t_code_generated = VALUE #( BASE t_code_generated ( line = | PROGRAM SUBPOOL. | )
                                          ( line = | LOAD-OF-PROGRAM. | )
                                          ( line = | FORM run USING input TYPE string  |
                                                 & | CHANGING fo_data TYPE REF TO data |
                                                 & |          runtime TYPE bwsd_runtime. | )
                                          ( line = | DATA: w_timestart type timestampl,| )
                                          ( line = |       w_timeend type timestampl. |  )
                                          ( line = | GET TIME STAMP FIELD w_timestart. | ) ).
        ENDCASE.
      WHEN 'END'.
        CASE lcl_toolbar=>tool_selected.
          WHEN gc_tool_abap.
            t_code_generated = VALUE #( BASE t_code_generated ( line = | GET TIME STAMP FIELD w_timeend. | )
                                            ( line = | FIELD-SYMBOLS <ft_result> LIKE results .| )
                                            ( line = | CREATE DATA fo_result LIKE results .| )
                                            ( line = | ASSIGN fo_result->* TO <ft_result> .| )
                                            ( line = | <ft_result> = results. | )
                                            ( line = | count = lines( results ). | )
                                            ( line = | runtime = w_timeend - w_timestart. | )
                                            ( line = | ENDFORM. | ) ).
          WHEN gc_tool_temp.
            t_code_generated = VALUE #( BASE t_code_generated ( line = | GET TIME STAMP FIELD w_timeend. | )
                                          ( line = | FIELD-SYMBOLS <ft_data> LIKE m_data .| )
                                          ( line = | CREATE DATA fo_data LIKE m_data .| )
                                          ( line = | ASSIGN fo_data->* TO <ft_data> .| )
                                          ( line = | <ft_data> = m_data. | )
                                          ( line = | runtime = w_timeend - w_timestart. | )
                                          ( line = | ENDFORM. | ) ).
        ENDCASE.
    ENDCASE.

  ENDMETHOD.

  METHOD get_editor_code.

    load_code( 'TOP' ).
    REFRESH _t_code_run.

    _t_code_run = go_tree->get_editor_content(  ).
    APPEND LINES OF _t_code_run TO t_code_generated.

    load_code( 'END' ).

  ENDMETHOD.

  METHOD pretty_code.

    REFRESH: _t_code_run.
    _t_code_run = go_tree->get_editor_content(  ).
    CHECK _t_code_run IS NOT INITIAL.
    error = go_tree->pretty_editor_content( CHANGING ct_codes = _t_code_run ).
    CHECK error IS INITIAL.
    MESSAGE 'Source code was formatted!' TYPE 'S'.

  ENDMETHOD.

  METHOD run_code.

    DATA: lv_mess(225),
          lv_line      TYPE i,
          lv_word(30),
          lv_prog      TYPE sy-repid.

    DATA: lo_result  TYPE REF TO data,
          lt_setting TYPE ztb_alv_settings,
          lv_runtime TYPE bwsd_runtime,
          lv_count   TYPE i,
          lv_title   TYPE lvc_title.


    REFRESH t_code_generated.

    get_editor_code(  ).
    CHECK pretty_code(  ) IS INITIAL.
    DELETE t_code_generated WHERE line(1) = '*'  ##NO_TEXT.
    DATA(t_cached_code) = _t_code_run.
    DELETE t_cached_code WHERE line(2) = '* ' OR line(2) = '**'.
    DATA(t_clean_code)  = _t_code_run.
    DELETE t_clean_code WHERE line(1) = '*'.

    CASE lcl_toolbar=>tool_selected.

      WHEN gc_tool_abap.

        FIND REGEX 'results\stype|\DATA\(results\)' IN TABLE t_clean_code IGNORING CASE.
        IF sy-subrc NE 0.
          DELETE t_code_generated WHERE line = | CREATE DATA fo_result LIKE results .|
                                  OR    line = | ASSIGN fo_result->* TO <ft_result> .|
                                  OR    line = | <ft_result> = results.|
                                  OR    line = | count = lines( results ).|
                                  OR    line = | FIELD-SYMBOLS <ft_result> LIKE results .|.
          FIND 'screen_out' IN TABLE t_clean_code IGNORING CASE.
          IF sy-subrc NE 0.
            IF go_screen_display->check_screen_active(  ) IS NOT INITIAL.
              go_screen_display->hide_screen(  ).
            ENDIF.
          ELSE.
            go_screen_display->display_screen_out(  ).
          ENDIF.
        ENDIF.

        GENERATE SUBROUTINE POOL t_code_generated[] NAME lv_prog
                 MESSAGE lv_mess LINE lv_line WORD lv_word.

        IF sy-subrc NE 0.
          lv_mess = | { lv_mess }( line:{ lv_line - 2 }, word: { lv_word } )|.
          zcx_ul_handle_errors=>raise_message( iv_msg_text = CONV #( lv_mess ) ).
        ELSE.
          zcl_ul_data_layer=>write_data( is_data = t_cached_code is_key = VALUE #( application = 'WB_DEV' main_key = 'LAST_RUN' sub_key = sy-uname ) ).
          PERFORM run IN PROGRAM (lv_prog) CHANGING lo_result lt_setting go_screen_display->screen lv_runtime lv_count.
          IF lo_result IS NOT INITIAL.
            ASSIGN lo_result->* TO FIELD-SYMBOL(<ft_result>).
            lv_title = |Code Execution Result: Number of entries: { lv_count }, Runtime: { lv_runtime } ms|.
            go_screen_display->display_alv( EXPORTING title = lv_title
                                                      t_setting = lt_setting
                                            CHANGING  ct_data   = <ft_result> ).
          ELSE.
            MESSAGE |Processing time: { lv_runtime } ms| TYPE 'S'.
          ENDIF.
        ENDIF.

      WHEN gc_tool_temp.

        go_tree->generated_template( CHANGING ct_code_run = t_cached_code ).
        go_tree->call_wb( t_cached_code ).

    ENDCASE.

  ENDMETHOD.

  METHOD save.

    go_tree->save_editor_content( wb_type = wb_type ).

  ENDMETHOD.

  METHOD settings.

    REFRESH lcl_alv=>t_tms.
    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'WB_DEV' iv_mainkey = 'SET_STMS'
                                  IMPORTING e_data         = lcl_alv=>t_tms  ).

    IF lcl_alv=>t_tms IS INITIAL.
      SELECT FROM tmscsys FIELDS * INTO CORRESPONDING FIELDS OF TABLE @lcl_alv=>t_tms.
    ENDIF.

    zcl_ul_alv_adapter=>del_toolbar(  ).
    zcl_ul_alv_adapter=>create( EXPORTING iv_title = 'STMS Tool Settings'
                                          ir_local_class = cl_abap_classdescr=>describe_by_name( 'LCL_ALV' )
                                          it_col_set = VALUE #( ( fieldname = 'DEV_FLAG' reptext = 'DEV' checkbox = abap_true edit = abap_true )
                                                                ( fieldname = 'QAS_FLAG' reptext = 'QAS' checkbox = abap_true edit = abap_true )
                                                                ( fieldname = 'PRD_FLAG' reptext = 'PRD' checkbox = abap_true edit = abap_true )
                                                                ( fieldname = 'SYNC_CLIENT' reptext = 'Sync.Client' edit = abap_true ) )
                                CHANGING ct_table  = lcl_alv=>t_tms ).


  ENDMETHOD.

  METHOD call_api_adapter.

    DATA: adapter TYPE REF TO zif_ul_wb_adapter,
          object  TYPE REF TO object.

    CLEAR: text_in, text_out.

    IF lcl_toolbar=>adapter_selected(3) NE 'CON' AND lcl_toolbar=>adapter_selected(3) NE 'API'.
      go_tree->text->set_textstream( text_in ).
    ENDIF.

    SELECT SINGLE FROM ztb_wb_api FIELDS class,tree_flag WHERE kind = @lcl_toolbar=>adapter_selected(3) INTO ( @DATA(class), @DATA(tree_flag) ).
    IF sy-subrc IS NOT INITIAL.
      zcx_ul_handle_errors=>raise_message( iv_msg_text = 'No implement class found!' ). RETURN.
    ENDIF.

    CREATE OBJECT object TYPE (class) EXPORTING iv_request = CONV string( SWITCH string( tree_flag WHEN abap_true THEN go_tree->get_node(  )-text
                                                                                         ELSE lcl_toolbar=>adapter_selected+4 ) ).
    adapter ?= object.
    go_tree->text->get_textstream( IMPORTING text = text_in ).
    cl_gui_cfw=>flush( ).
    text_out = adapter->api_adapter( iv_text_in = text_in ).
    IF text_in IS INITIAL.
      go_tree->text->set_textstream( adapter->text_in ).
    ENDIF.
    go_screen_display->active_screen(  ).
    go_screen_display->text->set_textstream( text_out ).

  ENDMETHOD.

ENDCLASS.

CLASS lcl_alv IMPLEMENTATION.

  METHOD mine_save_event.

    zcl_ul_data_layer=>write_data( EXPORTING is_data = lcl_alv=>t_tms is_key = VALUE #( application = 'WB_DEV' main_key = 'SET_STMS' ) ).
    MESSAGE 'Your setting was saved!' TYPE 'S'.

  ENDMETHOD.

ENDCLASS.
