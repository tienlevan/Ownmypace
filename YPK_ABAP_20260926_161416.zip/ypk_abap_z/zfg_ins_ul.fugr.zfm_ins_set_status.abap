FUNCTION zfm_ins_set_status.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(I_RELEASED) TYPE  CHAR1
*"     REFERENCE(I_STATUS) TYPE  CHAR2 OPTIONAL
*"----------------------------------------------------------------------

  gw_released = i_released.
  gw_status = i_status.
ENDFUNCTION.
