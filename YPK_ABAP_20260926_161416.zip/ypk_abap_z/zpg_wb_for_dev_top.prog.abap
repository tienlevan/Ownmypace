*&---------------------------------------------------------------------*
*&  Include  zpg_wb_for_dev_top
*&---------------------------------------------------------------------*
CLASS lcl_adapter DEFINITION DEFERRED.
CLASS lcl_toolbar DEFINITION DEFERRED.
CLASS lcl_tree    DEFINITION DEFERRED.
CLASS lcl_screen_display DEFINITION DEFERRED.

CONSTANTS: gc_tool_abap TYPE string VALUE 'ABAP',
           gc_tool_stms TYPE string VALUE 'STMS',
           gc_tool_user TYPE string VALUE 'MY_MENU',
           gc_tool_temp TYPE string VALUE 'TEMPLATE',
           gc_tool_api  TYPE string VALUE 'API',
           gc_tool_cfg  TYPE string VALUE 'CONFIGURATION'.

DATA: go_adapter        TYPE REF TO lcl_adapter,
      go_toolbar        TYPE REF TO lcl_toolbar,
      go_tree           TYPE REF TO lcl_tree,
      go_screen_display TYPE REF TO lcl_screen_display.

DATA: ok_code  TYPE sy-ucomm,
      ok_codes TYPE TABLE OF sy-ucomm.
