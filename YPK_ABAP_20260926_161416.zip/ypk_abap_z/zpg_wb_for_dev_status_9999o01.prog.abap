*----------------------------------------------------------------------*
***INCLUDE ZPG_WB_FOR_DEV_STATUS_9999O01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  STATUS_9999  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_9999 OUTPUT.

  SET TITLEBAR  'T9999'.

  CHECK go_adapter IS NOT BOUND.
  CREATE OBJECT go_adapter.

  IF go_adapter->client_state NE 'C'
  AND sy-uname NOT IN zcl_ul_abap=>get_stvarv_val( 'ZTABM_SUPERUSER' )
  AND lcl_toolbar=>tool_selected NE gc_tool_abap
  AND lcl_toolbar=>tool_selected NE gc_tool_stms.
    ok_codes = VALUE #( ( 'SAVE' ) ).
  ENDIF.

  SET PF-STATUS 'S9999' EXCLUDING ok_codes.

ENDMODULE.
