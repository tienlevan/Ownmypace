*&---------------------------------------------------------------------*
*& Report ZRP_T100_ALV_IDA
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zrp_t100_alv_ida.
TABLES: t100.

SELECTION-SCREEN BEGIN OF BLOCK z0 WITH FRAME TITLE TEXT-100.
SELECT-OPTIONS: s_msgnr FOR t100-msgnr,
                s_arbgb FOR t100-arbgb.
SELECTION-SCREEN END OF BLOCK z0.

CLASS lcl_salv_ida DEFINITION FINAL.

  PUBLIC SECTION.
    DATA: lo_salv_ida TYPE REF TO if_salv_gui_table_ida.
    DATA: gv_fcode TYPE ui_func.
    METHODS: add_sel_cond.
    METHODS: button_search FOR EVENT function_selected OF if_salv_gui_toolbar_ida
      IMPORTING ev_fcode,
      double_click FOR EVENT double_click OF if_salv_gui_table_display_opt
        IMPORTING eo_row_data.

ENDCLASS.

CLASS lcl_cal_field_handler DEFINITION FINAL.
  PUBLIC SECTION.
    INTERFACES: if_salv_ida_calc_field_handler.
    TYPES: BEGIN OF ty_new_types,
             count TYPE i,
             ucase TYPE natxt,
           END OF ty_new_types.
    ALIASES: get_requested_fields FOR if_salv_ida_calc_field_handler~get_requested_fields,
             calculate_line       FOR if_salv_ida_calc_field_handler~calculate_line.

ENDCLASS.
CLASS lcl_cal_field_handler IMPLEMENTATION.
  METHOD get_requested_fields.
    DATA lv_field_name TYPE fieldname.
    DATA(its_calc_field_name_line) = its_calc_field_name[ table_line = 'UCASE' ].
    IF its_calc_field_name_line IS NOT INITIAL.
      lv_field_name = 'TEXT'.
      INSERT lv_field_name INTO TABLE rts_db_field_name.
    ENDIF.
  ENDMETHOD.
  METHOD calculate_line.
    DATA: ls_t100_line     TYPE t100,
          ls_t100_new_line TYPE ty_new_types.

    ls_t100_line = is_data_base_line.
    ls_t100_new_line-ucase =  to_upper( ls_t100_line-text ).

    FIND ALL OCCURRENCES OF '&' IN ls_t100_line-text
    MATCH COUNT ls_t100_new_line-count.

    es_calculated_fields = ls_t100_new_line.
  ENDMETHOD.
  METHOD if_salv_ida_calc_field_handler~start_page.
  ENDMETHOD.
  METHOD if_salv_ida_calc_field_handler~end_page.
  ENDMETHOD.
  METHOD if_salv_ida_calc_field_handler~get_calc_field_structure.
  ENDMETHOD.
ENDCLASS.


CLASS lcl_salv_ida IMPLEMENTATION.

  METHOD add_sel_cond.
    DATA lo_field_calc TYPE REF TO lcl_cal_field_handler.
    TRY .

        cl_salv_gui_table_ida=>create( EXPORTING iv_table_name = 'T100'
                                       RECEIVING ro_alv_gui_table_ida = lo_salv_ida ).
      CATCH: cx_salv_db_connection
             cx_salv_db_table_not_supported
             cx_salv_ida_contract_violation
             cx_root
             INTO DATA(lx_err).

        MESSAGE lx_err TYPE 'I'.

    ENDTRY.

    DATA(lo_range_collect) = NEW cl_salv_range_tab_collector( ).
    lo_range_collect->add_ranges_for_name( iv_name = 'MSGNR' it_ranges = s_msgnr[] ).
    lo_range_collect->add_ranges_for_name( iv_name = 'ARBGB' it_ranges = s_arbgb[] ).
    lo_range_collect->get_collected_ranges( IMPORTING et_named_ranges  = DATA(lt_range_sel) ).

    " For hard condition
    DATA(lo_cond_dictionary) = lo_salv_ida->condition_factory( ).
    lo_salv_ida->set_select_options( it_ranges = lt_range_sel io_condition = lo_cond_dictionary->equals( name = 'SPRSL' value = 'E' ) ).

    DATA(lo_toolbar) = lo_salv_ida->toolbar( ).

    lo_toolbar->add_button( iv_fcode = 'SHOW' iv_icon = '@3A@' iv_text = 'Where-used List' ).
    lo_toolbar->add_button( iv_fcode = 'ZKBN' iv_icon = icon_helpassistent_on iv_text = 'Knowledge Base Note' ).
    lo_toolbar->add_button( iv_fcode = 'ZSRG' iv_icon = ICON_INSPECTION_LOT iv_text = 'Search On Internet' ).
    lo_toolbar->add_separator( iv_before_standard_functions = abap_true ).
    SET HANDLER button_search FOR lo_toolbar.

    lo_salv_ida->selection( )->set_selection_mode( iv_mode = if_salv_gui_selection_ida=>cs_selection_mode-single ).
    lo_salv_ida->display_options( )->set_title( iv_title = 'Message System' ).
    lo_salv_ida->display_options( )->enable_alternating_row_pattern( ).
    lo_salv_ida->display_options( )->enable_double_click( ).
    lo_salv_ida->standard_functions( )->set_text_search_active( 'X' ).
    lo_salv_ida->field_catalog( )->enable_text_search( 'TEXT' ).
    set HANDLER double_click FOR lo_salv_ida->display_options( ).

    DATA(lo_full_screen) = lo_salv_ida->fullscreen( ).
    lo_full_screen->display( ).

  ENDMETHOD.


  METHOD button_search.

    DATA ls_data TYPE t100.

    DATA(lv_sel) = lo_salv_ida->selection( )->is_row_selected( ).
    CHECK lv_sel IS NOT INITIAL.
    lo_salv_ida->selection( )->get_selected_row( EXPORTING iv_request_type = if_salv_gui_selection_ida=>cs_request_type-all_fields
                                                 IMPORTING es_row = ls_data ).
    CHECK ls_data IS NOT INITIAL.

    CASE ev_fcode.

      WHEN 'SHOW'.

        DATA(lv_obj) = cl_wb_object_type=>get_concatenated_key_from_id( p_key_component1 = ls_data-arbgb p_key_component2 = ls_data-msgnr p_external_id = 'NN' ).
        SUBMIT wb_mngr_start_from_tool_access AND RETURN
         WITH  action   = 'WHEREUSED'
         WITH  obj_type = 'NN'
         WITH  obj_name = lv_obj
         WITH  tool     = 'CL_WB_INFOSYSTEM'.

      WHEN 'ZKBN'.

        SELECT SINGLE FROM ztb_kb_notes FIELDS noteid WHERE arbgb = @ls_data-arbgb AND msgnr = @ls_data-msgnr INTO @DATA(lv_noteid).
        IF sy-subrc IS INITIAL.
          SET PARAMETER ID 'ZREQID' FIELD lv_noteid.
          CALL TRANSACTION 'ZKBN' AND SKIP FIRST SCREEN.
        ELSE.
          MESSAGE 'No Knowledge Base Note found!' TYPE 'I'.
        ENDIF.

      WHEN 'ZSRG'.

         zcl_ul_tree_display=>navigate_to_object( iv_access_type = zcl_ul_tree_display=>c_node_weblink
                                                  iv_object = |https://www.bing.com/search?q=message { ls_data-arbgb }{ ls_data-msgnr }+SAP| ).

    ENDCASE.

  ENDMETHOD.

  METHOD double_click.

    DATA ls_data TYPE t100.
    DATA help_info TYPE help_info.
    DATA t_dselcs TYPE TABLE OF dselc.
    DATA t_dvals TYPE TABLE OF dval.

    eo_row_data->get_row_data( IMPORTING es_row = ls_data ).
    help_info = VALUE #( call = 'D' program = sy-cprog spras = sy-langu messageid = ls_data-arbgb messagenr = ls_data-msgnr docuid = 'NA' ).

    CALL FUNCTION 'HELP_START'
          EXPORTING
            help_infos   = help_info
          TABLES
            dynpselect   = t_dselcs
            dynpvaluetab = t_dvals.


  ENDMETHOD.

ENDCLASS.

START-OF-SELECTION.

  NEW lcl_salv_ida( )->add_sel_cond( ).
