FUNCTION zfm_ins_call_configuration.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IV_CONFIGURATION_GROUP) TYPE  TEXT10 OPTIONAL
*"     REFERENCE(IV_CONFIGURATION_ID) TYPE  TEXT10 OPTIONAL
*"----------------------------------------------------------------------

  configuration_group = iv_configuration_group.
  configuration_id    = iv_configuration_id.

  CALL SCREEN 0601.

ENDFUNCTION.
