*&---------------------------------------------------------------------*
*&  Include           ZPG_KB_CREATE_TOP
*&---------------------------------------------------------------------*
TABLES sscrfields.
DATA: gs_note      TYPE ztb_kb_notes,
      gt_impacts   TYPE TABLE OF ztb_kb_impact,
      gs_fcode     TYPE smp_dyntxt,
      gt_excludes  TYPE TABLE OF sy-ucomm,
      gv_mode      TYPE char2,
      gv_mode_text TYPE text10.

CONSTANTS: gc_mode_display TYPE char2 VALUE '03',
           gc_mode_change  TYPE char2 VALUE '02',
           gc_mode_create  TYPE char2 VALUE '01'.

PARAMETERS: p_noteid TYPE ztb_kb_notes-noteid MATCHCODE OBJECT zsh_noteid.

SELECTION-SCREEN FUNCTION KEY 1.
SELECTION-SCREEN FUNCTION KEY 2.
SELECTION-SCREEN FUNCTION KEY 3.
