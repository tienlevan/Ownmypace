*&---------------------------------------------------------------------*
*& Report ZQLCTKM_TABLE_MAINTAIN
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zqlctkm_table_maintain.
*****************************Start of declaration*****************************************
TYPE-POOLS:
     vimty, rsds.
TABLES:
  sscrfields.
TYPES :
  BEGIN OF ty_mod,
    row_id    TYPE i,
    fieldname TYPE lvc_fname,
    value     TYPE lvc_value,
    tabix     TYPE i,
  END OF ty_mod.


DATA:
  g_container        TYPE scrfname VALUE 'ZCON',
  grid1              TYPE REF TO cl_gui_alv_grid,
  g_custom_container TYPE REF TO cl_gui_custom_container.
DATA:
  i_table TYPE REF TO data,
  wa_all  TYPE REF TO data.
DATA:
  org_crit_inst     TYPE vimty_oc_type,
  old_rc            LIKE sy-subrc,
  rfc               TYPE text50,
  act_level         LIKE authb-actvt,
  only_show_allowed TYPE c,
  it_exclude        TYPE TABLE OF sy-ucomm,
  i_exclude         TYPE ui_functions.
DATA :
  i_mod TYPE STANDARD TABLE OF ty_mod,
  i_del TYPE STANDARD TABLE OF ty_mod.
FIELD-SYMBOLS:
  <i_itab> TYPE table,
  <wa_tab> TYPE any,
  <ft_old> TYPE STANDARD TABLE.
DATA: BEGIN OF header OCCURS 1.
    INCLUDE STRUCTURE vimdesc.
DATA: END OF header.
DATA: BEGIN OF namtab OCCURS 50.
    INCLUDE STRUCTURE vimnamtab.
DATA: END OF namtab.
DATA: vim_wheretab LIKE vimwheretb OCCURS 10.
DATA: dba_sellist LIKE vimsellist OCCURS 10.
DATA: gv_selid_for_fs TYPE rsdynsel-selid,
      gv_title        TYPE  sy-title,
      gv_grid_title   TYPE lvc_title.
DATA: gt_fields LIKE rsdsfields OCCURS 0 WITH HEADER LINE,
      gt_tabs   LIKE rsdstabs OCCURS 0  WITH HEADER LINE,
      gt_where  TYPE rsds_twhere,
      gs_where  TYPE rsds_where.
DATA: gt_fieldnm TYPE TABLE OF dd03l-fieldname,
      gv_fieldnm TYPE dd03l-fieldname.
DATA: ld_row    TYPE i,
      ld_col    TYPE i,
      ld_value  TYPE char200,
      lt_cols   TYPE lvc_t_col,
      gt_detail LIKE se16n_selfields OCCURS 0 WITH HEADER LINE.

DATA: gv_container   TYPE REF TO cl_gui_custom_container,
      gv_okcode      TYPE sy-ucomm,
      gv_text_editor TYPE REF TO cl_gui_textedit,
      gv_text        TYPE string,
      gi_texttab     TYPE soli_tab,
      gi_texttab1    TYPE soli_tab.

CONSTANTS : gc_button_text TYPE c LENGTH 10 VALUE 'TE'.
DATA: dfies_tab TYPE dfies_tab.
DATA: upld, int, answer.
**********************************************************************************************

***********************Start of selection screen***********************************************
SELECTION-SCREEN BEGIN OF BLOCK bb WITH FRAME TITLE TEXT-100.
SELECTION-SCREEN SKIP 1.
PARAMETERS: viewname TYPE dd02l-tabname,
            maxsel   TYPE i.
SELECTION-SCREEN: FUNCTION KEY 1,
                  FUNCTION KEY 2,
                  FUNCTION KEY 3,
                  FUNCTION KEY 4,
                  FUNCTION KEY 5.
SELECTION-SCREEN SKIP 1.
SELECTION-SCREEN BEGIN OF LINE.
SELECTION-SCREEN PUSHBUTTON 10(10) TEXT-101 USER-COMMAND b1. "Display
SELECTION-SCREEN PUSHBUTTON 26(10) TEXT-102 USER-COMMAND b2. "Change
SELECTION-SCREEN PUSHBUTTON 42(10) TEXT-103 USER-COMMAND b3. "Upload
SELECTION-SCREEN PUSHBUTTON 58(10) TEXT-104 USER-COMMAND b4. "Backup
SELECTION-SCREEN PUSHBUTTON 74(10) TEXT-105 USER-COMMAND b5. "Restore
SELECTION-SCREEN END OF LINE.
SELECTION-SCREEN END OF BLOCK bb.

* Pop-up upload selection screen
SELECTION-SCREEN BEGIN OF SCREEN 1001 TITLE TEXT-sl0.
SELECTION-SCREEN BEGIN OF BLOCK blk02 WITH FRAME TITLE TEXT-103.
PARAMETERS: p_file LIKE rlgrap-filename OBLIGATORY.
PARAMETERS: replace AS CHECKBOX.
SELECTION-SCREEN END OF BLOCK blk02.
SELECTION-SCREEN END OF SCREEN 1001.

* Pop-up using defined layouts
SELECTION-SCREEN BEGIN OF SCREEN 1002 TITLE TEXT-sl1.
PARAMETERS: variant TYPE slis_vari .
SELECTION-SCREEN END OF SCREEN 1002.

* Pop-up for remote control
SELECTION-SCREEN BEGIN OF SCREEN 1003 TITLE TEXT-sl2.
PARAMETERS: rfcport TYPE rfcdest .
SELECTION-SCREEN END OF SCREEN 1003.

AT SELECTION-SCREEN.

  PERFORM authorized_check.

  CASE sy-ucomm.

    WHEN 'B1'.
      CALL SCREEN 9001.
    WHEN 'B2'.
      CALL SCREEN 9001.
    WHEN 'B3'.
      CALL SELECTION-SCREEN 1001 STARTING AT 5 5.
      IF p_file IS NOT INITIAL.
        upld = 'X'.
        PERFORM upload_data.
        CALL SCREEN 9001.
      ENDIF.
    WHEN 'B4'.
      PERFORM backup_data.
    WHEN 'B5'.
      PERFORM restore_data.

  ENDCASE.

  CASE sscrfields-ucomm.
    WHEN 'FC01'.
      CLEAR: gt_where, gs_where.
      PERFORM dynamic_selscreen.
    WHEN 'FC02'.
      CLEAR variant.
      CALL SELECTION-SCREEN 1002 STARTING AT 5 5.
    WHEN 'FC03'.
      CALL FUNCTION 'RS_DD_FIEL_SHOW'
        EXPORTING
          objname = viewname
        EXCEPTIONS
          OTHERS  = 4.
    WHEN 'FC04'.
      CALL SCREEN 9002 STARTING AT 5 5 .
    WHEN 'FC05'.
      CALL SELECTION-SCREEN 1003 STARTING AT 5 5.
      IF rfcport IS NOT INITIAL.
        rfc = |Connecting to { rfcport }|.
      ENDIF.
  ENDCASE.

* Delete execution button
AT SELECTION-SCREEN OUTPUT.

  APPEND 'ONLI' TO it_exclude.
  CALL FUNCTION 'RS_SET_SELSCREEN_STATUS'
    EXPORTING
      p_status  = ' '
      p_program = sy-repid
    TABLES
      p_exclude = it_exclude.

* Check table input
AT SELECTION-SCREEN ON viewname.
  IF sscrfields-ucomm <> 'FC04' AND sscrfields-ucomm <> 'FC05'
  AND sy-uname NOT IN zcl_ul_abap=>get_stvarv_val( 'ZTABM_SUPERUSER' ).
    PERFORM f_validate_table.
  ENDIF.

* Select file upload
AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  PERFORM f4_file_name.

* Select variants
AT SELECTION-SCREEN ON VALUE-REQUEST FOR variant.
  PERFORM f4_variant.

*******************************************************************************************

**************************Declaration of events********************************************
* Class used to get changed data
CLASS lcl_event_handler DEFINITION .

  PUBLIC SECTION .

    METHODS: handle_double_click
                  FOR EVENT double_click OF cl_gui_alv_grid
      IMPORTING e_row e_column es_row_no.

    METHODS: handle_data_changed
                  FOR EVENT data_changed OF cl_gui_alv_grid
      IMPORTING er_data_changed.

ENDCLASS.                    "lcl_event_handler DEFINITION
* Class used to get changed data
CLASS lcl_event_handler IMPLEMENTATION .

* Double clicked
  METHOD handle_double_click.

    CALL METHOD cl_gui_control=>set_focus
      EXPORTING
        control = grid1.

    CALL METHOD cl_gui_cfw=>flush.
    CHECK: es_row_no-row_id > 0.
    CALL METHOD grid1->get_current_cell
      IMPORTING
        e_row     = ld_row
        e_col     = ld_col
        es_row_no = es_row_no
        e_value   = ld_value.

    PERFORM show_grid_line.

  ENDMETHOD.
*  Handle Data Changed
  METHOD handle_data_changed .
    PERFORM handle_data_changed USING er_data_changed .
  ENDMETHOD.                    "handle_data_changed
ENDCLASS.                    "lcl_event_handler IMPLEMENTATION

****************************************************************************************

INITIALIZATION.
  sscrfields-functxt_01 = 'Select Options'.
  sscrfields-functxt_02 = 'Defined Variants'.
  sscrfields-functxt_03 = 'Technical Specs.'.
  sscrfields-functxt_04 = 'Dynamic Report'.
  sscrfields-functxt_05 = 'Remote Control'.

*&---------------------------------------------------------------------*
*&      Module  STATUS_9001  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_9001 OUTPUT.

  DATA :
    lh_norec     TYPE i,
    lh_total(5)  TYPE c,
    lh_succ(50)  TYPE c,
    lwa_del      TYPE ty_mod,
    lwa_mod      TYPE ty_mod,
    lh_totdel    TYPE i,
    lh_flag      TYPE c,
    s_layout     TYPE lvc_s_layo,
    li_fieldcat  TYPE lvc_t_fcat,
    ls_variant   TYPE disvariant,
    lwa_fieldcat TYPE lvc_s_fcat.

  DATA gr_event_handler TYPE REF TO lcl_event_handler.

* Creating an instance for the event handler
  CREATE OBJECT gr_event_handler .
  " For display new create data
  IF lh_flag <> 'X'.
    IF upld IS INITIAL.
      CREATE DATA i_table TYPE TABLE OF (viewname).
      ASSIGN i_table->* TO <i_itab>.
      CREATE DATA wa_all LIKE LINE OF <i_itab>.
      ASSIGN wa_all->* TO <wa_tab>.
      READ TABLE gt_where INTO gs_where INDEX 1.

*     Selecting data dynamically/ Set new entry at top
      IF NOT i_mod[] IS INITIAL.
        SELECT * FROM (viewname) INTO TABLE <i_itab> UP TO maxsel ROWS
                 WHERE (gs_where-where_tab).
        SORT <i_itab> ASCENDING.
        LOOP AT i_mod INTO lwa_mod.
          READ TABLE <i_itab> INTO <wa_tab> INDEX lwa_mod-row_id.
          DELETE <i_itab>  INDEX lwa_mod-row_id.
          INSERT <wa_tab> INTO <i_itab> INDEX 1.
        ENDLOOP.
        CLEAR: i_mod[].

      ELSE.

        IF rfcport IS NOT INITIAL.

          DATA data TYPE string.
          CALL FUNCTION 'ZRFC_TABLE_CONTROL'
            DESTINATION rfcport
            EXPORTING
              iv_max_rows = maxsel
              it_wheretab = gs_where-where_tab
              iv_tabname  = viewname
            CHANGING
              cs_data     = data.

          /ui2/cl_json=>deserialize( EXPORTING json = data
                                     CHANGING data = <i_itab> ).

        ELSE.

          TRY.
              SELECT * FROM (viewname) INTO TABLE <i_itab> UP TO maxsel ROWS
                     WHERE (gs_where-where_tab).
            CATCH cx_sy_dynamic_osql_semantics.
              MESSAGE s013(zalv_table_class) WITH viewname DISPLAY LIKE 'E'.
          ENDTRY.

        ENDIF.

        SORT <i_itab> ASCENDING.

        " Catch old data
        IF int IS INITIAL.
          ASSIGN i_table->* TO <ft_old>.
          int = 'X'.
        ENDIF.

      ENDIF.
    ENDIF.
  ELSE.
    " For delete empty rows~
    DELETE ADJACENT DUPLICATES FROM <i_itab> COMPARING ALL FIELDS.
    DELETE <i_itab> INDEX lines( <i_itab> ).
  ENDIF.


  " Building catalog
  PERFORM build_catalog.

*     Setting layout
  CLEAR s_layout.
  s_layout-cwidth_opt = 'X'.
  s_layout-sel_mode = 'A'.

*     Set variant
  CLEAR ls_variant.
  ls_variant-report   = |{ sy-repid }{ viewname }|.
  ls_variant-username = sy-uname.
  ls_variant-variant  = variant.

*     Making fields editable except key fields
  IF sy-ucomm = 'CHANGE' OR sy-ucomm = 'B2'.
    LOOP AT li_fieldcat INTO lwa_fieldcat.
      IF lwa_fieldcat-key = space.
        lwa_fieldcat-edit = 'X'.
        MODIFY li_fieldcat FROM lwa_fieldcat.
      ENDIF.
    ENDLOOP.
  ENDIF.

*     Making fields editable
  IF sy-ucomm = 'NEW'.
    lh_flag = 'X'.
    LOOP AT li_fieldcat INTO lwa_fieldcat.
      lwa_fieldcat-edit = 'X'.
      MODIFY li_fieldcat FROM lwa_fieldcat.
    ENDLOOP.
    CLEAR : <i_itab>, <wa_tab>.
    DO 25 TIMES.
      APPEND <wa_tab> TO <i_itab>.
    ENDDO.
  ENDIF.

*     Exclude buttons
  PERFORM exclude_tb_functions CHANGING i_exclude.

  IF g_custom_container IS NOT BOUND.

    CREATE OBJECT g_custom_container
      EXPORTING
        container_name = g_container.

    CREATE OBJECT grid1
      EXPORTING
        i_parent = g_custom_container.

  ENDIF.

  IF sy-ucomm = 'SAVE'.
    LOOP AT li_fieldcat INTO lwa_fieldcat.
      IF lh_flag IS NOT INITIAL.
        lwa_fieldcat-edit = space.
      ELSE.
        IF lwa_fieldcat-key NE space.
          lwa_fieldcat-edit = space.
        ENDIF.
      ENDIF.
      MODIFY li_fieldcat FROM lwa_fieldcat.
    ENDLOOP.
  ENDIF.

  IF sy-ucomm = 'DISPLAY'.
    LOOP AT li_fieldcat INTO lwa_fieldcat.
      IF lwa_fieldcat-key EQ space.
        IF lwa_fieldcat-edit = ' '.
          lwa_fieldcat-edit = 'X'.
        ELSE.
          lwa_fieldcat-edit = ' '.
        ENDIF.
      ELSE.
        lwa_fieldcat-edit = ' '.
      ENDIF.
      MODIFY li_fieldcat FROM lwa_fieldcat.
    ENDLOOP.
  ENDIF.

  DATA(lines) = condense( |{ lines( <i_itab> ) }| ).
  IF lines > 1.
    lines = |({ lines } Rows)|.
  ELSE.
    lines = space.
  ENDIF.

  CASE sy-ucomm.
    WHEN 'B1'.
      SET PF-STATUS 'ALV'.
      SET TITLEBAR 'DIS' WITH viewname lines.
    WHEN 'B2'.
      SET PF-STATUS 'ALV1'.
      SET TITLEBAR 'Z001' WITH viewname lines.
    WHEN 'B3'.
      SET TITLEBAR 'UPL' WITH viewname.
    WHEN 'B5'.
      SET PF-STATUS 'ALV2'.
      SET TITLEBAR 'RST' WITH viewname.
  ENDCASE.

*     Displaying ALV Grid
  CALL METHOD grid1->set_table_for_first_display
    EXPORTING
      is_variant           = ls_variant
      i_save               = 'A'
      is_layout            = s_layout
      i_structure_name     = viewname
      it_toolbar_excluding = i_exclude
    CHANGING
      it_outtab            = <i_itab>
      it_fieldcatalog      = li_fieldcat.

  IF sy-subrc NE 0.
    RETURN.
  ENDIF.

*      Getting the changed data
  TRY.
      SET HANDLER gr_event_handler->handle_data_changed FOR grid1 .
      SET HANDLER gr_event_handler->handle_double_click FOR grid1 .
    CATCH cx_sy_create_data_error.
  ENDTRY.
ENDMODULE.                 " STATUS_9001  OUTPUT

*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9001  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9001 INPUT.

  PERFORM authorized_check.

  CASE sy-ucomm.

    WHEN 'CHANGE'.
      SET PF-STATUS 'ALV1'.
      SET TITLEBAR 'Z001' WITH viewname.

    WHEN 'NEW'.
      SET PF-STATUS 'ALV'.
      SET TITLEBAR 'Z002' WITH viewname.

    WHEN 'TRANSFER'.
      FIELD-SYMBOLS <ft_transfer> TYPE STANDARD TABLE.
      DATA lr_transfer TYPE REF TO data.
      DATA lv_retcode TYPE sy-subrc.
      CREATE DATA lr_transfer TYPE STANDARD TABLE OF (viewname).
      ASSIGN lr_transfer->* TO <ft_transfer>.
      grid1->get_selected_rows( IMPORTING et_index_rows = DATA(t_rows) ).
      LOOP AT t_rows ASSIGNING FIELD-SYMBOL(<fs_row>).
        APPEND INITIAL LINE TO <ft_transfer> ASSIGNING FIELD-SYMBOL(<fs_transfer>).
        <fs_transfer> = <i_itab>[ <fs_row>-index ].
      ENDLOOP.

      CALL SELECTION-SCREEN 1003 STARTING AT 5 5.
      CHECK rfcport IS NOT INITIAL.

      data = /ui2/cl_json=>serialize( data = <ft_transfer> ).
      CALL FUNCTION 'ZRFC_TABLE_CONTROL'
        DESTINATION rfcport
        EXPORTING
          iv_mode     = 'INSERT'
          iv_max_rows = maxsel
          it_wheretab = gs_where-where_tab
          iv_tabname  = viewname
        IMPORTING
          ev_subrc    = lv_retcode
        CHANGING
          cs_data     = data.

      IF lv_retcode NE 0.
        MESSAGE e014(zalv_table_class).
      ELSE.
        MESSAGE s015(zalv_table_class).
      ENDIF.

      CLEAR rfcport.

    WHEN 'RFC'.
      MESSAGE s016(zalv_table_class) WITH rfcport.
      CLEAR: rfc, rfcport.

    WHEN 'REFRESH'.
      REFRESH <i_itab>.

    WHEN 'RESTORE'.
      CHECK zcl_ul_abap=>popup_to_confirm( 'Do you really want to restore data?' ) = '1'.
      IF zcl_ul_abap=>popup_to_confirm( 'Create a backup version before restoring?' ) = '1'.
        PERFORM backup_data.
      ENDIF.
      DELETE FROM (viewname).
      MODIFY (viewname) FROM TABLE <i_itab>.
      MESSAGE s017(zalv_table_class).

    WHEN 'SAVE'.
*     Lock the table
      CALL FUNCTION 'ENQUEUE_E_TABLE'
        EXPORTING
          mode_rstable   = 'E'
          tabname        = viewname
        EXCEPTIONS
          foreign_lock   = 1
          system_failure = 2
          OTHERS         = 3.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
      ENDIF.
      IF NOT grid1 IS INITIAL .
        CALL METHOD grid1->check_changed_data .
      ENDIF .
      SORT i_mod BY row_id fieldname.
      DELETE ADJACENT DUPLICATES  FROM i_mod COMPARING row_id fieldname.
      DATA(i_mod1) = i_mod[].
      DELETE ADJACENT DUPLICATES FROM i_mod1 COMPARING row_id.
      lh_norec = lines( i_mod1 ).
      lh_total = lh_norec.
      SHIFT lh_total LEFT DELETING LEADING space.
*  Standard Table Update
      IF i_mod1 IS NOT INITIAL.

        IF rfcport IS INITIAL.

          LOOP AT i_mod1 INTO DATA(lwa_mod1).
            READ TABLE <i_itab> ASSIGNING <wa_tab> INDEX lwa_mod1-row_id.
            IF <wa_tab> IS ASSIGNED .
              IF lh_flag NE 'X'.
                MODIFY (viewname) FROM <wa_tab>.
                IF sy-subrc IS INITIAL.
*            zcl_bus_logic=>write_change_log( EXPORTING
*                                              iv_tabname = viewname
*                                              iv_mode = 'C'
*                                              it_data = <ft_old>
*                                             CHANGING
*                                              ct_mod  = i_mod  ).
                ENDIF.
              ELSE.
                INSERT (viewname) FROM <wa_tab>.
                IF sy-subrc IS INITIAL.
*                zcl_bus_logic=>write_change_log( EXPORTING
*                                                   iv_tabname = viewname
*                                                   iv_mode = 'I'
*                                                   it_data = <i_itab>
*                                                 CHANGING
*                                                   ct_mod  = i_mod  ).
                ELSE.
                  MESSAGE e009(zalv_table_class).
                ENDIF.
              ENDIF.
            ENDIF.
          ENDLOOP.

        ELSE.

          IF lh_flag NE 'X'.

            CALL FUNCTION 'ZRFC_REMOTE_CONTROL'
              DESTINATION rfcport
              EXPORTING
                iv_tabname            = viewname
                iv_mode               = 'MODIFY'
                iv_rfc                = rfcport
                it_wheretab           = gs_where-where_tab
              TABLES
                t_mod                 = i_mod1
              EXCEPTIONS
                communication_failure = 1
                system_failure        = 2
                OTHERS                = 3.
            IF sy-subrc <> 0.
              MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
            ENDIF.
          ELSE.

            CALL FUNCTION 'ZRFC_REMOTE_CONTROL'
              DESTINATION rfcport
              EXPORTING
                iv_tabname            = viewname
                iv_mode               = 'INSERT'
                iv_rfc                = rfcport
                it_wheretab           = gs_where-where_tab
              TABLES
                t_mod                 = i_mod1
              EXCEPTIONS
                communication_failure = 1
                system_failure        = 2
                OTHERS                = 3.
            IF sy-subrc <> 0.
              MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
            ENDIF.
          ENDIF.
        ENDIF.
        CONCATENATE lh_total '  ' TEXT-s01 INTO lh_succ SEPARATED BY space.
        MESSAGE s000(zalv_table_class) WITH lh_succ.
      ENDIF.
*     Unlock the table
      CALL FUNCTION 'DEQUEUE_E_TABLE'
        EXPORTING
          mode_rstable = 'E'
          tabname      = viewname.

    WHEN 'DELETE'.

      CALL FUNCTION 'POPUP_TO_DECIDE_DELETE'
        EXPORTING
          titel  = 'Confirm to delete data!'
          what   = '1'
        IMPORTING
          answer = answer.
      IF answer = 'J'.

*   Selecting Selected Rows
        PERFORM handle_user_command USING sy-ucomm.
        IF i_del[] IS NOT INITIAL AND rfcport IS INITIAL.
          LOOP AT i_del INTO lwa_del.
            READ TABLE <i_itab> INTO <wa_tab> INDEX lwa_del-row_id.
            IF sy-subrc = 0.
              DELETE (viewname) FROM <wa_tab>.
            ENDIF.
          ENDLOOP.
        ELSEIF i_del[] IS NOT INITIAL AND rfcport IS NOT INITIAL.
          CALL FUNCTION 'ZRFC_REMOTE_CONTROL'
            DESTINATION rfcport
            EXPORTING
              iv_tabname  = viewname
              iv_mode     = 'DELETE'
              iv_rfc      = rfcport
              it_wheretab = gs_where-where_tab
            TABLES
              t_mod       = i_del.
        ELSE.
          MESSAGE e000(zalv_table_class) WITH TEXT-s03.
        ENDIF.

        IF sy-subrc IS INITIAL.
          lh_totdel = lines( i_del ).
          MESSAGE s011(zalv_table_class) WITH lh_totdel.
*        zcl_bus_logic=>write_change_log( EXPORTING
*                                        iv_tabname = viewname
*                                        iv_mode = 'D'
*                                        it_data = <i_itab>
*                                       CHANGING
*                                         ct_mod  = i_del  ).
*        CLEAR : i_del[], lh_totdel .
        ELSE.
          MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
          WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
        ENDIF.
      ELSE.
        RETURN.
      ENDIF.

    WHEN 'EXIT'   OR
         'BACK'   OR
         'CANCEL' OR
         'E'      OR
         'ENDE'.
      CLEAR : li_fieldcat[],
              i_exclude[],
              i_del[],
              lh_flag,
              upld,
              int,
              lh_totdel.

      LEAVE TO SCREEN 0.

  ENDCASE.

ENDMODULE.                 " USER_COMMAND_9001  INPUT


*&---------------------------------------------------------------------*
*&      Form  handle_data_changed
*&---------------------------------------------------------------------*
FORM handle_data_changed  USING    p_er_data_changed TYPE REF TO cl_alv_changed_data_protocol.
  DATA :
    lwa_mod_cell TYPE lvc_s_modi,
    lwa_mod      TYPE ty_mod.
  LOOP AT p_er_data_changed->mt_good_cells INTO lwa_mod_cell.
    MOVE-CORRESPONDING lwa_mod_cell TO lwa_mod.
    APPEND lwa_mod TO i_mod.
  ENDLOOP.
ENDFORM.                    " handle_data_changed
*&---------------------------------------------------------------------*
*&      Form  exclude_tb_functions
*&---------------------------------------------------------------------*
FORM exclude_tb_functions CHANGING pt_exclude TYPE ui_functions .
  DATA:
    lwa_exclude TYPE ui_func.
  lwa_exclude = cl_gui_alv_grid=>mc_fc_loc_append_row.
  APPEND lwa_exclude TO pt_exclude.
  lwa_exclude = cl_gui_alv_grid=>mc_fc_loc_copy.
  APPEND lwa_exclude TO pt_exclude.
  lwa_exclude = cl_gui_alv_grid=>mc_fc_loc_copy_row.
  APPEND lwa_exclude TO pt_exclude.
  lwa_exclude = cl_gui_alv_grid=>mc_fc_loc_cut.
  APPEND lwa_exclude TO pt_exclude.
  lwa_exclude = cl_gui_alv_grid=>mc_fc_loc_delete_row.
  APPEND lwa_exclude TO pt_exclude.
  lwa_exclude = cl_gui_alv_grid=>mc_fc_loc_insert_row.
  APPEND lwa_exclude TO pt_exclude.
  lwa_exclude = cl_gui_alv_grid=>mc_fc_loc_move_row.
  APPEND lwa_exclude TO pt_exclude.
  lwa_exclude = cl_gui_alv_grid=>mc_fc_loc_paste.
  APPEND lwa_exclude TO pt_exclude.
  lwa_exclude = cl_gui_alv_grid=>mc_fc_loc_paste_new_row.
  APPEND lwa_exclude TO pt_exclude.
ENDFORM.                    "exclude_tb_functions
*&---------------------------------------------------------------------*
*&      Form  handle_user_command
*&---------------------------------------------------------------------*
FORM handle_user_command  USING  p_ucomm TYPE syucomm.
  DATA :
    i_selected_rows  TYPE lvc_t_roid .
  DATA :
    lwa_selected_row TYPE lvc_s_roid,
    lwa_del          TYPE ty_mod.
  CALL METHOD grid1->get_selected_rows
    IMPORTING
      et_row_no = i_selected_rows.
  LOOP AT i_selected_rows INTO lwa_selected_row.
    lwa_del-row_id = lwa_selected_row-row_id.
    APPEND lwa_del TO i_del.
  ENDLOOP.
ENDFORM.


FORM f_validate_table .

  DATA lv_tabname TYPE dd02l-tabname.

  IF viewname IS INITIAL.
    MESSAGE e012(zalv_table_class).
  ENDIF.

* Upload only Tables in customer namespace
  IF viewname+0(1) NE 'Z' AND viewname+0(1) NE 'Y'.
    IF sy-uname <> 'TIENLV1' AND sy-sysid NP 'PRD*'.
      MESSAGE e001(zalv_table_class).
    ELSE.
      MESSAGE i004(zalv_table_class) WITH viewname.
    ENDIF.
  ENDIF.

* Only transparent tables can be uploaded
  SELECT SINGLE tabname
  FROM dd02l
  INTO lv_tabname
  WHERE tabname = viewname AND
  tabclass = 'TRANSP'.
  IF sy-subrc NE 0.
    MESSAGE e002(zalv_table_class) WITH viewname.
  ENDIF.

* Count max entries
  IF maxsel IS INITIAL.
    IF rfcport IS NOT INITIAL.
*   zcl_bus_logic=>get_remote_data( EXPORTING
*                                    iv_tabname   = viewname
*                                    iv_rfc       = rfcport
*                                    it_wheretab  = gs_where-where_tab
*                                    iv_mode      = 'COUNT'
*                                   IMPORTING
*                                    ev_count      = maxsel ).
    ELSE.
      SELECT COUNT(*) FROM (viewname) INTO maxsel.
      IF sy-subrc <> 0.
        MESSAGE s010(zalv_table_class) WITH viewname.
      ENDIF.
    ENDIF.
  ENDIF.

ENDFORM.
" F_VALIDATE_TABLE
*&---------------------------------------------------------------------*
*&      Form  DYNAMIC_SELSCREEN
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM dynamic_selscreen .

  REFRESH: gt_fieldnm, gt_fields, gt_tabs, gt_where.

  gt_tabs-prim_tab = viewname.
  APPEND gt_tabs.

  SELECT fieldname FROM dd03l INTO TABLE gt_fieldnm
                   WHERE tabname EQ viewname
                     AND keyflag = 'X'.

  gt_fields-tablename = viewname.
  LOOP AT gt_fieldnm INTO gv_fieldnm.
    CHECK gv_fieldnm NE 'MANDT'.
    gt_fields-fieldname = gv_fieldnm.
    APPEND gt_fields.
  ENDLOOP.

  CONCATENATE 'Selection Options Applied For Table' viewname INTO gv_title SEPARATED BY space.

  CALL FUNCTION 'FREE_SELECTIONS_INIT'
    EXPORTING
      kind                     = 'T'
    IMPORTING
      selection_id             = gv_selid_for_fs
    TABLES
      tables_tab               = gt_tabs
      fields_tab               = gt_fields
    EXCEPTIONS
      fields_incomplete        = 1
      fields_no_join           = 2
      field_not_found          = 3
      no_tables                = 4
      table_not_found          = 5
      expression_not_supported = 6
      incorrect_expression     = 7
      illegal_kind             = 8
      area_not_found           = 9
      inconsistent_area        = 10
      kind_f_no_fields_left    = 11
      kind_f_no_fields         = 12
      too_many_fields          = 13
      dup_field                = 14
      field_no_type            = 15
      field_ill_type           = 16
      dup_event_field          = 17
      node_not_in_ldb          = 18
      area_no_field            = 19
      OTHERS                   = 20.
  IF sy-subrc <> 0 AND sy-msgty IS NOT INITIAL.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.

  CALL FUNCTION 'FREE_SELECTIONS_DIALOG'
    EXPORTING
      selection_id    = gv_selid_for_fs
      title           = gv_title
      status          = '1'
    IMPORTING
      where_clauses   = gt_where
    TABLES
      fields_tab      = gt_fields
    EXCEPTIONS
      internal_error  = 1
      no_action       = 2
      selid_not_found = 3
      illegal_status  = 4
      OTHERS          = 5.
  IF sy-subrc <> 0 AND sy-msgty IS NOT INITIAL.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
            WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  F4_FILE_NAME
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f4_file_name .

  CALL FUNCTION 'KD_GET_FILENAME_ON_F4'
    CHANGING
      file_name     = p_file
    EXCEPTIONS
      mask_too_long = 1
      OTHERS        = 2.

  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  UPLOAD_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM upload_data .

* Declarations for Result Count
  DATA: gv_success TYPE i,
        gv_error   TYPE i.

  CREATE DATA i_table TYPE TABLE OF (viewname).
  ASSIGN i_table->* TO <i_itab>.
  CREATE DATA wa_all LIKE LINE OF <i_itab>.
  ASSIGN wa_all->* TO <wa_tab>.

* Validation Table data
  IF replace EQ 'X'.

    CALL FUNCTION 'POPUP_TO_CONFIRM_STEP'
      EXPORTING
        titel     = 'Table Data Deletion Confirmation'
        textline1 = 'Do you really want to delete all old data for replacing'
        textline2 = 'with new uploaded data?'
      IMPORTING
        answer    = answer.

    CASE answer.
      WHEN 'J'.
        DELETE FROM (viewname).
      WHEN 'N' OR 'A'.
        LEAVE TO SCREEN 1000.
    ENDCASE.

  ENDIF.

*Get Excel data in internal table
  DATA lt_raw_data  TYPE truxs_t_text_data.

  CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
    EXPORTING
      i_line_header        = 'X'
      i_tab_raw_data       = lt_raw_data
      i_filename           = p_file
    TABLES
      i_tab_converted_data = <i_itab>
    EXCEPTIONS
      conversion_failed    = 1
      OTHERS               = 2.
  IF sy-subrc <> 0.
    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
    WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ENDIF.

  PERFORM build_catalog.

* Upload data to database table
  CLEAR dfies_tab.
  CALL FUNCTION 'DDIF_FIELDINFO_GET'
    EXPORTING
      tabname   = viewname
    TABLES
      dfies_tab = dfies_tab.

  SET UPDATE TASK LOCAL.

  DESCRIBE TABLE <i_itab> LINES DATA(total).

  LOOP AT <i_itab> ASSIGNING <wa_tab>.

    LOOP AT dfies_tab INTO DATA(dfies_wa) WHERE datatype = 'CHAR'.
      DATA(fieldname) = dfies_wa-fieldname.
      ASSIGN COMPONENT fieldname OF STRUCTURE <wa_tab> TO FIELD-SYMBOL(<fval>).
      TRANSLATE <fval> TO UPPER CASE.
    ENDLOOP.

    INSERT (viewname) FROM <wa_tab>.

    IF sy-subrc = 0.
      gv_success = gv_success + 1.
    ELSE.

      DELETE <i_itab> INDEX sy-tabix.
      gv_error = gv_error + 1.

    ENDIF.

  ENDLOOP.

  IF sy-subrc = 0.
*        zcl_bus_logic=>write_change_log( iv_tabname = viewname iv_mode = 'U' it_data = <i_itab> ).
    DATA(mess) = | Success: { gv_success } Error: { gv_error } Total: { total }|.
    MESSAGE mess TYPE 'S'.
  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  BUILD_CATALOG
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM build_catalog .

* Building the fieldcatelog
  CALL FUNCTION 'LVC_FIELDCATALOG_MERGE'
    EXPORTING
      i_structure_name       = viewname
    CHANGING
      ct_fieldcat            = li_fieldcat
    EXCEPTIONS
      inconsistent_interface = 1
      program_error          = 2
      OTHERS                 = 3.
  IF sy-subrc <> 0.

    MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
  ELSE.

* Fill missing header
    LOOP AT li_fieldcat ASSIGNING FIELD-SYMBOL(<fs_field>) WHERE reptext IS INITIAL.
      CALL FUNCTION 'DDIF_FIELDINFO_GET'
        EXPORTING
          tabname   = viewname
          fieldname = <fs_field>-fieldname
        TABLES
          dfies_tab = dfies_tab.
      <fs_field>-reptext = dfies_tab[ 1 ]-fieldtext.
    ENDLOOP.

  ENDIF.
ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  F4_VARIANT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM f4_variant .

  DATA: ls_variant LIKE disvariant,
        ld_exit.

  CHECK viewname IS NOT INITIAL.

  CLEAR ls_variant.

  ls_variant-report = |{ sy-repid }{ viewname }|.

  CALL FUNCTION 'REUSE_ALV_VARIANT_F4'
    EXPORTING
      is_variant    = ls_variant
      i_save        = 'A'
    IMPORTING
      e_exit        = ld_exit
      es_variant    = ls_variant
    EXCEPTIONS
      not_found     = 1
      program_error = 2
      OTHERS        = 3.

  IF sy-subrc = 0 AND ld_exit <> 'X'.
    variant = ls_variant-variant.
    MESSAGE s008(zalv_table_class) WITH variant viewname.
  ELSE.
    MESSAGE s007(zalv_table_class) WITH viewname DISPLAY LIKE 'E'.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  AUTHORIZED_CHECK
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM authorized_check .

  IF viewname IS INITIAL AND sy-ucomm NE 'FC04' AND sy-ucomm NE 'FC05'.
    MESSAGE e012(zalv_table_class) WITH viewname. SET CURSOR FIELD viewname.
    RETURN.
  ENDIF.

  TRY.
      CHECK sy-uname NOT IN zcl_ul_abap=>get_stvarv_val( 'ZTABM_SUPERUSER' ).
    CATCH zcx_ul_handle_errors INTO DATA(error).
      error->show_message(  ). RETURN.
  ENDTRY.

  DATA: lv_act     TYPE xuval,
        lv_tab     TYPE xuval,
        lv_exc(10) TYPE c.

  CLEAR: lv_act, lv_exc, lv_tab.

  lv_tab = viewname.


  CASE sy-ucomm.

    WHEN 'B1'.
      lv_act = '03'.
      lv_exc = 'display'.
    WHEN 'B2' OR 'CHANGE'.
      lv_act = '02'.
      lv_exc = 'change'.
    WHEN 'B3'.
      lv_act = '60'.
      lv_exc = 'upload'.
    WHEN 'DELETE'.
      lv_act = '06'.
      lv_exc = 'delete'.
    WHEN 'NEW'.
      lv_act = '01'.
      lv_exc = 'creating'.

  ENDCASE.

  CHECK lv_act IS NOT INITIAL.

  CALL FUNCTION 'AUTHORITY_CHECK'
    EXPORTING
      user                = sy-uname
      object              = 'ZTABM'
      field1              = 'TABLE'
      value1              = lv_tab
      field2              = 'ACTVT'
      value2              = lv_act
    EXCEPTIONS
      user_is_authorized  = 0
      user_dont_exist     = 1
      user_not_authorized = 2
      user_is_locked      = 3.

  IF sy-subrc <> 0.
    MESSAGE e003(zalv_table_class) WITH lv_exc viewname.
  ENDIF.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  SHOW_GRID_LINE
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM show_grid_line .

  DATA: ls_dfies    LIKE dfies.
  DATA: ld_tab      TYPE ddobjname.
  DATA: ls_rseumod  LIKE rseumod.
  DATA: ld_timestmp LIKE cest1-timestmp.
  DATA: ld_date     LIKE sy-datum.
  DATA: ld_time     LIKE sy-uzeit.
  FIELD-SYMBOLS: <f>, <g>,                                  "1424238
                 <wa_table> TYPE any.

  READ TABLE <i_itab> INDEX ld_row ASSIGNING <wa_table>.

  CHECK: sy-subrc = 0.
  REFRESH gt_detail.
  LOOP AT li_fieldcat INTO lwa_fieldcat.
    CLEAR gt_detail.
    gt_detail-scrtext_l = lwa_fieldcat-reptext.
    ASSIGN COMPONENT lwa_fieldcat-fieldname OF STRUCTURE <wa_table>
                     TO <f>.
    gt_detail-fieldname = lwa_fieldcat-fieldname.
    gt_detail-tabname   = lwa_fieldcat-ref_table.

    IF ls_dfies-datatype = 'CURR' AND
       ls_dfies-tabname = ls_dfies-reftable.
      ASSIGN COMPONENT ls_dfies-reffield OF STRUCTURE <wa_table>
                       TO <g>.
      WRITE <f> TO gt_detail-low CURRENCY <g> LEFT-JUSTIFIED.
    ELSE.

      IF ls_dfies-domname = 'RKE_TSTMP'.
        ld_timestmp = <f>.
        CALL FUNCTION 'RKE_TIMESTAMP_CONVERT_OUTPUT'
          EXPORTING
            i_dayst    = sy-dayst
            i_timestmp = ld_timestmp
            i_tzone    = sy-tzone
          IMPORTING
            e_date     = ld_date
            e_time     = ld_time.

        WRITE ld_date TO gt_detail-low(10).
        WRITE ld_time TO gt_detail-low+12(8).
      ELSE.
        WRITE <f> TO gt_detail-low LEFT-JUSTIFIED.
      ENDIF.
    ENDIF.

    SELECT SINGLE * FROM rseumod INTO ls_rseumod
                  WHERE uname = sy-uname.
    IF sy-subrc             = 0 AND
       ls_rseumod-tbconvert = 'X'.
      gt_detail-low_noconv = gt_detail-low.
    ELSE.
* unconverted line
      gt_detail-low_noconv = <f>.
      SHIFT gt_detail-low_noconv LEFT DELETING LEADING space.

    ENDIF.
    APPEND gt_detail.
  ENDLOOP.
  IF sy-ucomm = 'CANC' OR sy-ucomm = 'ENTER'.
    RETURN.
  ENDIF.

  CALL FUNCTION 'TSWUSL_SHOW_DETAIL'
    TABLES
      it_selfields = gt_detail.


ENDFORM.
*&---------------------------------------------------------------------*
*&      Module  STATUS_9002  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_9002 OUTPUT.
  SET PF-STATUS 'ZQUERY'.
*  SET TITLEBAR 'xxx'.
  IF gv_container IS INITIAL.
    CREATE OBJECT gv_container
      EXPORTING
        container_name              = 'CONTAINER'
      EXCEPTIONS
        cntl_error                  = 1
        cntl_system_error           = 2
        create_error                = 3
        lifetime_error              = 4
        lifetime_dynpro_dynpro_link = 5.
  ENDIF.

  CREATE OBJECT gv_text_editor
    EXPORTING
      parent                 = gv_container
      wordwrap_mode          = '2'
      wordwrap_position      = '250'
    EXCEPTIONS
      error_cntl_create      = 1
      error_cntl_init        = 2
      error_cntl_link        = 3
      error_dp_create        = 4
      gui_type_not_supported = 5.

  gv_text_editor->set_text_as_r3table( table = gi_texttab1[] ).

*/.. Set focus on the editor.
  CALL METHOD cl_gui_docking_container=>set_focus
    EXPORTING
      control = gv_text_editor.

  CALL METHOD gv_text_editor->set_readonly_mode
    EXPORTING
      readonly_mode          = 0
    EXCEPTIONS
      error_cntl_call_method = 1
      invalid_parameter      = 2
      OTHERS                 = 3.
ENDMODULE.
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_9002  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_9002 INPUT.

  CASE sy-ucomm.

    WHEN 'OK'.

      CLEAR: gi_texttab1[], gi_texttab[].

      APPEND `PROGRAM subpool.`                                                                   TO gi_texttab[].
      APPEND `DATA lv_alv_table TYPE REF TO cl_salv_table.`                                       TO gi_texttab[].
      APPEND `DATA lv_layout_grid_header TYPE REF TO cl_salv_form_layout_grid.`                   TO gi_texttab[].
      APPEND `DATA lv_columns TYPE REF TO cl_salv_columns_table.`                                 TO gi_texttab[].
      APPEND `LOAD-OF-PROGRAM.`                                                                   TO gi_texttab[].
      APPEND `FORM demo_query.`                                                                   TO gi_texttab[].

      gv_text_editor->get_text_as_r3table( IMPORTING table = gi_texttab1[] ).

      APPEND LINES OF gi_texttab1[] TO gi_texttab[].

      APPEND `CREATE OBJECT lv_layout_grid_header.`                                               TO gi_texttab[].
      APPEND `lv_layout_grid_header->create_header_information( `                                 TO gi_texttab[].
      APPEND `row = 1 ` & `column = 1 ` & `text   = 'Query Result' ).`                            TO gi_texttab[].
      APPEND `DESCRIBE TABLE ITAB LINES DATA(lines).`                                             TO gi_texttab[].
      APPEND `lv_layout_grid_header->create_text( `                                               TO gi_texttab[].
      APPEND `row = 2 ` & `column = 1 ` & `text   = |Number of entries: { lines }| ).`            TO gi_texttab[].

      APPEND `cl_salv_table=>factory(` &
      ` IMPORTING ` & `R_SALV_TABLE = lv_alv_table`                                               TO gi_texttab[].
      APPEND ` CHANGING ` & `T_TABLE = ITAB ).`                                                   TO gi_texttab[].
      APPEND `lv_columns = lv_alv_table->get_columns( ).`                                         TO gi_texttab[].
      APPEND `lv_columns->set_optimize( 'X' ).`                                                   TO gi_texttab[].
      APPEND `lv_alv_table->set_top_of_list( VALUE = lv_layout_grid_header ).`                    TO gi_texttab[].
      APPEND `DATA(lv_func) = lv_alv_table->get_functions( ).`                                    TO gi_texttab[].
      APPEND `lv_func->set_all( 'X' ).`                                                           TO gi_texttab[].
      APPEND `lv_alv_table->display( ).`                                                          TO gi_texttab[].
      APPEND `ENDFORM.`                                                                           TO gi_texttab[].

      GENERATE SUBROUTINE POOL gi_texttab[] NAME DATA(prog)
               MESSAGE                           DATA(mess)
               SHORTDUMP-ID                      DATA(sid).

      IF sy-subrc = 0.
        PERFORM demo_query IN PROGRAM (prog) IF FOUND.
      ELSEIF sy-subrc = 4.
        MESSAGE mess TYPE 'I'.
      ELSEIF sy-subrc = 8.
        MESSAGE sid TYPE 'I'.
      ENDIF.

      CALL METHOD cl_gui_cfw=>flush
        EXCEPTIONS
          OTHERS = 1.

    WHEN 'CANCEL'.
      LEAVE TO SCREEN 0.

  ENDCASE.

ENDMODULE.
*&---------------------------------------------------------------------*
*&      Form  BACKUP_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM backup_data .

  FIELD-SYMBOLS <i_backup> TYPE STANDARD TABLE.

  CREATE DATA i_table TYPE TABLE OF (viewname).
  ASSIGN i_table->* TO <i_backup>.

  SELECT FROM (viewname) FIELDS * INTO TABLE @<i_backup>.
  CHECK <i_backup> IS NOT INITIAL.
  CHECK zcl_ul_abap=>popup_to_confirm( |A new backup version will be created for table { viewname }?| ) = '1'.
  zcl_ul_data_layer=>write_data( is_key = VALUE #( application = 'TBBACKUP' main_key = |{ viewname }| sub_key = |{ NEW zcl_ul_date( sy-datum )->date_out }| )
                                 is_data = <i_backup> ).
  MESSAGE |Backup done!| TYPE 'S'.

ENDFORM.
*&---------------------------------------------------------------------*
*&      Form  RESTORE_DATA
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
*  -->  p1        text
*  <--  p2        text
*----------------------------------------------------------------------*
FORM restore_data .

  DATA t_sfcat TYPE slis_t_fieldcat_alv.
  DATA s_selfield TYPE slis_selfield.
  DATA t_excludes TYPE slis_t_extab.

  CREATE DATA i_table TYPE TABLE OF (viewname).
  ASSIGN i_table->* TO <i_itab>.

  SELECT FROM ztb_data_layer FIELDS sub_key WHERE application = 'TBBACKUP' AND main_key = @viewname
   INTO TABLE @DATA(t_version).

  IF t_version IS INITIAL.
    MESSAGE 'No backup version found' TYPE 'I'. RETURN.
  ENDIF.

  APPEND INITIAL LINE TO t_sfcat ASSIGNING FIELD-SYMBOL(<fs_sfcat>).
  <fs_sfcat>-fieldname = 'SUB_KEY'.
  <fs_sfcat>-seltext_s = <fs_sfcat>-seltext_m = <fs_sfcat>-seltext_l = 'Version'.
  <fs_sfcat>-outputlen = 16.
  t_excludes = VALUE #( ( fcode = '&ILT' )
                        ( fcode = '&OUP' )
                        ( fcode = '&ODN' )
                        ( fcode = '&OL0' )
                        ( fcode = '%SC'  )
                        ( fcode = '%SC+' )
                        ( fcode = '&ETA' ) ).

  CALL FUNCTION 'REUSE_ALV_POPUP_TO_SELECT'
    EXPORTING
      i_title     = 'Select a version'
      i_tabname   = ''
      it_fieldcat = t_sfcat
      it_excluding = t_excludes
    IMPORTING
      es_selfield = s_selfield
    TABLES
      t_outtab    = t_version.

  IF s_selfield-value IS NOT INITIAL.
    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'TBBACKUP'
                                            iv_mainkey = CONV #( viewname )
                                            iv_subkey = CONV #( s_selfield-value )
                                  IMPORTING e_data = <i_itab> ).
    upld = 'X'. sy-ucomm = 'B5' .CALL SCREEN 9001.
  ELSE.
    MESSAGE 'Action cancelled!' TYPE 'S'.
  ENDIF.


ENDFORM.
