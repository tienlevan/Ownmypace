FUNCTION zfm_ins_load_alv.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IO_ALV) TYPE REF TO  ZCL_UL_ALV_ADAPTER
*"     REFERENCE(IV_TITLE) TYPE  LVC_TITLE OPTIONAL
*"----------------------------------------------------------------------

  go_alv = io_alv.
  gv_title = iv_title.

ENDFUNCTION.
