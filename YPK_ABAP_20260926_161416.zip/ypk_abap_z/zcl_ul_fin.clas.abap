CLASS zcl_ul_fin DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    TYPES:
      BEGIN OF ty_bdc,
        group    TYPE apqi-groupid,
        holddate TYPE apqi-startdate,
        keep     TYPE apqi-qerase,
        user     TYPE apqi-userid,
      END OF ty_bdc .
    TYPES:
      BEGIN OF ty_trans,
        mode   TYPE rfpdo-allgazmd,
        update TYPE rfpdo-allgvbmd,
        xbdcc  TYPE rfipi-xbdcc,
      END OF ty_trans .
    TYPES:
      BEGIN OF ty_pi_para,
        client   TYPE sy-mandt,
        function TYPE rfipi-funct,
        bdc      TYPE ty_bdc,
        trans    TYPE ty_trans,
      END OF ty_pi_para .
    TYPES:
      tt_blntab TYPE TABLE OF blntab .

    CONSTANTS co_funct_bdc TYPE rfipi-funct VALUE 'B' ##NO_TEXT.
    CONSTANTS co_funct_trans TYPE rfipi-funct VALUE 'C' ##NO_TEXT.
    DATA mo_message TYPE REF TO zcx_ul_handle_errors .
    DATA mt_bapi_ext2 TYPE bapiparex_t .

    METHODS constructor .
    METHODS pi_start
      IMPORTING
        !is_parameter TYPE ty_pi_para .
    METHODS pi_post
      IMPORTING
        !iv_tcode     TYPE sy-tcode
        !iv_simu      TYPE boole_d
      RETURNING
        VALUE(rs_doc) TYPE blntab .
    METHODS pi_clearing
      IMPORTING
        !iv_auglv     TYPE t041a-auglv
        !iv_simu      TYPE boole_d
      RETURNING
        VALUE(rs_doc) TYPE blntab .
    METHODS pi_reset_clearing
      IMPORTING
        !iv_augbl TYPE rf05r-augbl
        !iv_bukrs TYPE rf05r-bukrs
        !iv_gjahr TYPE rf05r-gjahr OPTIONAL .
    METHODS pi_fill_header
      IMPORTING
        !is_header TYPE bkpf .
    METHODS pi_fill_items
      IMPORTING
        !it_item TYPE bseg_t .
    METHODS pi_fill_cleardata
      IMPORTING
        !it_cleardata TYPE fdm_t_ftclear .
    METHODS pi_end
      IMPORTING
        !iv_bdcimmed TYPE rfipi-bdcimmed DEFAULT abap_true .
    METHODS pi_reverse
      IMPORTING
        !iv_belns     TYPE rf05a-belns
        !iv_budat     TYPE bsis-budat OPTIONAL
        !iv_bukrs     TYPE bkpf-bukrs
        !iv_gjahs     TYPE rf05a-gjahs OPTIONAL
        !iv_monat     TYPE bsis-monat OPTIONAL
        !iv_voidr     TYPE rf05a-voidr OPTIONAL
        !iv_stgrd     TYPE uf05a-stgrd DEFAULT '01'
      RETURNING
        VALUE(rs_doc) TYPE blntab .
    METHODS bapi_start .
    METHODS bapi_end .
    METHODS bapi_post
      IMPORTING
        !iv_rfcdest      TYPE rfcdest OPTIONAL
      RETURNING
        VALUE(rv_objkey) TYPE bapiache09-obj_key .
    METHODS bapi_check_post
      IMPORTING
        !iv_rfcdest TYPE rfcdest OPTIONAL .
    METHODS bapi_reverse
      IMPORTING
        !iv_rfcdest      TYPE rfcdest OPTIONAL
        !is_reversal     TYPE bapiacrev
      RETURNING
        VALUE(rv_objkey) TYPE bapiache09-obj_key .
    METHODS bapi_check_reverse
      IMPORTING
        !iv_rfcdest  TYPE rfcdest OPTIONAL
        !is_reversal TYPE bapiacrev .
    METHODS bapi_fill_header
      IMPORTING
        !is_header TYPE bkpf .
    METHODS bapi_fill_gl
      IMPORTING
        !it_item TYPE bseg_t .
    METHODS bapi_fill_ar
      IMPORTING
        !it_item TYPE bseg_t .
    METHODS bapi_fill_ap
      IMPORTING
        !it_item TYPE bseg_t .
    METHODS bapi_fill_copa
      IMPORTING
        !it_copa TYPE bapiackec9_tab .
    METHODS bapi_fill_amt
      IMPORTING
        !it_amt TYPE bapiaccr09_tab .
    METHODS bapi_fill_ext2
      IMPORTING
        !is_ext2 TYPE any .
    METHODS bapi_add_tax
      IMPORTING
        !it_tax TYPE bapiactx09_tab.
  PROTECTED SECTION.

    DATA ms_pi_parameter TYPE ty_pi_para .
    DATA:
      mt_pi_postdata  TYPE TABLE OF ftpost .
    DATA:
      mt_pi_taxdata   TYPE TABLE OF fttax .
    DATA:
      mt_pi_cleardata TYPE TABLE OF ftclear .
    DATA ms_bapi_header TYPE bapiache09 .
    DATA mt_bapi_gl TYPE bapiacgl09_tab .
    DATA mt_bapi_ar TYPE bapiacar09_tab .
    DATA mt_bapi_ap TYPE bapiacap09_tab .
    DATA mt_bapi_copa TYPE bapiackec9_tab .
    DATA mt_bapi_amt TYPE bapiaccr09_tab .
    DATA mt_bapi_tax TYPE bapiactx09_tab .
  PRIVATE SECTION.
    METHODS _bapi_fill_tax.
    METHODS _handle_message.
    METHODS _pi_covert_data IMPORTING iv_typekind      TYPE abap_typekind
                                      iv_value         TYPE any
                            RETURNING VALUE(rv_fvalue) TYPE bdc_fval.
ENDCLASS.



CLASS zcl_ul_fin IMPLEMENTATION.


  METHOD bapi_check_post.

    DATA return TYPE bapiret2_t.
    _bapi_fill_tax(  ).

    IF iv_rfcdest IS NOT INITIAL.

      CALL FUNCTION 'BAPI_ACC_DOCUMENT_CHECK'
        DESTINATION iv_rfcdest
        EXPORTING
          documentheader    = ms_bapi_header
        TABLES
          accountgl         = mt_bapi_gl
          accountreceivable = mt_bapi_ar
          accountpayable    = mt_bapi_ap
          accounttax        = mt_bapi_tax
          criteria          = mt_bapi_copa
          currencyamount    = mt_bapi_amt
          return            = return
          extension2        = mt_bapi_ext2.

    ELSE.

      CALL FUNCTION 'BAPI_ACC_DOCUMENT_CHECK'
        EXPORTING
          documentheader    = ms_bapi_header
        TABLES
          accountgl         = mt_bapi_gl
          accountreceivable = mt_bapi_ar
          accountpayable    = mt_bapi_ap
          accounttax        = mt_bapi_tax
          criteria          = mt_bapi_copa
          currencyamount    = mt_bapi_amt
          return            = return
          extension2        = mt_bapi_ext2.

    ENDIF.

    CHECK return IS NOT INITIAL.
    mo_message->add_bapiret2_table( return ).

  ENDMETHOD.


  METHOD bapi_check_reverse.

    DATA return TYPE bapiret2_t.

    IF iv_rfcdest IS NOT INITIAL.

      CALL FUNCTION 'BAPI_ACC_DOCUMENT_REV_CHECK'
        DESTINATION iv_rfcdest
        EXPORTING
          reversal = is_reversal
          bus_act  = 'RFBU'
        TABLES
          return   = return.
    ELSE.

      CALL FUNCTION 'BAPI_ACC_DOCUMENT_REV_CHECK'
        EXPORTING
          reversal = is_reversal
          bus_act  = 'RFBU'
        TABLES
          return   = return.

    ENDIF.

    CHECK return IS NOT INITIAL.
    mo_message->add_bapiret2_table( return ).

  ENDMETHOD.


  METHOD bapi_end.

    IF mo_message->has_messages(  ) IS INITIAL.
      CALL FUNCTION 'BAPI_TRANSACTION_COMMIT' EXPORTING wait = abap_true.
    ELSE.
      _handle_message(  ).
      CALL FUNCTION 'BAPI_TRANSACTION_ROLLBACK'.
    ENDIF.

  ENDMETHOD.


  METHOD bapi_fill_amt.

    APPEND LINES OF it_amt TO mt_bapi_amt.

  ENDMETHOD.


  METHOD bapi_fill_ap.

    LOOP AT it_item ASSIGNING FIELD-SYMBOL(<fs_item>).
      mt_bapi_ap = VALUE #( BASE mt_bapi_ap
                          ( itemno_acc = <fs_item>-buzei vendor_no = <fs_item>-lifnr gl_account = <fs_item>-hkont
                            item_text  = <fs_item>-sgtxt profit_ctr = <fs_item>-prctr bus_area = <fs_item>-gsber
                            alloc_nmbr = <fs_item>-zuonr bline_date = <fs_item>-zfbdt bank_id = <fs_item>-hbkid
                            ref_key_1 = <fs_item>-xref1 ref_key_2 = <fs_item>-xref2 ref_key_3 = <fs_item>-xref3
                            pmnttrms = <fs_item>-zterm businessplace = <fs_item>-bupla partner_bk = <fs_item>-bvtyp ) ).
    ENDLOOP.

  ENDMETHOD.


  METHOD bapi_fill_ar.

    LOOP AT it_item ASSIGNING FIELD-SYMBOL(<fs_item>).
      mt_bapi_ar = VALUE #( BASE mt_bapi_ar
                            ( itemno_acc = <fs_item>-buzei sp_gl_ind = <fs_item>-umskz tax_code = <fs_item>-mwskz
                              customer = <fs_item>-kunnr gl_account = <fs_item>-hkont item_text = <fs_item>-sgtxt
                              bus_area = <fs_item>-gsber alloc_nmbr  = <fs_item>-zuonr bline_date  = <fs_item>-zfbdt
                              bank_id  = <fs_item>-hbkid businessplace = <fs_item>-bupla ) ).

    ENDLOOP.

  ENDMETHOD.


  METHOD bapi_fill_copa.

    mt_bapi_copa = it_copa.

  ENDMETHOD.


  METHOD bapi_fill_ext2.

    DATA: BEGIN OF ls_exchange,
            valuepart1 TYPE bapiparex-valuepart1,
            valuepart2 TYPE bapiparex-valuepart2,
            valuepart3 TYPE bapiparex-valuepart3,
            valuepart4 TYPE bapiparex-valuepart4,
          END OF ls_exchange.

    DATA(lv_json) = /ui2/cl_json=>serialize( data = is_ext2 compress = 'X' expand_includes = 'X' ).
    ls_exchange = lv_json.
    DATA(len) = strlen( cl_abap_structdescr=>describe_by_data( is_ext2 )->absolute_name ) - 6.
    mt_bapi_ext2 = VALUE #( BASE mt_bapi_ext2 ( structure = cl_abap_structdescr=>describe_by_data( is_ext2 )->absolute_name+6(len)
                                                  valuepart1 = ls_exchange-valuepart1  valuepart2 = ls_exchange-valuepart2
                                                  valuepart3 = ls_exchange-valuepart3  valuepart4 = ls_exchange-valuepart4 ) ).

  ENDMETHOD.


  METHOD bapi_fill_gl.

    LOOP AT it_item ASSIGNING FIELD-SYMBOL(<fs_item>).
      mt_bapi_gl = VALUE #( BASE mt_bapi_gl
                            ( itemno_acc = <fs_item>-buzei gl_account = <fs_item>-hkont item_text = <fs_item>-sgtxt costcenter = <fs_item>-kostl
                              quantity = <fs_item>-menge base_uom = <fs_item>-meins profit_ctr = <fs_item>-prctr bus_area = <fs_item>-gsber cs_trans_t = <fs_item>-bewar
                              value_date = <fs_item>-valut ref_key_2 = <fs_item>-xref2 ref_key_1 = <fs_item>-xref1 ref_key_3 = <fs_item>-xref3 alloc_nmbr = <fs_item>-zuonr
                              vendor_no = <fs_item>-lifnr customer = <fs_item>-kunnr orderid = <fs_item>-aufnr trade_id = <fs_item>-vbund tax_code = <fs_item>-mwskz
                              func_area_long  = <fs_item>-fkber acct_type = <fs_item>-koart asset_no = <fs_item>-anln1 sub_number = <fs_item>-anln2  ) ).

    ENDLOOP.

  ENDMETHOD.


  METHOD bapi_fill_header.

    ms_bapi_header = VALUE #( username   = is_header-usnam  header_txt = is_header-bktxt fis_period = is_header-monat
                              comp_code  = is_header-bukrs doc_date   = is_header-bldat pstng_date = is_header-budat
                              doc_type   = is_header-blart ref_doc_no = is_header-xblnr ).

  ENDMETHOD.


  METHOD bapi_post.

    DATA return TYPE bapiret2_t.
    _bapi_fill_tax(  ).

    IF iv_rfcdest IS NOT INITIAL.

      CALL FUNCTION 'BAPI_ACC_DOCUMENT_POST'
        DESTINATION iv_rfcdest
        EXPORTING
          documentheader    = ms_bapi_header
        IMPORTING
          obj_key           = rv_objkey
        TABLES
          accountgl         = mt_bapi_gl
          accountreceivable = mt_bapi_ar
          accountpayable    = mt_bapi_ap
          accounttax        = mt_bapi_tax
          criteria          = mt_bapi_copa
          currencyamount    = mt_bapi_amt
          return            = return
          extension2        = mt_bapi_ext2.

    ELSE.

      CALL FUNCTION 'BAPI_ACC_DOCUMENT_POST'
        EXPORTING
          documentheader    = ms_bapi_header
        IMPORTING
          obj_key           = rv_objkey
        TABLES
          accountgl         = mt_bapi_gl
          accountreceivable = mt_bapi_ar
          accountpayable    = mt_bapi_ap
          accounttax        = mt_bapi_tax
          criteria          = mt_bapi_copa
          currencyamount    = mt_bapi_amt
          return            = return
          extension2        = mt_bapi_ext2.

    ENDIF.

    CHECK return IS NOT INITIAL.
    mo_message->add_bapiret2_table( return ).

  ENDMETHOD.


  METHOD bapi_reverse.

    DATA return TYPE bapiret2_t.

    IF iv_rfcdest IS NOT INITIAL.

      CALL FUNCTION 'BAPI_ACC_DOCUMENT_REV_POST'
        DESTINATION iv_rfcdest
        EXPORTING
          reversal = is_reversal
          bus_act  = 'RFBU'
        IMPORTING
          obj_key  = rv_objkey
        TABLES
          return   = return.
    ELSE.

      CALL FUNCTION 'BAPI_ACC_DOCUMENT_REV_POST'
        EXPORTING
          reversal = is_reversal
          bus_act  = 'RFBU'
        IMPORTING
          obj_key  = rv_objkey
        TABLES
          return   = return.

    ENDIF.

    CHECK return IS NOT INITIAL.
    mo_message->add_bapiret2_table( return ).

  ENDMETHOD.


  METHOD bapi_start.

    REFRESH: mt_bapi_amt, mt_bapi_ap, mt_bapi_ar, mt_bapi_copa, mt_bapi_gl,
             mt_bapi_ext2, mt_bapi_copa, mt_bapi_tax.

  ENDMETHOD.


  METHOD constructor.

    " Instance message
    CREATE OBJECT mo_message.

  ENDMETHOD.


  METHOD pi_clearing.

    DATA subrc TYPE sy-subrc.
    DATA t_blntab TYPE TABLE OF blntab.

    CHECK mo_message->has_messages(  ) IS INITIAL.

    CALL FUNCTION 'POSTING_INTERFACE_CLEARING'
      EXPORTING
        i_auglv   = iv_auglv
        i_xsimu   = iv_simu
        i_tcode   = 'FB05'
      IMPORTING
        e_msgid   = sy-msgid
        e_msgno   = sy-msgno
        e_msgty   = sy-msgty
        e_msgv1   = sy-msgv1
        e_msgv2   = sy-msgv2
        e_msgv3   = sy-msgv3
        e_msgv4   = sy-msgv4
        e_subrc   = subrc
      TABLES
        t_ftclear = mt_pi_cleardata
        t_ftpost  = mt_pi_postdata
        t_fttax   = mt_pi_taxdata
        t_blntab  = t_blntab.

    IF subrc IS NOT INITIAL.
      mo_message->add_system_message(  ).
    ELSEIF t_blntab IS NOT INITIAL.
      rs_doc = t_blntab[ 1 ].
    ENDIF.

  ENDMETHOD.


  METHOD pi_end.

    CALL FUNCTION 'POSTING_INTERFACE_END'
      EXPORTING
        i_bdcimmed              = iv_bdcimmed
      EXCEPTIONS
        session_not_processable = 1
        error_message           = 2
        OTHERS                  = 3.

    IF sy-subrc IS NOT INITIAL.
      mo_message->add_system_message(  ).
      RETURN.
    ENDIF.

    IF mo_message->has_messages(  ) IS NOT INITIAL.
      _handle_message( ).
      ROLLBACK WORK.
    ELSE.
      COMMIT WORK AND WAIT.
    ENDIF.

  ENDMETHOD.


  METHOD pi_fill_cleardata.

    mt_pi_cleardata = it_cleardata.

  ENDMETHOD.


  METHOD pi_fill_header.

    DATA t_diic TYPE ddfields.

    TRY.
        DATA(o_data) = NEW zcl_ul_rtts_services( iv_data = is_header ).
        DATA(t_components) = o_data->get_struct_inf( IMPORTING et_ddic_fields = t_diic ).
      CATCH zcx_ul_handle_errors.
        RETURN.
    ENDTRY.

    LOOP AT t_components ASSIGNING FIELD-SYMBOL(<component>).
      ASSIGN COMPONENT <component>-name OF STRUCTURE is_header TO FIELD-SYMBOL(<fv>).
      CHECK <fv> IS NOT INITIAL.
      CASE t_diic[ fieldname = <component>-name ]-datatype.
        WHEN 'DATS' OR 'CURR'.
          DATA(fvalue) = _pi_covert_data( iv_typekind = <component>-type->type_kind iv_value = <fv> ).
        WHEN 'DEC'.
          DATA lv_dec TYPE p DECIMALS 3.
          lv_dec = <fv>.
          fvalue = |{ lv_dec NUMBER = USER }|.
          CONDENSE fvalue.
        WHEN OTHERS.
          fvalue = <fv>.
          CONDENSE fvalue.
      ENDCASE.
      DATA(fname) = |BKPF-{ <component>-name }|.
      pi_postdata 'K' space fname fvalue.
    ENDLOOP.

  ENDMETHOD.


  METHOD pi_fill_items.

    DATA t_diic TYPE ddfields.

    TRY.
        DATA(o_data) = NEW zcl_ul_rtts_services( iv_name = 'BSEG' ).
        DATA(t_components) = o_data->get_struct_inf( IMPORTING et_ddic_fields = t_diic ).
      CATCH zcx_ul_handle_errors.
        RETURN.
    ENDTRY.

    LOOP AT it_item ASSIGNING FIELD-SYMBOL(<item>).
      LOOP AT t_components ASSIGNING FIELD-SYMBOL(<component>).
        ASSIGN COMPONENT <component>-name OF STRUCTURE <item> TO FIELD-SYMBOL(<fv>).
        CHECK <fv> IS NOT INITIAL AND <component>-name NE 'BUZEI'.
        IF t_diic[ fieldname = <component>-name ]-datatype = 'DATS' OR t_diic[ fieldname = <component>-name ]-datatype = 'CURR'.
          DATA(fvalue) = _pi_covert_data( iv_typekind = <component>-type->type_kind iv_value = <fv> ).
        ELSE.
          fvalue = <fv>.
        ENDIF.
        IF <component>-name IN zcl_ul_abap=>string_to_range( 'PRCTR,KOSTL,PS_POSID,AUFNR,BEWAR'  ).
          IF <component>-name = 'BEWAR'.
            DATA(fname) = 'COBL-RMVCT'.
          ELSE.
            fname = |COBL-{ <component>-name }|.
          ENDIF.
        ELSE.
          fname = |BSEG-{ <component>-name }|.
        ENDIF.
        pi_postdata 'P' <item>-buzei fname fvalue.
      ENDLOOP.
    ENDLOOP.

  ENDMETHOD.


  METHOD pi_post.

    DATA subrc TYPE sy-subrc.
    DATA t_blntab TYPE TABLE OF blntab.

    CHECK mo_message->has_messages(  ) IS INITIAL AND mt_pi_postdata IS NOT INITIAL.

    CALL FUNCTION 'POSTING_INTERFACE_DOCUMENT'
      EXPORTING
        i_tcode  = iv_tcode
        i_xsimu  = iv_simu
      IMPORTING
        e_msgid  = sy-msgid
        e_msgno  = sy-msgno
        e_msgty  = sy-msgty
        e_msgv1  = sy-msgv1
        e_msgv2  = sy-msgv2
        e_msgv3  = sy-msgv3
        e_msgv4  = sy-msgv4
        e_subrc  = subrc
      TABLES
        t_ftpost = mt_pi_postdata
        t_fttax  = mt_pi_taxdata
        t_blntab = t_blntab.

    IF subrc IS NOT INITIAL AND sy-msgty = 'E'.
      mo_message->add_system_message(  ).
    ELSEIF t_blntab IS NOT INITIAL.
      rs_doc = t_blntab[ 1 ].
    ENDIF.

  ENDMETHOD.


  METHOD pi_reset_clearing.

    DATA subrc TYPE sy-subrc.
    DATA t_blntab TYPE TABLE OF blntab.

    CHECK mo_message->has_messages(  ) IS INITIAL.

    CALL FUNCTION 'POSTING_INTERFACE_RESET_CLEAR'
      EXPORTING
        i_augbl = iv_augbl
        i_bukrs = iv_bukrs
        i_gjahr = iv_gjahr
        i_tcode = 'FBRA'
      IMPORTING
        e_msgid = sy-msgid
        e_msgno = sy-msgno
        e_msgty = sy-msgty
        e_msgv1 = sy-msgv1
        e_msgv2 = sy-msgv2
        e_msgv3 = sy-msgv3
        e_msgv4 = sy-msgv4
        e_subrc = subrc.

    IF subrc IS NOT INITIAL.
      mo_message->add_system_message(  ).
    ENDIF.

  ENDMETHOD.


  METHOD pi_reverse.

    DATA subrc TYPE sy-subrc.
    DATA t_blntab TYPE TABLE OF blntab.

    CHECK mo_message->has_messages(  ) IS INITIAL.

    CALL FUNCTION 'POSTING_INTERFACE_REVERSE_DOC'
      EXPORTING
        i_belns  = iv_belns
        i_budat  = iv_budat
        i_bukrs  = iv_bukrs
        i_gjahs  = iv_gjahs
        i_monat  = iv_monat
        i_tcode  = 'FB08'
        i_voidr  = iv_voidr
        i_stgrd  = iv_stgrd
      IMPORTING
        e_msgid  = sy-msgid
        e_msgno  = sy-msgno
        e_msgty  = sy-msgty
        e_msgv1  = sy-msgv1
        e_msgv2  = sy-msgv2
        e_msgv3  = sy-msgv3
        e_msgv4  = sy-msgv4
        e_subrc  = subrc
      TABLES
        t_blntab = t_blntab.

    IF subrc IS NOT INITIAL.
      mo_message->add_system_message(  ).
    ELSEIF t_blntab IS NOT INITIAL.
      rs_doc = t_blntab[ 1 ].
    ENDIF.

  ENDMETHOD.


  METHOD pi_start.

    "Refresh data
    REFRESH: mt_pi_taxdata, mt_pi_cleardata, mt_pi_postdata.

    "Auto fill default parameter
    ms_pi_parameter = is_parameter.
    ms_pi_parameter-client       = COND #( WHEN ms_pi_parameter-client IS INITIAL THEN sy-mandt    ELSE ms_pi_parameter-client ).
    ms_pi_parameter-bdc-user     = COND #( WHEN ms_pi_parameter-bdc-user IS INITIAL THEN sy-uname  ELSE ms_pi_parameter-bdc-user ).
    ms_pi_parameter-bdc-group    = COND #( WHEN ms_pi_parameter-bdc-group IS INITIAL THEN 'PI_FI'  ELSE ms_pi_parameter-bdc-group ).
    ms_pi_parameter-trans-mode   = COND #( WHEN ms_pi_parameter-trans-mode IS INITIAL THEN 'N'     ELSE ms_pi_parameter-trans-mode ).
    ms_pi_parameter-trans-update = COND #( WHEN ms_pi_parameter-trans-update IS INITIAL THEN 'S'   ELSE ms_pi_parameter-trans-update ).

    CALL FUNCTION 'POSTING_INTERFACE_START'
      EXPORTING
        i_client           = ms_pi_parameter-client
        i_function         = ms_pi_parameter-function
        i_group            = ms_pi_parameter-bdc-group
        i_holddate         = ms_pi_parameter-bdc-holddate
        i_keep             = ms_pi_parameter-bdc-keep
        i_user             = ms_pi_parameter-bdc-user
        i_xbdcc            = ms_pi_parameter-trans-xbdcc
        i_mode             = ms_pi_parameter-trans-mode
        i_update           = ms_pi_parameter-trans-update
      EXCEPTIONS
        client_incorrect   = 1
        function_invalid   = 2
        group_name_missing = 3
        mode_invalid       = 4
        update_invalid     = 5
        user_invalid       = 6
        error_message      = 7
        OTHERS             = 8.

    IF sy-subrc IS NOT INITIAL.
      mo_message->add_system_message(  ).
    ENDIF.

  ENDMETHOD.


  METHOD _bapi_fill_tax.

    DATA subrc TYPE subrc.
    DATA return TYPE bapirettab.

    CALL FUNCTION 'FI_TAX_SERVICES_CALCULATE'
      EXPORTING
        documentheader    = ms_bapi_header
        accountpayable    = mt_bapi_ap
        accountreceivable = mt_bapi_ar
        extension2        = mt_bapi_ext2
      IMPORTING
        return_code       = subrc
      CHANGING
        accountgl         = mt_bapi_gl
        accounttax        = mt_bapi_tax
        currencyamount    = mt_bapi_amt
        return            = return.

    "Recaluate due to rounding
    DATA(amt_check) = REDUCE #( INIT x TYPE bapidoccur FOR amt IN mt_bapi_amt
                                NEXT x = x + amt-amt_doccur ).
    IF amt_check <> 0.
      READ TABLE mt_bapi_tax INTO DATA(ls_bapi_tax) INDEX 1.
      IF sy-subrc IS INITIAL.
        READ TABLE mt_bapi_amt ASSIGNING FIELD-SYMBOL(<fs_bapi_amt>) WITH KEY itemno_acc = ls_bapi_tax-itemno_acc.
        CHECK <fs_bapi_amt> IS ASSIGNED.
        <fs_bapi_amt>-amt_doccur = <fs_bapi_amt>-amt_doccur - amt_check.
      ENDIF.
    ENDIF.

    IF subrc IS NOT INITIAL.
      mo_message->add_bapiret2_table( return ).
    ENDIF.

  ENDMETHOD.


  METHOD _handle_message.

    IF sy-batch IS INITIAL.
      mo_message->show_message(  ).
    ELSE.
      mo_message->log_message(  ).
    ENDIF.

  ENDMETHOD.


  METHOD _pi_covert_data.

    DATA lv_p TYPE p LENGTH 16 DECIMALS 0.

    CASE iv_typekind.
      WHEN 'D'.
        rv_fvalue = NEW zcl_ul_date( iv_value )->date_out.
      WHEN 'P'.
        DATA lv_currency TYPE waers.
        TRY.
            lv_currency = mt_pi_postdata[ stype = 'K' fnam = 'BKPF-WAERS' ]-fval.
          CATCH cx_sy_itab_line_not_found.
            lv_currency = 'VND'.
        ENDTRY.
        lv_p = zcl_ul_abap=>convert_amt_currency( iv_amount = iv_value iv_currency = lv_currency iv_format = '1' ).
        rv_fvalue = lv_p. CONDENSE rv_fvalue.
      WHEN OTHERS.
        rv_fvalue = iv_value.
    ENDCASE.

  ENDMETHOD.

  METHOD bapi_add_tax.

    APPEND LINES OF it_tax TO mt_bapi_tax.

  ENDMETHOD.

ENDCLASS.
