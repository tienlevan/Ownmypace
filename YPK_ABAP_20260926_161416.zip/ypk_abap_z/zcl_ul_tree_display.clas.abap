class ZCL_UL_TREE_DISPLAY definition
  public
  final
  create public .

public section.

  types:
    tb_treeload TYPE STANDARD TABLE OF ztb_treeload .
  types:
    tb_treeit   TYPE STANDARD TABLE OF mtreeitm .

  constants C_NODE_PROGRAM type ZTB_TREELOAD-ACC_TYPE value '01' ##NO_TEXT.
  constants C_NODE_TCODE type ZTB_TREELOAD-ACC_TYPE value '02' ##NO_TEXT.
  constants C_NODE_MVIEW type ZTB_TREELOAD-ACC_TYPE value '03' ##NO_TEXT.
  constants C_NODE_DBTABLE type ZTB_TREELOAD-ACC_TYPE value '04' ##NO_TEXT.
  constants C_NODE_WEBLINK type ZTB_TREELOAD-ACC_TYPE value '05' ##NO_TEXT.
  constants C_NODE_MENUID type ZTB_TREELOAD-ACC_TYPE value '06' ##NO_TEXT.
  constants C_NODE_ACTVID type ZTB_TREELOAD-ACC_TYPE value '07' ##NO_TEXT.
  constants C_NODE_FM type ZTB_TREELOAD-ACC_TYPE value '08' ##NO_TEXT.
  constants C_NODE_CL type ZTB_TREELOAD-ACC_TYPE value '09' ##NO_TEXT.
  constants C_NODE_CODE type ZTB_TREELOAD-ACC_TYPE value '10' ##NO_TEXT.
  constants C_NODE_DOC type ZTB_TREELOAD-ACC_TYPE value '11' ##NO_TEXT.
  constants C_NODE_FLP type ZTB_TREELOAD-ACC_TYPE value '12' ##NO_TEXT.
  constants C_NODE_DYCF type ZTB_TREELOAD-ACC_TYPE value '13' ##NO_TEXT.
  constants C_NODE_ROLE type ZTB_TREELOAD-ACC_TYPE value '14' ##NO_TEXT.
  constants C_NODE_KBN type ZTB_TREELOAD-ACC_TYPE value '15' ##NO_TEXT.
  constants C_NODE_TXT type ZTB_TREELOAD-ACC_TYPE value '16' ##NO_TEXT.
  constants C_NODE_TXTEDIT type ZTB_TREELOAD-ACC_TYPE value '17' ##NO_TEXT.
  data AT_NODE type TREEV_NTAB .
  data AT_ITEM type TB_TREEIT .
  data AT_CONFIG type TB_TREELOAD .
  data AV_MODULE type TL12 .
  data AT_NODE_KEY type TREEV_NKS .
  data:
    at_events   TYPE STANDARD TABLE OF cntl_simple_event .
  data AR_TREE type ref to CL_GUI_LIST_TREE .
  data CX_ERROR type ref to ZCX_UL_HANDLE_ERRORS .
  data AV_NODE_KEY type TV_NODEKEY .
  class-data AV_CLIENT type RFCDEST .
  constants C_SYMBOL_PROG type ICON_D value '@9U@' ##NO_TEXT.
  constants C_SYMBOL_TCODE type ICON_D value '@CS@' ##NO_TEXT.
  constants C_SYMBOL_TABLE type ICON_D value '@PO@' ##NO_TEXT.
  constants C_SYMBOL_IMG type ICON_D value '@15@' ##NO_TEXT.
  constants C_SYMBOL_CLS type ICON_D value '@7I@' ##NO_TEXT.
  constants C_SYMBOL_FM type ICON_D value '@39@' ##NO_TEXT.
  constants C_SYMBOL_MV type ICON_D value '@XD@' ##NO_TEXT.
  constants C_SYMBOL_WL type ICON_D value '@8S@' ##NO_TEXT.
  constants C_SYMBOL_MNID type ICON_D value '@6A@' ##NO_TEXT.
  constants C_SYMBOL_FLP type ICON_D value '@G3@' ##NO_TEXT.
  constants C_SYMBOL_DYCF type ICON_D value '@MF@' ##NO_TEXT.
  data AR_TREE_CONT type ref to CL_GUI_CONTAINER .
  data AR_HTML type ref to CL_GUI_CONTAINER .
  data AR_PIC type ref to CL_GUI_PICTURE .
  data AR_HTML_CONTROL type ref to CL_GUI_HTML_VIEWER .
  data AR_TEXTEDIT type ref to CL_GUI_TEXTEDIT .
  data AR_EDITOR type ref to CL_GUI_ABAPEDIT .
  data AR_ALV type ref to CL_GUI_CONTAINER .
  data AR_DOI_DOC type ref to ZCL_UL_DOI_USAGE .
  data AV_DOC_OPEN type ABAP_BOOL .
  data AV_OBJECTKEY type /PLMB/SWO_TYPEID .

  methods CONSTRUCTOR
    importing
      !IV_MODULE type TL12 optional
      !IV_HEADER type TREEV_HHDR optional
      !IV_REDIFINED_EVENT type ABAP_BOOL default ABAP_TRUE
      !IO_CONTAINER type ref to CL_GUI_CONTAINER optional
      !IO_BROWSER type ref to CL_GUI_CONTAINER optional
      !IV_REDIFINED_SCREEN type ABAP_BOOL default ABAP_TRUE
      !IV_IMG_OBJ type W3OBJID optional
      !IV_OBJECTKEY type /PLMB/SWO_TYPEID optional
      !IV_HOME_URL type CSEQUENCE optional
      !IV_IMG_BDS type SDYDO_KEY optional .
  methods CREATE_INT_TREE
    importing
      !IT_CONFIG type TB_TREELOAD optional
    exporting
      !ET_NODETAB type TREEV_NTAB
      !ET_ITEM type TB_TREEIT .
  methods TREE_DISPLAY
    importing
      !IT_CONFIG type TB_TREELOAD optional .
  methods SET_NODE_TECH
    importing
      !IV_ACTIVE type ABAP_BOOL
    raising
      ZCX_UL_HANDLE_ERRORS .
  methods FIND_NODE_KEY
    importing
      !IV_NODETYPE type ZTB_TREELOAD-ACC_TYPE optional
      !IV_VALUE type ZTB_TREELOAD-PROGRAMNAME
      !IV_INDEX type SY-TABIX optional
    returning
      value(RV_INDEX) type SY-TABIX .
  methods WHERE_USED_LIST .
  methods EDIT_HELP .
  methods TRANSPORT_MENU .
  methods EDITOR_CALL .
  methods ADD_NODES
    importing
      !IT_NODES type TB_TREELOAD .
  class-methods BUILD_ACC_TYPE
    returning
      value(RT_ACC_TYPES) type VRM_VALUES .
  class-methods SET_DEFAULT_TEXT
    importing
      !IV_ACC_TYPE type ZTB_TREELOAD-ACC_TYPE
    exporting
      !EV_SYMBOL type ZTB_TREELOAD-N_IMAGE
    changing
      !CV_VALUE type ZTB_TREELOAD-PROGRAMNAME optional
    returning
      value(RV_TEXT) type ZTB_TREELOAD-TEXT .
  methods F1_IN_EDITOR
    for event F1 of CL_GUI_ABAPEDIT .
  methods SET_VISIBLE
    importing
      !IV_CLASS_NAME type C .
  methods GET_NODE_INF
    importing
      !IV_NODEKEY type TV_NODEKEY
    returning
      value(RS_NODEKEY) type ZTB_TREELOAD
    raising
      ZCX_UL_HANDLE_ERRORS .
  methods GET_SELECTED_NODE
    returning
      value(RV_NODE_KEY) type TV_NODEKEY .
  methods ADD_DOCUMENT
    importing
      !IO_DOC type ref to ZCL_UL_DOI_USAGE optional .
  methods OPEN_DOCUMENT
    importing
      !IV_NODEKEY type TV_NODEKEY .
  methods WEB_BROWSER
    importing
      !IV_URL type CSEQUENCE
      !IV_TITLE type CL_ABAP_BROWSER=>TITLE default 'SAP Web Browser'
      !IV_BREAK type CHAR1 optional .
  methods GET_NODES_BY_PARENT
    importing
      !IV_PARENT_KEY type TV_NODEKEY
    returning
      value(RT_NODES) type ZTT_TREELOAD .
  methods SET_IMAGE
    importing
      !IV_OBJ type W3OBJID .
  methods SET_BDS_IMAGE
    importing
      !IV_IMAGE_ID type SDYDO_KEY optional .
  methods SET_VISIBLE_OBJECT
    importing
      !IO_OBJECT type ref to OBJECT .
  class-methods NAVIGATE_TO_OBJECT
    importing
      !IV_ACCESS_TYPE type ZACC_TYPE
      !IV_OBJECT type TEXT70_OBJ
      !IV_LINE type TPDA_SC_LINE optional .
  methods TRANSPORT_FOLDER .
  methods TEXTEDIT_CALL .
  PROTECTED SECTION.

private section.

  data AR_DRAPDROP type ref to CL_DRAGDROP .
  data AV_DRAG_OBJ type TV_NODEKEY .
  data AV_DROP_OBJ type TV_NODEKEY .
  data AV_DRAPDROP_HANDLE type I .
  data AV_FCODE type SY-UCOMM .
  data AV_ISFOLDER type AS4FLAG .

  events ZCX_UL_HANDLE_ERRORS .

  methods ON_USER_DRAG
    for event ON_DRAG of CL_GUI_LIST_TREE
    importing
      !NODE_KEY
      !ITEM_NAME
      !DRAG_DROP_OBJECT .
  methods ON_USER_DROP
    for event ON_DROP of CL_GUI_LIST_TREE
    importing
      !NODE_KEY
      !DRAG_DROP_OBJECT .
  methods ON_USER_DROP_COMPLETE
    for event ON_DROP_COMPLETE of CL_GUI_LIST_TREE
    importing
      !NODE_KEY
      !ITEM_NAME
      !DRAG_DROP_OBJECT .
  methods ON_USER_DB_CLICK
    for event NODE_DOUBLE_CLICK of CL_GUI_LIST_TREE
    importing
      !NODE_KEY .
  methods MODIFY_NODES
    importing
      !IS_SOURCE type ZTB_TREELOAD
      !IS_TARGET type ZTB_TREELOAD
    exporting
      value(ET_RESULT) type TB_TREELOAD
    raising
      ZCX_UL_HANDLE_ERRORS .
  methods UPDATE_NODES
    importing
      !IT_UPDATE_NODES type TB_TREELOAD
      !IV_SAVE type BOOLEAN default ABAP_TRUE .
  methods ON_NODE_MENU_REQUEST
    for event NODE_CONTEXT_MENU_REQUEST of CL_GUI_LIST_TREE
    importing
      !NODE_KEY
      !MENU .
  methods ON_NODE_MENU_SELECT
    for event NODE_CONTEXT_MENU_SELECT of CL_GUI_LIST_TREE
    importing
      !NODE_KEY
      !FCODE .
  methods ON_NODE_KEYPRESS
    for event NODE_KEYPRESS of CL_GUI_LIST_TREE
    importing
      !NODE_KEY
      !KEY .
  methods WRITE_HTML_TABLE
    importing
      !IV_TABNAME type ZTB_TREELOAD-PROGRAMNAME .
  methods WRITE_HTML_PROG
    importing
      !IV_PROG type ZTB_TREELOAD-PROGRAMNAME .
  methods WRITE_HTML_ACT
    importing
      !IV_OBJ type ZTB_TREELOAD-PROGRAMNAME
      !IV_OBJTYPE type DOKU_ID .
  methods DELETE_NODES
    importing
      !IV_NODEKEY type TV_NODEKEY .
  methods DBLCLICK_IN_EDITOR
    for event DBLCLICK of CL_GUI_ABAPEDIT .
  methods FIORI_LAUNCHER
    importing
      !IV_FUNCTION type STRING optional .
ENDCLASS.



CLASS ZCL_UL_TREE_DISPLAY IMPLEMENTATION.


  METHOD add_document.

    SORT at_config DESCENDING BY pos.
    DATA lt_add_node TYPE TABLE OF ztb_treeload.

    TRY.
        DATA(ls_node) = get_node_inf( get_selected_node( ) ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message(  ). RETURN.
    ENDTRY.

    IF ar_doi_doc IS NOT BOUND.
      ar_doi_doc = io_doc.
    ENDIF.

    IF ls_node-isfolder IS NOT INITIAL.

      CASE ar_doi_doc->at_doc_signatures[ prop_name = 'BDS_DOCUMENTCLASS' ]-prop_value.
        WHEN 'DOC' OR 'DOCX'.
          DATA(lv_image) = '@J7@'.
        WHEN 'XLS' OR 'XLSX'.
          lv_image =  '@J2@'.
        WHEN 'XLSM'.
          lv_image = '@J3@'.
        WHEN 'PPT' OR 'PPTX'.
          lv_image = '@J5@'.
        WHEN 'PDF'.
          lv_image = '@IT@'.
        WHEN 'MSG'.
          lv_image = '@J1'.
        WHEN 'JPG'.
          lv_image = '@J0@'.
        WHEN OTHERS.
          lv_image = '@OA@'.
      ENDCASE.

      lt_add_node = VALUE #( ( modulelo = av_module node_key = |ITEM{ at_config[ 1 ]-pos + 1 }| n_image = lv_image
                               text = ar_doi_doc->at_doc_signatures[ prop_name = 'DESCRIPTION' ]-prop_value created_by = sy-uname
                               docname = ar_doi_doc->at_doc_signatures[ 1 ]-doc_id acc_type = c_node_doc dragdropid = 1 created_on = zcl_ul_abap=>encode_timestamp( )
                               pos = at_config[ 1 ]-pos + 1 relatkey = ls_node-node_key relatship = 6 object_key = av_objectkey file_size = ar_doi_doc->at_doc_components[ 1 ]-comp_size
                               length = strlen( ar_doi_doc->at_doc_signatures[ prop_name = 'DESCRIPTION' ]-prop_value ) + 1 ) ).

      add_nodes( it_nodes = lt_add_node ).
      MODIFY ztb_treeload FROM TABLE lt_add_node.
      ar_tree->set_selected_node( lt_add_node[ 1 ]-node_key ).
      MESSAGE 'New document is inserted!' TYPE 'S'.

    ELSE.

      zcx_ul_handle_errors=>raise_message( iv_msg_text = 'Please select a folder!' ).

    ENDIF.

  ENDMETHOD.


  METHOD add_nodes.

    CHECK ar_tree IS BOUND.
    create_int_tree( EXPORTING it_config  = it_nodes
                     IMPORTING et_nodetab = DATA(lt_node)
                               et_item    = DATA(lt_item) ).
    MODIFY ztb_treeload FROM TABLE it_nodes.
    CHECK sy-subrc IS INITIAL.
    ar_tree->add_nodes_and_items( node_table = lt_node item_table = lt_item item_table_structure_name = 'ZTB_TREELOAD' ).
    ar_tree->set_screen_update( abap_true ).

  ENDMETHOD.


  METHOD build_acc_type.

    TRY.

        DATA(lt_fix_vals) = NEW zcl_ul_rtts_services( iv_name = 'ZACC_TYPE' )->get_fix_values( ).
      CATCH zcx_ul_handle_errors INTO DATA(cx_err).
        cx_err->show_message( ).

    ENDTRY.


    cl_abap_corresponding=>create(
      source      = lt_fix_vals
      destination = rt_acc_types
      mapping     = VALUE cl_abap_corresponding=>mapping_table(
           ( level = 0 kind = 1 srcname = 'LOW'    dstname = 'KEY' )
           ( level = 0 kind = 1 srcname = 'DDTEXT' dstname = 'TEXT' ) )
           )->execute( EXPORTING source      = lt_fix_vals
                       CHANGING  destination = rt_acc_types ).
    CALL FUNCTION 'VRM_SET_VALUES'
      EXPORTING
        id     = 'ZTB_TREELOAD-ACC_TYPE'
        values = rt_acc_types.

  ENDMETHOD.


  METHOD constructor.


    " Create error handle instance
    CREATE OBJECT cx_error.

    " For needed header hierachy
    IF iv_header IS NOT INITIAL.DATA(lv_with_header) = abap_true.ENDIF.

    " Fill module menu
    IF iv_module IS NOT INITIAL. av_module = iv_module. ENDIF.
    IF iv_objectkey IS NOT INITIAL. av_objectkey = iv_objectkey. ENDIF.

    " Fill tree container.
    IF io_container IS BOUND. ar_tree_cont = io_container. ENDIF.

    " Fill html container
    IF io_browser IS BOUND. ar_html = io_browser. ENDIF.

    " Set redifinded screen/ Screen must call
    IF iv_redifined_screen IS NOT INITIAL AND io_container IS NOT BOUND AND io_browser IS NOT BOUND.
      DATA(lo_splitter) = NEW cl_gui_splitter_container(
        parent  = cl_gui_container=>default_screen
        rows    = 1
        columns = 2 ).
      ar_tree_cont = lo_splitter->get_container( row = 1 column = 1 ).
      ar_html = lo_splitter->get_container( row = 1 column = 2 ).
      lo_splitter->set_column_sash( id    = 2
                                    type  = cl_gui_splitter_container=>type_movable
                                    value = cl_gui_splitter_container=>true ).
      lo_splitter->set_column_width( id = 1 width = 25 ).
    ENDIF.

    " Create tree instance
    ar_tree = NEW #(  parent              = ar_tree_cont
                      node_selection_mode = cl_gui_list_tree=>node_sel_mode_single
                      item_selection      = abap_false
                      with_headers        = lv_with_header
                      hierarchy_header    = iv_header ).

    " Set image picture
    IF iv_img_obj IS NOT INITIAL.
      set_image( iv_img_obj ).
    ELSEIF iv_img_bds IS NOT INITIAL.
      set_bds_image( iv_img_bds ).
    ELSE.
      set_bds_image( ).
    ENDIF.

    " Set home page
    IF iv_home_url IS NOT INITIAL AND iv_img_obj IS INITIAL.
      web_browser( EXPORTING iv_url = iv_home_url ).
    ENDIF.

    " Set redifined events
    CHECK iv_redifined_event = abap_true.
    " Drag_drop event
    CREATE OBJECT ar_drapdrop.
    ar_drapdrop->add( flavor = 'USER'  dragsrc = abap_true  droptarget = abap_true effect = cl_dragdrop=>move ).
    ar_drapdrop->get_handle( IMPORTING handle = av_drapdrop_handle ).
    at_events = VALUE #( ( eventid = cl_gui_list_tree=>eventid_node_double_click appl_event = abap_true )
                         ( eventid = cl_gui_list_tree=>eventid_node_context_menu_req appl_event = abap_true )
                         ( eventid = cl_gui_list_tree=>eventid_node_keypress appl_event = abap_true ) ).

    ar_tree->set_ctx_menu_select_event_appl( appl_event = abap_true ).
    ar_tree->set_registered_events( events = at_events ).


  ENDMETHOD.


  METHOD create_int_tree.

    DATA: node TYPE treev_node,
          item TYPE mtreeitm.

    IF it_config IS INITIAL AND av_module IS NOT INITIAL.
      " Loading configuration
      REFRESH at_config.
      SELECT FROM ztb_treeload FIELDS * WHERE modulelo = @av_module AND object_key = @av_objectkey INTO CORRESPONDING FIELDS OF TABLE @at_config .
      CHECK at_config IS NOT INITIAL.
      SORT at_config ASCENDING BY pos.

    ELSE.

      at_config = it_config.

    ENDIF.

    LOOP AT at_config ASSIGNING FIELD-SYMBOL(<fs_config>).

      CLEAR: node, item.
      node = CORRESPONDING #( <fs_config> ).
      item = CORRESPONDING #( <fs_config> ).
      node-node_key  = <fs_config>-node_key.
      item-node_key  = <fs_config>-node_key.
      node-exp_image = <fs_config>-n_image.
      item-item_name = 1.
      APPEND node TO et_nodetab.
      APPEND item TO et_item.
      CHECK node-expander IS NOT INITIAL.
      APPEND node-node_key TO at_node_key.

    ENDLOOP.


  ENDMETHOD.


  METHOD dblclick_in_editor.

*    FIELD-SYMBOLS <wb> TYPE REF TO cl_wb_editor.
*    DATA text TYPE TABLE OF text255.
*
*    Break tienlv1.
*    ar_editor->get_selected_text_as_table( IMPORTING table = text ).
*    CALL FUNCTION 'EDITOR_TABLE'
*      TABLES
*        content = text.
*    ASSIGN ('(SAPLS38E)ABAP_EDITOR') TO <wb>.
*    <wb>->get_source_instance( IMPORTING source_object = DATA(source) ).
*    <wb>->visualize_source(  ).


*    DATA:
*      l_str_cursor TYPE typ_str_cursor,
*      l_word       TYPE c LENGTH 1000,
*      l_tab_lines  TYPE cl_cmp_composer=>tab_code,
*      l_line_no    TYPE i,
*      l_first_line TYPE i,
*      l_flg_nav    TYPE xflag,
*      l_line       TYPE c  LENGTH 1000,
*      l_line_x     TYPE c  LENGTH 1000,
*      l_pos        TYPE i.
*
*    DATA:
*      l_word    LIKE r_word,
*      l_length  TYPE i,
*      l_current TYPE c LENGTH 1,
*      l_offset  TYPE i.
*
*    CALL FUNCTION 'CONTROL_FLUSH'
*      EXCEPTIONS
*        cntl_system_error = 1
*        cntl_error        = 2
*        OTHERS            = 3.
*
*    TRY.
*
*        ar_editor->get_selection_pos(
*          IMPORTING
*            i_from_line = l_line_no
*            i_from_pos  = l_pos
*          EXCEPTIONS
*            OTHERS    = 1 ).
*
*        ar_editor->get_first_visible_line( IMPORTING line = l_first_line ).
*        l_str_cursor-line   = l_line_no.
*        l_str_cursor-offset = l_pos.
*
*        ar_editor->get_text( IMPORTING table = l_tab_lines ).
*
*        READ TABLE l_tab_lines
*          INTO l_line
*            INDEX l_line_no.
*
*        CHECK sy-subrc = 0.
*
*        IF l_line IS INITIAL.
*
*          ar_editor->set_first_visible_line( i_line = l_first_line  ).
*          ar_editor->set_cursor_position( i_str_cursor = l_str_cursor ).
*          EXIT.
*
*        ENDIF.
*
*        ar_editor->set_selection_pos_in_line( line = l_line_no  pos = l_pos ).
*
*        l_offset = l_pos.
*        l_length = strlen( l_line ).
*
*        CHECK l_length GE i_pos.
*        CHECK NOT l_length IS INITIAL.
*        DO.
*          CLEAR l_current.
*          IF l_offset GE 0.
*            l_current = i_line+l_offset(1).
*          ENDIF.
*
*          IF l_current IS INITIAL.
*            EXIT.
*          ENDIF.
*
*          r_word = l_current && r_word.
*          SUBTRACT 1 FROM l_offset.
*
*        ENDDO.
*
*        IF r_word IS INITIAL.
*          EXIT.
*        ENDIF.
*
*        l_word = r_word.
*        l_offset = i_pos + 1.
*
*        DO.
*          CLEAR l_current.
*          IF l_offset LE l_length.
*            l_current = i_line+l_offset(1).
*          ENDIF.
*
*          IF l_current IS INITIAL.
*            EXIT.
*          ENDIF.
*
*          r_word = r_word && l_current.
*          ADD 1 TO l_offset.
*
*        ENDDO.
*
*        IF l_word = r_word.
*          CLEAR r_word.
*        ENDIF.
*        l_line_x = l_line.
*
*        SHIFT l_line_x LEFT DELETING LEADING space.
*
*        IF l_line_x(1) = '@' OR is_cc_word( l_word ) IS NOT INITIAL.
*
*          handle_cc_click(
*          EXPORTING
*            i_line_no = l_line_no
*            i_pos     = l_pos
*            i_word    = l_word
*           IMPORTING
*             e_flg_nav = l_flg_nav  ).
*
*        ELSE.
*
*          handle_wb_click(
*           EXPORTING
*             i_line_no = l_line_no
*             i_pos     = l_pos
*           IMPORTING
*             e_flg_nav = l_flg_nav ).
*
*
*        ENDIF.
*
*      CATCH cx_tpda_edit_ctrl.
*                                                            "#EC *
*    ENDTRY.
*    IF l_flg_nav IS INITIAL.
*      me->set_first_visible_line( i_line = l_first_line  ).
*      me->set_cursor_position( i_str_cursor = l_str_cursor ).
*      EXIT.
*    ENDIF.

  ENDMETHOD.


  METHOD delete_nodes.

    DATA lt_nodes TYPE treev_nks.
    DATA ans.

    CALL FUNCTION 'POPUP_TO_CONFIRM'
      EXPORTING
        titlebar              = 'Delete Folder/Item'
        text_question         = 'Are you sure to delete this node and all related nodes?'
        default_button        = '2'
        display_cancel_button = abap_false
        start_column          = 5
        start_row             = 10
      IMPORTING
        answer                = ans.

    CHECK ans = '1'.
    " Get node infor
    TRY .
        DATA(ls_node) = get_node_inf( iv_nodekey ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message( ).
        RETURN.
    ENDTRY.

    IF ls_node-acc_type = c_node_code.
      DELETE FROM ztb_tree_rtcode WHERE modulelo = av_module AND node_key = iv_nodekey.
    ELSEIF ls_node-isfolder IS NOT INITIAL.
      " Get related nodes
      SELECT FROM ztb_treeload FIELDS node_key
             WHERE modulelo = @av_module AND relatkey = @iv_nodekey
             INTO TABLE @DATA(lt_child_nodes).

      IF lt_child_nodes IS NOT INITIAL.
        SORT lt_child_nodes DESCENDING BY node_key.
        APPEND LINES OF lt_child_nodes TO lt_nodes.
      ENDIF.
    ELSEIF ls_node-docname IS NOT INITIAL.
      IF ar_doi_doc IS NOT BOUND.
        TRY.
            ar_doi_doc = NEW #( ).
          CATCH zcx_ul_handle_errors INTO cx_error.
            cx_error->show_message( ).
            RETURN.
        ENDTRY.
      ENDIF.
      TRY.
          ar_doi_doc->close_document( ).
          ar_doi_doc->delete_document( iv_doc_id = ls_node-docname ).
        CATCH zcx_ul_handle_errors INTO cx_error.
          cx_error->show_message( ).
          RETURN.
      ENDTRY.
    ENDIF.

    " For safety, a folder should be once deleted
    APPEND iv_nodekey TO lt_nodes.

    LOOP AT lt_nodes ASSIGNING FIELD-SYMBOL(<fs_node>).

      IF <fs_node> NE iv_nodekey AND ( <fs_node> CP 'RTCODEF*' OR <fs_node> CP 'NODE*' ).
        MESSAGE 'For safety, a folder should be once deleted!' TYPE 'I'.
        RETURN.
      ENDIF.

      DELETE FROM ztb_treeload WHERE modulelo = av_module AND node_key = <fs_node> AND object_key = av_objectkey.
      CHECK sy-subrc IS NOT INITIAL.
      MESSAGE 'Failed to delete this node!' TYPE 'E' DISPLAY LIKE 'S'.
      RETURN.

    ENDLOOP.

    ar_tree->delete_nodes( node_key_table = lt_nodes ).
    set_visible( 'CL_GUI_HTML_VIEWER'  ).
    MESSAGE 'The entry has been deleted!' TYPE 'S'.

  ENDMETHOD.


  METHOD editor_call.

    CHECK ar_html IS BOUND.

*    DATA(editor) = zcl_ul_abap_editor=>create( i_ref_container = ar_html
*                                               i_ref_wbtool    = NEW cl_cmp_wb_tool( i_name = 'EDITOR' ) ).
*    ar_editor = editor->ref_control.
*
*    set_visible( 'CL_GUI_ABAPEDIT' ).


    IF ar_editor IS NOT BOUND.
      ar_editor = NEW #( parent = ar_html ).
      ar_editor->register_event_completion( ).
      ar_editor->register_event_quick_info( ).
      ar_editor->register_event_insert_pattern( ).
      ar_editor->register_event_dblclick( ).
      ar_editor->set_registered_events( events = VALUE #( ( eventid = cl_gui_textedit=>event_f1 ) ) ).
      av_doc_open = abap_false.
    ENDIF.

    ar_editor->set_readonly_mode( ar_editor->true ).

    set_visible( 'CL_GUI_ABAPEDIT' ).

    " Event set
    ar_editor->init_completer( ).
    DATA(lo_completer) = ar_editor->get_completer( ).
    SET HANDLER lo_completer->handle_completion_request FOR ar_editor.
    SET HANDLER lo_completer->handle_insertion_request FOR ar_editor.
    SET HANDLER lo_completer->handle_quickinfo_request FOR ar_editor.
*    SET HANDLER lo_completer->get_element_info FOR ar_editor.
    SET HANDLER dblclick_in_editor FOR ar_editor.
    SET HANDLER f1_in_editor FOR ar_editor.

  ENDMETHOD.


  METHOD edit_help.

    " Get node info
    TRY .
        DATA(ls_node) = get_node_inf( get_selected_node( ) ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message( ).
        RETURN.
    ENDTRY.

    IF ls_node-docname IS NOT INITIAL.
      open_document( iv_nodekey = ls_node-node_key ).
      RETURN.
    ENDIF.

    CASE ls_node-acc_type.
      WHEN c_node_dbtable.
        DATA(lv_type) = 'TB'.
      WHEN c_node_program.
        lv_type = 'RE'.
      WHEN c_node_actvid.
        lv_type = 'HY'.
      WHEN c_node_fm.
        lv_type = 'FU'.
      WHEN OTHERS.
        MESSAGE 'This node type is not supported!' TYPE 'I'.
        RETURN.
    ENDCASE.

    CALL FUNCTION 'DOCU_CALL'
      EXPORTING
        id         = lv_type
        langu      = sy-langu
        object     = CONV doku_obj( ls_node-programname )
      EXCEPTIONS
        wrong_name = 1
        OTHERS     = 2.

    CHECK sy-subrc IS NOT INITIAL.
    cx_error->add_system_message( ).
    cx_error->show_message( ).

  ENDMETHOD.


  METHOD f1_in_editor.

    DATA : lw_cursor_line_from TYPE i,
           lw_cursor_line_to   TYPE i,
           lw_cursor_pos_from  TYPE i,
           lw_cursor_pos_to    TYPE i,
           lw_offset           TYPE i,
           lw_length           TYPE i,
           lt_query            TYPE soli_tab,
           ls_query            LIKE LINE OF lt_query,
           lw_sel              TYPE string.

* Find active query
    CALL METHOD ar_editor->get_selection_pos
      IMPORTING
        from_line = lw_cursor_line_from
        from_pos  = lw_cursor_pos_from
        to_line   = lw_cursor_line_to
        to_pos    = lw_cursor_pos_to.

* If nothing selected, no help to display
    IF lw_cursor_line_from = lw_cursor_line_to
     AND lw_cursor_pos_to = lw_cursor_pos_from.
      RETURN.
    ENDIF.

* Get content of abap edit box
    CALL METHOD ar_editor->get_text
      IMPORTING
        table  = lt_query[]
      EXCEPTIONS
        OTHERS = 1.


    READ TABLE lt_query INTO ls_query INDEX lw_cursor_line_from.

    IF lw_cursor_line_from = lw_cursor_line_to.
      lw_length = lw_cursor_pos_to - lw_cursor_pos_from.
      lw_offset = lw_cursor_pos_from - 1.
      lw_sel = ls_query+lw_offset(lw_length).
    ELSE.
      lw_offset = lw_cursor_pos_from - 1.
      lw_sel = ls_query+lw_offset.
    ENDIF.

    CALL FUNCTION 'ABAP_DOCU_START'
      EXPORTING
        word = lw_sel.

  ENDMETHOD.


  METHOD find_node_key.

    DATA: l_index TYPE sy-tabix.

    CHECK at_config IS NOT INITIAL.

    l_index = iv_index + 1.

    IF l_index < lines( at_config ).
      IF NOT iv_nodetype IS INITIAL.
        LOOP AT at_config INTO DATA(ls_config) FROM l_index.
          IF ls_config-acc_type = iv_nodetype
          AND ls_config-programname = iv_value.
            rv_index = sy-tabix.
            EXIT.
          ENDIF.
        ENDLOOP.
      ELSE.
        LOOP AT at_config INTO ls_config FROM l_index.
          FIND iv_value IN ls_config-text IGNORING CASE.
          IF sy-subrc IS INITIAL.
            rv_index = sy-tabix.
            EXIT.
          ENDIF.
        ENDLOOP.
      ENDIF.

    ELSE.

      MESSAGE 'No further hits were found'(m11) TYPE 'S'.

    ENDIF.


    IF rv_index IS INITIAL.
      MESSAGE 'The search has not produced any hits'(m10) TYPE 'S'.
    ELSE.
      CALL METHOD ar_tree->set_selected_node
        EXPORTING
          node_key = ls_config-node_key.
    ENDIF.

  ENDMETHOD.


  METHOD fiori_launcher.

    IF ar_html_control IS NOT BOUND.
      ar_html_control = NEW cl_gui_html_viewer( parent = ar_html ).
    ENDIF.
    NEW zcl_ul_fiori( )->single_sign_on( io_viewer = ar_html_control iv_function = iv_function ).
    set_visible_object( ar_html_control ).

  ENDMETHOD.


  METHOD get_nodes_by_parent.

    SELECT FROM ztb_treeload FIELDS * WHERE relatkey = @iv_parent_key AND modulelo = @av_module AND object_key = @av_objectkey
      INTO CORRESPONDING FIELDS OF TABLE @rt_nodes.


  ENDMETHOD.


  METHOD get_node_inf.

    SELECT SINGLE FROM ztb_treeload FIELDS *
           WHERE node_key = @iv_nodekey AND modulelo = @av_module AND object_key = @av_objectkey
           INTO CORRESPONDING FIELDS OF @rs_nodekey.

    IF sy-subrc NE 0.
      TRY.
          rs_nodekey = at_config[ node_key = iv_nodekey object_key = av_objectkey ].
        CATCH cx_sy_itab_line_not_found.
          cx_error->add_text( iv_message = 'Node key &1 is invalid!' iv_type = 'E' iv_variable_1 = CONV #( iv_nodekey ) ).
          RAISE EXCEPTION cx_error.
      ENDTRY.
    ENDIF.

  ENDMETHOD.


  METHOD get_selected_node.

    CHECK ar_tree IS BOUND.
    ar_tree->get_selected_node( IMPORTING node_key = rv_node_key ).

    cl_gui_cfw=>flush( ).

  ENDMETHOD.


  METHOD modify_nodes.

    " Check target is same source
    IF is_source-relatkey EQ is_target-relatkey.
      " Get nodes is affected
      SELECT FROM ztb_treeload FIELDS *
        WHERE modulelo = @av_module
        AND relatkey = @is_target-relatkey
        INTO TABLE @DATA(lt_nodes).

      SORT lt_nodes ASCENDING BY pos.
      IF is_source-pos > is_target-pos.

        DELETE lt_nodes WHERE pos >= is_source-pos OR pos <= is_target-pos.
        IF lt_nodes IS INITIAL.
          cx_error->add_text( iv_type = 'E' iv_message = 'Two nodes have a right position!' ).
          RAISE EXCEPTION cx_error.
        ENDIF.

      ELSE.

        DELETE lt_nodes WHERE pos >= is_target-pos OR pos <= is_source-pos.

      ENDIF.

      LOOP AT lt_nodes ASSIGNING FIELD-SYMBOL(<fs_node>).

        CASE sy-tabix.

          WHEN 1.
            IF is_source-pos > is_target-pos.
              DATA(ls_update) = CORRESPONDING ztb_treeload( is_source ).
              ls_update-node_key = <fs_node>-node_key.
              ls_update-pos      = <fs_node>-pos.
              APPEND ls_update TO et_result.
              DATA(ls_pending) = CORRESPONDING ztb_treeload( <fs_node> ).
            ELSE.
              ls_update = CORRESPONDING #( <fs_node> ).
              ls_update-node_key = is_source-node_key.
              ls_update-pos      = is_source-pos.
              APPEND ls_update TO et_result.
              ls_pending = CORRESPONDING ztb_treeload( <fs_node> ).
            ENDIF.
          WHEN OTHERS.
            IF is_source-pos > is_target-pos.
              ls_update = CORRESPONDING #( ls_pending ).
              ls_update-node_key = <fs_node>-node_key.
              ls_update-pos      = <fs_node>-pos.
              APPEND ls_update TO et_result.
              ls_pending = CORRESPONDING #( <fs_node> ).
            ELSE.
              ls_update = CORRESPONDING #( <fs_node> ).
              ls_update-node_key = ls_pending-node_key.
              ls_update-pos      = ls_pending-pos.
              APPEND ls_update TO et_result.
              ls_pending = CORRESPONDING #( <fs_node> ).
            ENDIF.

        ENDCASE.

      ENDLOOP.

      " Fill last row?
      IF is_source-pos > is_target-pos.

        ls_update = CORRESPONDING #( ls_pending ).
        ls_update-node_key = is_source-node_key.
        ls_update-pos      = is_source-pos.
        APPEND ls_update TO et_result.

      ELSE.

        IF ls_pending IS NOT INITIAL.
          ls_update = CORRESPONDING #( is_target ).
          ls_update-node_key = ls_pending-node_key.
          ls_update-pos      = ls_pending-pos.
          APPEND ls_update TO et_result.
        ELSE.
          ls_update = CORRESPONDING #( is_target ).
          ls_update-node_key = is_source-node_key.
          ls_update-pos      = is_source-pos.
          APPEND ls_update TO et_result.
        ENDIF.

        ls_update = CORRESPONDING #( is_source ).
        ls_update-node_key = is_target-node_key.
        ls_update-pos      = is_target-pos.
        APPEND ls_update TO et_result.

      ENDIF.

    ELSE.

      IF av_isfolder IS NOT INITIAL.
        ls_update = CORRESPONDING #( is_source ).
        ls_update-relatkey = is_target-relatkey.
        ls_update-pos      = is_target-pos + 1.
        ls_update-node_key = |Item{ ls_update-pos }|.
        APPEND ls_update TO et_result.
        ar_tree->delete_node( is_source-node_key ).
        DELETE ztb_treeload FROM is_source.
      ELSE.
        cx_error->add_text( iv_type = 'E' iv_message = 'Two nodes are not same parent nodes' ).
        RAISE EXCEPTION cx_error.
      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD navigate_to_object.

    DATA t_bdc TYPE TABLE OF bdcdata.

    CASE iv_access_type.

      WHEN c_node_program.

        IF iv_line IS INITIAL.
          SUBMIT (iv_object) VIA SELECTION-SCREEN AND RETURN.
        ELSE.
          SUBMIT tpda_editor_start AND RETURN
           WITH prgm  = iv_object
           WITH incl  = iv_object
           WITH dynp = space
           WITH line = iv_line.
        ENDIF.

      WHEN c_node_tcode.

        IF av_client IS NOT INITIAL.

          CALL FUNCTION 'MENU_EXECUTE_OBJECT' STARTING NEW TASK 'EA'
            DESTINATION av_client
            EXPORTING
              object_name           = CONV extdreport( iv_object )
              reporttype            = 'TR'
              sap_guid              = ' '
              new_window            = 'X'
            EXCEPTIONS
              communication_failure = 1
              system_failure        = 2
              OTHERS                = 3.

        ELSE.

          CALL FUNCTION 'ABAP4_CALL_TRANSACTION'
            EXPORTING
              tcode                   = CONV syst_tcode( iv_object )
            EXCEPTIONS
              call_transaction_denied = 1
              tcode_invalid           = 2
              OTHERS                  = 3.

        ENDIF.

      WHEN c_node_mview.

        CALL FUNCTION 'VIEW_MAINTENANCE_CALL'
          EXPORTING
            action                       = 'U'
            view_name                    = CONV tabname( iv_object )
          EXCEPTIONS
            client_reference             = 1
            foreign_lock                 = 2
            invalid_action               = 3
            no_clientindependent_auth    = 4
            no_database_function         = 5
            no_editor_function           = 6
            no_show_auth                 = 7
            no_tvdir_entry               = 8
            no_upd_auth                  = 9
            only_show_allowed            = 10
            system_failure               = 11
            unknown_field_in_dba_sellist = 12
            view_not_found               = 13
            maintenance_prohibited       = 14.

      WHEN c_node_dbtable.

        CALL FUNCTION 'SE16N_START'
          EXPORTING
            i_tab  = CONV se16n_tab( iv_object )
            i_hana = 'X'.

      WHEN c_node_weblink.

        cl_gui_frontend_services=>execute( EXPORTING document = CONV #( iv_object )
                                            EXCEPTIONS error_execute_failed = 1 bad_parameter = 2 cntl_error = 3
                                                     error_no_gui = 4 file_extension_unknown = 5
                                                     file_not_found = 6 not_supported_by_gui = 7
                                                     path_not_found = 8 synchronous_failed = 9 OTHERS = 10 ).

      WHEN c_node_menuid.

        DATA ls_mess TYPE hier_mess.
        CALL FUNCTION 'STREE_EXTERNAL_DISPLAY'
          EXPORTING
            structure_id = CONV hier_treeg( iv_object )
          IMPORTING
            message      = ls_mess.

        CHECK ls_mess IS NOT INITIAL.
        MESSAGE ID ls_mess-msgid TYPE ls_mess-msgty NUMBER ls_mess-msgno
         WITH ls_mess-msgv1 ls_mess-msgv2 ls_mess-msgv3 ls_mess-msgv4 INTO DATA(lv_mess).
        zcx_ul_handle_errors=>raise_message( iv_msg_text = lv_mess ).

      WHEN c_node_actvid.

        CALL FUNCTION 'S_CUS_ACTIVITY_EXECUTE'
          EXPORTING
            activity                = CONV cus_act( iv_object )
            called_via_generated_ta = 'X'.

      WHEN c_node_fm.

        SELECT SINGLE FROM tfdir FIELDS pname, include
               WHERE funcname = @iv_object
               INTO ( @DATA(lv_name), @DATA(lv_num) ).

        CHECK sy-subrc EQ 0.
        DATA lv_include TYPE progname.
        CALL FUNCTION 'FUNCTION_INCLUDE_CONCATENATE'
          EXPORTING
            include_number           = lv_num
          IMPORTING
            include                  = lv_include
          CHANGING
            program                  = lv_name
          EXCEPTIONS
            not_enough_input         = 1
            no_function_pool         = 2
            delimiter_wrong_position = 3.

        IF sy-subrc IS INITIAL.
          EDITOR-CALL FOR REPORT lv_include DISPLAY-MODE.
        ENDIF.

      WHEN c_node_cl.

        CALL FUNCTION 'RS_TOOL_ACCESS'
          EXPORTING
            operation           = 'SHOW'
            object_name         = iv_object
            object_type         = 'CLAS'
          EXCEPTIONS
            not_executed        = 1
            invalid_object_type = 2.

      WHEN c_node_flp.

        NEW zcl_ul_tree_display( )->fiori_launcher( iv_function = CONV #( iv_object ) ).

      WHEN c_node_dycf.

        zcl_ul_dynamic_configuration=>call_configuration( configuration_group = CONV #( iv_object ) ).

      WHEN c_node_role.

        t_bdc = VALUE #( ( dynbegin = abap_true dynpro = '0121' program = 'SAPLPRGN_TREE' )
                        ( fnam = 'AGR_NAME_NEU' fval = iv_object )
                        ( fnam = 'BDC_OKCODE' fval = 'ANZE' ) ).

        CALL TRANSACTION 'PFCG' USING t_bdc MODE 'E'.

      WHEN c_node_kbn.

        SET PARAMETER ID 'ZREQID' FIELD iv_object.
        CALL TRANSACTION 'ZKBN' AND SKIP FIRST SCREEN.

    ENDCASE.

    IF sy-subrc IS NOT INITIAL.
      zcx_ul_handle_errors=>raise_message( ).
    ENDIF.

  ENDMETHOD.


  METHOD on_node_keypress.

    " Get node inf
    CHECK key = cl_gui_list_tree=>key_enter.

    TRY.
        DATA(ls_node) = get_node_inf( iv_nodekey = node_key ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message( ).
        RETURN.
    ENDTRY.

    CASE ls_node-acc_type.

      WHEN  c_node_program.
        write_html_prog( iv_prog = ls_node-programname ).
      WHEN  c_node_tcode.
        SELECT SINGLE FROM tstc FIELDS pgmna
               WHERE tcode = @ls_node-programname
               INTO  @DATA(lv_prog).
        write_html_prog( iv_prog = CONV #( lv_prog ) ).
      WHEN  c_node_dbtable.
        write_html_table( iv_tabname = ls_node-programname ).
      WHEN  c_node_actvid.
        write_html_act( iv_obj = ls_node-programname iv_objtype = 'HY' ).
      WHEN  c_node_cl.
        write_html_act( iv_obj = ls_node-programname iv_objtype = 'CL' ).
      WHEN  c_node_fm.
        write_html_act( iv_obj = ls_node-programname iv_objtype = 'FU' ).

    ENDCASE.

  ENDMETHOD.


  METHOD on_node_menu_request.

    DATA lv_client_state TYPE cccategory.

    TRY.
        IF sy-tcode NE 'START_REPORT' AND sy-uname NOT IN zcl_ul_abap=>get_stvarv_val( 'ZTABM_SUPERUSER' ).
          CALL FUNCTION 'VIEW_GET_CLIENT_STATE'
            IMPORTING
              client_state = lv_client_state.
          CHECK lv_client_state = 'C'.
        ENDIF.
      CATCH zcx_ul_handle_errors INTO DATA(cx_error).
        cx_error->show_message(  ). RETURN.
    ENDTRY.

    TRY .
        DATA(ls_node) = get_node_inf( get_selected_node( ) ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message( ).
        RETURN.
    ENDTRY.

    IF ls_node-isfolder IS NOT INITIAL.
      menu->add_function( text = 'Create Folder'      fcode = 'CNODE' ).
      menu->add_function( text = 'Change Folder'      fcode = 'XNODE' ).
      menu->add_function( text = 'Delete Folder'      fcode = 'DEL'   ).
      menu->add_function( text = 'Transport Folder'   fcode = 'TRFOL'   ).
      menu->add_function( text = 'Create Item'        fcode = 'CITEM' ).
      menu->add_function( text = 'Create Document'    fcode = 'CDOC'  ).
    ELSEIF ls_node-acc_type EQ c_node_doc.
      menu->add_function( text = 'Change Title'       fcode = 'XITEM' ).
      menu->add_function( text = 'Download Document'   fcode = 'DOWN'  ).
      menu->add_function( text = 'Transport Document' fcode = 'TRDOC' ).
      menu->add_function( text = 'Delete Document'    fcode = 'DEL'   ).
    ELSEIF ls_node-acc_type EQ c_node_code.
      menu->add_function( text = 'Change Name'        fcode = 'XITEM' ).
      menu->add_function( text = 'Delete RT Code'     fcode = 'DEL'   ).
    ELSE.
      menu->add_function( text = 'Change Item'        fcode = 'XITEM' ).
      menu->add_function( text = 'Delete Item'        fcode = 'DEL'   ).
      menu->add_function( text = 'Documentation'      fcode = 'DOCU'  ).
      menu->add_function( text = 'Assign Document'    fcode = 'CDOC'  ).
      menu->add_function( text = 'Dowload Document'   fcode = 'DOWN'  ).
    ENDIF.


    " For special case, need be authorized
    IF ls_node-modulelo = 'DOCMANAGER'.

      " Hide certain function
      DATA(lt_exclude_funcs) = VALUE ui_functions( ( 'CITEM' ) ).
      menu->hide_functions( fcodes = lt_exclude_funcs ).

      IF 1 = 2.
        SELECT SINGLE FROM usr02 FIELDS @abap_true WHERE bname = @sy-uname AND class = 'IT_SAP' INTO @DATA(lv_ath).
        CHECK lv_ath IS INITIAL.
        lt_exclude_funcs = VALUE #( BASE lt_exclude_funcs ( 'CDOC' ) ( 'XNODE' ) ( 'CNODE' ) ( 'DEL' ) ).
        menu->hide_functions( fcodes = lt_exclude_funcs ).
      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD on_node_menu_select.

    TRY .
        DATA(ls_node) = get_node_inf( get_selected_node( ) ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message( ).
        RETURN.
    ENDTRY.

    CASE fcode.

      WHEN 'DEL'.

        delete_nodes( node_key ).

      WHEN 'CDOC'.

        CALL FUNCTION 'ZFM_INS_DOI_CREATE'
          EXPORTING
            io_tree     = me
          IMPORTING
            eo_document = ar_doi_doc.

      WHEN 'DOWN'.

        IF ar_doi_doc IS NOT BOUND.
          TRY.
              ar_doi_doc = NEW #( ).
            CATCH zcx_ul_handle_errors INTO cx_error.
              cx_error->show_message( ).
              RETURN.
          ENDTRY.
        ENDIF.

        TRY.
            ar_doi_doc->download_document( iv_doc_id = ls_node-docname iv_treename = CONV #( ls_node-text ) ).
          CATCH zcx_ul_handle_errors INTO cx_error.
            cx_error->show_message( ).
        ENDTRY.

      WHEN 'TRDOC'.

        IF ar_doi_doc IS NOT BOUND.
          TRY.
              ar_doi_doc = NEW #( ).
            CATCH zcx_ul_handle_errors INTO cx_error.
              cx_error->show_message( ).
              RETURN.
          ENDTRY.
        ENDIF.

        ar_doi_doc->transport_document( iv_doc_id = ls_node-docname iv_obj_key = ls_node-object_key ).

      WHEN 'DOCU'.

        on_node_keypress( EXPORTING key = cl_gui_list_tree=>key_enter node_key = ls_node-node_key  ).

      WHEN 'TRFOL'.

        transport_folder( ).

      WHEN OTHERS.

        CALL FUNCTION 'ZFM_INS_TREE_CONTEXT_MN'
          EXPORTING
            iv_node_key = node_key
            iv_fcode    = fcode
            iv_menu     = av_module
            io_tree     = me.

    ENDCASE.


  ENDMETHOD.


  METHOD on_user_db_click.

    " check event occur
    cl_gui_cfw=>dispatch( IMPORTING return_code = DATA(lv_return_code) ).
    IF lv_return_code <> cl_gui_cfw=>rc_noevent.
      CLEAR sy-ucomm.
    ENDIF.

    " Load node key information
    TRY.
        DATA(ls_node) = get_node_inf( node_key ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message( ).
        RETURN.
    ENDTRY.

    " Navigate to a relevant object
    CHECK ls_node-acc_type IS NOT INITIAL.

    CASE ls_node-acc_type.

      WHEN c_node_program.

        SUBMIT (ls_node-programname) VIA SELECTION-SCREEN AND RETURN.

      WHEN c_node_tcode.

        IF av_client IS NOT INITIAL.

          CALL FUNCTION 'MENU_EXECUTE_OBJECT' STARTING NEW TASK 'EA'
            DESTINATION av_client
            EXPORTING
              object_name           = CONV extdreport( ls_node-programname )
              reporttype            = 'TR'
              sap_guid              = ' '
              new_window            = 'X'
            EXCEPTIONS
              communication_failure = 1
              system_failure        = 2
              OTHERS                = 3.

        ELSE.

          CALL FUNCTION 'ABAP4_CALL_TRANSACTION'
            EXPORTING
              tcode                   = CONV syst_tcode( ls_node-programname )
            EXCEPTIONS
              call_transaction_denied = 1
              tcode_invalid           = 2
              OTHERS                  = 3.

        ENDIF.

        IF sy-subrc IS NOT INITIAL.
          cx_error->add_system_message( ).
        ENDIF.

      WHEN c_node_mview.

        CALL FUNCTION 'VIEW_MAINTENANCE_CALL'
          EXPORTING
            action                       = 'U'
            view_name                    = CONV tabname( ls_node-programname )
          EXCEPTIONS
            client_reference             = 1
            foreign_lock                 = 2
            invalid_action               = 3
            no_clientindependent_auth    = 4
            no_database_function         = 5
            no_editor_function           = 6
            no_show_auth                 = 7
            no_tvdir_entry               = 8
            no_upd_auth                  = 9
            only_show_allowed            = 10
            system_failure               = 11
            unknown_field_in_dba_sellist = 12
            view_not_found               = 13
            maintenance_prohibited       = 14.

        IF sy-subrc IS NOT INITIAL.
          cx_error->add_system_message( ).
        ENDIF.

      WHEN c_node_dbtable.

        CALL FUNCTION 'SE16N_START'
          EXPORTING
            i_tab  = CONV se16n_tab( ls_node-programname )
            i_hana = 'X'.

        IF sy-subrc IS NOT INITIAL.
          cx_error->add_system_message( ).
        ENDIF.

      WHEN c_node_weblink.

        IF ar_html IS NOT BOUND OR sy-tcode = 'ZDOC'.
          cl_gui_frontend_services=>execute( EXPORTING document = CONV #( ls_node-programname )
                                             EXCEPTIONS error_execute_failed = 1 bad_parameter = 2 cntl_error = 3
                                                      error_no_gui = 4 file_extension_unknown = 5
                                                      file_not_found = 6 not_supported_by_gui = 7
                                                      path_not_found = 8 synchronous_failed = 9 OTHERS = 10 ).
          CHECK sy-subrc IS NOT INITIAL.
          zcx_ul_handle_errors=>raise_message( ).
        ELSE.
          web_browser( iv_url = ls_node-programname ).
        ENDIF.

      WHEN c_node_menuid.

        DATA ls_mess TYPE hier_mess.
        CALL FUNCTION 'STREE_EXTERNAL_DISPLAY'
          EXPORTING
            structure_id = CONV hier_treeg( ls_node-programname )
          IMPORTING
            message      = ls_mess.

        CHECK ls_mess IS NOT INITIAL.
        MESSAGE ID ls_mess-msgid TYPE ls_mess-msgty NUMBER ls_mess-msgno
         WITH ls_mess-msgv1 ls_mess-msgv2 ls_mess-msgv3 ls_mess-msgv4 INTO DATA(lv_mess).
        cx_error->add_text( iv_message = CONV #( lv_mess ) ).

      WHEN c_node_actvid.

        CALL FUNCTION 'S_CUS_ACTIVITY_EXECUTE'
          EXPORTING
            activity                = CONV cus_act( ls_node-programname )
            called_via_generated_ta = 'X'.

      WHEN c_node_fm.

        SELECT SINGLE FROM tfdir FIELDS pname, include
               WHERE funcname = @ls_node-programname
               INTO ( @DATA(lv_name), @DATA(lv_num) ).

        CHECK sy-subrc EQ 0.
        DATA lv_include TYPE progname.
        CALL FUNCTION 'FUNCTION_INCLUDE_CONCATENATE'
          EXPORTING
            include_number           = lv_num
          IMPORTING
            include                  = lv_include
          CHANGING
            program                  = lv_name
          EXCEPTIONS
            not_enough_input         = 1
            no_function_pool         = 2
            delimiter_wrong_position = 3.

        IF sy-subrc IS NOT INITIAL.
          cx_error->add_system_message( ).
        ELSE.
          EDITOR-CALL FOR REPORT lv_include DISPLAY-MODE.
        ENDIF.

      WHEN c_node_cl.

        CALL FUNCTION 'RS_TOOL_ACCESS'
          EXPORTING
            operation           = 'SHOW'
            object_name         = ls_node-programname
            object_type         = 'CLAS'
          EXCEPTIONS
            not_executed        = 1
            invalid_object_type = 2.

        IF sy-subrc IS NOT INITIAL.
          cx_error->add_system_message( ).
        ENDIF.

      WHEN c_node_code.

        DATA: lt_code TYPE soli_tab.

        SELECT SINGLE FROM ztb_tree_rtcode
          FIELDS rt_code
          WHERE modulelo = @av_module
          AND   node_key = @ls_node-node_key
          INTO @DATA(lv_code).

        CHECK sy-subrc IS INITIAL.
        SPLIT lv_code AT cl_abap_char_utilities=>cr_lf
                      INTO TABLE lt_code.

        DATA(lt_query) = VALUE soli_tab(  ( line = |***************************************************************************************| )
                                          ( line = |* Welcome to Online-Dev Tool| )
                                          ( line = |* This tool helps you try-out a piece of code for online results! | )
                                          ( line = |* Tool also have a built-in function support for building a only query with ABAP,| )
                                          ( line = |* Just define any kind of table with name 'RESULTS' for output and see a magic!!!| )
                                          ( line = |***************************************************************************************| ) ).

        APPEND LINES OF lt_code TO lt_query.

        editor_call( ).
        ar_editor->set_text( table = lt_query ).

      WHEN c_node_doc.

        open_document( ls_node-node_key ).

      WHEN c_node_flp.

        fiori_launcher( iv_function = CONV #( ls_node-programname ) ).

      WHEN c_node_dycf.

        zcl_ul_dynamic_configuration=>call_configuration( configuration_group = CONV #( ls_node-programname ) ).

      WHEN c_node_txt.

        SELECT SINGLE FROM ztb_tree_rtcode
          FIELDS rt_code
          WHERE modulelo = @av_module
          AND   node_key = @ls_node-node_key
          INTO @lv_code.

          textedit_call( ).
          ar_textedit->set_textstream( lv_code ).

    ENDCASE.

    CHECK cx_error->has_messages( ) = abap_true.
    cx_error->show_message( ).

  ENDMETHOD.


  METHOD on_user_drag.

    DATA(drag_object) = NEW lcl_dragdropobject( ).
    av_drag_obj = node_key.
    drag_object->src_node_key = node_key.
    drag_drop_object->object = drag_object.

    " Check whether node_key is folder
    TRY.
        CHECK get_node_inf( iv_nodekey = node_key )-isfolder IS NOT INITIAL.
        cx_error->add_text( iv_type = 'E' iv_message = 'Node &1 is not permitted!' iv_variable_1 = CONV #( node_key ) ).
        CLEAR av_drag_obj.
      CATCH zcx_ul_handle_errors INTO DATA(cx_err).
        cx_error->add_exception_object( cx_err ).
    ENDTRY.

    cx_error->show_message( ).

  ENDMETHOD.


  METHOD on_user_drop.

    DATA(drop_object) = NEW lcl_dragdropobject( ).
    av_drop_obj = node_key.
    drop_object->src_node_key = node_key.
    drag_drop_object->object = drop_object.
    av_drop_obj = node_key.

    " Check whether node_key is folder
    CLEAR av_isfolder.
    TRY.
        IF get_node_inf( iv_nodekey = node_key )-isfolder IS NOT INITIAL.
          DATA(lt_nodes) = get_nodes_by_parent( node_key ).
          IF lt_nodes IS NOT INITIAL.
            SORT lt_nodes DESCENDING BY pos.
            CLEAR av_drop_obj.
            CHECK zcl_ul_abap=>popup_to_confirm( 'The entry will be added to this folder?' ) = '1'.
            av_drop_obj = lt_nodes[ 1 ]-node_key.
            av_isfolder = abap_true.
          ENDIF.
        ENDIF.
      CATCH zcx_ul_handle_errors.
    ENDTRY.

  ENDMETHOD.


  METHOD on_user_drop_complete.

    TRY.

        DATA(dataobj) = NEW lcl_dragdropobject( ).
        dataobj ?= drag_drop_object->object.

        CHECK av_drag_obj IS NOT INITIAL.
        DATA(source_node) = get_node_inf( iv_nodekey = av_drag_obj ).
        CHECK av_drop_obj IS NOT INITIAL.
        DATA(target_node) = get_node_inf( iv_nodekey = av_drop_obj ).

        modify_nodes( EXPORTING is_source = source_node
                                is_target = target_node
                      IMPORTING et_result = DATA(lt_update) ).

      CATCH zcx_ul_handle_errors INTO DATA(cx_err).
        cx_error->show_message( ).
        RETURN.

    ENDTRY.

    CHECK lt_update IS NOT INITIAL.
    IF av_isfolder IS INITIAL.
      " Update tree
      update_nodes( lt_update ).
      " Set selected node
      ar_tree->set_selected_node( node_key = source_node-node_key ).
    ELSE.
      " Add tree
      add_nodes( lt_update ).
      " Set selected node
      ar_tree->set_selected_node( node_key = lt_update[ 1 ]-node_key ).
    ENDIF.

  ENDMETHOD.


  METHOD open_document.

    av_doc_open = abap_true.
    IF ar_doi_doc IS NOT BOUND.
      TRY.
          ar_doi_doc = NEW zcl_ul_doi_usage( io_container = ar_html ).
        CATCH zcx_ul_handle_errors INTO cx_error.
          cx_error->show_message( ).
          RETURN.
      ENDTRY.
    ENDIF.

    SELECT SINGLE FROM ztb_treeload FIELDS docname WHERE node_key = @iv_nodekey AND modulelo = @av_module INTO @DATA(lv_doc_id).
    ar_doi_doc->open_document( iv_doc_id       = lv_doc_id
                               io_tree_display = me ).


  ENDMETHOD.


  METHOD set_bds_image.

    DATA: signatures     TYPE TABLE OF bapisignat,
          random_number  TYPE i,
          random_desktop TYPE sdydo_key.

    CHECK ar_html IS BOUND.
    LOOP AT ar_html->children ASSIGNING FIELD-SYMBOL(<children>).
      <children>->free( ).
    ENDLOOP.

    IF iv_image_id IS INITIAL.
      CALL FUNCTION 'QF05_RANDOM_INTEGER'
        EXPORTING
          ran_int_max = 7
          ran_int_min = 1
        IMPORTING
          ran_int     = random_number.
      random_desktop = |DESKTOP_{ random_number }|.
    ELSE.
      random_desktop = iv_image_id.
    ENDIF.

    DATA(dd) = NEW zcl_ul_dd_document( iv_no_dialog = abap_true ).
    dd->document->initialize_document( no_margins = abap_true ).
    dd->document->add_picture( picture_id = random_desktop width = '105%' alternative_text = CONV #( random_desktop ) ).
    dd->show( io_container = ar_html ).
    set_visible( 'CL_GUI_HTML_VIEWER' ).

  ENDMETHOD.


  METHOD set_default_text.

    DATA lv_u_value TYPE ztb_treeload-text.

    IF iv_acc_type <> c_node_weblink AND cv_value IS NOT INITIAL.
      cv_value = to_upper( cv_value ).
    ENDIF.

    CASE iv_acc_type.

      WHEN c_node_program.

        ev_symbol = c_symbol_prog.

        CHECK cv_value IS NOT INITIAL.
        SELECT SINGLE FROM trdirt FIELDS text
               WHERE name  = @cv_value
               AND   sprsl = @sy-langu
               INTO @rv_text.


      WHEN c_node_tcode.

        ev_symbol = c_symbol_tcode.

        CHECK cv_value IS NOT INITIAL.
        SELECT SINGLE FROM tstct FIELDS ttext
               WHERE tcode = @cv_value
               AND   sprsl = @sy-langu
               INTO @rv_text.

      WHEN c_node_mview.

        DATA ls_dd25d TYPE dd25v.

        ev_symbol = c_symbol_mv.

        CHECK cv_value IS NOT INITIAL.
        CALL FUNCTION 'DDIF_VIEW_GET'
          EXPORTING
            name          = CONV ddobjname( cv_value )
            langu         = sy-langu
          IMPORTING
            dd25v_wa      = ls_dd25d
          EXCEPTIONS
            illegal_input = 1
            OTHERS        = 2.
        IF sy-subrc <> 0.
          MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                 WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
        ELSE.
          MOVE ls_dd25d-ddtext TO rv_text.
        ENDIF.

      WHEN c_node_dbtable.

        ev_symbol = c_symbol_table.

        CHECK cv_value IS NOT INITIAL.
        SELECT SINGLE FROM dd02t FIELDS ddtext
               WHERE tabname = @cv_value
               AND   ddlanguage = @sy-langu
               AND   as4local   = 'A'
               AND   as4vers    = '0000'
               INTO  @rv_text.

      WHEN c_node_weblink.

        ev_symbol = c_symbol_wl.

      WHEN c_node_menuid.

        ev_symbol = c_symbol_mnid.

        CHECK cv_value IS NOT INITIAL.
        SELECT SINGLE FROM ttreet FIELDS text
               WHERE id = @cv_value
               AND   spras = @sy-langu
               INTO @rv_text.

      WHEN c_node_actvid.

        ev_symbol = c_symbol_img.

        CHECK cv_value IS NOT INITIAL.
        SELECT SINGLE FROM cus_actt FIELDS text
               WHERE act_id = @cv_value
               INTO @rv_text.


      WHEN c_node_fm.

        ev_symbol = c_symbol_fm.

        CHECK cv_value IS NOT INITIAL.
        SELECT SINGLE FROM tftit FIELDS stext
               WHERE funcname = @cv_value
               INTO @rv_text.

      WHEN c_node_cl.

        ev_symbol = c_symbol_cls.

        CHECK cv_value IS NOT INITIAL.
        SELECT SINGLE FROM seoclasstx FIELDS descript
               WHERE clsname = @cv_value
               AND   langu   = @sy-langu
               INTO @rv_text.

      WHEN c_node_flp.

        ev_symbol = c_symbol_flp.

      WHEN c_node_dycf.

        ev_symbol = c_symbol_dycf.
        CHECK cv_value IS NOT INITIAL.
        DATA t_config_groups TYPE TABLE OF zcl_ul_dynamic_configuration=>ty_configuration_group.
        zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'CONFIG_GRP' IMPORTING e_data = t_config_groups ).
        TRY .
            rv_text = t_config_groups[ configuration_group = cv_value ]-configuration_group_txt.
          CATCH cx_sy_itab_line_not_found.
            zcx_ul_handle_errors=>raise_message( iv_msg_text = |Configuration group { cv_value } does not exist!| ).
        ENDTRY.

      WHEN c_node_role.

        ev_symbol = icon_role.
        SELECT SINGLE FROM agr_texts FIELDS text WHERE agr_name = @cv_value AND spras = @sy-langu INTO @rv_text.

      WHEN c_node_kbn.

        ev_symbol = icon_transfer.
        SELECT SINGLE FROM ztb_kb_notes FIELDS descript WHERE noteid = @cv_value INTO @rv_text.

    ENDCASE.

  ENDMETHOD.


  METHOD set_image.

    DATA lv_url TYPE cndp_url.

    CHECK ar_html IS NOT INITIAL.
    ar_pic  = NEW #( parent = ar_html ).

    " Get image url
    CALL FUNCTION 'DP_PUBLISH_WWW_URL'
      EXPORTING
        objid    = iv_obj
        lifetime = cndp_lifetime_transaction
      IMPORTING
        url      = lv_url
      EXCEPTIONS
        OTHERS   = 1.

    CHECK sy-subrc IS INITIAL.
    ar_pic->load_picture_from_url_async( url = lv_url ).
    ar_pic->set_display_mode( display_mode = cl_gui_picture=>display_mode_stretch ).
    set_visible( 'CL_GUI_PICTURE' ).

  ENDMETHOD.


  METHOD set_node_tech.


    " Reload config
    SELECT FROM ztb_treeload FIELDS *
      WHERE modulelo = @av_module AND acc_type NE ' ' AND acc_type NE @c_node_weblink
       AND  acc_type NE @c_node_menuid AND acc_type NE @c_node_actvid
      INTO TABLE @DATA(lt_config).

    IF iv_active = abap_true.
      LOOP AT lt_config ASSIGNING FIELD-SYMBOL(<fs_config>).
        <fs_config>-text = |{ <fs_config>-programname }-{ <fs_config>-text }|.
        <fs_config>-length = strlen( <fs_config>-text ) + 5.
      ENDLOOP.
    ENDIF.

    update_nodes( it_update_nodes = lt_config iv_save = abap_false ).

  ENDMETHOD.


  METHOD set_visible.

    CHECK ar_html IS BOUND.
    LOOP AT ar_html->children ASSIGNING FIELD-SYMBOL(<fs_chid>).
      DATA(lv_class_name) = cl_abap_classdescr=>get_class_name( <fs_chid> ).
      IF lv_class_name+7 = iv_class_name.
        <fs_chid>->set_visible( abap_true ).
      ELSE.
        <fs_chid>->set_visible( abap_false ).
      ENDIF.
    ENDLOOP.

  ENDMETHOD.


  METHOD set_visible_object.

    IF ar_html IS BOUND.
      LOOP AT ar_html->children ASSIGNING FIELD-SYMBOL(<fs_child>).
        IF <fs_child> = io_object.
          <fs_child>->set_visible( abap_true ).
        ELSE.
          <fs_child>->set_visible( abap_false ).
        ENDIF.
      ENDLOOP.
    ELSEIF io_object IS BOUND.
      CALL METHOD io_object->('SET_VISIBLE') EXPORTING visible = abap_true.
    ENDIF.

  ENDMETHOD.


  METHOD TEXTEDIT_CALL.

    CHECK ar_html IS BOUND.

    IF ar_textedit IS NOT BOUND.
      ar_textedit = NEW #( parent = ar_html lifetime = cl_gui_container=>lifetime_dynpro ).
    ENDIF.

    set_visible_object( ar_textedit ).

  ENDMETHOD.


  METHOD transport_folder.

    DATA lt_e071  TYPE tr_objects.
    DATA lt_e071k TYPE tr_keys.
    DATA lt_commfile_entries TYPE TABLE OF bapicomfil.
    DATA lt_doc_components TYPE sbdst_components.
    DATA lt_doc_signatures TYPE sbdst_signature.
    DATA request_type TYPE c LENGTH 2.
    DATA cross_client TYPE ccnocliind.

    TRY.
        DATA(s_folder) = get_node_inf( get_selected_node( ) ).
        DATA(lo_document) = NEW zcl_ul_doi_usage( ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message(  ). RETURN.
    ENDTRY.

    DATA(lv_tab_key) = zcl_ul_abap=>build_key( iv_add_client = abap_true is_data = s_folder ).
    DATA(ls_e071) = VALUE e071( pgmid = 'R3TR' object = 'TABU' obj_name = 'ZTB_TREELOAD' objfunc = 'K' ).
    APPEND ls_e071 TO lt_e071.
    lt_e071k = VALUE #( BASE lt_e071k ( mastertype = ls_e071-object mastername = ls_e071-obj_name pgmid = 'R3TR' object = 'TABU' objname = 'ZTB_TREELOAD' tabkey = lv_tab_key ) ).

    SELECT SINGLE FROM ztb_tree_rtcode FIELDS * WHERE modulelo = @s_folder-modulelo AND node_key = @s_folder-node_key INTO @DATA(ls_tree_code).
    IF sy-subrc IS INITIAL.
      lv_tab_key = zcl_ul_abap=>build_key( iv_add_client = abap_true is_data = ls_tree_code ).
      ls_e071 = VALUE #( pgmid = 'R3TR' object = 'TABU' obj_name = 'ZTB_TREE_RTCODE' objfunc = 'K' ).
      APPEND ls_e071 TO lt_e071.
      lt_e071k = VALUE #( BASE lt_e071k ( mastertype = ls_e071-object mastername = ls_e071-obj_name pgmid = 'R3TR' object = 'TABU' objname = 'ZTB_TREE_RTCODE' tabkey = lv_tab_key ) ).
    ENDIF.

    SELECT FROM ztb_treeload FIELDS * WHERE modulelo = @av_module AND relatkey = @s_folder-node_key INTO TABLE @DATA(lt_tree_data).

    LOOP AT lt_tree_data REFERENCE INTO DATA(lr_tree_data).

      lv_tab_key = zcl_ul_abap=>build_key( iv_add_client = abap_true is_data = lr_tree_data->* ).
      ls_e071 = VALUE e071( pgmid = 'R3TR' object = 'TABU' obj_name = 'ZTB_TREELOAD' objfunc = 'K' ).
      lt_e071k = VALUE #( BASE lt_e071k ( mastertype = ls_e071-object mastername = ls_e071-obj_name pgmid = 'R3TR' object = 'TABU' objname = 'ZTB_TREELOAD' tabkey = lv_tab_key ) ).

      IF lr_tree_data->docname IS NOT INITIAL.
        REFRESH: lt_doc_signatures, lt_doc_components.
        CALL FUNCTION 'BDS_BUSINESSDOCUMENT_GET_INFO'
          EXPORTING
            classname       = 'SOFFICEINTEGRATION'
            classtype       = 'OT'
            object_key      = 'DOI'
            all             = 'X'
          TABLES
            components      = lt_doc_components
            signature       = lt_doc_signatures
          EXCEPTIONS
            nothing_found   = 1
            parameter_error = 2
            not_allowed     = 3
            error_kpro      = 4
            internal_error  = 5
            not_authorized  = 6
            OTHERS          = 7.

        CHECK sy-subrc IS INITIAL.
        DELETE lt_doc_signatures WHERE doc_id NE lr_tree_data->docname.
        DATA(lv_doc_count) = lt_doc_signatures[ 1 ]-doc_count.
        DELETE lt_doc_components WHERE doc_count NE lv_doc_count.

        CALL FUNCTION 'BDS_BUSINESSDOCUMENT_GET_TP'
          EXPORTING
            classname        = 'SOFFICEINTEGRATION'
            classtype        = 'OT'
            client           = sy-mandt
            object_key       = 'DOI'
          TABLES
            signature        = lt_doc_signatures
            commfile_entries = lt_commfile_entries
          EXCEPTIONS
            nothing_found    = 1
            error_kpro       = 2
            internal_error   = 3
            not_authorized   = 4
            parameter_error  = 5
            not_allowed      = 6
            OTHERS           = 7.

        CHECK sy-subrc IS INITIAL.
        DATA(lt_e071_file) = CORRESPONDING tr_objects( lt_commfile_entries ).
        APPEND LINES OF lt_e071_file TO lt_e071.
      ENDIF.

      SELECT SINGLE FROM ztb_tree_rtcode FIELDS * WHERE modulelo = @lr_tree_data->modulelo AND node_key = @lr_tree_data->node_key INTO @ls_tree_code.
      IF sy-subrc IS INITIAL.
        lv_tab_key = zcl_ul_abap=>build_key( iv_add_client = abap_true is_data = ls_tree_code ).
        ls_e071 = VALUE #( pgmid = 'R3TR' object = 'TABU' obj_name = 'ZTB_TREE_RTCODE' objfunc = 'K' ).
        IF line_exists( lt_e071[ obj_name = 'ZTB_TREE_RTCODE' ] ).
        ELSE.
          APPEND ls_e071 TO lt_e071.
        ENDIF.
        lt_e071k = VALUE #( BASE lt_e071k ( mastertype = ls_e071-object mastername = ls_e071-obj_name pgmid = 'R3TR' object = 'TABU' objname = 'ZTB_TREE_RTCODE' tabkey = lv_tab_key ) ).
        CLEAR ls_tree_code.
      ENDIF.

    ENDLOOP.

    CALL FUNCTION 'TR_SYS_PARAMS'
      IMPORTING
        sys_cliinddep_edit = cross_client.
    request_type = SWITCH #( cross_client WHEN '' THEN 'K' WHEN '2' THEN 'W' ELSE 'KW' ).

    CALL FUNCTION 'TR_REQUEST_CHOICE'
      EXPORTING
        iv_request_types     = request_type
        it_e071              = lt_e071
        it_e071k             = lt_e071k
        iv_title             = 'Transport menu'
      EXCEPTIONS
        invalid_request      = 1
        invalid_request_type = 2
        user_not_owner       = 3
        no_objects_appended  = 4
        enqueue_error        = 5
        cancelled_by_user    = 6
        recursive_call       = 7
        OTHERS               = 8.

    IF sy-subrc <> 0.
      zcx_ul_handle_errors=>raise_message( ).
    ELSE.
      MESSAGE 'Create transport objects sucessfully!' TYPE 'S'.
    ENDIF.

  ENDMETHOD.


  METHOD transport_menu.

    DATA lt_e071  TYPE tr_objects.
    DATA lt_e071k TYPE tr_keys.
    DATA lt_commfile_entries TYPE TABLE OF bapicomfil.
    DATA lt_doc_components TYPE sbdst_components.
    DATA lt_doc_signatures TYPE sbdst_signature.
    DATA request_type TYPE c LENGTH 2.
    DATA cross_client TYPE ccnocliind.

    SELECT FROM ztb_treeload FIELDS * WHERE modulelo = @av_module INTO TABLE @DATA(lt_tree_data).
    TRY.
        DATA(lo_document) = NEW zcl_ul_doi_usage( ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message(  ). RETURN.
    ENDTRY.

    LOOP AT lt_tree_data REFERENCE INTO DATA(lr_tree_data).

      DATA(lv_tab_key) = zcl_ul_abap=>build_key( iv_add_client = abap_true is_data = lr_tree_data->* ).
      DATA(ls_e071) = VALUE e071( pgmid = 'R3TR' object = 'TABU' obj_name = 'ZTB_TREELOAD' objfunc = 'K' ).
      IF lt_e071 IS INITIAL.
        APPEND ls_e071 TO lt_e071.
      ENDIF.
      lt_e071k = VALUE #( BASE lt_e071k ( mastertype = ls_e071-object mastername = ls_e071-obj_name pgmid = 'R3TR' object = 'TABU' objname = 'ZTB_TREELOAD' tabkey = lv_tab_key ) ).

      IF lr_tree_data->docname IS NOT INITIAL.
        REFRESH: lt_doc_signatures, lt_doc_components.
        CALL FUNCTION 'BDS_BUSINESSDOCUMENT_GET_INFO'
          EXPORTING
            classname       = 'SOFFICEINTEGRATION'
            classtype       = 'OT'
            object_key      = 'DOI'
            all             = 'X'
          TABLES
            components      = lt_doc_components
            signature       = lt_doc_signatures
          EXCEPTIONS
            nothing_found   = 1
            parameter_error = 2
            not_allowed     = 3
            error_kpro      = 4
            internal_error  = 5
            not_authorized  = 6
            OTHERS          = 7.

        CHECK sy-subrc IS INITIAL.
        DELETE lt_doc_signatures WHERE doc_id NE lr_tree_data->docname.
        DATA(lv_doc_count) = lt_doc_signatures[ 1 ]-doc_count.
        DELETE lt_doc_components WHERE doc_count NE lv_doc_count.

        CALL FUNCTION 'BDS_BUSINESSDOCUMENT_GET_TP'
          EXPORTING
            classname        = 'SOFFICEINTEGRATION'
            classtype        = 'OT'
            client           = sy-mandt
            object_key       = 'DOI'
          TABLES
            signature        = lt_doc_signatures
            commfile_entries = lt_commfile_entries
          EXCEPTIONS
            nothing_found    = 1
            error_kpro       = 2
            internal_error   = 3
            not_authorized   = 4
            parameter_error  = 5
            not_allowed      = 6
            OTHERS           = 7.

        CHECK sy-subrc IS INITIAL.
        DATA(lt_e071_file) = CORRESPONDING tr_objects( lt_commfile_entries ).
        APPEND LINES OF lt_e071_file TO lt_e071.
      ENDIF.

      SELECT SINGLE FROM ztb_tree_rtcode FIELDS * WHERE modulelo = @lr_tree_data->modulelo AND node_key = @lr_tree_data->node_key INTO @DATA(ls_tree_code).
      IF ls_tree_code IS NOT INITIAL.
        lv_tab_key = zcl_ul_abap=>build_key( iv_add_client = abap_true is_data = ls_tree_code ).
        ls_e071 = VALUE #( pgmid = 'R3TR' object = 'TABU' obj_name = 'ZTB_TREE_RTCODE' objfunc = 'K' ).
        IF line_exists( lt_e071[ obj_name = 'ZTB_TREE_RTCODE' ] ).
        ELSE.
          APPEND ls_e071 TO lt_e071.
        ENDIF.
        lt_e071k = VALUE #( BASE lt_e071k ( mastertype = ls_e071-object mastername = ls_e071-obj_name pgmid = 'R3TR' object = 'TABU' objname = 'ZTB_TREE_RTCODE' tabkey = lv_tab_key ) ).
        CLEAR ls_tree_code.
      ENDIF.

    ENDLOOP.

    CALL FUNCTION 'TR_SYS_PARAMS'
      IMPORTING
        sys_cliinddep_edit = cross_client.
    request_type = SWITCH #( cross_client WHEN '' THEN 'K' WHEN '2' THEN 'W' ELSE 'KW' ).

    CALL FUNCTION 'TR_REQUEST_CHOICE'
      EXPORTING
        iv_request_types     = request_type
        it_e071              = lt_e071
        it_e071k             = lt_e071k
        iv_title             = 'Transport menu'
      EXCEPTIONS
        invalid_request      = 1
        invalid_request_type = 2
        user_not_owner       = 3
        no_objects_appended  = 4
        enqueue_error        = 5
        cancelled_by_user    = 6
        recursive_call       = 7
        OTHERS               = 8.

    IF sy-subrc <> 0.
      zcx_ul_handle_errors=>raise_message( ).
    ELSE.
      MESSAGE 'Create transport objects sucessfully!' TYPE 'S'.
    ENDIF.

  ENDMETHOD.


  METHOD tree_display.

    create_int_tree( EXPORTING it_config  = it_config
                     IMPORTING et_nodetab = at_node
                               et_item    = at_item ).

    ar_tree->add_nodes_and_items( node_table                = at_node
                                  item_table                = at_item
                                  item_table_structure_name = 'ZTB_TREELOAD' ).

    ar_tree->expand_nodes( node_key_table = at_node_key ).


    CHECK at_events IS NOT INITIAL.

    " Handle double click
    SET HANDLER on_user_db_click FOR ar_tree.

    " Handle drag drop event
    SET HANDLER on_user_drag FOR ar_tree.
    SET HANDLER on_user_drop FOR ar_tree.
    SET HANDLER on_user_drop_complete FOR ar_tree.

    " Context menu
    SET HANDLER on_node_menu_request FOR ar_tree.
    SET HANDLER on_node_menu_select  FOR ar_tree.

    " Handle key 'ENTER'
    ar_tree->add_key_stroke( key = ar_tree->key_enter ).
    SET HANDLER on_node_keypress FOR ar_tree.

  ENDMETHOD.


  METHOD update_nodes.

    DATA: lt_upitem TYPE TABLE OF bdtreevupd.

    create_int_tree( EXPORTING it_config  = it_update_nodes
                     IMPORTING et_item    = DATA(lt_item)
                               et_nodetab = DATA(lt_node) ).
    DATA(lt_upnode) = VALUE treev_upno( FOR u_node IN lt_node LET base1 = VALUE treev_unod( u_all = abap_true ) IN
                                        ( CORRESPONDING #( BASE ( base1 ) u_node ) ) ).

    lt_upitem = VALUE #( FOR u_item IN lt_item  LET base2 = VALUE bdtreevupd( u_all = abap_true ) IN
                                 ( CORRESPONDING #( BASE ( base2 ) u_item ) ) ).

    ar_tree->update_nodes_and_items( node_table = lt_upnode item_table = lt_upitem item_table_structure_name = 'ZTB_TREELOAD' ).

    IF sy-subrc IS INITIAL AND iv_save = abap_true.
      MODIFY ztb_treeload FROM TABLE it_update_nodes.
    ENDIF.

    ar_tree->set_screen_update( abap_true ).

  ENDMETHOD.


  METHOD web_browser.


    cl_abap_browser=>show_url( url          = iv_url
                               modal        = abap_false
                               size         = cl_abap_browser=>medium
                               position     = cl_abap_browser=>middle
                               format       = cl_abap_browser=>portrait
                               buttons      = cl_abap_browser=>navigate_html_after_sap_event
                               printing     = abap_false
                               dialog       = abap_false
                               title        = iv_title
                               container    = ar_html
                               context_menu = abap_true ).

    IF iv_break IS INITIAL.
      set_visible( 'CL_GUI_SPLITTER_CONTAINER' ).
    ENDIF.

  ENDMETHOD.


  METHOD where_used_list.

    " Get node info
    TRY.
        DATA(ls_node) = get_node_inf( get_selected_node( ) ).
      CATCH zcx_ul_handle_errors INTO cx_error.
        cx_error->show_message( ).
        RETURN.
    ENDTRY.

    CASE ls_node-acc_type.

      WHEN c_node_dbtable.

        SELECT SINGLE FROM dd02l FIELDS tabclass
               WHERE tabname = @ls_node-programname
               AND   as4local = 'A'
               AND   as4vers  = '0000'
               INTO @DATA(lv_tabclass).

        IF lv_tabclass = 'VIEW'.
          DATA(lv_obj_type) = 'DV'.
        ELSE.
          lv_obj_type = 'DT'.
        ENDIF.

      WHEN c_node_program.
        lv_obj_type = 'P'.
      WHEN c_node_tcode.
        lv_obj_type = 'T'.
      WHEN c_node_fm.
        lv_obj_type = 'FF'.
      WHEN c_node_cl.
        lv_obj_type = 'OC'.

    ENDCASE.

    SUBMIT wb_mngr_start_from_tool_access AND RETURN
     WITH  action   = 'WHEREUSED'
     WITH  obj_type = lv_obj_type
     WITH  obj_name = ls_node-programname
     WITH  tool     = 'CL_WB_INFOSYSTEM'.

  ENDMETHOD.


  METHOD write_html_act.

    DATA : l_object       TYPE doku_obj,
           ls_data_table  TYPE htmlline,
           lt_data_table  LIKE TABLE OF ls_data_table,
           lt_lines       TYPE TABLE OF tline,
           ls_line        TYPE tline,
           lt_lines2      TYPE TABLE OF tline,
           l_docu_to_html TYPE REF TO cl_epss_docu_to_html,
           l_url(2048),
           l_title        TYPE dsyst-doktitle,
           l_doctype      TYPE dokil-typ,
           l_langu        TYPE sy-langu,
           lt_styles      TYPE tlinetab,
           l_stylename    TYPE doku_obj.

    DATA : BEGIN OF ls_clsmeth,
             clsname  TYPE seocompo-clsname,
             cmpname  TYPE seocompo-cmpname,
             descript TYPE seocompotx-descript,
           END OF ls_clsmeth,
           lt_clsmeth LIKE TABLE OF ls_clsmeth.

    IF iv_objtype = 'HY'.
* Search Documentation
      SELECT SINGLE docu_id INTO l_object
             FROM cus_imgach
             WHERE activity = iv_obj.
      IF sy-subrc NE 0.
* If no specific documentation, try to display object documentation
        CONCATENATE 'SIMG' iv_obj INTO l_object.
      ENDIF.
    ELSE.
      l_object = iv_obj.
    ENDIF.

* Get doc
    DO 4 TIMES.
* Search in first enduser doc in connexion language
      IF sy-index = 1.
        l_langu = sy-langu.
        l_doctype = 'E'.
* If not found, search enduser doc in english
      ELSEIF sy-index = 2.
        l_langu = 'E'.
        l_doctype = 'E'.
* If not found, search technical doc in connexion language
      ELSEIF sy-index = 3.
        l_langu = 'E'.
        l_doctype = 'T'.
* If not found, search technical doc in english
      ELSEIF sy-index = 4.
        l_langu = sy-langu.
        l_doctype = 'T'.
      ELSE.
        EXIT. " exit do
      ENDIF.

      SELECT SINGLE object INTO l_object
             FROM  dokil
             WHERE id         = iv_objtype
             AND   object     = l_object
             AND   langu      = l_langu
             AND   typ        = l_doctype.
      IF sy-subrc EQ 0.
        CLEAR l_title.
        CALL FUNCTION 'DOCU_GET'
          EXPORTING
            id       = iv_objtype
            object   = l_object
            langu    = l_langu
            typ      = l_doctype
          IMPORTING
            doktitle = l_title
          TABLES
            line     = lt_lines
          EXCEPTIONS
            OTHERS   = 2.
        IF sy-subrc NE 0.
          CLEAR lt_lines.
        ELSE.
* Add appendix
          CALL FUNCTION 'DOCU_GET_APPENDIX'
            EXPORTING
              langu  = l_langu
              id     = iv_objtype
              object = l_object
            TABLES
              docu   = lt_lines2.
          APPEND LINES OF lt_lines2 TO lt_lines.
        ENDIF.
        EXIT. "exit do
      ENDIF.
    ENDDO.

* Write Header tags
    REFRESH lt_data_table.
    htmlo '<html><head>'.
    htmlo '<title>Object'.
    htmlo l_object.
    htmlo 'info</title>'.

* Add sap style
* check for customer style, since modifications or other
* includes/commands we will not be supported here
* this style should exist only in English, since before SAP one existed
* only in German (DE)
    SELECT SINGLE object FROM dokil INTO l_stylename
      WHERE id = 'TX'
        AND object = 'Z_EPSS_STYLES'
        AND langu = 'E'
        AND typ = 'E'.
    IF sy-subrc = 0.
* Get EPSS styles from SE61 store
      CALL FUNCTION 'DOCU_GET'
        EXPORTING
          id     = 'TX'
          langu  = 'E'
          object = l_stylename
        TABLES
          line   = lt_styles
        EXCEPTIONS
          OTHERS = 1.
    ENDIF.
    IF sy-subrc <> 0 OR lt_styles[] IS INITIAL.
* customer styles is not found, check for SAP one
      l_stylename = 'EPSS_STYLES'.
* Get EPSS styles from SE61 store
      CALL FUNCTION 'DOCU_GET'
        EXPORTING
          id     = 'TX'
          langu  = 'D'
          object = l_stylename
        TABLES
          line   = lt_styles
        EXCEPTIONS
          OTHERS = 0.
      IF lt_styles[] IS INITIAL.
* second language
        CALL FUNCTION 'DOCU_GET'
          EXPORTING
            id     = 'TX'
            langu  = 'E'
            object = l_stylename
          TABLES
            line   = lt_styles
          EXCEPTIONS
            OTHERS = 0.
      ENDIF.
    ENDIF.
* Insert styles into HTML lines
    IF lt_styles[] IS NOT INITIAL.
      APPEND LINES OF lt_styles TO lt_data_table.
    ENDIF.

    htmlo '</head><body bgcolor=#EEF4FB>'.

* For class, search Method list
    IF iv_objtype = 'CL'.
      SELECT t1~clsname t1~cmpname t2~descript
             INTO TABLE lt_clsmeth
             FROM seocompo AS t1
             LEFT JOIN seocompotx AS t2

             ON t1~clsname = t2~clsname
             AND t1~cmpname = t2~cmpname
             AND t2~langu = 'E'
             WHERE ( t1~clsname = iv_obj
             OR t1~clsname IN ( SELECT refclsname
                                FROM vseoimplem
                                WHERE clsname = iv_obj )
                    )
             AND t1~cmptype = '1'. "method

      IF sy-subrc = 0.
        CLEAR ls_line.
        ls_line-tdformat = 'U1'.
        ls_line-tdline = 'Methods'.
        APPEND ls_line TO lt_lines.

        LOOP AT lt_clsmeth INTO ls_clsmeth.
          CLEAR ls_line.
          ls_line-tdformat = 'AS'.

* For each method, search if a doc exist.
* If found, add a link to the method documentaiton
          CLEAR l_object.
          l_object(30) = ls_clsmeth-clsname.
          l_object+30 = ls_clsmeth-cmpname.
          SELECT SINGLE object INTO l_object
                 FROM dokil
                 WHERE id = 'CO'
                 AND object = l_object.
          IF sy-subrc = 0.
            CONCATENATE '<DS:CO.' l_object '>' ls_clsmeth-cmpname
                        '</>'
                        INTO ls_line-tdline.
          ELSE.
            IF ls_clsmeth-clsname = iv_obj.
              ls_line-tdline = ls_clsmeth-cmpname.
            ELSE.
              CONCATENATE ls_clsmeth-clsname ls_clsmeth-cmpname
                          INTO ls_line-tdline SEPARATED BY '~'.
            ENDIF.
          ENDIF.
          IF NOT ls_clsmeth-descript IS INITIAL.
            CONCATENATE ls_line-tdline ls_clsmeth-descript
                        INTO ls_line-tdline SEPARATED BY ' : '.
          ENDIF.
          APPEND ls_line TO lt_lines.
        ENDLOOP.
      ENDIF.
    ENDIF.

* If doc found, display it in html
    IF NOT lt_lines[] IS INITIAL.
* Add doc title
      IF l_title IS INITIAL.
        IF iv_objtype = 'HY'.
          SELECT SINGLE text INTO l_title
                 FROM cus_imgact
                 WHERE activity = iv_obj
                 AND spras = sy-langu.
          IF sy-subrc NE 0.
            SELECT SINGLE text INTO l_title
                   FROM cus_imgact
                   WHERE activity = iv_obj
                   AND spras = 'E'.
          ENDIF.
        ELSEIF iv_objtype = 'FU'.
          SELECT SINGLE stext INTO l_title
                 FROM tftit
                 WHERE funcname = iv_obj
                 AND spras = sy-langu.
          IF sy-subrc NE 0.
            SELECT SINGLE stext INTO l_title
                   FROM tftit
                   WHERE funcname = iv_obj
                   AND spras = 'E'.
          ENDIF.
        ELSEIF iv_objtype = 'CL'.
          l_title = iv_obj.
        ELSEIF iv_objtype = 'CO'
        OR iv_objtype = 'CA'.
          CONCATENATE iv_obj(30) '->' iv_obj+30 INTO l_title.
          CONDENSE l_title NO-GAPS.
        ENDIF.
      ENDIF.
      IF l_title NE space.
        CLEAR ls_line.
        ls_line-tdformat = 'U1'.
        ls_line-tdline = l_title.
        INSERT ls_line INTO lt_lines INDEX 1.
      ENDIF.

* Create doc html converter
      CREATE OBJECT l_docu_to_html.
      CONCATENATE 'DS:' iv_objtype '.' l_object
                  INTO l_docu_to_html->doc_link.
* Load doc into converter
      l_docu_to_html->itflines = lt_lines[].

* Fill header
      l_docu_to_html->header-tdname = l_object.
      l_docu_to_html->header-tdid = iv_objtype.
      l_docu_to_html->header-tdform = 'S_DOCU_SHOW'.
      l_docu_to_html->header-tdstyle = 'S_DOCUS1'.
      IF iv_objtype = 'HY'.
        l_docu_to_html->header-tdobject = 'DSYS'.
      ELSE.
        l_docu_to_html->header-tdobject = 'DOKU'.
      ENDIF.

* Convert doc into html
      CALL METHOD l_docu_to_html->convert_itf_to_html.
*    CALL METHOD l_docu_to_html->add_sapicons_to_html.

* Delete all header until <body>
      LOOP AT l_docu_to_html->htmllines INTO ls_data_table.
        TRANSLATE ls_data_table TO UPPER CASE.
        CONDENSE ls_data_table NO-GAPS.
        DELETE l_docu_to_html->htmllines.
        IF ls_data_table(5) NE '<BODY'.
          CONTINUE.
        ELSE.
          EXIT.
        ENDIF.
      ENDLOOP.

* Write doc
      APPEND LINES OF l_docu_to_html->htmllines TO lt_data_table.
    ELSE.
* No help found
      htmlo '<p align="center">No Help for this entry</p>'.
      htmlo '</body></html>'.
    ENDIF.

* Display page
    IF ar_html_control IS NOT BOUND.
      ar_html_control = NEW cl_gui_html_viewer( parent = ar_html ).
    ENDIF.
    ar_html_control->load_data( IMPORTING assigned_url = l_url
                                CHANGING  data_table   = lt_data_table ).
    ar_html_control->show_url( url = l_url ).
    set_visible( 'CL_GUI_HTML_VIEWER' ).

  ENDMETHOD.


  METHOD write_html_prog.

    DATA : l_object           TYPE doku_obj,
           ls_data_table      TYPE htmlline,
           lt_data_table      LIKE TABLE OF ls_data_table,
           lt_lines           TYPE TABLE OF tline,
           l_docu_to_html     TYPE REF TO cl_epss_docu_to_html,
           l_n                TYPE i,
           l_url(2048),
           l_report           TYPE string,
           l_report_char1(1)  TYPE c,
           lt_report          LIKE TABLE OF l_report,
           l_comment_found(1) TYPE c,
           l_prog             TYPE programm,
           l_style(1)         TYPE c,
           l_open(1)          TYPE c.

    l_object = iv_prog.
* Get doc language
    SELECT SINGLE object INTO l_object
           FROM  dokil
           WHERE id         = 'RE'
           AND   object     = l_object
           AND   langu      = sy-langu
           AND   typ        = 'E'.
    IF sy-subrc EQ 0.
      CALL FUNCTION 'DOCU_GET'
        EXPORTING
          id     = 'RE'
          object = l_object
          langu  = sy-langu
        TABLES
          line   = lt_lines
        EXCEPTIONS
          OTHERS = 2.
      IF sy-subrc NE 0.
        CLEAR lt_lines.
      ENDIF.
    ELSE.
      SELECT SINGLE object INTO l_object
             FROM  dokil
             WHERE id         = 'RE'
             AND   object     = l_object
             AND   langu      = 'E'
             AND   typ        = 'E'.

      IF sy-subrc EQ 0.
        CALL FUNCTION 'DOCU_GET'
          EXPORTING
            id     = 'RE'
            object = l_object
            langu  = 'E'
          TABLES
            line   = lt_lines
          EXCEPTIONS
            OTHERS = 2.
        IF sy-subrc NE 0.
          CLEAR lt_lines.
        ENDIF.
      ENDIF.
    ENDIF.

* Write Header tags
    REFRESH lt_data_table.
    htmlpog '<html>'.
    htmlpog '<title>Program info</title>'.
    htmlpog '<style type="text/css">'.
    htmlpog 'p{margin:0;}'.
    htmlpog '.spacer{margin-top:10px;}'.
    htmlpog '.code{font-family:courier;}'.
    htmlpog '</style>'.
    htmlpog '<body bgcolor=#EEF4FB>'.

* If doc found, display it in html
    IF NOT lt_lines[] IS INITIAL.
* Create doc html converter
      CREATE OBJECT l_docu_to_html.
      CONCATENATE 'DS:' 'RE' '.' l_object
                  INTO l_docu_to_html->doc_link.
* Load doc into converter
      l_docu_to_html->itflines = lt_lines[].
* Convert doc into html
      CALL METHOD l_docu_to_html->convert_itf_to_html.
      CALL METHOD l_docu_to_html->add_sapicons_to_html.

* Delete end tags </body> and </html>
      DESCRIBE TABLE l_docu_to_html->htmllines LINES l_n.
      DELETE l_docu_to_html->htmllines INDEX l_n.
      l_n = l_n - 1.
      DELETE l_docu_to_html->htmllines INDEX l_n.

* Delete all header until <body>
      LOOP AT l_docu_to_html->htmllines INTO ls_data_table.
        TRANSLATE ls_data_table TO UPPER CASE.
        CONDENSE ls_data_table NO-GAPS.
        DELETE l_docu_to_html->htmllines.
        IF ls_data_table(5) NE '<BODY'.
          CONTINUE.
        ELSE.
          EXIT.
        ENDIF.
      ENDLOOP.

* Write doc
      APPEND LINES OF l_docu_to_html->htmllines TO lt_data_table.
    ELSE.
* if no help is found, display the header of the program
      l_prog = iv_prog.
      READ REPORT l_prog INTO lt_report.
      CLEAR l_comment_found.
      CLEAR l_open.
      LOOP AT lt_report INTO l_report.
        l_report_char1 = l_report.
        IF l_report_char1 NE '*'.
          IF l_comment_found = abap_true.
            EXIT.
          ELSE.
            CONTINUE.
          ENDIF.
        ELSE.
          l_comment_found = abap_true.
          l_report = l_report+1.
          CLEAR l_style.
          IF NOT l_report IS INITIAL AND l_report(1) CA '&=23E'.
            l_style = l_report(1).
            l_report = l_report+1.
          ENDIF.

* Try top remove &* at end of line
          IF NOT l_report IS INITIAL.
            l_n = strlen( l_report ) - 1.
            IF l_report+l_n(1) = '*'.
              l_report = l_report(l_n).
              l_n = l_n - 1.
              IF l_n GT 0 AND l_report+l_n(1) = '&'.
                l_report = l_report(l_n).
              ENDIF.
            ENDIF.
          ENDIF.
          IF l_report IS INITIAL OR l_report CO '*& '.
            IF l_open = abap_true.
              htmlpog '</p>'.
              CLEAR l_open.
            ENDIF.
            htmlpog '<p class="spacer"> </p>'.
          ELSEIF l_report CO '*&-' AND l_report CA '-'.
            IF l_open = abap_true.
              htmlpog '</p>'.
              CLEAR l_open.
            ENDIF.
            htmlpog '<hr>'.
          ELSEIF NOT l_style IS INITIAL.
            CASE l_style.
              WHEN '3'.
                IF l_open = abap_true.
                  htmlpog '</p>'.
                  CLEAR l_open.
                ENDIF.
                CONCATENATE '<h3>' l_report '</h3>' INTO l_report.
                htmlpog l_report.
              WHEN '2'.
                IF l_open = abap_true.
                  htmlpog '</p>'.
                  CLEAR l_open.
                ENDIF.
                CONCATENATE '<h2>' l_report '</h2>' INTO l_report.
                htmlpog l_report.
              WHEN '='.
                htmlpog l_report.
              WHEN 'E'.
                IF l_open = abap_true.
                  htmlpog '</p>'.
                  CLEAR l_open.
                ENDIF.
                htmlpog '<p class="code">'.
                htmlpog l_report.
                l_open = abap_true.
              WHEN OTHERS.
                IF l_open = abap_true.
                  htmlpog '</p>'.
                  CLEAR l_open.
                ENDIF.
                htmlpog '<p>'.
                htmlpog l_report.
                l_open = abap_true.
            ENDCASE.
          ELSE.
            IF l_open = abap_true.
              htmlpog '</p>'.
              CLEAR l_open.
            ENDIF.
            htmlpog '<p>'.
            htmlpog l_report.
            l_open = abap_true.
          ENDIF.
        ENDIF.
      ENDLOOP.
      IF sy-subrc NE 0 OR NOT l_comment_found = abap_true.
        htmlpog '<p align="center">No Help for this program</p>'.
      ENDIF.
      IF l_open = abap_true.
        htmlpog '</p>'.
        CLEAR l_open.
      ENDIF.
    ENDIF.

* Write end tags
    htmlpog '</body></html>'.

* Display page
* Display page
    IF ar_html_control IS NOT BOUND.
      ar_html_control = NEW cl_gui_html_viewer( parent = ar_html ).
    ENDIF.
    ar_html_control->load_data( IMPORTING assigned_url = l_url
                                CHANGING  data_table   = lt_data_table ).
    ar_html_control->show_url( url = l_url ).
    set_visible( 'CL_GUI_HTML_VIEWER' ).

  ENDMETHOD.


  METHOD write_html_table.

    DATA : ls_data_table  TYPE htmlline,
           lt_data_table  TYPE  htmltable,
           l_url(2048),
           lt_sel         TYPE TABLE OF vimsellist,
           lt_head        TYPE TABLE OF vimdesc,
           lt_tab         TYPE TABLE OF vimnamtab,
           l_object       TYPE  doku_obj,
           lt_lines       TYPE TABLE OF tline,
           l_docu_to_html TYPE REF TO cl_epss_docu_to_html,
           l_n            TYPE i,
           l_mandant(1)   TYPE c,
           lt_nametab     TYPE TABLE OF dntab,
           l_table        TYPE tabname,
           l_tabletxt     TYPE dd08v-tabname.

*  DEFINE htmlt.
*    ls_data_table = &1.
*    APPEND ls_data_table TO lt_data_table.
*  END-OF-DEFINITION.

    l_table = CONV #( iv_tabname ).

    CALL FUNCTION 'VIEW_GET_DDIC_INFO'
      EXPORTING
        viewname        = l_table
      TABLES
        sellist         = lt_sel
        x_header        = lt_head
        x_namtab        = lt_tab
      EXCEPTIONS
        no_tvdir_entry  = 1
        table_not_found = 2
        OTHERS          = 3.
    CASE sy-subrc.
      WHEN 1.
*  l_nomaint = abap_true.
      WHEN 0.
        DATA(ls_head) = lt_head[ 1 ].
      WHEN OTHERS.
        RETURN.
    ENDCASE.

    l_object = CONV #( iv_tabname ).

    SELECT SINGLE object INTO l_object
           FROM  dokil
           WHERE id         = 'TB'
           AND   object     = l_object
           AND   langu      = 'E'
           AND   typ        = 'E'.
    IF sy-subrc EQ 0.
      CALL FUNCTION 'DOCU_GET'
        EXPORTING
          id     = 'TB'
          object = l_object
          langu  = 'E'
        TABLES
          line   = lt_lines
        EXCEPTIONS
          OTHERS = 2.
      IF sy-subrc NE 0.
        CLEAR lt_lines.
      ENDIF.
    ELSE.
      SELECT SINGLE object INTO l_object
             FROM  dokil
             WHERE id         = 'TB'
             AND   object     = l_object
             AND   langu      = 'E'
             AND   typ        = 'E'.

      IF sy-subrc EQ 0.
        CALL FUNCTION 'DOCU_GET'
          EXPORTING
            id     = 'TB'
            object = l_object
            langu  = 'E'
          TABLES
            line   = lt_lines
          EXCEPTIONS
            OTHERS = 2.
        IF sy-subrc NE 0.
          CLEAR lt_lines.
        ENDIF.
      ENDIF.
    ENDIF.

* If no maint view title found, search table title
    IF ls_head-ddtext IS INITIAL.
      SELECT SINGLE ddtext INTO ls_head-ddtext
             FROM dd02t
             WHERE tabname = l_table
             AND as4local = 'A'
             AND ddlanguage = sy-langu
             AND as4vers = space. "not used field
      IF sy-subrc NE 0.
        SELECT SINGLE ddtext INTO ls_head-ddtext
               FROM dd02t
               WHERE tabname = l_table
               AND as4local = 'A'
               AND ddlanguage = sy-langu
               AND as4vers = space. "not used field
      ENDIF.
    ENDIF.

* Write Header tags
    REFRESH lt_data_table.
    htmlt '<html>'.
    htmlt '<title>Table info</title>'.
    htmlt '<body bgcolor=#EEF4FB>'.
    htmlt '<table width=100%><tr>'.
    htmlt '<td align="center" colspan=2><strong>'.
    htmlt l_table.
    htmlt '-'.
    htmlt ls_head-ddtext.
    htmlt '</strong><br>&nbsp;'.
    htmlt '</td></tr>'.

* If doc found, display it in html
    IF NOT lt_lines[] IS INITIAL.
* Create doc html converter
      CREATE OBJECT l_docu_to_html.
      CONCATENATE 'DS:' 'TB' '.' l_object
                  INTO l_docu_to_html->doc_link.
* Load doc into converter
      l_docu_to_html->itflines = lt_lines[].
* Convert doc into html
      CALL METHOD l_docu_to_html->convert_itf_to_html.
      CALL METHOD l_docu_to_html->add_sapicons_to_html.

* Delete end tags </body> and </html>
      DESCRIBE TABLE l_docu_to_html->htmllines LINES l_n.
      DELETE l_docu_to_html->htmllines INDEX l_n.
      l_n = l_n - 1.
      DELETE l_docu_to_html->htmllines INDEX l_n.

* Delete all header until <body>
      LOOP AT l_docu_to_html->htmllines INTO ls_data_table.
        TRANSLATE ls_data_table TO UPPER CASE.
        CONDENSE ls_data_table NO-GAPS.
        DELETE l_docu_to_html->htmllines.
        IF ls_data_table(5) NE '<BODY'.
          CONTINUE.
        ELSE.
          EXIT.
        ENDIF.
      ENDLOOP.

* Write doc
      htmlt '<tr><td colspan=2>'.
      APPEND LINES OF l_docu_to_html->htmllines TO lt_data_table.
      htmlt '<hr color=black><br>'.
      htmlt '</td></tr>'.
    ENDIF.

    CLEAR l_mandant.
* Display maintenance view fields
    LOOP AT lt_tab ASSIGNING FIELD-SYMBOL(<fs_tab>).
      IF <fs_tab>-domname = 'MANDT' AND sy-tabix = 1.
        l_mandant = abap_true.
      ELSE.
        htmlt '<tr><td>'.
        htmlt <fs_tab>-viewfield.
        htmlt '</td><td>'.
        htmlt <fs_tab>-scrtext.
        htmlt '</td></tr>'.
      ENDIF.
    ENDLOOP.
    IF sy-subrc NE 0.
* If no maintenance view exists, inform user and get table fields
      htmlt '<tr><td colspan=2 align=center><strong>'.
      htmlt 'NO MAINTENANCE VIEW FOR THIS TABLE'(004).
      htmlt '</strong></td></tr>'.

      CALL FUNCTION 'NAMETAB_GET'
        EXPORTING
          langu               = sy-langu
          tabname             = l_table
        TABLES
          nametab             = lt_nametab
        EXCEPTIONS
          internal_error      = 1
          table_has_no_fields = 2
          table_not_activ     = 3
          no_texts_found      = 4
          OTHERS              = 5.
      IF sy-subrc EQ 0.
        htmlt '<tr><td colspan=2><br><hr color=black><br></td></tr>'.
        LOOP AT lt_nametab ASSIGNING FIELD-SYMBOL(<fs_nametab>).
          IF <fs_nametab>-fieldname = 'MANDT' AND sy-tabix = 1.
            l_mandant = abap_true.
          ELSE.
            htmlt '<tr><td>'.
            htmlt <fs_nametab>-fieldname.
            htmlt '</td><td>'.
            htmlt <fs_nametab>-fieldtext.
            htmlt '</td></tr>'.
          ENDIF.
        ENDLOOP.
      ENDIF.
    ENDIF.

* Add mandant dependance
    htmlt '<tr><td colspan=2><br>'.
    htmlt 'Data depend on mandant :'(001).
    htmlt '<strong>'.
    IF l_mandant IS INITIAL.
      htmlt 'No'(003).
    ELSE.
      htmlt 'Yes'(002).
    ENDIF.
    htmlt '</strong></td></tr>'.

* Add text table info
    CALL FUNCTION 'DDUT_TEXTTABLE_GET'
      EXPORTING
        tabname   = l_table
      IMPORTING
        texttable = l_tabletxt.
    IF l_tabletxt IS INITIAL.
      l_tabletxt = '-'.
    ENDIF.
    htmlt '<tr><td colspan=2><br>'.
    htmlt 'Associated text table :'(005).
    htmlt '<strong>'.
    htmlt l_tabletxt.
    htmlt '</strong></td></tr>'.

* Write end tags
    htmlt '</table>'.
    htmlt '</body></html>'.


* Display page
    IF ar_html_control IS NOT BOUND.
      ar_html_control = NEW cl_gui_html_viewer( parent = ar_html ).
    ENDIF.
    ar_html_control->load_data( IMPORTING assigned_url = l_url
                                CHANGING  data_table   = lt_data_table ).
    ar_html_control->show_url( url = l_url ).
    set_visible( 'CL_GUI_HTML_VIEWER' ).


  ENDMETHOD.
ENDCLASS.
