*"* use this source file for any macro definitions you need
*"* in the implementation part of the class

DEFINE pi_postdata.

  APPEND VALUE ftpost(
         stype = &1 count = &2 fnam = &3 fval = &4 )
         TO mt_pi_postdata.

END-OF-DEFINITION.
