*&---------------------------------------------------------------------*
*&  Include           ZFM_SEARCH_TREE_NODE_TOP
*&---------------------------------------------------------------------*
DATA gv_search_txt TYPE searchtxt.
DATA go_tree TYPE REF TO zcl_ul_tree_display.
