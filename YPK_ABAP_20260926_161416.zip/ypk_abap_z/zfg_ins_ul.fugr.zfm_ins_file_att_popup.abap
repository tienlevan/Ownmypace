FUNCTION zfm_ins_file_att_popup.
*"----------------------------------------------------------------------
*"*"Local Interface:
*"  IMPORTING
*"     REFERENCE(IS_DATA) TYPE  ANY
*"     REFERENCE(IV_OBJECT_TYPE) TYPE  ZACC_TYPE DEFAULT '02'
*"     REFERENCE(IV_OBJECT_ADDRESS) TYPE  CHAR100 OPTIONAL
*"     REFERENCE(IV_MODULE) TYPE  CHAR12
*"----------------------------------------------------------------------

  CALL FUNCTION 'ZFM_INS_FILE_ATTACHMENT'
    EXPORTING
      is_data           = is_data
      iv_object_address = iv_object_address
      iv_object_type    = iv_object_type
      iv_module         = iv_module.

  CALL SCREEN 403 STARTING AT 1 5.


ENDFUNCTION.
