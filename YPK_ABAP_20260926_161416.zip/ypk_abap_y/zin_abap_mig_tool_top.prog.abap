*&---------------------------------------------------------------------*
*&  Include  zpg_ccm_cpm_sales_top
*&---------------------------------------------------------------------*
CLASS lcl_control DEFINITION DEFERRED.
DATA application TYPE REF TO lcl_control.

CONSTANTS: gc_act_upld TYPE char2 VALUE '01',
           gc_act_view TYPE char2 VALUE '02',
           gc_act_temp TYPE char3 VALUE '03'.

DATA: gt_migration TYPE TABLE OF zcl_migration_configure=>ty_migration,
      gt_tree      TYPE TABLE OF zcl_migration_configure=>ty_migration_tree.


SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.
PARAMETERS: p_action TYPE char2 AS LISTBOX OBLIGATORY VISIBLE LENGTH 20 USER-COMMAND act MODIF ID m0,
            p_func   TYPE c LENGTH 40 AS LISTBOX VISIBLE LENGTH 20 MODIF ID m0 OBLIGATORY.
SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-002.
PARAMETERS: p_file TYPE rlgrap-filename  MODIF ID m1.
SELECTION-SCREEN END OF BLOCK b2.
