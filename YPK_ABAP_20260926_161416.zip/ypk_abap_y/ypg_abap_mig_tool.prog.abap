*&---------------------------------------------------------------------*
*& Report zpg_ccm_cpm_sales
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT ypg_abap_mig_tool.

INCLUDE zin_abap_mig_tool_top.
INCLUDE zin_abap_mig_tool_cls.
INCLUDE zin_abap_mig_tool_pbo.
INCLUDE zin_abap_mig_tool_pai.

INITIALIZATION.
  p_action = gc_act_upld.


START-OF-SELECTION.
  CALL SCREEN 100.
