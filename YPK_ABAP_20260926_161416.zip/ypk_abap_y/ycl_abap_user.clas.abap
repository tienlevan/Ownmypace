class YCL_ABAP_USER definition
  public
  final
  create public .

public section.

  methods CONSTRUCTOR
    importing
      !IV_USER type XUBNAME default SY-UNAME
      !IV_UPDATE type BOOLE_D default ABAP_FALSE .
  methods GET_NAME
    returning
      value(RS_NAME) type SUID_ST_NODE_PERSON_NAME .
  methods COMMIT
    returning
      value(RV_SUCCESS) type BOOLE_D .
  methods GET_MOBILE
    returning
      value(RV_MOBILE) type AD_TLNMBR .
  methods GET_EMAIL
    returning
      value(RV_EMAIL) type AD_SMTPADR .
  methods GET_LOGONDATA
    returning
      value(RS_LOGONDATA) type SUID_ST_NODE_LOGONDATA .
  methods GET_LAST_LOGON_DATE
    returning
      value(RV_DATE) type DATUM .
  methods GET_LOCK_STATUS
    returning
      value(RV_LOCK) like CL_IDENTITY=>IF_IDENTITY~CO_LOCKED_BY_ADMIN .
  methods SET_LOCK_STATUS
    importing
      !IS_LOCK type SUID_ST_LOCKSCOPE optional
    returning
      value(RV_SUCCESS) type BOOLE_D .
  methods GET_INSTANCE
    returning
      value(RV_INSTANCE) type ref to CL_IDENTITY .
  PROTECTED SECTION.
private section.

  data _MO_USER type ref to CL_IDENTITY .
  data _MV_USER type XUBNAME .
  data _MO_MSG type ref to CL_SUID_MSG_BUFFER .

  methods _SHOW_MESSAGE .
  methods _ADD_DEFAULT_MESSAGE .
ENDCLASS.



CLASS YCL_ABAP_USER IMPLEMENTATION.


  METHOD commit.

    TRY.
        _mo_user->finalize( IMPORTING eo_msg_buffer = DATA(if_msg) ).
        _mo_user->do_save( IMPORTING eo_msg_buffer = if_msg ).
        _mo_user->cleanup(  ).
      CATCH cx_suid_identity.
        _add_default_message( ). RETURN.
    ENDTRY.

    _mo_msg = CAST #( if_msg ).
    IF _mo_msg->find_error_for_user( EXPORTING iv_bname = _mv_user
                                               iv_permanent_only = abap_false ) = abap_true.
      _show_message( ).
      RETURN.
    ENDIF.

    rv_success = cl_identity=>if_identity~co_true.
    COMMIT WORK AND WAIT.

  ENDMETHOD.


  METHOD constructor.

    TRY.
        IF iv_update = abap_false.
          cl_identity=>retrieve( EXPORTING it_bname       = VALUE #( ( bname = iv_user ) )
                                 IMPORTING et_node_root   = DATA(t_node_root)
                                           eo_msg_buffer  = DATA(if_msg) ).
        ELSE.
          cl_identity=>retrieve_for_update( EXPORTING it_bname       = VALUE #( ( bname = iv_user ) )
                                            IMPORTING et_node_root   = t_node_root
                                                      eo_msg_buffer  = if_msg ).
        ENDIF.
        _mo_msg = CAST #( if_msg ).
      CATCH cx_suid_identity.
        _add_default_message(  ).
    ENDTRY.

    IF _mo_msg->find_error_for_user( EXPORTING iv_bname = iv_user
                                               iv_permanent_only = abap_false ) = abap_true.
      _show_message( ).
      RETURN.
    ENDIF.

    _mo_user ?= t_node_root[ 1 ]-idref.
    _mv_user  = iv_user.

  ENDMETHOD.


  METHOD get_email.

    SELECT SINGLE FROM usr21 INNER JOIN adr6
    ON usr21~addrnumber = adr6~addrnumber AND usr21~persnumber = adr6~persnumber
    FIELDS smtp_addr
    WHERE bname = @_mv_user INTO @rv_email. "#EC CI_SEL_NESTED

  ENDMETHOD.


  METHOD get_instance.

    rv_instance = _mo_user.

  ENDMETHOD.


  METHOD get_last_logon_date.

    SELECT SINGLE FROM usr02 FIELDS trdat
      WHERE bname = @_mv_user
      INTO @rv_date.

  ENDMETHOD.


  METHOD get_lock_status.

    TRY.
        _mo_user->get_lockstatus( IMPORTING ev_locked_by_admin        = DATA(lock_admin)
                                            ev_locked_by_global_admin = DATA(lock_global)
                                            ev_locked_by_failed_logon = DATA(lock_failed) ).
      CATCH cx_suid_identity.
        _add_default_message( ).
    ENDTRY.

    CASE abap_true.
      WHEN lock_admin.
        rv_lock = cl_identity=>if_identity~co_locked_by_admin.
      WHEN lock_global.
        rv_lock = rv_lock = cl_identity=>if_identity~co_locked_by_global_admin.
      WHEN lock_failed.
        rv_lock = rv_lock = cl_identity=>if_identity~co_locked_by_wrong_logon.
    ENDCASE.

  ENDMETHOD.


  METHOD get_logondata.

    TRY.
        _mo_user->if_identity~get_logondata( IMPORTING es_logondata = rs_logondata ).
      CATCH cx_suid_identity.
        _add_default_message( ).
    ENDTRY.

  ENDMETHOD.


  METHOD get_mobile.

    TRY.
        _mo_user->if_identity_person~get_communication_data( IMPORTING et_telephone = DATA(t_mobile) ).
      CATCH cx_suid_identity.
        _add_default_message( ).
    ENDTRY.

    CHECK t_mobile IS NOT INITIAL.
    SORT t_mobile DESCENDING BY valid_to.
    rv_mobile = t_mobile[ 1 ]-tel_number.

  ENDMETHOD.


  METHOD get_name.

    TRY.
        _mo_user->if_identity_person~get_personname( IMPORTING es_personname = rs_name ).
      CATCH cx_suid_identity.
        _add_default_message( ).
    ENDTRY.

  ENDMETHOD.


  METHOD set_lock_status.

    TRY.
        _mo_user->if_identity~action_lock( EXPORTING is_lockscope = is_lock
                                           IMPORTING eo_msg_buffer = DATA(if_msg) ).
        _mo_msg = CAST #( if_msg ).
      CATCH cx_suid_identity INTO DATA(cx).
        ycx_abap_error=>raise_message( io_msg_object = cx ).
        RETURN.
    ENDTRY.

    IF _mo_msg->find_error_for_user( EXPORTING iv_bname = _mv_user
                                               iv_permanent_only = abap_false ) = abap_true.
      _show_message( ).
      RETURN.
    ENDIF.

    rv_success = abap_true.

  ENDMETHOD.


  METHOD _add_default_message.

    _mo_msg->add_object_message_symsg( is_msg   = VALUE #( msgty = if_suid_msg_buffer=>co_type_error
                                                           msgid = 'E4'
                                                           msgno = '000'
                                                           msgv1 = 'Exception raised!' )
                                       iv_bname = _mv_user ).

  ENDMETHOD.


  METHOD _show_message.

    DATA(cx_error) = NEW ycx_abap_error( ).

    LOOP AT _mo_msg->if_suid_msg_buffer~get_messages( )
    ASSIGNING FIELD-SYMBOL(<fs_msg>).
      cx_error->add_bapiret2_struc( VALUE #( type       = <fs_msg>-msgty
                                             id         = <fs_msg>-msgid
                                             number     = <fs_msg>-msgno
                                             field      = <fs_msg>-field
                                             message_v1 = <fs_msg>-msgv1
                                             message_v2 = <fs_msg>-msgv2
                                             message_v3 = <fs_msg>-msgv3
                                             message_v4 = <fs_msg>-msgv4
                                             message    = <fs_msg>-message ) ).
    ENDLOOP.

    cx_error->show_message( ).

  ENDMETHOD.
ENDCLASS.
