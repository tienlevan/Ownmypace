CLASS ycl_abap_prog_n DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    TYPES:
      BEGIN OF ty_obj,
        pgmid    TYPE pgmid,
        object   TYPE trobjtype,
        obj_name TYPE trobj_name,
      END OF ty_obj .
    TYPES:
      tt_obj TYPE TABLE OF ty_obj WITH DEFAULT KEY .
    TYPES:
      BEGIN OF ty_trans,
        program TYPE tt_obj,
        domain  TYPE tt_obj,
        type    TYPE tt_obj,
        shld    TYPE tt_obj,
        struct  TYPE tt_obj,
        table   TYPE tt_obj,
        fm      TYPE tt_obj,
        class   TYPE tt_obj,
        screen  TYPE tt_obj,
        status  TYPE tt_obj,
        text    TYPE tt_obj,
        others  TYPE tt_obj,
      END OF ty_trans .

    CONSTANTS mc_r3tr TYPE pgmid VALUE 'R3TR' ##NO_TEXT.
    CONSTANTS mc_limu TYPE pgmid VALUE 'LIMU' ##NO_TEXT.
    CONSTANTS mc_domd TYPE trobjtype VALUE 'DOMD' ##NO_TEXT.
    CONSTANTS mc_dted TYPE trobjtype VALUE 'DTED' ##NO_TEXT.
    CONSTANTS mc_shld TYPE trobjtype VALUE 'SHLD' ##NO_TEXT.
    CONSTANTS mc_tabd TYPE trobjtype VALUE 'TABD' ##NO_TEXT.
    CONSTANTS mc_vied TYPE trobjtype VALUE 'VIED' ##NO_TEXT.
    CONSTANTS mc_ttyd TYPE trobjtype VALUE 'TTYD' ##NO_TEXT.
    CONSTANTS mc_tabl TYPE trobjtype VALUE 'TABL' ##NO_TEXT.
    CONSTANTS mc_func TYPE trobjtype VALUE 'FUNC' ##NO_TEXT.
    CONSTANTS mc_prog TYPE trobjtype VALUE 'PROG' ##NO_TEXT.
    CONSTANTS mc_meth TYPE trobjtype VALUE 'METH' ##NO_TEXT.
    CONSTANTS mc_repo TYPE trobjtype VALUE 'REPO' ##NO_TEXT.
    CONSTANTS mc_reps TYPE trobjtype VALUE 'REPS' ##NO_TEXT.
    CONSTANTS mc_rept TYPE trobjtype VALUE 'REPT' ##NO_TEXT.
    CONSTANTS mc_cpri TYPE trobjtype VALUE 'CPRI' ##NO_TEXT.
    CONSTANTS mc_cpro TYPE trobjtype VALUE 'CPRO' ##NO_TEXT.
    CONSTANTS mc_cpub TYPE trobjtype VALUE 'CPUB' ##NO_TEXT.
    CONSTANTS mc_clas TYPE trobjtype VALUE 'CLAS' ##NO_TEXT.
    CLASS-DATA ms_trans TYPE ty_trans .
    CLASS-DATA mt_scan_obj TYPE TABLE OF ty_obj.
    DATA ms_obj TYPE ty_obj .

    METHODS constructor
      IMPORTING
        !iv_pgmid            TYPE pgmid
        !iv_obj_type         TYPE cnvcdmcucia_obj_type
        !iv_obj_name         TYPE cnvcdmc_obj_name
        !iv_exclude_standard TYPE cnvcdmc_flag DEFAULT abap_on .
    METHODS scan .
  PROTECTED SECTION.
private section.

  data _O_PROG type ref to CL_CI_SCAN .
  data _MS_OBJ type TY_OBJ .
  data _MV_PROG type PROGNAME .
  data _MV_EXCLUDE_STANDARD type BOOLE_D .

  methods _SCAN_STATUS .
  methods _SCAN_TEXT .
  methods _APPEND_DEEP
    importing
      !IO_OBJ type ref to YCL_ABAP_PROG_N .
  methods _REMOVE_DUPLICATE
    changing
      !CT_OBJ type TT_OBJ .
  methods _SCAN_SCREEN .
  methods _SCAN_FM .
ENDCLASS.



CLASS YCL_ABAP_PROG_N IMPLEMENTATION.


  METHOD constructor.

    IF iv_obj_type = mc_prog OR iv_obj_type = mc_repo OR iv_obj_type = mc_reps.
      cl_ci_scan=>create( EXPORTING  p_include = cl_ci_source_include=>create( p_trdir = VALUE #( name = iv_obj_name ) )
                          IMPORTING  p_ref     = _o_prog
                          EXCEPTIONS remote_not_found     = 1
                                     remote_wrong_version = 2
                                     OTHERS               = 3 ).
    ENDIF.

    CASE iv_obj_type.
      WHEN mc_prog OR mc_repo OR mc_reps.
        APPEND VALUE #( pgmid  = iv_pgmid object = iv_obj_type obj_name = iv_obj_name ) TO ms_trans-program.
      WHEN mc_meth OR mc_cpri OR mc_cpro OR mc_cpub OR mc_clas.
        APPEND VALUE #( pgmid  = iv_pgmid object = iv_obj_type obj_name = iv_obj_name ) TO ms_trans-class.
      WHEN mc_domd.
        APPEND VALUE #( pgmid  = iv_pgmid object = iv_obj_type obj_name = iv_obj_name ) TO ms_trans-domain.
      WHEN mc_dted.
        APPEND VALUE #( pgmid  = iv_pgmid object = iv_obj_type obj_name = iv_obj_name ) TO ms_trans-type.
      WHEN mc_shld.
        APPEND VALUE #( pgmid  = iv_pgmid object = iv_obj_type obj_name = iv_obj_name ) TO ms_trans-shld.
      WHEN mc_tabd OR mc_vied OR mc_ttyd.
        APPEND VALUE #( pgmid  = iv_pgmid object = iv_obj_type obj_name = iv_obj_name ) TO ms_trans-table.
      WHEN mc_func.
        APPEND VALUE #( pgmid  = iv_pgmid object = iv_obj_type obj_name = iv_obj_name ) TO ms_trans-fm.
      WHEN OTHERS.
        APPEND VALUE #( pgmid  = iv_pgmid object = iv_obj_type obj_name = iv_obj_name ) TO ms_trans-others.
    ENDCASE.

    ms_obj = VALUE #( pgmid = iv_pgmid object = iv_obj_type obj_name = iv_obj_name ).
    _mv_exclude_standard = iv_exclude_standard.

    IF _o_prog IS BOUND AND iv_obj_type = mc_prog.
      _mv_prog = iv_obj_name.
      _scan_screen( ).
      _scan_status( ).
*      _scan_text( ).
*      _scan_fm( ).
    ENDIF.



  ENDMETHOD.


  METHOD scan.

    DATA lt_ref_obj    TYPE TABLE OF cnvcdmccts_objs_ref.
    DATA lt_ref_obj_st TYPE TABLE OF cnvcdmccts_objs_ref.

    CALL FUNCTION '/SDF/TEAP_GET_REF_OBJECTS'
      EXPORTING
        iv_pgmid                   = ms_obj-pgmid
        iv_obj_type                = ms_obj-object
        iv_obj_name                = ms_obj-obj_name
      TABLES
        it_obj_ref_tab             = lt_ref_obj
      EXCEPTIONS
        no_objs_specified_for_anal = 1
        no_ref_found               = 2
        OTHERS                     = 3.

    CHECK sy-subrc IS INITIAL.

    IF _mv_exclude_standard IS NOT INITIAL.
      CALL FUNCTION '/SDF/TEAP_GET_REF_OBJECTS'
        EXPORTING
          iv_pgmid                   = ms_obj-pgmid
          iv_obj_type                = ms_obj-object
          iv_obj_name                = ms_obj-obj_name
          iv_exclude_cust            = 'X'
        TABLES
          it_obj_ref_tab             = lt_ref_obj_st
        EXCEPTIONS
          no_objs_specified_for_anal = 1
          no_ref_found               = 2
          OTHERS                     = 3.

      LOOP AT lt_ref_obj_st INTO DATA(ls_ref_obj_st).
        DELETE lt_ref_obj WHERE ref_obj_name = ls_ref_obj_st-ref_obj_name.
      ENDLOOP.

    ENDIF.

    SORT lt_ref_obj ASCENDING BY ref_pgmid ref_obj_type ref_obj_name.
    DELETE ADJACENT DUPLICATES FROM lt_ref_obj COMPARING ref_pgmid ref_obj_type ref_obj_name.

    LOOP AT lt_ref_obj INTO DATA(ls_ref_obj) WHERE ref_pgmid = mc_r3tr AND ( ref_obj_name CP 'Z*' OR ref_obj_name CP 'Y*' ).
      READ TABLE mt_scan_obj WITH KEY pgmid = ls_ref_obj-ref_pgmid object = ls_ref_obj-ref_obj_type obj_name = ls_ref_obj-ref_obj_name TRANSPORTING NO FIELDS.
      IF sy-subrc IS INITIAL.
        CONTINUE.
      ELSE.
        mt_scan_obj = VALUE #( BASE mt_scan_obj ( pgmid = ls_ref_obj-ref_pgmid object = ls_ref_obj-ref_obj_type obj_name = ls_ref_obj-ref_obj_name ) ).
        DATA(lo_scan) = NEW ycl_abap_prog_n( iv_pgmid = ls_ref_obj-ref_pgmid  iv_obj_type = ls_ref_obj-ref_obj_type iv_obj_name = ls_ref_obj-ref_obj_name
                                             iv_exclude_standard = _mv_exclude_standard ).
        lo_scan->scan( ).
        _append_deep( lo_scan ).
      ENDIF.
    ENDLOOP.

    _remove_duplicate( CHANGING ct_obj = ms_trans-class ).
    _remove_duplicate( CHANGING ct_obj = ms_trans-domain ).
    _remove_duplicate( CHANGING ct_obj = ms_trans-fm ).
    _remove_duplicate( CHANGING ct_obj = ms_trans-program ).
    _remove_duplicate( CHANGING ct_obj = ms_trans-screen ).
    _remove_duplicate( CHANGING ct_obj = ms_trans-status ).
    _remove_duplicate( CHANGING ct_obj = ms_trans-struct ).
    _remove_duplicate( CHANGING ct_obj = ms_trans-table ).
    _remove_duplicate( CHANGING ct_obj = ms_trans-type ).
    _remove_duplicate( CHANGING ct_obj = ms_trans-text ).

  ENDMETHOD.


  METHOD _append_deep.

    APPEND LINES OF io_obj->ms_trans-class      TO ms_trans-class.
    APPEND LINES OF io_obj->ms_trans-domain     TO ms_trans-domain.
    APPEND LINES OF io_obj->ms_trans-fm         TO ms_trans-fm.
    APPEND LINES OF io_obj->ms_trans-program    TO ms_trans-program.
    APPEND LINES OF io_obj->ms_trans-screen     TO ms_trans-screen.
    APPEND LINES OF io_obj->ms_trans-status     TO ms_trans-status.
    APPEND LINES OF io_obj->ms_trans-struct     TO ms_trans-struct.
    APPEND LINES OF io_obj->ms_trans-table      TO ms_trans-table.
    APPEND LINES OF io_obj->ms_trans-text       TO ms_trans-text.
    APPEND LINES OF io_obj->ms_trans-type       TO ms_trans-type.

  ENDMETHOD.


  METHOD _remove_duplicate.

    SORT ct_obj ASCENDING BY obj_name.
    DELETE ct_obj WHERE obj_name IS INITIAL.
    DELETE ADJACENT DUPLICATES FROM ct_obj COMPARING obj_name.

  ENDMETHOD.


  METHOD _scan_fm.

    _ms_obj = VALUE #( pgmid  = 'LIMU'
                      object = 'FUNC' ).
    LOOP AT _o_prog->tokens ASSIGNING FIELD-SYMBOL(<fs_token>)
      WHERE type = 'I' AND str = 'FUNCTION'.
      DATA(index) = sy-tabix.
      _ms_obj-obj_name = _o_prog->tokens[ index + 1 ]-str.
      REPLACE ALL OCCURRENCES OF |'| IN _ms_obj-obj_name WITH space. CONDENSE _ms_obj-obj_name.
      IF line_exists( ms_trans-struct[ obj_name = _ms_obj-obj_name ] ).
        CONTINUE.
      ENDIF.
      CHECK _ms_obj-obj_name CP 'Z*' OR _ms_obj-obj_name CP 'Y*'.
      APPEND _ms_obj TO mt_scan_obj.
      APPEND _ms_obj TO ms_trans-fm.
    ENDLOOP.

  ENDMETHOD.


  METHOD _scan_screen.

    _ms_obj = VALUE #( pgmid  = 'LIMU'
                       object = 'DYNP' ).

    SELECT FROM d020s FIELDS dnum WHERE prog = @_mv_prog INTO TABLE @DATA(t_dnum).

    LOOP AT t_dnum INTO DATA(s_dnum).
      _ms_obj-obj_name = _mv_prog.
      _ms_obj-obj_name+116 = s_dnum-dnum.
      APPEND _ms_obj TO mt_scan_obj.
      APPEND _ms_obj TO ms_trans-screen.
    ENDLOOP.

    CHECK ms_trans-screen IS NOT INITIAL.
    _scan_status(  ).

  ENDMETHOD.


  METHOD _scan_status.

    DATA lv_rcode TYPE sy-subrc.

    CALL FUNCTION 'RS_CUA_EXISTENCE_CHECK'
      EXPORTING
        program = _mv_prog
      IMPORTING
        rcode   = lv_rcode.

    CHECK lv_rcode IS INITIAL.
    _ms_obj = VALUE #( pgmid    = 'LIMU'
                       object   = 'CUAD'
                       obj_name = _mv_prog ).

    APPEND _ms_obj TO mt_scan_obj.
    APPEND _ms_obj TO ms_trans-status.

  ENDMETHOD.


  METHOD _scan_text.

    DATA lt_text TYPE textpool_t.

    CHECK ms_obj-pgmid = mc_r3tr AND ms_obj-object = mc_prog.
    READ TEXTPOOL ms_obj-obj_name INTO lt_text.
    CHECK lt_text IS NOT INITIAL.
    _ms_obj = VALUE #( pgmid    = ms_obj-pgmid
                       object   = mc_rept
                       obj_name = ms_obj-obj_name ).
    APPEND _ms_obj TO mt_scan_obj.
    APPEND _ms_obj TO ms_trans-text.

  ENDMETHOD.
ENDCLASS.
