*----------------------------------------------------------------------*
***INCLUDE ZPG_CCM_CPM_SALES_USER_COMMI01.
*----------------------------------------------------------------------*
*&---------------------------------------------------------------------*
*&      Module  USER_COMMAND_0100  INPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE user_command_0100 INPUT.

  CASE sy-ucomm.
    WHEN 'BACK'.
      LEAVE TO SCREEN 0.
    WHEN 'SAVE'.
      application->model->process_data(  ).
      application->refresh(  ).
  ENDCASE.

ENDMODULE.
