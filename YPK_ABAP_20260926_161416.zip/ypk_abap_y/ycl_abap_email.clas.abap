CLASS ycl_abap_email DEFINITION
  PUBLIC
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_serializable_object .

    TYPES:
      BEGIN OF ts_s10_var,
        var   TYPE char6,
        value TYPE string,
      END OF ts_s10_var .
    TYPES:
      tt_s10_var TYPE STANDARD TABLE OF ts_s10_var .
    TYPES:
      BEGIN OF ts_recipient,
        recipient    TYPE REF TO if_recipient_bcs,
        i_express    TYPE os_boolean,
        i_copy       TYPE os_boolean,
        i_blind_copy TYPE os_boolean,
        i_no_forward TYPE os_boolean,
      END OF ts_recipient .
    TYPES:
      tt_recipients TYPE STANDARD TABLE OF ts_recipient .

    DATA send_request TYPE REF TO cl_bcs .
    DATA document TYPE REF TO cl_document_bcs .
    DATA sender TYPE REF TO if_sender_bcs .
    DATA exception_info TYPE REF TO if_os_exception_info .
    DATA bcs_exception TYPE REF TO cx_bcs .
    DATA recipients TYPE tt_recipients .
    CLASS-DATA filename TYPE string .

    METHODS constructor
      RAISING
        ycx_abap_error .

    METHODS send_email
      RETURNING
        VALUE(error) TYPE string
      RAISING
        ycx_abap_error .
    METHODS set_sender
      IMPORTING
        !internet_address TYPE adr6-smtp_addr OPTIONAL
        !sap_user         TYPE uname OPTIONAL
        !sms_address      TYPE ad_pagnmbr OPTIONAL
        !fax_address      TYPE ad_fxnmbr OPTIONAL
      RAISING
        ycx_abap_error .
    METHODS set_subject
      IMPORTING
        !subject TYPE string
      RAISING
        ycx_abap_error .
    METHODS set_receipients
      IMPORTING
        !user_name        TYPE uname OPTIONAL
        !internet_address TYPE ad_smtpadr OPTIONAL
        !i_express        TYPE os_boolean DEFAULT abap_true
        !i_copy           TYPE os_boolean DEFAULT abap_true
        !i_blind_copy     TYPE os_boolean DEFAULT abap_true
        !i_no_forward     TYPE os_boolean DEFAULT abap_true
      RAISING
        ycx_abap_error .
    METHODS create_document
      IMPORTING
        !i_type              TYPE so_obj_tp DEFAULT 'RAW'
        !i_subject           TYPE so_obj_des DEFAULT 'Use Long Subject'
        !i_importance        TYPE bcs_docimp OPTIONAL
        !i_sensitivity       TYPE so_obj_sns OPTIONAL
        !i_text              TYPE soli_tab OPTIONAL
        !i_hex               TYPE solix_tab OPTIONAL
        !is_attachment       TYPE boolean OPTIONAL
        !i_size              TYPE sood-objlen OPTIONAL
        !i_attachment_header TYPE soli_tab OPTIONAL
        !i_language          TYPE so_obj_la DEFAULT space
      RAISING
        ycx_abap_error .
    CLASS-METHODS document_text_so
      IMPORTING
        !text_name          TYPE tdobname OPTIONAL
        !so10_var           TYPE tt_s10_var
      RETURNING
        VALUE(content_text) TYPE soli_tab .
    METHODS document_email_temp
      IMPORTING
        !it_data_key          TYPE if_smtg_email_template=>ty_gt_data_key
        !iv_language          TYPE if_smtg_email_template=>ty_gs_tmpl_cont-langu DEFAULT sy-langu
        VALUE(iv_template_id) TYPE smtg_tmpl_id
      RETURNING
        VALUE(rv_content)     TYPE string .
    CLASS-METHODS attachment_pdf
      IMPORTING
        !iv_formname             TYPE tdsfname OPTIONAL
        !iv_spool_request        TYPE tsp01-rqident OPTIONAL
      RETURNING
        VALUE(rt_binary_content) TYPE solix_tab .
    CLASS-METHODS attachment_xlsx
      CHANGING
        !ct_data          TYPE table
      RETURNING
        VALUE(rt_content) TYPE solix_tab .
    CLASS-METHODS attachment_xtt
      IMPORTING
        !io_xtt           TYPE REF TO zcl_xtt
      RETURNING
        VALUE(rt_content) TYPE solix_tab .
    METHODS send_email_remote .
  PROTECTED SECTION.
  PRIVATE SECTION.

    DATA cx_error TYPE REF TO ycx_abap_error .
ENDCLASS.



CLASS ycl_abap_email IMPLEMENTATION.


  METHOD attachment_pdf.

    DATA: lv_fname   TYPE rs38l_fnam,
          lv_xstr    TYPE xstring,
          lv_filesz  TYPE so_obj_len,
          lt_otfdata TYPE ssfcrescl,
          lt_pdf_tab TYPE STANDARD TABLE OF tline,
          lt_otf     TYPE STANDARD TABLE OF itcoo.

    IF iv_formname IS NOT INITIAL.

      CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
        EXPORTING
          formname           = iv_formname
        IMPORTING
          fm_name            = lv_fname
        EXCEPTIONS
          no_form            = 1
          no_function_module = 2
          OTHERS             = 3.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
        RETURN.
      ENDIF.

      " Control parameter
      DATA(ls_ctrlop) = VALUE ssfctrlop( getotf = abap_true no_dialog = abap_true preview = abap_false ).
      DATA(ls_outopt) = VALUE ssfcompop( tdnoprev = abap_true tddest = 'LOCL' tdnoprint = abap_true ).

      " Get otf data
      CALL FUNCTION lv_fname
        EXPORTING
          control_parameters = ls_ctrlop
          output_options     = ls_outopt
        IMPORTING
          job_output_info    = lt_otfdata
        EXCEPTIONS
          formatting_error   = 1
          internal_error     = 2
          send_error         = 3
          user_canceled      = 4
          OTHERS             = 5.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
        RETURN.
      ENDIF.

      CHECK lt_otfdata IS NOT INITIAL. lt_otf[] = lt_otfdata-otfdata[].

      " Covert otf data to xstring
      CALL FUNCTION 'CONVERT_OTF'
        EXPORTING
          format                = 'PDF'
        IMPORTING
          bin_filesize          = lv_filesz
          bin_file              = lv_xstr
        TABLES
          otf                   = lt_otf[]
          lines                 = lt_pdf_tab[]
        EXCEPTIONS
          err_max_linewidth     = 1
          err_format            = 2
          err_conv_not_possible = 3
          OTHERS                = 4.
      IF sy-subrc <> 0.
        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
                WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
        RETURN.
      ENDIF.

    ELSEIF iv_spool_request IS NOT INITIAL.

      DATA: rq       TYPE tsp01,
            bin_size TYPE i,
            dummy    TYPE TABLE OF rspoattr.

      CALL FUNCTION 'RSPO_GET_ATTRIBUTES_SPOOLJOB'
        EXPORTING
          rqident     = iv_spool_request
        IMPORTING
          rq          = rq
        TABLES
          attributes  = dummy
        EXCEPTIONS
          no_such_job = 1
          OTHERS      = 2.
      IF sy-subrc <> 0.
        MESSAGE e126(po) WITH iv_spool_request.
      ENDIF.

      IF rq-rqdoctype = 'OTF' OR rq-rqdoctype = 'SMART'.
        CALL FUNCTION 'CONVERT_OTFSPOOLJOB_2_PDF'
          EXPORTING
            src_spoolid     = iv_spool_request
            no_dialog       = 'X'
            pdf_destination = 'X'
            no_background   = 'X'
          IMPORTING
            pdf_bytecount   = bin_size
            bin_file        = lv_xstr
          EXCEPTIONS
            OTHERS          = 12.
        IF sy-subrc <> 0.
          MESSAGE e712(po) WITH sy-subrc 'CONVERT_OTFSPOOLJOB_2_PDF'.
        ENDIF.
      ELSEIF rq-rqdoctype = 'LIST'.
        CALL FUNCTION 'CONVERT_ABAPSPOOLJOB_2_PDF'
          EXPORTING
            src_spoolid     = iv_spool_request
            no_dialog       = 'X'
            pdf_destination = 'X'
            no_background   = 'X'
          IMPORTING
            pdf_bytecount   = bin_size
            bin_file        = lv_xstr
          EXCEPTIONS
            OTHERS          = 12.
        IF sy-subrc <> 0.
          MESSAGE e712(po) WITH sy-subrc 'CONVERT_ABAPSPOOLJOB_2_PDF'.
        ENDIF.
      ELSE.
        MESSAGE e789(po) WITH rq-rqdoctype.
      ENDIF.

    ELSE.

      " Open to choose file
      DATA: file_path TYPE filetable,
            rc        TYPE i.

      IF filename IS INITIAL.
        cl_gui_frontend_services=>file_open_dialog( EXPORTING window_title = 'Choose file to send email'
                                                    CHANGING file_table = file_path
                                                             rc         = rc ).

        " Get file upload
        filename = file_path[ 1 ]-filename.
      ENDIF.

      cl_gui_frontend_services=>gui_upload( EXPORTING filetype = 'BIN' filename = filename
                                            CHANGING data_tab  = rt_binary_content ).

    ENDIF.

    " Convert xstring to binary data
    CHECK rt_binary_content IS INITIAL.
    rt_binary_content = cl_document_bcs=>xstring_to_solix( lv_xstr ).


  ENDMETHOD.


  METHOD attachment_xlsx.

    DATA: lv_header    TYPE string,
          lv_data      TYPE string,
          lv_data_line TYPE string.

    " Get field catalog
    DATA(field_tab) = zcl_ul_table_manager=>get_field_catalog( CHANGING ct_data = ct_data ).

    " Buiding header
    LOOP AT field_tab ASSIGNING FIELD-SYMBOL(<fs_field>).
      IF <fs_field>-reptext IS INITIAL.
        <fs_field>-reptext = <fs_field>-fieldname.
      ENDIF.
      IF lv_header IS INITIAL.
        lv_header = <fs_field>-reptext.
      ELSE.
        CONCATENATE lv_header <fs_field>-reptext INTO lv_header SEPARATED BY cl_abap_char_utilities=>horizontal_tab.
      ENDIF.
    ENDLOOP.

    " Building data
    DATA val TYPE string.
    LOOP AT ct_data ASSIGNING FIELD-SYMBOL(<fs_data>).
      CLEAR lv_data_line.
      LOOP AT field_tab ASSIGNING <fs_field>.
        ASSIGN COMPONENT <fs_field>-fieldname OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fv>).
        val = <fv>.
        IF sy-tabix = 1.
          lv_data_line = val.
        ELSE.
          CONCATENATE lv_data_line val INTO lv_data_line SEPARATED BY cl_abap_char_utilities=>horizontal_tab.
        ENDIF.
      ENDLOOP.

      IF lv_data IS INITIAL.
        lv_data = lv_data_line.
      ELSE.
        CONCATENATE lv_data lv_data_line INTO lv_data SEPARATED BY cl_abap_char_utilities=>newline.
      ENDIF.

    ENDLOOP.

    CONCATENATE lv_header lv_data INTO lv_data SEPARATED BY cl_abap_char_utilities=>newline.

    " Covert to xstring
    DATA lv_xstring TYPE xstring.
    CALL FUNCTION 'HR_KR_STRING_TO_XSTRING'
      EXPORTING
        codepage_to    = '8300'
        unicode_string = lv_data
      IMPORTING
        xstring_stream = lv_xstring
      EXCEPTIONS
        OTHERS         = 3.

    CHECK sy-subrc = 0.
    rt_content = cl_document_bcs=>xstring_to_solix( lv_xstring ).

  ENDMETHOD.


  METHOD attachment_xtt.

    DATA: lv_value TYPE xstring.

    IF io_xtt->mv_file_name IS NOT INITIAL.
      lv_value = io_xtt->get_raw( ).
      rt_content = cl_document_bcs=>xstring_to_solix( lv_value ).
    ENDIF.

  ENDMETHOD.


  METHOD constructor.

    CLASS cl_bcs DEFINITION LOAD.
    CLASS cl_cam_address_bcs DEFINITION LOAD.
    CLASS cl_abap_char_utilities DEFINITION LOAD.

    TRY.

        send_request = cl_bcs=>create_persistent( ).
        cx_error = NEW ycx_abap_error( ).

      CATCH cx_send_req_bcs INTO DATA(oref).
        cx_error->add_exception_object( oref ).
        RAISE EXCEPTION cx_error.

    ENDTRY.


  ENDMETHOD.


  METHOD create_document.

    TRY.

        IF is_attachment IS INITIAL.

          IF i_text IS NOT INITIAL.
            document = cl_document_bcs=>create_document( i_type        = i_type
                                                         i_text        = i_text
                                                         i_subject     = i_subject
                                                         i_language    = i_language
                                                         i_importance  = i_importance
                                                         i_sensitivity = i_sensitivity ).
          ELSE.
            document = cl_document_bcs=>create_document( i_type        = i_type
                                                         i_hex         = i_hex
                                                         i_subject     = i_subject
                                                         i_language    = i_language
                                                         i_importance  = i_importance
                                                         i_sensitivity = i_sensitivity ).
          ENDIF.

        ELSE.

          IF i_text IS NOT INITIAL.
            document->add_attachment( i_attachment_type    = i_type
                                      i_attachment_subject = i_subject
                                      i_attachment_size    = i_size
                                      i_att_content_text   = i_text
                                      i_attachment_header  = i_attachment_header ).
          ELSE.
            document->add_attachment( i_attachment_type    = i_type
                                      i_attachment_subject = i_subject
                                      i_attachment_size    = i_size
                                      i_att_content_hex    = i_hex
                                      i_attachment_header  = i_attachment_header ).
          ENDIF.

        ENDIF.

      CATCH cx_document_bcs INTO DATA(oref).
        cx_error->add_exception_object( oref ).
        RAISE EXCEPTION cx_error.

    ENDTRY.

  ENDMETHOD.


  METHOD document_email_temp.

    TRY.
        DATA(lo_email_api) = cl_smtg_email_api=>get_instance( iv_template_id = iv_template_id  ).
        CHECK it_data_key IS NOT INITIAL.
        lo_email_api->render_bcs( io_bcs = send_request iv_language = iv_language it_data_key = it_data_key ).
      CATCH cx_smtg_email_common INTO DATA(cx).
        ycx_abap_error=>raise_message( io_msg_object = cx ).
    ENDTRY.

  ENDMETHOD.


  METHOD document_text_so.

    DATA: lt_line TYPE tline_t,
          lt_text TYPE soli_tab.
    " Get text
    CALL FUNCTION 'READ_TEXT'
      EXPORTING
        id       = 'ST'
        language = sy-langu
        name     = text_name
        object   = 'TEXT'
      TABLES
        lines    = lt_line
      EXCEPTIONS
        OTHERS   = 8.
    IF sy-subrc NE 0.
      NEW ycx_abap_error( )->add_system_message( ).
      RETURN.
    ENDIF.

    CHECK lt_line IS NOT INITIAL.
    LOOP AT so10_var ASSIGNING FIELD-SYMBOL(<fs_var>).
      IF strlen( <fs_var>-value ) > 255.
        FIND FIRST OCCURRENCE OF cl_abap_char_utilities=>newline IN <fs_var>-value.
        CHECK sy-subrc IS INITIAL.
        SPLIT <fs_var>-value AT cl_abap_char_utilities=>newline INTO TABLE lt_text IN CHARACTER MODE.
        DATA(pos) = sy-tabix.
        LOOP AT lt_text ASSIGNING FIELD-SYMBOL(<fs_text>).
          REPLACE ALL OCCURRENCES OF <fs_var>-var IN TABLE lt_line WITH <fs_text>-line.
          CHECK sy-tabix < lines( lt_text ).
          INSERT VALUE #( tdformat = '*' tdline = <fs_var>-var ) INTO lt_line INDEX pos + sy-tabix.
        ENDLOOP.
      ELSE.
        REPLACE ALL OCCURRENCES OF <fs_var>-var IN TABLE lt_line WITH <fs_var>-value.
      ENDIF.
    ENDLOOP.

    " Build final document
    content_text = VALUE #( FOR ls_line IN lt_line ( line = ls_line-tdline ) ).

  ENDMETHOD.


  METHOD send_email.

    TRY.

        " Set sender
        send_request->set_sender( sender ).

        " Set recipient
        DELETE ADJACENT DUPLICATES FROM recipients COMPARING recipient.
        LOOP AT recipients ASSIGNING FIELD-SYMBOL(<fs_recipient>).
          send_request->add_recipient( i_recipient = <fs_recipient>-recipient i_express = <fs_recipient>-i_express i_copy = <fs_recipient>-i_copy
                                       i_blind_copy = <fs_recipient>-i_blind_copy i_no_forward = <fs_recipient>-i_no_forward ).
        ENDLOOP.

        " Set that if not need to return status email
        send_request->set_status_attributes( i_requested_status = 'N' ).

        " Set document to send
        IF document IS BOUND.
          send_request->set_document( document ).
        ENDIF.

        " Send immediately
        send_request->set_send_immediately( abap_true ).

        " Send email
        send_request->send( ).

        " Commit work
        COMMIT WORK AND WAIT.

      CATCH: cx_address_bcs
             cx_send_req_bcs
             cx_document_bcs
             ycx_abap_error
      INTO   DATA(oref).

        cx_error->add_exception_object( oref ).
        RAISE EXCEPTION cx_error.

    ENDTRY.


  ENDMETHOD.


  METHOD send_email_remote.

*    DATA email TYPE string.
*    DATA o_email TYPE REF TO zcl_ul_send_email.
*
*    CALL TRANSFORMATION id_indent SOURCE o_email = me->document RESULT XML email.
*
*    DATA email_911 TYPE REF TO zcl_ul_send_email.
*    DATA DOCUMENT TYPE REF TO CL_DOCUMENT_BCS.
*
*    CALL TRANSFORMATION id_indent SOURCE XML email RESULT o_email = document.

*    CALL FUNCTION 'ZFM_RFC_EMAIL'
*      DESTINATION 'PEC@911'
*      EXPORTING
*        iv_email = email.

  ENDMETHOD.


  METHOD set_receipients.

    DATA: lt_addsmtp TYPE STANDARD TABLE OF bapiadsmtp,
          lt_return  TYPE TABLE OF bapiret2.

    TRY.

        IF user_name IS NOT INITIAL AND internet_address IS INITIAL.

          CALL FUNCTION 'BAPI_USER_GET_DETAIL'
            EXPORTING
              username = user_name
            TABLES
              return   = lt_return
              addsmtp  = lt_addsmtp.

          CHECK lt_addsmtp IS NOT INITIAL.
          CHECK lt_addsmtp[ 1 ]-e_mail IS NOT INITIAL.
          DATA(recipient) = cl_cam_address_bcs=>create_internet_address( lt_addsmtp[ 1 ]-e_mail ).

        ELSEIF internet_address IS NOT INITIAL.

          recipient = cl_cam_address_bcs=>create_internet_address( internet_address ).

        ENDIF.


        APPEND VALUE #( recipient = recipient i_express = i_express i_copy = i_copy i_blind_copy = i_blind_copy i_no_forward = i_no_forward ) TO recipients.

      CATCH cx_address_bcs INTO DATA(oref).
        cx_error->add_exception_object( oref ).
        RAISE EXCEPTION cx_error.

    ENDTRY.


  ENDMETHOD.


  METHOD set_sender.

    TRY.

        IF internet_address IS NOT INITIAL.
          sender = cl_cam_address_bcs=>create_internet_address( internet_address ).
        ELSEIF sap_user IS NOT INITIAL.
          sender = cl_sapuser_bcs=>create( sap_user ).
        ELSEIF sms_address IS NOT INITIAL.
          sender = cl_cam_address_bcs=>create_sms_address( i_number = sms_address ).
        ELSEIF fax_address IS NOT INITIAL.
          sender = cl_cam_address_bcs=>create_fax_address( i_country = 'VN' i_number = fax_address ).
        ENDIF.

      CATCH cx_address_bcs INTO DATA(oref).
        cx_error->add_exception_object( oref ).
        RAISE EXCEPTION cx_error.

    ENDTRY.

  ENDMETHOD.


  METHOD set_subject.

    TRY.
        send_request->set_message_subject( ip_subject = subject ).

      CATCH cx_send_req_bcs INTO DATA(oref).
        cx_error->add_exception_object( oref ).
        RAISE EXCEPTION cx_error.

    ENDTRY.

  ENDMETHOD.
ENDCLASS.
