CLASS ycl_abap_rtts DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    DATA ar_data TYPE REF TO data .
    DATA ar_classdescr TYPE REF TO cl_abap_classdescr .
    DATA ar_datadescr TYPE REF TO cl_abap_datadescr .
    DATA ar_refdescr TYPE REF TO cl_abap_refdescr .
    DATA ar_elemdescr TYPE REF TO cl_abap_elemdescr .

    METHODS constructor
      IMPORTING
        !iv_name TYPE any OPTIONAL
        !iv_data TYPE any OPTIONAL
      RAISING
        ycx_abap_error .
    METHODS create_struct
      IMPORTING
        !it_components   TYPE cl_abap_structdescr=>component_table
      RETURNING
        VALUE(rr_struct) TYPE REF TO cl_abap_structdescr
      RAISING
        ycx_abap_error .
    METHODS create_table
      IMPORTING
        !it_components  TYPE cl_abap_structdescr=>component_table
      RETURNING
        VALUE(rr_table) TYPE REF TO cl_abap_tabledescr
      RAISING
        ycx_abap_error .
    METHODS get_data_inf
      EXPORTING
        VALUE(et_fixvalues) TYPE ddfixvalues
        VALUE(ev_filedescr) TYPE dfies
      RETURNING
        VALUE(rv_typename)  TYPE string .
    METHODS get_struct_inf
      EXPORTING
        VALUE(et_ddic_fields)       TYPE ddfields
        VALUE(et_components)        TYPE abap_component_tab
        VALUE(et_simple_components) TYPE abap_compdescr_tab
      RETURNING
        VALUE(rt_symbol_tab)        TYPE abap_component_symbol_tab .
    METHODS get_table_inf
      EXPORTING
        !et_ddic_fields      TYPE ddfields
        !et_tab_keys         TYPE abap_table_keydescr_tab
        VALUE(et_components) TYPE abap_component_tab
        !er_table_line       TYPE REF TO cl_abap_datadescr
      RETURNING
        VALUE(rt_symbol_tab) TYPE abap_component_symbol_tab .
    METHODS fill_sample_data
      EXPORTING
        !e_data  TYPE data
      CHANGING
        !cr_type TYPE REF TO cl_abap_datadescr OPTIONAL .
    METHODS get_fix_values
      RETURNING
        VALUE(rt_value) TYPE ddfixvalues .
  PROTECTED SECTION.
  PRIVATE SECTION.

    DATA cx_error TYPE REF TO ycx_abap_error .
    DATA ar_structdescr TYPE REF TO cl_abap_structdescr .
    DATA ar_tabledescr TYPE REF TO cl_abap_tabledescr .
ENDCLASS.



CLASS YCL_ABAP_RTTS IMPLEMENTATION.


  METHOD constructor.

    " Error handle Instance
    CREATE OBJECT cx_error.

    " Data type instance
    IF iv_name IS NOT INITIAL.

      cl_abap_typedescr=>describe_by_name( EXPORTING p_name = iv_name
                                           RECEIVING p_descr_ref = DATA(lo_type)
                                           EXCEPTIONS type_not_found = 1 ).
      IF sy-subrc = 1.
        cx_error->add_text( iv_message = 'Type &1 is not found' iv_variable_1 = conv #( iv_name ) ).
        RAISE EXCEPTION cx_error.
      ENDIF.

    ELSEIF iv_data IS SUPPLIED.

      lo_type = cl_abap_typedescr=>describe_by_data( iv_data ).

    ENDIF.

    CHECK lo_type IS BOUND.

    " Fill specific object
    CASE lo_type->kind.

      WHEN lo_type->kind_elem.
        ar_elemdescr ?= lo_type.
        CREATE DATA ar_data TYPE HANDLE ar_elemdescr.
      WHEN lo_type->kind_struct.
        ar_structdescr ?= lo_type.
        CREATE DATA ar_data TYPE HANDLE ar_structdescr.
      WHEN lo_type->kind_table.
        ar_tabledescr ?= lo_type.
        CREATE DATA ar_data TYPE HANDLE ar_tabledescr.
      WHEN lo_type->kind_class.
        ar_classdescr ?= lo_type.
      WHEN lo_type->kind_ref.
        ar_refdescr ?= lo_type.

    ENDCASE.

    " Fill parent object
    TRY.
        ar_datadescr ?= lo_type.
      CATCH cx_sy_move_cast_error INTO DATA(cx).
        cx_error->add_exception_object( cx ).
        RAISE EXCEPTION cx_error.
    ENDTRY.

  ENDMETHOD.


  METHOD create_struct.

    TRY .

        rr_struct ?= cl_abap_structdescr=>get( p_components = it_components ).

      CATCH cx_sy_struct_creation INTO DATA(cx_err).

        cx_error->add_exception_object( cx_err ).
        RAISE EXCEPTION cx_error.

    ENDTRY.

    CHECK rr_struct IS BOUND.
    ar_datadescr = rr_struct.
    CREATE DATA ar_data TYPE HANDLE rr_struct.

  ENDMETHOD.


  METHOD create_table.

    TRY .

        rr_table = cl_abap_tabledescr=>get( p_line_type  = create_struct( it_components ) ).

      CATCH cx_sy_table_creation INTO DATA(cx_err).
        cx_error->add_exception_object( cx_err ).
        RAISE EXCEPTION cx_error.

    ENDTRY.

    CHECK rr_table IS BOUND.
    ar_datadescr = rr_table.
    CREATE DATA ar_data TYPE HANDLE rr_table.

  ENDMETHOD.


  METHOD fill_sample_data.

    DATA: lo_struct TYPE REF TO cl_abap_structdescr,
          lo_table  TYPE REF TO cl_abap_tabledescr,
          lo_rtti   TYPE REF TO ycl_abap_rtts,
          lr_data   TYPE REF TO data.

    FIELD-SYMBOLS: <fs_struct> TYPE any,
                   <fs_data>   TYPE any,
                   <ft_data>   TYPE STANDARD TABLE.

    IF cr_type IS INITIAL.
      cr_type = ar_datadescr.
    ENDIF.

    CASE cr_type->type_kind.

      	WHEN cl_abap_typedescr=>typekind_char.
        e_data = |C{ cr_type->length }|.
      	WHEN cl_abap_typedescr=>typekind_date.
        e_data = sy-datum.
      WHEN cl_abap_typedescr=>typekind_string.
        e_data = 'String'.
      WHEN cl_abap_typedescr=>typekind_num OR cl_abap_typedescr=>typekind_int OR cl_abap_typedescr=>typekind_int1
        OR cl_abap_typedescr=>typekind_int2 OR cl_abap_typedescr=>typekind_int8 OR cl_abap_typedescr=>typekind_numeric
        OR cl_abap_typedescr=>typekind_packed OR cl_abap_typedescr=>typekind_float.
        e_data = 88.
      WHEN cl_abap_typedescr=>typekind_decfloat OR cl_abap_typedescr=>typekind_decfloat16 OR cl_abap_typedescr=>typekind_decfloat34.
        e_data = '8.8'.
      WHEN cl_abap_typedescr=>typekind_time.
        e_data = sy-timlo.

      WHEN cl_abap_typedescr=>typekind_struct1 OR cl_abap_typedescr=>typekind_struct2.

        CREATE DATA lr_data TYPE HANDLE cr_type.
        ASSIGN lr_data->* TO <fs_data>.
        TRY.
            DATA(lt_comps) = NEW ycl_abap_rtts( iv_data = <fs_data> )->get_struct_inf( ).
          CATCH ycx_abap_error INTO cx_error.
            cx_error->show_message( ).
            RETURN.
        ENDTRY.


        LOOP AT lt_comps ASSIGNING FIELD-SYMBOL(<fs_comp>).
          ASSIGN COMPONENT <fs_comp>-name OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fv>).
          CHECK <fv> IS ASSIGNED.
          fill_sample_data( IMPORTING e_data  = <fv>
                            CHANGING  cr_type = <fs_comp>-type ).
        ENDLOOP.
        e_data = <fs_data>.

      WHEN cl_abap_typedescr=>typekind_table.

        CREATE DATA lr_data TYPE HANDLE cr_type.
        ASSIGN lr_data->* TO <ft_data>.

        TRY.
            lt_comps = NEW ycl_abap_rtts( iv_data = <ft_data> )->get_table_inf( ).
          CATCH ycx_abap_error INTO cx_error.
            cx_error->show_message( ).
            RETURN.
        ENDTRY.

        APPEND INITIAL LINE TO <ft_data>.
        READ TABLE <ft_data> ASSIGNING <fs_data> INDEX 1.

        LOOP AT lt_comps ASSIGNING <fs_comp>.
          ASSIGN COMPONENT <fs_comp>-name OF STRUCTURE <fs_data> TO <fv>.
          CHECK <fv> IS ASSIGNED.
          fill_sample_data( IMPORTING e_data  = <fv>
                            CHANGING cr_type = <fs_comp>-type ).
        ENDLOOP.
        e_data = <ft_data>.

    ENDCASE.

  ENDMETHOD.


  METHOD get_data_inf.

    CHECK ar_elemdescr IS BOUND.
    rv_typename  = ar_elemdescr->get_relative_name( ).
    CHECK ar_elemdescr->is_ddic_type( ) IS NOT INITIAL.
    et_fixvalues = ar_elemdescr->get_ddic_fixed_values(  ).
    ev_filedescr = ar_elemdescr->get_ddic_field( ).

  ENDMETHOD.


  METHOD get_fix_values.

    CHECK ar_elemdescr IS BOUND.
    rt_value = ar_elemdescr->get_ddic_fixed_values( ).

  ENDMETHOD.


  METHOD get_struct_inf.

    CHECK ar_structdescr IS BOUND.
    et_simple_components = ar_structdescr->components.
    et_components = ar_structdescr->get_components( ).
    rt_symbol_tab = ar_structdescr->get_symbols( ).

    CHECK ar_structdescr->is_ddic_type( ) IS NOT INITIAL.
    et_ddic_fields = ar_structdescr->get_ddic_field_list( ).

  ENDMETHOD.


  METHOD get_table_inf.

    CHECK ar_tabledescr IS NOT INITIAL.
    ar_structdescr ?= ar_tabledescr->get_table_line_type( ).

    CHECK ar_structdescr IS BOUND.
    get_struct_inf( IMPORTING et_ddic_fields = et_ddic_fields
                              et_components  = et_components
                    RECEIVING rt_symbol_tab  = rt_symbol_tab ).

    et_tab_keys = ar_tabledescr->get_keys( ).
    ar_tabledescr->get_table_line_type( ).

  ENDMETHOD.
ENDCLASS.
