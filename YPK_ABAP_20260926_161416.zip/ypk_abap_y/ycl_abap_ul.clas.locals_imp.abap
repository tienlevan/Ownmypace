*"* use this source file for any type of declarations (class
*"* definitions, interfaces or type declarations) you need for
*"* components in the private section

CLASS lcl_json_util DEFINITION FINAL.
  PUBLIC SECTION.
    CLASS-DATA:
     mt_xsdboolean TYPE stringtab.
    CLASS-METHODS:
      class_constructor.
ENDCLASS.

CLASS lcl_json_util IMPLEMENTATION.
  METHOD class_constructor.
    FIELD-SYMBOLS <lv_type> LIKE LINE OF mt_xsdboolean.
    " Get all boolean types
    SELECT rollname INTO TABLE mt_xsdboolean
    FROM dd04l
    WHERE ( domname = 'XSDBOOLEAN' OR domname = 'OS_BOOLEAN' ) AND as4local = 'A'.
    " Add text for speed
    LOOP AT mt_xsdboolean ASSIGNING <lv_type>.
      CONCATENATE '\TYPE=' <lv_type> INTO <lv_type>.
    ENDLOOP.
    " Is standard table
    SORT mt_xsdboolean BY table_line.
  ENDMETHOD.
ENDCLASS.
