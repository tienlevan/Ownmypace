CLASS ycx_abap_error DEFINITION
  PUBLIC
  INHERITING FROM cx_static_check
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    INTERFACES if_t100_dyn_msg .
    INTERFACES if_t100_message .

    ALIASES msgty
      FOR if_t100_dyn_msg~msgty .

    TYPES:
      BEGIN OF ty_return_n.
        INCLUDE TYPE bapiret2.
    TYPES: program TYPE tpda_program,
           include TYPE tpda_include,
           line    TYPE tpda_sc_line.
    TYPES: END OF ty_return_n .
    TYPES:
      tt_return TYPE TABLE OF ty_return_n .
    TYPES:
      gtt_bapireturn_t TYPE STANDARD TABLE OF bapireturn WITH DEFAULT KEY .
    TYPES:
      gtt_bdc_messages  TYPE STANDARD TABLE OF bdcmsgcoll WITH DEFAULT KEY .
    TYPES:
      ty_rc TYPE c LENGTH 2 .
    TYPES:
      BEGIN OF ty_message.
        INCLUDE TYPE esp1_message_wa_type.
    TYPES: messtype TYPE icon_d,
           message  TYPE string,
           docflag  TYPE icon_d,
           docobj   TYPE dokil-object,
           errloc   TYPE icon_d,
           program  TYPE tpda_program,
           include  TYPE tpda_include,
           line     TYPE tpda_sc_line,
           END OF ty_message .

    CONSTANTS:
      BEGIN OF zcx_text2tab_error,
        msgid TYPE symsgid VALUE 'SY',
        msgno TYPE symsgno VALUE '499',
        attr1 TYPE scx_attrname VALUE 'METHNAME',
        attr2 TYPE scx_attrname VALUE 'MSG',
        attr3 TYPE scx_attrname VALUE 'LOCATION',
        attr4 TYPE scx_attrname VALUE '',
      END OF zcx_text2tab_error .
    CONSTANTS:
      BEGIN OF msgtype,
        abort       TYPE msgty VALUE 'A',
        error       TYPE msgty VALUE 'E',
        warning     TYPE msgty VALUE 'W',
        information TYPE msgty VALUE 'I',
        success     TYPE msgty VALUE 'S',
        exit        TYPE msgty VALUE 'X',
      END OF msgtype .
    DATA methname TYPE string READ-ONLY .
    DATA msg TYPE string READ-ONLY .
    DATA code TYPE ty_rc READ-ONLY .
    DATA location TYPE string READ-ONLY .
    DATA line TYPE i READ-ONLY .
    DATA field TYPE string READ-ONLY .
    DATA structure TYPE string READ-ONLY .


METHODS constructor
  IMPORTING
    textid LIKE if_t100_message=>t100key OPTIONAL
    previous LIKE previous OPTIONAL
    methname TYPE string OPTIONAL
    msg TYPE string OPTIONAL
    code TYPE ty_rc OPTIONAL
    location TYPE string OPTIONAL
    line TYPE i OPTIONAL
    field TYPE string OPTIONAL
    structure TYPE string OPTIONAL
    return TYPE tt_return OPTIONAL.

    CLASS-METHODS raise
      IMPORTING
        !msg       TYPE string
        !code      TYPE ty_rc OPTIONAL
        !location  TYPE string OPTIONAL
        !methname  TYPE string OPTIONAL
        !line      TYPE i OPTIONAL
        !field     TYPE string OPTIONAL
        !structure TYPE string OPTIONAL
      RAISING
        ycx_abap_error .
    CLASS-METHODS raise_message
      IMPORTING
        !iv_msg_type           TYPE msgty DEFAULT msgtype-error
        !iv_line_msg           TYPE abap_bool DEFAULT abap_false
        !iv_msg_text           TYPE string OPTIONAL
        !is_msg_struct         TYPE any OPTIONAL
        !it_msg_tab            TYPE STANDARD TABLE OPTIONAL
        !io_msg_object         TYPE REF TO cx_root OPTIONAL
        !iv_log_message        TYPE abap_bool DEFAULT abap_false
      RETURNING
        VALUE(rv_has_messages) TYPE abap_bool .
    METHODS has_messages
      RETURNING
        VALUE(rv_has_messages) TYPE abap_bool .
    METHODS add_system_message
      IMPORTING
        !iv_field_name  TYPE bapi_fld OPTIONAL
        !iv_msgty       TYPE sy-msgty OPTIONAL
        !iv_retcode     TYPE sy-subrc DEFAULT sy-subrc
      RETURNING
        VALUE(rv_msgty) TYPE sy-msgty .
    METHODS get_bapiret2_struc
      RETURNING
        VALUE(rs_bapiret2) TYPE bapiret2 .
    METHODS get_bapiret2_table
      EXPORTING
        VALUE(rt_bapiret2) TYPE bapiret2_t .
    METHODS add_message_and_text_var
      IMPORTING
        !iv_type          TYPE bapi_mtype DEFAULT 'E'
        !iv_id            TYPE symsgid
        !iv_number        TYPE symsgno
        !iv_text_variable TYPE char200 OPTIONAL .
    METHODS add_exception_object
      IMPORTING
        !ir_exception_object TYPE REF TO cx_root .
    METHODS add_bapireturn_struc
      IMPORTING
        !is_bapireturn TYPE bapireturn .
    METHODS add_bapireturn_table
      IMPORTING
        !it_return TYPE gtt_bapireturn_t .
    METHODS add_bapiret1_struc
      IMPORTING
        !is_return TYPE bapiret1 .
    METHODS add_bapiret1_table
      IMPORTING
        !it_return TYPE bapiret1_tab .
    METHODS add_bapiret2_struc
      IMPORTING
        !is_return TYPE bapiret2 .
    METHODS add_bapiret2_table
      IMPORTING
        !it_return TYPE bapiret2_t .
    METHODS add_bdc_table
      IMPORTING
        !it_bdc_messages TYPE gtt_bdc_messages .
    METHODS add_text
      IMPORTING
        !iv_type       TYPE bapi_mtype DEFAULT msgtype-error
        !iv_message    TYPE bapi_msg
        !iv_variable_1 TYPE symsgv OPTIONAL
        !iv_variable_2 TYPE symsgv OPTIONAL
        !iv_variable_3 TYPE symsgv OPTIONAL
        !iv_variable_4 TYPE symsgv OPTIONAL .
    METHODS show_message
      IMPORTING
        !keep_message TYPE boole_d OPTIONAL .
    METHODS show_line_message .
    METHODS raise_short_dump
      RAISING
        ycx_abap_error .
    METHODS log_message .
  PROTECTED SECTION.

    DATA gt_return TYPE tt_return .

    METHODS map_text_var_to_bapiret2
      IMPORTING
        !iv_type           TYPE bapi_mtype
        !iv_id             TYPE symsgid
        !iv_number         TYPE symsgno
        !iv_text           TYPE char200
      RETURNING
        VALUE(rs_bapiret2) TYPE bapiret2 .
    METHODS map_bapireturn_to_bapiret2
      IMPORTING
        !is_bapireturn     TYPE bapireturn
      RETURNING
        VALUE(rs_bapiret2) TYPE bapiret2 .
    METHODS map_bapiret1_to_bapiret2
      IMPORTING
        !is_bapireturn     TYPE bapiret1
      RETURNING
        VALUE(rs_bapiret2) TYPE bapiret2 .
    CLASS-METHODS map_bdc_to_bapiret2
      IMPORTING
        !is_bdc_message    TYPE bdcmsgcoll
      RETURNING
        VALUE(rs_bapiret2) TYPE bapiret2 .
  PRIVATE SECTION.
ENDCLASS.



CLASS ycx_abap_error IMPLEMENTATION.

  METHOD add_bapiret1_struc.

    DATA(ls_bapiret2_struc) = map_bapiret1_to_bapiret2( is_return ).

    add_bapiret2_struc( ls_bapiret2_struc ).

  ENDMETHOD.


  METHOD add_bapiret1_table.

    LOOP AT it_return ASSIGNING FIELD-SYMBOL(<ls_return>).

      add_bapiret1_struc( <ls_return> ).

    ENDLOOP.

  ENDMETHOD.


  METHOD add_bapiret2_struc.

*    "Update GT_RETURN if instantiated by RAISE EXCEPTION.
*    get_bapiret2_struc(  ).

    DATA(t_stacks) = cl_abap_get_call_stack=>format_call_stack_with_struct( cl_abap_get_call_stack=>get_call_stack( ) ).
    DELETE t_stacks WHERE progname CS 'YCX_ABAP_ERROR'.
    READ TABLE t_stacks INTO DATA(s_stack) INDEX 1.

    IF is_return-type CA 'EAXI'.

      DATA(ls_return) = CORRESPONDING ty_return_n( is_return ).

      IF ls_return-id IS NOT INITIAL AND ls_return-message IS INITIAL.

        MESSAGE
          ID     ls_return-id
          TYPE   ls_return-type
          NUMBER ls_return-number
          WITH
            ls_return-message_v1
            ls_return-message_v2
            ls_return-message_v3
            ls_return-message_v4
          INTO ls_return-message.

        ls_return-program = s_stack-progname.
        ls_return-include = s_stack-includename.
        ls_return-line    = s_stack-line.

      ELSE.

        zcl_ul_abap=>string_split_space( EXPORTING iv_string = CONV #( ls_return-message )
                                                   iv_max_len = 50
                                         IMPORTING ev_str1 = DATA(msgv1)
                                                   ev_str2 = DATA(msgv2)
                                                   ev_str3 = DATA(msgv3)
                                                   ev_str4 = DATA(msgv4) ).

        ls_return-message_v1 = msgv1.
        ls_return-message_v2 = msgv2.
        ls_return-message_v3 = msgv3.
        ls_return-message_v4 = msgv4.
        ls_return-program = s_stack-progname.
        ls_return-include = s_stack-includename.
        ls_return-line    = s_stack-line.
*        SPLIT ls_return-message AT '$' INTO ls_return-message_v1 ls_return-message_v2 ls_return-message_v3 ls_return-message_v4.
        CLEAR ls_return-message.
        ls_return-id = 'E4'.
        ls_return-number = '000'.

      ENDIF.

      APPEND ls_return TO gt_return.

    ENDIF.

    IF lines( gt_return ) = 1.

      msgty                    = is_return-type.
      if_t100_dyn_msg~msgv1    = is_return-message_v1.
      if_t100_dyn_msg~msgv2    = is_return-message_v2.
      if_t100_dyn_msg~msgv3    = is_return-message_v3.
      if_t100_dyn_msg~msgv4    = is_return-message_v4.

      if_t100_message~t100key-msgid = is_return-id.
      if_t100_message~t100key-msgno = is_return-number.

      IF if_t100_dyn_msg~msgv1 IS NOT INITIAL.
        if_t100_message~t100key-attr1 = 'IF_T100_DYN_MSG~MSGV1'.
      ENDIF.
      IF if_t100_dyn_msg~msgv2 IS NOT INITIAL.
        if_t100_message~t100key-attr2 = 'IF_T100_DYN_MSG~MSGV2'.
      ENDIF.
      IF if_t100_dyn_msg~msgv3 IS NOT INITIAL.
        if_t100_message~t100key-attr3 = 'IF_T100_DYN_MSG~MSGV3'.
      ENDIF.
      IF if_t100_dyn_msg~msgv4 IS NOT INITIAL.
        if_t100_message~t100key-attr4 = 'IF_T100_DYN_MSG~MSGV4'.
      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD add_bapiret2_table.

    LOOP AT it_return ASSIGNING FIELD-SYMBOL(<ls_return>).

      add_bapiret2_struc( <ls_return> ).

    ENDLOOP.

  ENDMETHOD.


  METHOD add_bapireturn_struc.

    DATA(ls_bapiret2) =
      map_bapireturn_to_bapiret2( is_bapireturn ).

    me->add_bapiret2_struc( ls_bapiret2 ).

  ENDMETHOD.


  METHOD add_bapireturn_table.

    LOOP AT it_return ASSIGNING FIELD-SYMBOL(<ls_return>).

      add_bapireturn_struc( <ls_return> ).

    ENDLOOP.

  ENDMETHOD.


  METHOD add_bdc_table.

    DATA lt_bapiret2          TYPE bapiret2_t.

    LOOP AT it_bdc_messages
      ASSIGNING FIELD-SYMBOL(<ls_bdc_message>).

      APPEND INITIAL LINE TO lt_bapiret2
        ASSIGNING FIELD-SYMBOL(<ls_bapiret2>).

      <ls_bapiret2> = map_bdc_to_bapiret2( <ls_bdc_message> ).

    ENDLOOP.

    add_bapiret2_table( lt_bapiret2 ).

  ENDMETHOD.


  METHOD add_exception_object.

    "********************************************************
    "Split message text string into variables of length 50

    DATA(lv_text) = ir_exception_object->get_text( ).

    DATA:
      BEGIN OF ls_variables,
        msgv1(50),
        msgv2(50),
        msgv3(50),
        msgv4(50),
      END OF ls_variables.

    ls_variables = lv_text.

    "********************************************************
    "Add message
    DATA: ls_bapiret2 TYPE bapiret2.

    ls_bapiret2-type        = sy-msgty.
    ls_bapiret2-id          = sy-msgid.
    ls_bapiret2-number      = sy-msgno.

    ls_bapiret2-message_v1  = ls_variables-msgv1.
    ls_bapiret2-message_v2  = ls_variables-msgv2.
    ls_bapiret2-message_v3  = ls_variables-msgv3.
    ls_bapiret2-message_v4  = ls_variables-msgv4.

    IF ls_variables IS NOT INITIAL AND ls_bapiret2-type IS INITIAL.
      ls_bapiret2-type = 'E'.
      ls_bapiret2-message = ls_variables.
    ENDIF.

    add_bapiret2_struc( ls_bapiret2 ).

  ENDMETHOD.


  METHOD add_message_and_text_var.

    DATA(ls_bapiret2) =
      map_text_var_to_bapiret2(
      iv_type   = iv_type
      iv_id     = iv_id
      iv_number = iv_number
      iv_text   = iv_text_variable ).

    me->add_bapiret2_struc( ls_bapiret2 ).

    show_line_message( ).

  ENDMETHOD.


  METHOD add_system_message.

    DATA:
      ls_return TYPE bapiret2.

    IF iv_msgty IS NOT INITIAL.
      IF sy-msgty <> iv_msgty.
        RETURN.
      ENDIF.
    ELSE.
      sy-msgty = msgtype-error.
    ENDIF.

    ls_return-type        = sy-msgty.
    ls_return-id          = sy-msgid.
    ls_return-number      = sy-msgno.

    ls_return-message_v1  = sy-msgv1.
    ls_return-message_v2  = sy-msgv2.
    ls_return-message_v3  = sy-msgv3.
    ls_return-message_v4  = sy-msgv4.

    ls_return-field       = iv_field_name.

    add_bapiret2_struc( ls_return ).

*   show_line_message( ).
    rv_msgty = sy-msgty.

  ENDMETHOD.


  METHOD add_text.

    "Example:
    "IV_TYPE         = 'E'
    "IV_MESSAGE      = 'Sales order &1 not found.'
    "IV_VARIABLE_1   = '100001
    "IV_VARIABLE_2   = ''
    "IV_VARIABLE_3   = ''
    "IV_VARIABLE_4   = ''

    DATA:
      lv_message TYPE bapi_msg,
      ls_return  TYPE bapiret2.

    " Add text
    lv_message = iv_message.

    DO 4 TIMES.


      DATA lv_placeholder_name TYPE c LENGTH 2.
      DATA lv_variable_name TYPE c LENGTH 15.

      lv_placeholder_name  = '&' && sy-index.

      lv_variable_name  = 'iv_variable_' && sy-index.

      ASSIGN (lv_variable_name)
        TO FIELD-SYMBOL(<lv_variable>).

      CHECK sy-subrc IS INITIAL.
      DATA(lv_variable) = condense( <lv_variable> ).

      REPLACE ALL OCCURRENCES OF lv_placeholder_name
        IN lv_message
        WITH lv_variable
        IN CHARACTER MODE.

      DATA lv_return_var_name TYPE c LENGTH 15.

      lv_return_var_name = 'MESSAGE_V' && sy-index.

      ASSIGN COMPONENT lv_return_var_name
        OF STRUCTURE ls_return
        TO FIELD-SYMBOL(<lv_return_variable>).

      <lv_return_variable> = lv_variable.

    ENDDO.

    ls_return-type    = iv_type.
    ls_return-message = lv_message.

    add_bapiret2_struc( ls_return ).

  ENDMETHOD.


  METHOD constructor ##ADT_SUPPRESS_GENERATION.

    super->constructor( previous = previous ).

    me->methname = methname.
    me->msg = msg.
    me->code = code.
    me->location = location.
    me->line = line.
    me->field = field.
    me->structure = structure.
    me->gt_return = return.

    CLEAR me->textid.
    IF textid IS INITIAL.
      if_t100_message~t100key = if_t100_message=>default_textid.
    ELSE.
      if_t100_message~t100key = textid.
    ENDIF.

  ENDMETHOD.


  METHOD get_bapiret2_struc.

    IF gt_return[] IS INITIAL.

      IF if_t100_message~t100key-msgid = if_t100_message~default_textid-msgid AND
         if_t100_message~t100key-msgno = if_t100_message~default_textid-msgno.
        CLEAR if_t100_message~t100key.
      ENDIF.

      IF if_t100_message~t100key IS NOT INITIAL.

        MESSAGE
          ID          if_t100_message~t100key-msgid
          TYPE        msgty
          NUMBER      if_t100_message~t100key-msgno
          WITH
            if_t100_dyn_msg~msgv1
            if_t100_dyn_msg~msgv2
            if_t100_dyn_msg~msgv3
            if_t100_dyn_msg~msgv4
          INTO DATA(lv_message).

        DATA(ls_bapiret2) = VALUE ty_return_n(
          type        = msgty
          id          = if_t100_message~t100key-msgid
          number      = if_t100_message~t100key-msgno
          message     = lv_message
          message_v1  = if_t100_dyn_msg~msgv1
          message_v2  = if_t100_dyn_msg~msgv2
          message_v3  = if_t100_dyn_msg~msgv3
          message_v4  = if_t100_dyn_msg~msgv4 ).

        APPEND ls_bapiret2 TO gt_return.

      ENDIF.

    ENDIF.

    READ TABLE gt_return
      INTO DATA(ls_return)
      INDEX 1.

    rs_bapiret2 = CORRESPONDING #( ls_return ).

  ENDMETHOD.


  METHOD get_bapiret2_table.

    IF gt_return[] IS INITIAL.

      DATA(ls_bapiret2) = get_bapiret2_struc( ).

      APPEND ls_bapiret2 TO rt_bapiret2.

    ELSE.

      rt_bapiret2 = CORRESPONDING #( gt_return ).

    ENDIF.


  ENDMETHOD.


  METHOD has_messages.
    IF gt_return[] IS NOT INITIAL.
      rv_has_messages = abap_true.
    ENDIF.
  ENDMETHOD.


  METHOD log_message.

    DATA: lv_handle     TYPE balloghndl,
          ls_header     TYPE bal_s_log,
          lt_log_handle TYPE bal_t_logh.

    ls_header = VALUE #( aldate = sy-datum altime = sy-uzeit
                         aluser = sy-uname altcode = sy-tcode
                         alprog = sy-cprog aldate_del = sy-datum + 30
                         object = 'Y_ABAP_LOG' subobject = 'LOGGER' ).

    CALL FUNCTION 'BAL_LOG_CREATE'
      EXPORTING
        i_s_log                 = ls_header
      IMPORTING
        e_log_handle            = lv_handle
      EXCEPTIONS
        log_header_inconsistent = 1
        OTHERS                  = 2.

    IF sy-subrc IS NOT INITIAL.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

    LOOP AT gt_return ASSIGNING FIELD-SYMBOL(<fs_return>).
      DATA(ls_message) = VALUE bal_s_msg( msgty = <fs_return>-type msgid = <fs_return>-id
                                          msgno = <fs_return>-number msgv1 = <fs_return>-message_v1
                                          msgv2 = <fs_return>-message_v2 msgv3 = <fs_return>-message_v3
                                          msgv4 = <fs_return>-message_v4 ).
      CALL FUNCTION 'BAL_LOG_MSG_ADD'
        EXPORTING
          i_log_handle     = lv_handle
          i_s_msg          = ls_message
        EXCEPTIONS
          log_not_found    = 1
          msg_inconsistent = 2
          log_is_full      = 3
          OTHERS           = 4.
    ENDLOOP.

    APPEND lv_handle TO lt_log_handle.
    CALL FUNCTION 'BAL_DB_SAVE'
      EXPORTING
        i_save_all       = 'X'
        i_t_log_handle   = lt_log_handle
        i_in_update_task = abap_false
      EXCEPTIONS
        log_not_found    = 1
        save_not_allowed = 2
        numbering_error  = 3
        OTHERS           = 4.

    IF sy-subrc IS NOT INITIAL.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
      WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

  ENDMETHOD.


  METHOD map_bapiret1_to_bapiret2.

    rs_bapiret2-type       = is_bapireturn-type.
    rs_bapiret2-id         = is_bapireturn-id.
    rs_bapiret2-number     = is_bapireturn-number.

    rs_bapiret2-message    = is_bapireturn-message.
    rs_bapiret2-log_no     = is_bapireturn-log_no.
    rs_bapiret2-log_msg_no = is_bapireturn-log_msg_no.

    rs_bapiret2-message_v1 = is_bapireturn-message_v1.
    rs_bapiret2-message_v2 = is_bapireturn-message_v2.
    rs_bapiret2-message_v3 = is_bapireturn-message_v3.
    rs_bapiret2-message_v4 = is_bapireturn-message_v4.

  ENDMETHOD.


  METHOD map_bapireturn_to_bapiret2.

    rs_bapiret2-type       = is_bapireturn-type.

    "Example value field code: IS504
    rs_bapiret2-id      = is_bapireturn-code+0(2).
    rs_bapiret2-number  = is_bapireturn-code+2(3).

    rs_bapiret2-message    = is_bapireturn-message.
    rs_bapiret2-log_no     = is_bapireturn-log_no.
    rs_bapiret2-log_msg_no = is_bapireturn-log_msg_no.
    rs_bapiret2-message_v1 = is_bapireturn-message_v1.
    rs_bapiret2-message_v2 = is_bapireturn-message_v2.
    rs_bapiret2-message_v3 = is_bapireturn-message_v3.
    rs_bapiret2-message_v4 = is_bapireturn-message_v4.

  ENDMETHOD.


  METHOD map_bdc_to_bapiret2.

    rs_bapiret2-type    = is_bdc_message-msgtyp.
    rs_bapiret2-id      = is_bdc_message-msgid.
    rs_bapiret2-number  = is_bdc_message-msgnr.

    rs_bapiret2-message_v1 = is_bdc_message-msgv1.
    rs_bapiret2-message_v2 = is_bdc_message-msgv2.
    rs_bapiret2-message_v3 = is_bdc_message-msgv3.
    rs_bapiret2-message_v4 = is_bdc_message-msgv4.

    MESSAGE
      ID rs_bapiret2-id
      TYPE rs_bapiret2-type
      NUMBER rs_bapiret2-number
      WITH
        rs_bapiret2-message_v1
        rs_bapiret2-message_v2
        rs_bapiret2-message_v3
        rs_bapiret2-message_v4
      INTO rs_bapiret2-message.

  ENDMETHOD.


  METHOD map_text_var_to_bapiret2.

    "***************************************************
    " Convert text to variables
    "***************************************************

    rs_bapiret2-type   = iv_type.
    rs_bapiret2-id     = iv_id.
    rs_bapiret2-number = iv_number.

    "***************************************************
    " Convert text to variables
    "***************************************************

    TYPES:
      BEGIN OF ltv_variable,
        text TYPE c LENGTH 50,
      END OF ltv_variable.

    DATA:
      lv_text_string TYPE string,
      lt_text        TYPE STANDARD TABLE OF ltv_variable.

    lv_text_string = iv_text.

    SPLIT lv_text_string AT ';' INTO TABLE lt_text.

*    CALL FUNCTION 'CONVERT_STRING_TO_TABLE'
*      EXPORTING
*        i_string         = lv_text_string
*        i_tabline_length = 50
*      TABLES
*        et_table         = lt_text.

    LOOP AT lt_text ASSIGNING FIELD-SYMBOL(<ls_variable>).

      CASE sy-tabix.
        WHEN 1.
          rs_bapiret2-message_v1 = <ls_variable>-text.
        WHEN 2.
          rs_bapiret2-message_v2 = <ls_variable>-text.
        WHEN 3.
          rs_bapiret2-message_v3 = <ls_variable>-text.
        WHEN 4.
          rs_bapiret2-message_v4 = <ls_variable>-text.
      ENDCASE.

    ENDLOOP.

  ENDMETHOD.


  METHOD raise.
    RAISE EXCEPTION TYPE ycx_abap_error
      EXPORTING
        msg       = msg
        code      = code
        methname  = methname
        line      = line
        field     = field
        structure = structure
        location  = location.
  ENDMETHOD.


  METHOD raise_message.

    DATA(cx_msg) = NEW ycx_abap_error(  ).

    IF sy-batch IS INITIAL.

      IF iv_msg_text IS NOT INITIAL.
        cx_msg->add_text( iv_type    = iv_msg_type
                          iv_message = CONV #( iv_msg_text ) ).
      ELSEIF is_msg_struct IS NOT INITIAL.
        TRY.
            DATA(lo_struct) = NEW ycl_abap_rtts( iv_data = is_msg_struct ).
            DATA(lv_struct_name) = lo_struct->ar_datadescr->get_relative_name(  ).
            CASE lv_struct_name.
              WHEN 'BAPIRET1'.
                cx_msg->add_bapiret1_struc( is_msg_struct ).
              WHEN 'BAPIRET2'.
                cx_msg->add_bapiret2_struc( is_msg_struct ).
              WHEN 'BAPIRETURN'.
                cx_msg->add_bapireturn_struc( is_msg_struct ).
            ENDCASE.
          CATCH ycx_abap_error INTO DATA(cx_error).
            raise_message( io_msg_object = cx_error ).
        ENDTRY.
      ELSEIF it_msg_tab IS NOT INITIAL.
        TRY.
            DATA(lo_table) = NEW ycl_abap_rtts( iv_data = it_msg_tab ).
            DATA(lv_table_name) = lo_table->ar_datadescr->get_relative_name(  ).
            CASE lv_table_name.
              WHEN 'BAPIRET1_TAB'.
                cx_msg->add_bapiret1_table( it_msg_tab ).
              WHEN 'BAPIRET2_T'.
                cx_msg->add_bapiret2_table( it_msg_tab ).
              WHEN 'GTT_BAPIRETURN_T'.
                cx_msg->add_bapireturn_table( it_msg_tab ).
              WHEN 'GTT_BDC_MESSAGES'.
                cx_msg->add_bdc_table( it_msg_tab ).
            ENDCASE.
          CATCH ycx_abap_error INTO cx_error.
            raise_message( io_msg_object = cx_error ).
        ENDTRY.
      ELSEIF io_msg_object IS BOUND.
        cx_msg->add_exception_object( io_msg_object ).
      ELSE.
        cx_msg->add_system_message( iv_msgty = iv_msg_type ).
      ENDIF.

      rv_has_messages = cx_msg->has_messages(  ).
      CHECK rv_has_messages IS NOT INITIAL.
      BREAK-POINT ID zcx_error.
      IF io_msg_object IS BOUND.
        io_msg_object->get_source_position( IMPORTING include_name = DATA(lv_include)
                                                      source_line  = DATA(lv_line) ).
        LOG-POINT ID zcx_error SUBKEY sy-uname FIELDS lv_include lv_line.
      ELSE.
        ASSERT ID zcx_error SUBKEY sy-uname CONDITION rv_has_messages = abap_true.
      ENDIF.

      IF iv_log_message = abap_true.
        cx_msg->log_message( ).
      ENDIF.

      IF iv_line_msg IS NOT INITIAL.
        cx_msg->show_line_message( ).
      ELSE.
        cx_msg->show_message( ).
      ENDIF.

    ELSE.

      cx_msg->log_message( ).

    ENDIF.

  ENDMETHOD.


  METHOD raise_short_dump.

    CHECK gt_return IS NOT INITIAL.
    DATA(ls_return) = gt_return[ 1 ].

    RAISE EXCEPTION TYPE ycx_abap_error
      MESSAGE ID ls_return-id
      NUMBER ls_return-number
      WITH ls_return-message_v1 ls_return-message_v2 ls_return-message_v3 ls_return-message_v4.

  ENDMETHOD.


  METHOD show_line_message.

    CHECK lines( gt_return ) = 1.
    DATA(ls_return) = gt_return[ 1 ].
    MESSAGE ID  ls_return-id
           TYPE ls_return-type
           NUMBER ls_return-number
           WITH   ls_return-message_v1
                  ls_return-message_v2
                  ls_return-message_v3
                  ls_return-message_v4.

    REFRESH gt_return.

  ENDMETHOD.


  METHOD show_message.

    DATA t_messages TYPE TABLE OF ty_message.

    " Collect message
    CHECK gt_return IS NOT INITIAL.
    t_messages = VALUE #( FOR gs_return IN gt_return INDEX INTO index
                          ( lineno = index msgid = gs_return-id msgno = gs_return-number msgty = gs_return-type
                            msgv1 = gs_return-message_v1  msgv2 = gs_return-message_v2 msgv3 = gs_return-message_v3
                            msgv4 = gs_return-message_v4 errloc = icon_abap_local program = gs_return-program
                            include = gs_return-include line = gs_return-line ) ).

    " Prepare to show message
    CHECK t_messages IS NOT INITIAL.
    DATA(no_out) = abap_true.

    LOOP AT t_messages INTO DATA(s_message).

      CALL FUNCTION 'DOCU_OBJECT_NAME_CONCATENATE'
        EXPORTING
          docu_id  = 'NA'
          element  = s_message-msgid
          addition = s_message-msgno
        IMPORTING
          object   = s_message-docobj.

      s_message-messtype = SWITCH #( s_message-msgty WHEN 'S' THEN icon_led_green
                                                     WHEN 'I' THEN icon_information
                                                     WHEN 'W' THEN icon_led_yellow
                                                     ELSE icon_led_red ).

      CALL FUNCTION 'MESSAGE_TEXT_BUILD'
        EXPORTING
          msgid               = s_message-msgid
          msgnr               = s_message-msgno
          msgv1               = s_message-msgv1
          msgv2               = s_message-msgv2
          msgv3               = s_message-msgv3
          msgv4               = s_message-msgv4
        IMPORTING
          message_text_output = s_message-message.

      IF zcl_ul_abap=>if_exist_data( is_data = VALUE dokil( id = 'NA' object = s_message-docobj
                                                            langu = sy-langu typ = 'E' ) ) IS NOT INITIAL.
        s_message-docflag = icon_hint.
        no_out = abap_false.
      ENDIF.

      MODIFY t_messages FROM s_message.

    ENDLOOP.

    AUTHORITY-CHECK OBJECT 'S_DEVELOP'
         ID 'DEVCLASS' DUMMY
         ID 'OBJTYPE'  DUMMY
         ID 'OBJNAME'  DUMMY
         ID 'P_GROUP'  DUMMY
         ID 'ACTVT'    FIELD '03'.

    IF sy-subrc IS NOT INITIAL.
      DATA(not_abaper) = abap_true.
    ELSE.
      IF line_exists( t_messages[ msgty = 'E' ] ).
        not_abaper = abap_false.
      ELSE.
        not_abaper = abap_true.
      ENDIF.
    ENDIF.

    zcl_ul_alv_adapter=>create( EXPORTING ir_local_class  = cl_abap_classdescr=>describe_by_name( 'LCL_EVENT' )
                                          is_layout       = VALUE #( no_toolbar = abap_true )
                                          iv_popup        = abap_true
                                          iv_auto_hide    = abap_true
                                          iv_popup_start  = 5
                                          iv_popup_end    = 15
                                          it_col_set      = VALUE #( ( fieldname = 'MESSTYPE' reptext = 'Type'
                                                                       icon = abap_true )
                                                                     ( fieldname = 'MESSAGE'  reptext = 'Message'
                                                                       outputlen = 70 )
                                                                     ( fieldname = 'DOCFLAG'  reptext = 'Hint'
                                                                       icon = abap_true hotspot = abap_true tech = no_out )
                                                                     ( fieldname = 'ERRLOC'   reptext = 'Error Location'
                                                                       icon = abap_true hotspot = abap_true tech = not_abaper ) )
                                          iv_title        = '***Messages***'
                                 CHANGING ct_table        = t_messages ).

    CHECK keep_message = abap_false.
    FREE gt_return.

  ENDMETHOD.

ENDCLASS.
