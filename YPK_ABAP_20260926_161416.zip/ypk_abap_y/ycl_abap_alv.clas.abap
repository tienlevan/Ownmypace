CLASS ycl_abap_alv DEFINITION
  PUBLIC
  INHERITING FROM cl_gui_alv_grid
  CREATE PUBLIC .

  PUBLIC SECTION.

    DATA cx_error TYPE REF TO ycx_abap_error .
    CLASS-DATA o_grid TYPE REF TO zcl_ul_alv_adapter .
    CONSTANTS cv_ccname TYPE char7 VALUE 'CC_GRID' ##NO_TEXT.
    DATA t_fcat TYPE lvc_t_fcat .
    DATA s_layout TYPE lvc_s_layo .
    DATA v_title TYPE lvc_title .
    CLASS-DATA r_table TYPE REF TO data .
    DATA o_container TYPE REF TO cl_gui_container .
    DATA o_splitter TYPE REF TO cl_gui_splitter_container .
    CLASS-DATA t_ex_functions TYPE ui_functions .
    CLASS-DATA v_call_screen TYPE dynnr .
    CLASS-DATA v_full_display TYPE boolean .
    DATA t_toolbar_add TYPE ttb_button .
    DATA t_sort TYPE lvc_t_sort .
    CONSTANTS:
      BEGIN OF cs_layout,
        global   TYPE char01 VALUE 'X',
        specific TYPE char01 VALUE 'U',
        all      TYPE char01 VALUE 'A',
        none     TYPE char01 VALUE ' ',
      END OF cs_layout .
    CLASS-DATA t_f4_fields TYPE lvc_t_f4 .
    DATA t_filter TYPE lvc_t_filt .

    METHODS constructor
      IMPORTING
        !io_parent TYPE REF TO cl_gui_container OPTIONAL
        !io_log    TYPE REF TO cl_gui_container OPTIONAL .
    CLASS-METHODS create
      IMPORTING
        !io_parent      TYPE REF TO cl_gui_container OPTIONAL
        !io_log         TYPE REF TO cl_gui_container OPTIONAL
        !ir_local_class TYPE REF TO cl_abap_typedescr OPTIONAL
        !iv_popup       TYPE boolean OPTIONAL
        !iv_tabname     TYPE tabname OPTIONAL
        !it_col_set     TYPE ztb_ul_alv_col OPTIONAL
        !is_layout      TYPE lvc_s_layo OPTIONAL
        !iv_f_head      TYPE boolean DEFAULT abap_true
        !it_sort        TYPE lvc_t_sort OPTIONAL
        !iv_auto_hide   TYPE boolean OPTIONAL
        !it_toolbar_add TYPE ttb_button OPTIONAL
        !iv_title       TYPE text100 OPTIONAL
        !iv_input       TYPE int4 OPTIONAL
        !iv_popup_start TYPE i OPTIONAL
        !iv_popup_end   TYPE i OPTIONAL
        !it_hyperlinks  TYPE lvc_t_hype OPTIONAL
        !it_dropval     TYPE lvc_t_drop OPTIONAL
      CHANGING
        !ct_table       TYPE STANDARD TABLE OPTIONAL
      RETURNING
        VALUE(ro_alv)   TYPE REF TO zcl_ul_alv_adapter .
    METHODS display
      IMPORTING
        !iv_tabname    TYPE tabname OPTIONAL
        !it_col_set    TYPE ztb_ul_alv_col OPTIONAL
        !iv_auto_hide  TYPE boolean OPTIONAL
        !iv_default    TYPE boolean DEFAULT abap_false
        !iv_save       TYPE char01 DEFAULT zcl_ul_alv_adapter=>cs_layout-specific
        !iv_input      TYPE int4 OPTIONAL
        !it_hyperlinks TYPE lvc_t_hype OPTIONAL
      CHANGING
        !ct_data       TYPE table OPTIONAL
      RAISING
        ycx_abap_error .
    METHODS lvc_fcat_from_itab
      CHANGING
        !ct_table TYPE STANDARD TABLE .
    CLASS-METHODS del_toolbar
      IMPORTING
        !it_funcs TYPE ui_functions OPTIONAL .
    METHODS get_sel_row_data
      EXPORTING
        !es_result TYPE any .
    METHODS refresh .
    METHODS mine_save_event .
    METHODS mine_back_event .
    METHODS get_data_excel
      EXPORTING
        !et_data TYPE STANDARD TABLE .
    METHODS hide_applog .
    METHODS show_applog .
    METHODS export_html
      RETURNING
        VALUE(et_html) TYPE sdydo_html_table .
    METHODS export_excel .
    METHODS set_fieldtext
      IMPORTING
        !iv_tabname TYPE tabname .
    METHODS load_instance
      IMPORTING
        !io_instance TYPE REF TO zcl_ul_alv_adapter .
    METHODS mine_conti_event .
    METHODS mine_support_event .
  PROTECTED SECTION.

    METHODS mine_user_command
          FOR EVENT user_command OF cl_gui_alv_grid
      IMPORTING
          !e_ucomm .
    METHODS mine_data_changed
          FOR EVENT data_changed OF cl_gui_alv_grid
      IMPORTING
          !er_data_changed
          !e_onf4
          !e_onf4_before
          !e_onf4_after
          !e_ucomm .
    METHODS mine_top_of_page
          FOR EVENT top_of_page OF cl_gui_alv_grid
      IMPORTING
          !e_dyndoc_id
          !table_index .
    METHODS mine_hotspot_click
          FOR EVENT hotspot_click OF cl_gui_alv_grid
      IMPORTING
          !e_row_id
          !e_column_id
          !es_row_no .
    METHODS mine_double_click
          FOR EVENT double_click OF cl_gui_alv_grid
      IMPORTING
          !e_row
          !e_column
          !es_row_no .
    METHODS mine_button_click
          FOR EVENT button_click OF cl_gui_alv_grid
      IMPORTING
          !es_col_id
          !es_row_no .
    METHODS mine_before_command
          FOR EVENT before_user_command OF cl_gui_alv_grid
      IMPORTING
          !e_ucomm .
    METHODS mine_context_req
          FOR EVENT context_menu_request OF cl_gui_alv_grid
      IMPORTING
          !e_object .
    METHODS mine_context_sel
          FOR EVENT context_menu_selected OF cl_gui_alv_grid
      IMPORTING
          !fcode .
    METHODS mine_on_f4
          FOR EVENT onf4 OF cl_gui_alv_grid
      IMPORTING
          !e_fieldname
          !e_fieldvalue
          !es_row_no
          !er_event_data
          !et_bad_cells
          !e_display .
    METHODS mine_data_changed_finished
          FOR EVENT data_changed_finished OF cl_gui_alv_grid
      IMPORTING
          !e_modified
          !et_good_cells
          !sender .
  PRIVATE SECTION.

    CONSTANTS:
      BEGIN OF cs_screen,
        full_screen TYPE scrfdynnr VALUE '0301',
        pop_up      TYPE scrfdynnr VALUE '0302',
      END OF cs_screen .
    CONSTANTS cv_program TYPE scraprog VALUE 'SAPLZFG_INS_UL' ##NO_TEXT.

    METHODS add_toolbar
          FOR EVENT toolbar OF cl_gui_alv_grid
      IMPORTING
          !e_object
          !e_interactive .
ENDCLASS.



CLASS ycl_abap_alv IMPLEMENTATION.


  METHOD add_toolbar.

    IF t_toolbar_add IS NOT INITIAL.
      APPEND LINES OF t_toolbar_add TO e_object->mt_toolbar.
    ENDIF.

  ENDMETHOD.


  METHOD constructor.

    super->constructor( i_parent = io_parent
                        i_applogparent = io_log ).

    " Instance error handling
    CREATE OBJECT cx_error.

  ENDMETHOD.


  METHOD create.

    v_full_display = iv_f_head.
    DATA lo_local TYPE REF TO object.
    DATA lv_input TYPE int4.

    IF ir_local_class IS NOT INITIAL AND io_parent IS BOUND.
      DATA(lv_sublcass_abs_name) = ir_local_class->absolute_name.
      CREATE OBJECT lo_local TYPE (lv_sublcass_abs_name)
        EXPORTING
          io_parent   = io_parent
          io_log      = io_log.
    ENDIF.

    IF iv_input IS NOT SUPPLIED AND it_col_set IS NOT INITIAL.
      IF line_exists( it_col_set[ edit = abap_true ] ).
        lv_input = 1.
      ENDIF.
    ELSE.
      lv_input = iv_input.
    ENDIF.

    IF io_parent IS NOT BOUND.

      v_call_screen = SWITCH #( iv_popup WHEN abap_true  THEN cs_screen-pop_up
                                         WHEN abap_false THEN cs_screen-full_screen ).

      r_table = REF #( ct_table ).
      DATA(title) = SWITCH lvc_title( iv_title WHEN '' THEN sy-title ELSE iv_title ).

      CALL FUNCTION 'ZFM_INS_ALV_ADAPTER'
        EXPORTING
          iv_screen      = v_call_screen
          iv_tabname     = iv_tabname
          it_col_set     = it_col_set
          is_layout      = is_layout
          it_sort        = it_sort
          iv_title       = title
          iv_auto_hide   = iv_auto_hide
          it_toolbar_add = it_toolbar_add
          ir_local_class = ir_local_class
          iv_popup_start = iv_popup_start
          iv_popup_end   = iv_popup_end
          iv_input       = lv_input
          it_hyperlinks  = it_hyperlinks
          it_dropval     = it_dropval
        IMPORTING
          eo_alv         = ro_alv
        CHANGING
          r_data         = r_table.

    ELSE.

      IF lo_local IS BOUND.
        ro_alv ?= lo_local.
      ELSE.
        CREATE OBJECT ro_alv
          EXPORTING
            io_parent = io_parent
            io_log    = io_log.
      ENDIF.

    ENDIF.

  ENDMETHOD.


  METHOD del_toolbar.

    " Hide fix questionable funcs?
    t_ex_functions = VALUE #( ( cl_gui_alv_grid=>mc_fc_loc_delete_row ) ( cl_gui_alv_grid=>mc_fc_loc_insert_row )
                              ( cl_gui_alv_grid=>mc_fc_loc_append_row ) ( cl_gui_alv_grid=>mc_fc_loc_paste_new_row )
                              ( cl_gui_alv_grid=>mc_fc_loc_copy )       ( cl_gui_alv_grid=>mc_fc_loc_copy_row )
                              ( cl_gui_alv_grid=>mc_fc_loc_cut )        ( cl_gui_alv_grid=>mc_fc_loc_paste )
                              ( cl_gui_alv_grid=>mc_fc_info )           ( cl_gui_alv_grid=>mc_fc_help )
                              ( cl_gui_alv_grid=>mc_fc_check )          ( cl_gui_alv_grid=>mc_fc_refresh )
                              ( cl_gui_alv_grid=>mc_fc_loc_undo )       ( cl_gui_alv_grid=>mc_fc_select_all ) ).

    CHECK it_funcs IS NOT INITIAL.
    APPEND LINES OF it_funcs TO t_ex_functions.

  ENDMETHOD.


  METHOD display.

    "Load fcat
    lvc_fcat_from_itab( CHANGING ct_table = ct_data ).

    "Using table label
    IF iv_tabname IS NOT INITIAL.
      set_fieldtext( iv_tabname ).
    ENDIF.

    " Any specific setting
    LOOP AT t_fcat ASSIGNING FIELD-SYMBOL(<fs_fcat>).

      IF <fs_fcat>-fieldname = 'MANDT' OR <fs_fcat>-fieldname = 'CLIENT'.
        <fs_fcat>-tech = abap_true.
        CONTINUE.
      ENDIF.

      READ TABLE it_col_set ASSIGNING FIELD-SYMBOL(<fs_col_set>) WITH KEY fieldname = <fs_fcat>-fieldname.

      IF sy-subrc IS INITIAL.
        DO.
          ASSIGN COMPONENT sy-index OF STRUCTURE <fs_col_set> TO FIELD-SYMBOL(<fv_new>).
          ASSIGN COMPONENT sy-index OF STRUCTURE <fs_fcat> TO FIELD-SYMBOL(<fv_default>).
          IF sy-subrc IS NOT INITIAL.
            EXIT.
          ENDIF.
          IF <fv_new> IS NOT INITIAL.
            <fv_default> = <fv_new>.
          ELSE.
            CONTINUE.
          ENDIF.
        ENDDO.
        IF <fs_col_set>-reptext IS NOT INITIAL.
          <fs_fcat>-scrtext_s = <fs_col_set>-reptext.
          <fs_fcat>-scrtext_m = <fs_col_set>-reptext.
          <fs_fcat>-scrtext_l = <fs_col_set>-reptext.
          <fs_fcat>-outputlen = COND #( WHEN strlen( <fs_fcat>-reptext ) > <fs_fcat>-outputlen
                                THEN strlen( <fs_fcat>-reptext ) ELSE <fs_fcat>-outputlen  ).
        ENDIF.
      ELSE.
        CHECK iv_auto_hide = abap_true.
        <fs_fcat>-tech = abap_true.
      ENDIF.

    ENDLOOP.

    IF t_f4_fields IS NOT INITIAL.
      me->register_f4_for_fields( it_f4 = t_f4_fields ).
    ENDIF.

    SET HANDLER add_toolbar FOR me.
    SET HANDLER mine_double_click FOR me.

    " Display
    me->set_table_for_first_display(
      EXPORTING
        i_save                        = iv_save
        is_variant                    = VALUE #( report = sy-cprog )
        i_default                     = iv_default
        it_toolbar_excluding          = t_ex_functions
        is_layout                     = s_layout
        it_hyperlink                  = it_hyperlinks
      CHANGING
        it_fieldcatalog               = t_fcat
        it_sort                       = t_sort
        it_filter                     = t_filter
        it_outtab                     = ct_data
      EXCEPTIONS
        invalid_parameter_combination = 1
        program_error                 = 2
        too_many_lines                = 3
        OTHERS                        = 4 ).

    IF sy-subrc IS NOT INITIAL.
      cx_error->add_system_message( ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    " Pass r_table
    r_table = mt_outtab.

*    "Top of page
    mine_top_of_page(  ).

    " Event handling
    me->set_ready_for_input( iv_input ).
    me->register_edit_event( i_event_id = cl_gui_alv_grid=>mc_evt_modified ).
    SET HANDLER mine_user_command FOR me.
    SET HANDLER mine_data_changed FOR me.
    SET HANDLER mine_hotspot_click FOR me.
    SET HANDLER mine_button_click FOR me.
    SET HANDLER mine_context_req FOR me.
    SET HANDLER mine_context_sel FOR me.
    SET HANDLER mine_before_command FOR me.
    SET HANDLER mine_on_f4 FOR me.

  ENDMETHOD.


  METHOD export_excel.

*    DATA xtt_file TYPE REF TO zif_xtt_file.
*
*    xtt_file = NEW zcl_xtt_file_grid( io_grid = me ).
*    NEW zcl_xtt_excel_xlsx( xtt_file )->merge( is_block = 'R' )->download( ).

  ENDMETHOD.


  METHOD export_html.

    CALL FUNCTION 'LVC_ALV_CONVERT_TO_HTML'
      EXPORTING
        it_data       = mt_data
        it_info       = mt_info
        i_file_dialog = abap_false
      IMPORTING
        et_html       = et_html.

  ENDMETHOD.


  METHOD get_data_excel.

    DATA: file    TYPE string,
          t_dummy TYPE truxs_t_text_data.


    CALL FUNCTION 'GUI_FILE_LOAD_DIALOG'
      EXPORTING
        window_title = 'Choose a file for uploading'
      IMPORTING
        filename     = file.

    CHECK file IS NOT INITIAL.
    CALL FUNCTION 'TEXT_CONVERT_XLS_TO_SAP'
      EXPORTING
        i_tab_raw_data       = t_dummy
        i_filename           = CONV localfile( file )
        i_line_header        = abap_true
      TABLES
        i_tab_converted_data = et_data
      EXCEPTIONS
        conversion_failed    = 1
        OTHERS               = 2.

    CHECK sy-subrc IS NOT INITIAL.
    ycx_abap_error=>raise_message( ).

  ENDMETHOD.


  METHOD get_sel_row_data.

    FIELD-SYMBOLS <outtab> TYPE INDEX TABLE.
    get_selected_rows( IMPORTING et_index_rows = DATA(rows) ).

    CHECK rows IS NOT INITIAL.
    ASSIGN me->mt_outtab->* TO <outtab>.
    READ TABLE <outtab> INTO es_result INDEX rows[ 1 ]-index.

  ENDMETHOD.


  METHOD hide_applog.

    CHECK o_splitter IS BOUND.
    o_splitter->set_row_height( id = 2 height = 0 ).
    o_splitter->set_row_sash( id = 2 type = cl_gui_splitter_container=>type_sashvisible value = cl_gui_splitter_container=>false ).

  ENDMETHOD.


  METHOD load_instance.

    CALL FUNCTION 'ZFM_INS_LOAD_ALV'
      EXPORTING
        io_alv   = io_instance
        iv_title = io_instance->v_title.

  ENDMETHOD.


  METHOD lvc_fcat_from_itab.

    TRY .
        cl_salv_table=>factory( IMPORTING r_salv_table = DATA(salv_table)
                                CHANGING  t_table      = ct_table ).

        t_fcat =  cl_salv_controller_metadata=>get_lvc_fieldcatalog(
                                               r_columns      = salv_table->get_columns( )
                                               r_aggregations = salv_table->get_aggregations( )  ).
      CATCH cx_root.

    ENDTRY.
  ENDMETHOD.


  METHOD mine_back_event.

    LEAVE TO SCREEN 0.

  ENDMETHOD.


  METHOD mine_before_command.

    " Control the user command to process your own function and then use the method “set_user_command” to set the ALV Grid user
    " command to space to avoid ALV Grid execute further with the standard function

*    CASE e_ucomm .
*      WHEN '&INFO' .
*        Provide your own logic here
*        CALL METHOD gr_alvgrid->set_user_command
*          EXPORTING
*            i_ucomm = space.
*    ENDCASE .

  ENDMETHOD.


  METHOD mine_button_click.
*     How to use:
*     - Include in output table lvc_t_styl( style = cl_gui_alv_grid=>mc_button )
*     - Layout-stylefname = 'Included style table'.
*     - Trigger with with this method
  ENDMETHOD.


  METHOD mine_context_req.
    " Define alv context menu

  ENDMETHOD.


  METHOD mine_context_sel.
    " Define user command executing from the context menu

  ENDMETHOD.


  METHOD mine_conti_event.

    check_changed_data( ).
    parent->free(  ).
    LEAVE TO SCREEN 0.

  ENDMETHOD.


  METHOD mine_data_changed.

    IF er_data_changed->mt_protocol IS NOT INITIAL.
      show_applog( ).
    ELSE.
      hide_applog( ).
    ENDIF.

  ENDMETHOD.


  METHOD mine_data_changed_finished.
  ENDMETHOD.


  METHOD mine_double_click.

    MOVE '&DETAIL' TO sy-ucomm.
    fcode_bouncer(  ).

  ENDMETHOD.


  METHOD mine_hotspot_click.

  ENDMETHOD.


  METHOD mine_on_f4.

  ENDMETHOD.


  METHOD mine_save_event.

  ENDMETHOD.


  METHOD mine_support_event.

    TYPES: BEGIN OF ty_info,
             lineno  TYPE mesg-zeile,
             msgid   TYPE sy-msgid,
             msgty   TYPE sy-msgty,
             msgno   TYPE sy-msgno,
             message TYPE text150,
             program TYPE tpda_program,
             include TYPE tpda_include,
             line    TYPE tpda_sc_line,
           END OF ty_info.
    DATA tt_infor TYPE TABLE OF ty_info.
    DATA lv_imagebytes TYPE xstring.
    DATA lv_mimetype TYPE string.
    DATA sender_email TYPE ad_smtpadr.
    DATA reaction TYPE sy-msgty.
    DATA error_table TYPE TABLE OF rpbenerr.

    TRY.

        DATA(html) = NEW zcl_ul_dd_document( iv_no_dialog = abap_true ).
        DATA(document) = html->document.
        DATA(email) = NEW ycl_abap_email( ).
        CALL FUNCTION 'HR_FBN_GET_USER_EMAIL_ADDRESS'
          EXPORTING
            user_id       = sy-uname
            reaction      = reaction
          IMPORTING
            email_address = sender_email
          TABLES
            error_table   = error_table.

        IF sender_email IS INITIAL.
          DATA(sender) = ycl_abap_ul=>get_stvarv_val( 'ZVAR_CCM_API_EMAIL' ).
          sender_email = sender[ 1 ]-low.
        ENDIF.

        ASSIGN mt_outtab->* TO FIELD-SYMBOL(<ft_data>).
        tt_infor = CORRESPONDING #( <ft_data> ).
        email->set_sender( internet_address = sender_email ).

        document->add_text( text = |Kính gửi anh/chị nhờ hỗ trợ,| sap_emphasis = cl_dd_area=>strong  ). document->new_line( 1 ).
        document->add_text( text = |Anh chị hỗ trợ kiểm tra thông tin lỗi với thông tin chi tiết phía dưới:| ).
        document->new_line( ).
        html->add_table_static_html( EXPORTING it_col_header = VALUE #( ( nr = 1 text = 'STT' )
                                                                        ( nr = 2 text = 'Message ID' )
                                                                        ( nr = 3 text = 'Message Type' )
                                                                        ( nr = 4 text = 'Message Number' )
                                                                        ( nr = 5 text = 'Message' )
                                                                        ( nr = 6 text = 'Program' )
                                                                        ( nr = 7 text = 'Include' )
                                                                        ( nr = 8 text = 'Line' ) )
                                                  is_table_attribute = VALUE #( line = 'BORDER=1; CELLSPACING=0;' )
                                        CHANGING  ct_table_value = tt_infor ).
        document->underline( ).
        document->add_text( text = 'Đây là mail tự động được tạo từ hệ thống SAP!' sap_emphasis = cl_dd_area=>emphasis ).

        email->create_document( i_importance = abap_true i_sensitivity = abap_true i_subject = |[SAP]YC Hỗ trợ từ user { sy-uname }|
                                i_type = 'HTM' i_text = document->html_table ).

        SELECT SINGLE FROM ztb_tcode_admin FIELDS admin WHERE tcode = @sy-tcode INTO @DATA(admin).
        IF sy-subrc IS NOT INITIAL.
          admin = 'TIENLV5'.
        ENDIF.

        email->set_receipients( user_name = admin  i_copy = abap_false ).

        cl_gui_frontend_services=>get_screenshot(
        IMPORTING
            mime_type_str = lv_mimetype
            image         = lv_imagebytes ).

        CHECK lv_imagebytes IS NOT INITIAL.
        DATA(t_solix_data) = cl_bcs_convert=>xstring_to_solix(
          EXPORTING
              iv_xstring = lv_imagebytes ).

        email->create_document( is_attachment = abap_true i_hex = t_solix_data i_subject = 'screenshot.jpg' i_type = 'BIN' ).

        email->send_email( ).

        MESSAGE 'Yêu cầu đã được ghi nhận, BP hỗ trợ sẽ phản hồi lại anh/chị trong thời gian sớm nhất!' TYPE 'I'.

      CATCH ycx_abap_error INTO DATA(cx_error).

        MESSAGE 'Lỗi gửi yêu cầu hỗ trợ' TYPE 'I'.

    ENDTRY.

  ENDMETHOD.


  METHOD mine_top_of_page.

  ENDMETHOD.


  METHOD mine_user_command.

  ENDMETHOD.


  METHOD refresh.

    refresh_table_display( i_soft_refresh = abap_true is_stable = VALUE #( row = abap_true col = abap_true ) ).

  ENDMETHOD.


  METHOD set_fieldtext.

    DATA lt_dfies TYPE dfies_tab.
    CALL FUNCTION 'DDIF_FIELDINFO_GET'
      EXPORTING
        tabname        = iv_tabname
      TABLES
        dfies_tab      = lt_dfies
      EXCEPTIONS
        not_found      = 1
        internal_error = 2.

    CHECK sy-subrc IS INITIAL.
    LOOP AT t_fcat ASSIGNING FIELD-SYMBOL(<fs_fcat>).
      TRY.
          DATA(lv_strlen) = strlen( lt_dfies[ fieldname = <fs_fcat>-fieldname ]-fieldtext ).
        CATCH cx_sy_itab_line_not_found.
          CONTINUE.
      ENDTRY.
      IF v_full_display IS NOT INITIAL.
        <fs_fcat>-outputlen = lv_strlen.
      ENDIF.
      DATA(lv_headnam) = lt_dfies[ fieldname = <fs_fcat>-fieldname ]-fieldtext.
      <fs_fcat>-reptext = lv_headnam.
      IF lv_strlen < 10.
        <fs_fcat>-scrtext_s = lv_headnam.
      ELSEIF lv_strlen BETWEEN 10 AND 20.
        <fs_fcat>-scrtext_m = lv_headnam.
      ELSE.
        <fs_fcat>-scrtext_l = lv_headnam.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.


  METHOD show_applog.

    CHECK o_splitter IS BOUND.
    o_splitter->set_row_height( id = 2 height = 30 ).
    o_splitter->set_row_sash( id = 2 type = cl_gui_splitter_container=>type_sashvisible value = cl_gui_splitter_container=>true ).

  ENDMETHOD.
ENDCLASS.
