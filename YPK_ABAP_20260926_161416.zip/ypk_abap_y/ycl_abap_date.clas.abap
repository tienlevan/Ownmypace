CLASS ycl_abap_date DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
    TYPES:
      BEGIN OF ts_timeline,
        pos       TYPE i,
        task      TYPE string,
        from_date TYPE char10,
        to_date   TYPE char10,
        duration  TYPE i,
      END OF ts_timeline .
    TYPES:
      tt_timeline TYPE TABLE OF ts_timeline.

    DATA month TYPE char02 .
    DATA day TYPE char02 .
    DATA year TYPE char04 .
    DATA date_out TYPE char10 .
    DATA date_in TYPE dats .
    DATA week TYPE nweek .
    DATA weekday_name TYPE string .
    DATA days_per_year TYPE i .
    DATA period TYPE zdd_period_code .

    METHODS constructor
      IMPORTING
        !date TYPE sy-datum DEFAULT sy-datum .
    METHODS add_days_to_date
      IMPORTING
        !days          TYPE i
      RETURNING
        VALUE(ro_date) TYPE REF TO ycl_abap_date .
    METHODS add_weeks_to_date
      IMPORTING
        !weeks         TYPE i
      RETURNING
        VALUE(ro_date) TYPE REF TO ycl_abap_date .
    METHODS add_months_to_date
      IMPORTING
        !months        TYPE i
      RETURNING
        VALUE(ro_date) TYPE REF TO ycl_abap_date .
    METHODS add_years_to_date
      IMPORTING
        !years         TYPE i
      RETURNING
        VALUE(ro_date) TYPE REF TO ycl_abap_date .
    METHODS subtract_days_from_date
      IMPORTING
        !days          TYPE i
      RETURNING
        VALUE(ro_date) TYPE REF TO ycl_abap_date .
    METHODS subtract_weeks_from_date
      IMPORTING
        !weeks         TYPE i
      RETURNING
        VALUE(ro_date) TYPE REF TO ycl_abap_date .
    METHODS subtract_months_from_date
      IMPORTING
        !months        TYPE i
      RETURNING
        VALUE(ro_date) TYPE REF TO ycl_abap_date .
    METHODS subtract_years_from_date
      IMPORTING
        !years         TYPE i
      RETURNING
        VALUE(ro_date) TYPE REF TO ycl_abap_date .
    METHODS get_week
      RETURNING
        VALUE(week) TYPE nweek .
    METHODS get_last_day_in_month
      RETURNING
        VALUE(ro_date) TYPE REF TO ycl_abap_date .
    METHODS get_last_day_previous_month
      RETURNING
        VALUE(ro_date) TYPE REF TO ycl_abap_date .
    METHODS get_nth_date
      IMPORTING
        !nth_date      TYPE char02
      RETURNING
        VALUE(ro_date) TYPE REF TO ycl_abap_date .
    METHODS get_working_date
      RETURNING
        VALUE(ro_working_date) TYPE REF TO ycl_abap_date .
    METHODS popup_date_request
      IMPORTING
        !title         TYPE string
        !fieldtext     TYPE string
      RETURNING
        VALUE(ro_date) TYPE REF TO ycl_abap_date .
    METHODS get_days_between_dates
      IMPORTING
        !iv_start_date TYPE sy-datum
        !iv_end_date   TYPE sy-datum
      RETURNING
        VALUE(rv_days) TYPE i .
    METHODS check_date_format
      IMPORTING
        !iv_date        TYPE string
      RETURNING
        VALUE(rv_error) TYPE abap_bool .
    METHODS generate_timeline
      IMPORTING
        !start_date  TYPE dats OPTIONAL
        !effort_rate TYPE char3 DEFAULT '2'
      CHANGING
        !ct_timeline TYPE tt_timeline .
  PROTECTED SECTION.
  PRIVATE SECTION.

    METHODS _get_days_per_year
      RETURNING
        VALUE(number_days) TYPE i .

ENDCLASS.



CLASS YCL_ABAP_DATE IMPLEMENTATION.


  METHOD add_days_to_date.

    date_in = date_in + days.
    ro_date = NEW #( date = date_in ).

  ENDMETHOD.


  METHOD add_months_to_date.

    ro_date = NEW #( cl_hrpad_date_computations=>add_months_to_date( start_date = date_in months = months ) ).

  ENDMETHOD.


  METHOD add_weeks_to_date.

    ro_date = NEW #( cl_hrpad_date_computations=>add_weeks_to_date( start_date = date_in weeks = weeks ) ).

  ENDMETHOD.


  METHOD add_years_to_date.

    ro_date = NEW #( cl_hrpad_date_computations=>add_years_to_date( start_date = date_in years = years ) ).

  ENDMETHOD.


  METHOD check_date_format.

    DATA: y TYPE char4,
          m TYPE char2,
          d TYPE char2.

    IF strlen( iv_date ) > 10 OR strlen( iv_date ) < 8.
      rv_error = abap_true. RETURN.
    ELSEIF strlen( iv_date ) = 8.
      y = iv_date(4).
      m = iv_date+4(2).
      d = iv_date+6(2).
    ELSEIF strlen( iv_date ) = 10.
      d = iv_date(2).
      DATA(s1) = iv_date+2(1).
      m = iv_date+3(2).
      DATA(s2) = iv_date+5(1).
      y = iv_date+6(4).
    ENDIF.

    IF y IS NOT INITIAL.
      IF s1 IS INITIAL.
        IF ( y NOT BETWEEN '0001' AND '9999' )
        OR ( m NOT BETWEEN '01' AND '12' )
        OR ( d NOT BETWEEN '01' AND '31' ).
          rv_error = abap_true. RETURN.
        ENDIF.
      ELSE.
        IF ( s1 NE '.' AND s1 NE '/' AND s1 IS NOT INITIAL )
        OR ( s2 NE '.' AND s2 NE '/' AND s2 IS NOT INITIAL )
        OR ( y NOT BETWEEN '0001' AND '9999' )
        OR ( m NOT BETWEEN '01' AND '12' )
        OR ( d NOT BETWEEN '01' AND '31' ).
          rv_error = abap_true. RETURN.
        ENDIF.
      ENDIF.
      date_in = |{ y }{ m }{ d }|.
      DATA(lastday) = get_last_day_in_month( )->date_in.
      IF lastday < date_in.
        rv_error = abap_true. RETURN.
      ENDIF.
    ELSE.
      rv_error = abap_true. RETURN.
    ENDIF.

  ENDMETHOD.


  METHOD constructor.

    CHECK date IS NOT INITIAL.

    date_in = date.

    year   = date_in(4).
    month  = date_in+4(2).
    day    = date_in+6(2).
    period = date_in(6).

    week = cl_hrpad_date_computations=>get_week( date = date_in ).
    weekday_name = SWITCH #( cl_hrpad_date_computations=>get_weekday_number( date = date_in )
                             WHEN 1 THEN 'Monday'
                             WHEN 2 THEN 'Tuesday'
                             WHEN 3 THEN 'Wednesday'
                             WHEN 4 THEN 'Thursday'
                             WHEN 5 THEN 'Friday'
                             WHEN 6 THEN 'Saturday'
                             WHEN 7 THEN 'Sunday' ).

    date_out      = |{ date_in DATE = USER  }|.
    days_per_year = _get_days_per_year( ).

  ENDMETHOD.


  METHOD generate_timeline.

    IF start_date IS NOT INITIAL.
      DATA(date) = NEW ycl_abap_date( start_date ).
    ELSE.
      date = me.
    ENDIF.

    SORT ct_timeline ASCENDING BY pos.
    LOOP AT ct_timeline ASSIGNING FIELD-SYMBOL(<fs_timeline>).
      IF <fs_timeline>-pos > 1.
        date = date->add_days_to_date( 1 )->get_working_date( ).
      ENDIF.
      <fs_timeline>-from_date = date->date_out.
      date = date->add_days_to_date( <fs_timeline>-duration * effort_rate )->get_working_date( ).
      <fs_timeline>-to_date = date->date_out.
    ENDLOOP.

  ENDMETHOD.


  METHOD get_days_between_dates.

    rv_days = iv_end_date - iv_start_date.

  ENDMETHOD.


  METHOD get_last_day_in_month.

    ro_date = NEW #( cl_hrpad_date_computations=>get_last_day_in_month( date_in = date_in ) ).

  ENDMETHOD.


  METHOD get_last_day_previous_month.

    ro_date = NEW #( cl_hrpad_date_computations=>get_last_day_previous_month( date_in = date_in ) ).

  ENDMETHOD.


  METHOD get_nth_date.

    DATA(date) = date_in.
    date+6 = nth_date.
    ro_date = NEW #( date ).

  ENDMETHOD.


  METHOD get_week.

    week = cl_hrpad_date_computations=>get_week( date = date_in ).

  ENDMETHOD.


  METHOD get_working_date.

    DATA lr_exclude_days TYPE RANGE OF dats.

    SELECT FROM ztb_set_work_day FIELDS * WHERE calendar_id = 'VN' AND fiscal_year = @sy-datum(4) INTO TABLE @DATA(t_calendar).
    IF t_calendar IS NOT INITIAL.
      LOOP AT t_calendar INTO DATA(s_calendar).
        lr_exclude_days = VALUE #( BASE lr_exclude_days ( sign = 'I' option = 'EQ' low = s_calendar-holiday_date ) ).
        IF s_calendar-add_day IS NOT INITIAL.
          DO s_calendar-add_day TIMES.
            lr_exclude_days = VALUE #( BASE lr_exclude_days ( sign = 'I' option = 'EQ'
                                                              low = NEW ycl_abap_date( s_calendar-holiday_date )->add_days_to_date(
                                                              sy-index )->date_in ) ).
          ENDDO.
        ELSEIF s_calendar-float_day IS NOT INITIAL.
          DO.
            DATA(date) = NEW ycl_abap_date( s_calendar-holiday_date )->add_days_to_date( CONV #( s_calendar-float_day * sy-index ) ).
            IF date->date_in <= |{ sy-datum(4) }1231|.
              lr_exclude_days = VALUE #( BASE lr_exclude_days ( sign = 'I' option = 'EQ' low = date->date_in ) ).
            ELSE.
              EXIT.
            ENDIF.
          ENDDO.
        ENDIF.
      ENDLOOP.
    ELSE.
      ycx_abap_error=>raise_message( iv_msg_text = 'No calendar setting found!' ).
      RETURN.
    ENDIF.

    IF weekday_name = 'Sunday'.
      ro_working_date = NEW ycl_abap_date( add_days_to_date( 1 )->date_in )->get_working_date( ).
    ELSE.
      IF date_in IN lr_exclude_days.
        ro_working_date = NEW ycl_abap_date( add_days_to_date( 1 )->date_in )->get_working_date( ).
      ELSE.
        ro_working_date = me.
      ENDIF.
    ENDIF.

  ENDMETHOD.


  METHOD popup_date_request.

    DATA: lv_retcode TYPE c ##NEEDED,
          lt_fields  TYPE TABLE OF sval.

    APPEND VALUE #( tabname   = 'SYST'
                    fieldname = 'DATUM'
                    fieldtext = fieldtext
                    value     = sy-datum
                  ) TO lt_fields.


    CALL FUNCTION 'POPUP_GET_VALUES'
      EXPORTING
        popup_title = title
      IMPORTING
        returncode  = lv_retcode
      TABLES
        fields      = lt_fields
      EXCEPTIONS
        OTHERS      = 1.

    IF sy-subrc NE 0.
      ycx_abap_error=>raise_message( ).
      RETURN.
    ELSEIF lv_retcode EQ 'A'.
      RETURN.
    ENDIF.

    LOOP AT lt_fields ASSIGNING FIELD-SYMBOL(<ls_field>).
      IF <ls_field>-fieldname EQ 'DATUM' AND
        <ls_field>-value IS NOT INITIAL.
        ro_date = NEW #( CONV #( <ls_field>-value ) ).
      ENDIF.
    ENDLOOP.


  ENDMETHOD.


  METHOD subtract_days_from_date.

    date_in = date_in - days.
    ro_date = NEW #( date = date_in ).


  ENDMETHOD.


  METHOD subtract_months_from_date.

    ro_date = NEW #( cl_hrpad_date_computations=>subtract_months_from_date( start_date = date_in months = months ) ).

  ENDMETHOD.


  METHOD subtract_weeks_from_date.

    ro_date = NEW #( cl_hrpad_date_computations=>subtract_weeks_from_date( start_date = date_in weeks = weeks ) ).

  ENDMETHOD.


  METHOD subtract_years_from_date.

    ro_date = NEW #( cl_hrpad_date_computations=>subtract_years_from_date( start_date = date_in years = years ) ).

  ENDMETHOD.


  METHOD _get_days_per_year.

    DATA: start_date TYPE d,
          end_date   TYPE d.

    start_date = date_in.
    end_date   = date_in.
    start_date+4(4) = '0101'.
    end_date+4(4)   = '1231'.
    number_days     = end_date - start_date + 1.

  ENDMETHOD.
ENDCLASS.
