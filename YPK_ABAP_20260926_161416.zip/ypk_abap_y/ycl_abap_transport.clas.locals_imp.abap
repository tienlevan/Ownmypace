*"* use this source file for the definition and implementation of
*"* local helper classes, interface definitions and type
*"* declarations

CLASS lcl_event DEFINITION INHERITING FROM zcl_ul_alv_adapter.

  PUBLIC SECTION.
    TYPES: BEGIN OF ty_tms,
             sysnam      TYPE tmssysnam,
             systxt      TYPE as4text,
             dev_flag    TYPE flag,
             qas_flag    TYPE flag,
             prd_flag    TYPE flag,
             sync_client TYPE mandt,
           END OF ty_tms.
    CLASS-DATA: t_tms TYPE TABLE OF ty_tms.

  PROTECTED SECTION.
    METHODS: mine_hotspot_click REDEFINITION.
    METHODS: mine_user_command  REDEFINITION.
    METHODS: mine_double_click  REDEFINITION.


  PRIVATE SECTION.
    METHODS: _get_trkorr IMPORTING idx           TYPE lvc_s_row
                         RETURNING VALUE(trkorr) TYPE trkorr,
      _refresh_display, _get_rows RETURNING VALUE(rt_rows) TYPE lvc_t_row,
      _get_request IMPORTING row TYPE lvc_index RETURNING VALUE(ro_request) TYPE REF TO ycl_abap_transport.

ENDCLASS.

CLASS lcl_event IMPLEMENTATION.

  METHOD mine_hotspot_click.

    DATA(o_tms) = NEW ycl_abap_transport( _get_trkorr( e_row_id ) ).
    o_tms->read_log( iv_system = CONV #( e_column_id ) ).

  ENDMETHOD.

  METHOD mine_user_command.

    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'WB_DEV' iv_mainkey = 'SET_STMS'
                                  IMPORTING e_data         = t_tms  ).
    IF t_tms IS INITIAL.
      ycx_abap_error=>raise_message( iv_msg_text = 'No settings found!' ).
      RETURN.
    ENDIF.

    CASE e_ucomm.

      WHEN 'TRANSPORT'.
        DATA(system) = t_tms[ qas_flag = abap_true ]-sysnam.
        LOOP AT _get_rows( ) INTO DATA(s_row).
          _get_request( s_row-index )->import( iv_system = system ).
        ENDLOOP.

        WAIT UP TO 2 SECONDS.
        _refresh_display(  ).

      WHEN 'EMAIL'.
        FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.
        ASSIGN mt_outtab->* TO <ft_data>.
        CHECK <ft_data> IS NOT INITIAL.

        LOOP AT _get_rows( ) INTO s_row.

          READ TABLE <ft_data> ASSIGNING FIELD-SYMBOL(<fs_data>) INDEX s_row-index.
          ASSIGN COMPONENT 'TRKORR' OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fv_trkorr>).
          ASSIGN COMPONENT t_tms[ qas_flag = abap_true ]-sysnam OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fv_status>).

          IF <fv_status> = icon_led_red.
            ycx_abap_error=>raise_message( iv_msg_text = |Transport request { <fv_trkorr> } was transported to the quality system with error!| ).
            CONTINUE.
          ELSEIF <fv_status> = icon_led_inactive.
            ycx_abap_error=>raise_message( iv_msg_text = |Transport request { <fv_trkorr> } does not be transported to the quality system!| ).
            CONTINUE.
          ENDIF.

          _get_request( s_row-index )->send_email(  ).

        ENDLOOP.

      WHEN 'CREATE'.
        DATA: req_type TYPE trfunction,
              req_text TYPE as4text.

        CALL FUNCTION 'TRINT_POPUP_TO_CREATE_REQUEST'
          CHANGING
            cv_type = req_type
            cv_text = req_text.

        IF req_type IS NOT INITIAL AND req_text IS NOT INITIAL.
          ycx_abap_error=>raise_message( iv_msg_text = |Transport request { ycl_abap_transport=>create( iv_type = req_type iv_text = req_text )->ms_header-trkorr } was created!|
                                               iv_msg_type = ycx_abap_error=>msgtype-information ).
          _refresh_display( ).
        ELSE.
          ycx_abap_error=>raise_message( iv_msg_text = 'Must fill all fields!' ).
        ENDIF.

      WHEN 'REFRESH'.
        _refresh_display(  ).

      WHEN 'MERGE'.
        get_selected_rows( IMPORTING et_index_rows = DATA(t_rows) ).
        IF t_rows IS INITIAL.
          ycx_abap_error=>raise_message( iv_msg_text = 'Please select a row!' ).
          RETURN.
        ELSEIF lines( t_rows ) > 1.
          ycx_abap_error=>raise_message( iv_msg_text = 'Please select one row only!' ).
          RETURN.
        ENDIF.

        DATA(s_request) = VALUE trwbo_request( h = CORRESPONDING #( _get_request( t_rows[ 1 ]-index )->ms_header ) ).
        s_request-h-clients_filled = abap_true.
        CALL FUNCTION 'TR_MERGE_REQUESTS'
          EXPORTING
            is_request_from        = s_request
          EXCEPTIONS
            action_aborted_by_user = 1
            error_db_access        = 2
            illegal_from_request   = 3
            illegal_to_request     = 4
            requests_dont_match    = 5
            request_locked         = 6
            OTHERS                 = 7.
        CHECK sy-subrc IS NOT INITIAL.
        MESSAGE ID sy-msgid TYPE 'I' NUMBER sy-msgno WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.

      WHEN 'INCLD'.
        get_selected_rows( IMPORTING et_index_rows = t_rows ).
        IF t_rows IS INITIAL.
          ycx_abap_error=>raise_message( iv_msg_text = 'Please select a row!' ).
          RETURN.
        ELSEIF lines( t_rows ) > 1.
          ycx_abap_error=>raise_message( iv_msg_text = 'Please select one row only!' ).
          RETURN.
        ENDIF.

        _get_request( t_rows[ 1 ]-index )->included_tr(  ).

      WHEN 'EXPORT'.
        get_selected_rows( IMPORTING et_index_rows = t_rows ).
        IF t_rows IS INITIAL.
          ycx_abap_error=>raise_message( iv_msg_text = 'Please select a row!' ).
          RETURN.
        ELSEIF lines( t_rows ) > 1.
          ycx_abap_error=>raise_message( iv_msg_text = 'Please select one row only!' ).
          RETURN.
        ENDIF.

        _get_request( t_rows[ 1 ]-index )->export_tr_file( ).

      WHEN 'IMPORT'.
        ycl_abap_transport=>import_tr_file( ).
        WAIT UP TO 2 SECONDS.
        _refresh_display( ).

      WHEN 'TOC'.
        t_rows = _get_rows( ).
        DATA(request) = _get_request( t_rows[ 1 ]-index ).
        DATA(transport_text) = |{ request->ms_header-as4text }_ToC|.
        DATA(toc_request) = ycl_abap_transport=>create( iv_target = request->ms_header-tarsystem
                                                        iv_text   = CONV #( transport_text )
                                                        iv_type   = ycl_abap_transport=>mc_req_type-transport_copy  ).
        CHECK toc_request IS BOUND.
        LOOP AT t_rows INTO s_row.
          toc_request->copy_tr( _get_request( s_row-index )->ms_header-trkorr ).
        ENDLOOP.

        MESSAGE |ToC { toc_request->ms_header-trkorr } was created!| TYPE 'S'.
        _refresh_display( ).

      WHEN 'DELETE'.
        LOOP AT _get_rows( ) INTO s_row.
          _get_request( s_row-index )->delete_tr( ).
        ENDLOOP.
        _refresh_display( ).


    ENDCASE.

  ENDMETHOD.

  METHOD mine_double_click.

    DATA(trkorr) = _get_trkorr( CONV #( e_row-index ) ).
    DATA(request) = NEW ycl_abap_transport( trkorr  ).
    IF request->ms_header-trstatus NE ycl_abap_transport=>mc_tr_status-released.
      set_visible( abap_false ).
      request->call_tr_organizer( ).
      set_visible( abap_true ).
    ELSE.
      CALL FUNCTION 'TRINT_TDR_USER_COMMAND'
        EXPORTING
          iv_object  = trkorr
          iv_type    = 'REQU'
          iv_command = 'REQUEST_SHOW'.
    ENDIF.

  ENDMETHOD.

  METHOD _get_trkorr.

    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.
    ASSIGN mt_outtab->* TO <ft_data>.
    CHECK <ft_data> IS NOT INITIAL.
    READ TABLE <ft_data> ASSIGNING FIELD-SYMBOL(<fs_data>) INDEX idx.
    ASSIGN COMPONENT 'TRKORR' OF STRUCTURE <fs_data> TO FIELD-SYMBOL(<fv_value>).
    trkorr = <fv_value>.

  ENDMETHOD.

  METHOD _refresh_display.

    FIELD-SYMBOLS <ft_data> TYPE STANDARD TABLE.
    CHECK mt_outtab IS NOT INITIAL.
    ASSIGN mt_outtab->* TO <ft_data>.
    ycl_abap_transport=>compare_tr_system( IMPORTING et_data = <ft_data> ).
    refresh(  ).

  ENDMETHOD.


  METHOD _get_request.

    ro_request = NEW ycl_abap_transport( _get_trkorr( CONV #( row ) ) ).

  ENDMETHOD.

  METHOD _get_rows.

    get_selected_rows( IMPORTING et_index_rows = rt_rows ).
    IF rt_rows IS INITIAL.
      ycx_abap_error=>raise_message( iv_msg_text = 'Please select at least one row!' ).
      RETURN.
    ENDIF.

  ENDMETHOD.

ENDCLASS.
