*"* use this source file for the definition and implementation of
*"* local helper classes, interface definitions and type
*"* declarations
CLASS lcl_event DEFINITION INHERITING FROM zcl_ul_alv_adapter.

  PROTECTED SECTION.
    METHODS: mine_hotspot_click REDEFINITION.

ENDCLASS.

CLASS lcl_event IMPLEMENTATION.

  METHOD mine_hotspot_click.
    DATA data TYPE ycx_abap_error=>ty_message.
    DATA help_info TYPE help_info.
    DATA t_dselcs TYPE TABLE OF dselc.
    DATA t_dvals TYPE TABLE OF dval.
    FIELD-SYMBOLS <ft_data> TYPE INDEX TABLE.
    ASSIGN mt_outtab->* TO <ft_data>.
    get_sel_row_data( IMPORTING es_result = data ).
    CASE e_column_id.
      WHEN 'DOCFLAG'.
        help_info = VALUE #( call = 'D' program = sy-cprog spras = sy-langu messageid = data-msgid messagenr = data-msgno
                             msgv1 = data-msgv1 msgv2 = data-msgv2 msgv3 = data-msgv3 msgv4 = data-msgv4 docuid = 'NA' ).
        CALL FUNCTION 'HELP_START'
          EXPORTING
            help_infos   = help_info
          TABLES
            dynpselect   = t_dselcs
            dynpvaluetab = t_dvals.
      WHEN 'ERRLOC'.
        SUBMIT tpda_editor_start AND RETURN
         WITH prgm  = data-program
         WITH incl  = data-include
         WITH dynp  = space
         WITH line  = data-line.
    ENDCASE.
  ENDMETHOD.
ENDCLASS.
