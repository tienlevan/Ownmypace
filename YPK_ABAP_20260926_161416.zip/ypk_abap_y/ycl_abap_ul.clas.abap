CLASS ycl_abap_ul DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.
    TYPE-POOLS js .

    TYPES abap_encoding TYPE char20 .
    TYPES lty_keycol_type TYPE string .
    TYPES lty_last_display_mode TYPE string .
    TYPES lty_commandid TYPE i .
    TYPES:
      lty_gen_prog_nro(10) TYPE n .
    TYPES lty_zhtdb_table_type TYPE string .
    TYPES lty_zhtdb_vrange_text TYPE string .
    TYPES:
      BEGIN OF lty_zhtdb_alv_tab,
        ddtext    TYPE lty_zhtdb_vrange_text,
        tablename TYPE tabname,
        fieldname TYPE fieldname,
        alias     TYPE tabname,
      END OF lty_zhtdb_alv_tab .
    TYPES:
      BEGIN OF lty_zhtdb_checktable_struc,
        tabname    TYPE tabname,
        fieldname  TYPE forfield,
        forkey     TYPE forkey,
        cardleft   TYPE cardleft,
        card       TYPE card,
        checktable TYPE checktable,
      END OF lty_zhtdb_checktable_struc .
    TYPES lty_zhtdb_join_text TYPE string .
    TYPES:
      BEGIN OF lty_zhtdb_checktable_struc_alv,
        tabname  TYPE tabname,
        ddtext   TYPE as4text,
        longtext TYPE lty_zhtdb_join_text,
      END OF lty_zhtdb_checktable_struc_alv .
    TYPES:
      BEGIN OF lty_zhtdb_fieldinfo,
        table           TYPE tabname,
        field           TYPE fieldname,
        is_key          TYPE flag,
        orig_field      TYPE char50,
        field_alias     TYPE char50,
        table_alias     TYPE char50,
        agg_function    TYPE char50,
        distinctf       TYPE flag,
        generated_field TYPE char50,
        samecount       TYPE int4,
      END OF lty_zhtdb_fieldinfo .
    TYPES:
      BEGIN OF lty_zhtdb_keyword,
        keyword   TYPE string,
        required  TYPE string,
        order_pos TYPE i,
        begins_at TYPE i,
        ends_at   TYPE i,
        additions TYPE string,
        text      TYPE string,
      END OF lty_zhtdb_keyword .
    TYPES:
      BEGIN OF lty_zhtdb_sign_pos,
        position TYPE i,
        type     TYPE char3,
      END OF lty_zhtdb_sign_pos .
    TYPES:
      BEGIN OF lty_zhtdb_table_aliases,
        table         TYPE tabname,
        alias         TYPE string,
        explain_alias TYPE string,
        type          TYPE lty_zhtdb_table_type,
        position      TYPE i,
      END OF lty_zhtdb_table_aliases .
    TYPES:
      lty_zhtdbt_string_tab          TYPE TABLE OF string .
    TYPES:
      lty_zhtdb_fieldinfo_tt         TYPE TABLE OF lty_zhtdb_fieldinfo .
    TYPES:
      lty_zhtdb_sign_pos_tt          TYPE TABLE OF lty_zhtdb_sign_pos .
    TYPES:
      lty_zhtdb_table_aliases_tt     TYPE TABLE OF lty_zhtdb_table_aliases .
    TYPES:
      BEGIN OF lty_zhdb_vrange,
        alias      TYPE tabname,
        rsds_range TYPE rsds_range,
      END OF lty_zhdb_vrange .
    TYPES:
      lty_zhdb_vrange_tab            TYPE STANDARD TABLE OF lty_zhdb_vrange .
    TYPES lty_colmn_header TYPE string .
    TYPES:
      BEGIN OF ty_notes,
        line TYPE string,
      END OF ty_notes .
    TYPES gty_tb_name TYPE dd02d-dbtabname .
    TYPES gty_fld_name TYPE dd03p-fieldname .
    TYPES gty_fieldinfo TYPE lty_zhtdb_fieldinfo .
    TYPES gty_table_aliases TYPE lty_zhtdb_table_aliases .
    TYPES:
      BEGIN OF gty_ddicref,
        fieldname  TYPE gty_fld_name,
        checktable TYPE tabname,
        ref_table  TYPE gty_tb_name,
        ref_field  TYPE gty_fld_name,
        key        TYPE string,
      END OF gty_ddicref .
    TYPES:
      BEGIN OF source,
        line TYPE string,
      END OF source .
    TYPES source_table TYPE soli_tab .
    TYPES gty_commandtext TYPE string .
    TYPES:
      BEGIN OF gty_linkedquery,
        fcode      TYPE ui_func,
        tabname    TYPE gty_tb_name,
        checktable TYPE gty_tb_name,
        fieldname  TYPE gty_fld_name,
        checkfield TYPE gty_fld_name,
        text       TYPE char40,
        longtext   TYPE char255,
        join_type  TYPE string,
        ddtext     TYPE dd02t-ddtext,
        primpos    TYPE dd05m-primpos,
      END OF gty_linkedquery .
    TYPES:
      BEGIN OF gty_ranges,
        table_alias TYPE string,
        fieldname   TYPE dd03p-fieldname,
        range       TYPE rsds_selopt_t,
        node_text   TYPE lvc_value,
        node_key    TYPE lvc_nkey,
        where_text  TYPE string,
      END OF gty_ranges .
    TYPES:
      BEGIN OF gty_tab_node_xref,
        node_key  TYPE lvc_nkey,
        tablename TYPE tabname,
        alias     TYPE string,
      END OF gty_tab_node_xref .
    TYPES:
      BEGIN OF gty_alias_ranges,
        table_alias TYPE string,
        fields      TYPE rsdsfields_t,
        expr        TYPE rsds_texpr,
        sel_id      TYPE rsdynsel-selid,
        active      TYPE i,
      END OF gty_alias_ranges .
    TYPES:
      BEGIN OF mty_t_type,
        line(255),
      END OF mty_t_type .
    TYPES:
      xuobject_t TYPE TABLE OF ust12 .
    TYPES:
      mty_tt_type  TYPE STANDARD TABLE OF mty_t_type WITH NON-UNIQUE DEFAULT KEY INITIAL SIZE 500 .

    CONSTANTS gc_line_length TYPE i VALUE 132 ##NO_TEXT.
    CONSTANTS:
      BEGIN OF mc_encoding,
        win_1251 TYPE abap_encoding VALUE '1504',
        utf_8    TYPE abap_encoding VALUE '4110',
        utf_16be TYPE abap_encoding VALUE '4102',
        utf_16le TYPE abap_encoding VALUE '4103',
      END OF mc_encoding .
    CONSTANTS:
      BEGIN OF mc_json_mode,
        standard TYPE string VALUE '1-2',
        safe     TYPE string VALUE '2-1',
      END OF mc_json_mode .
    CLASS-DATA cx_error TYPE REF TO ycx_abap_error .

    CLASS-METHODS class_constructor .
    CLASS-METHODS split_string
      IMPORTING
        !iv_string     TYPE string
        !iv_maxlen     TYPE i
        !iv_log_handle TYPE balloghndl OPTIONAL
      EXPORTING
        !et_string_tab TYPE lty_zhtdbt_string_tab .
    CLASS-METHODS get_word_at_pos
      IMPORTING
        !iv_string   TYPE string
        !iv_position TYPE i
      EXPORTING
        !ev_word     TYPE string .
    CLASS-METHODS parse_aptph
      IMPORTING
        !iv_condense   TYPE flag DEFAULT 'X'
        !iv_log_handle TYPE balloghndl OPTIONAL
      EXPORTING
        !et_aptph_pos  TYPE lty_zhtdb_sign_pos_tt
        !et_paranth    TYPE lty_zhtdb_sign_pos_tt
      CHANGING
        !cv_string     TYPE string
      EXCEPTIONS
        missing_aptph
        missing_parnth .
    CLASS-METHODS select_single_gen
      IMPORTING
        !is_key_value  TYPE REF TO data
        !iv_table_name TYPE strukname
        !it_keyf_list  TYPE lty_zhtdbt_string_tab
      EXPORTING
        !es_record     TYPE REF TO data .
    CLASS-METHODS convert_to_uppercase
      CHANGING
        !cv_string TYPE string .
    CLASS-METHODS pretty_printer
      CHANGING
        !ct_source TYPE soli_tab .
    CLASS-METHODS is_client_field
      IMPORTING
        !iv_tabname            TYPE tabname
        !iv_fieldname          TYPE fieldname
      RETURNING
        VALUE(ev_client_field) TYPE char1 .
    CLASS-METHODS has_client_field
      IMPORTING
        !iv_tabname                TYPE tabname
      RETURNING
        VALUE(ev_has_client_field) TYPE char1 .
    CLASS-METHODS pretty_printer_string
      CHANGING
        !ct_source TYPE lty_zhtdbt_string_tab .
    CLASS-METHODS determinte_tab_type
      IMPORTING
        !iv_table      TYPE tabname
      RETURNING
        VALUE(ev_type) TYPE lty_zhtdb_table_type
      EXCEPTIONS
        table_not_exist .
    CLASS-METHODS popup_to_confirm
      IMPORTING
        !iv_text        TYPE string DEFAULT 'Confirm Data?'
      RETURNING
        VALUE(rv_value) TYPE char1 .
    CLASS-METHODS set_dynpro_drop
      IMPORTING
        !iv_id         TYPE vrm_id
        !it_values     TYPE vrm_values OPTIONAL
        !iv_use_domval TYPE char40 OPTIONAL .
    CLASS-METHODS create_wf_item
      IMPORTING
        !iv_objtype    TYPE swr_struct-object_typ
        !iv_objkey     TYPE swr_struct-object_key
        !is_event      TYPE swr_struct-event
        !it_container  TYPE swrtcont
      RETURNING
        VALUE(rv_code) TYPE sy-subrc .
    CLASS-METHODS get_name_user
      IMPORTING
        !iv_user            TYPE bapibname
      RETURNING
        VALUE(rv_user_name) TYPE string .
    CLASS-METHODS convert_timestamp
      IMPORTING
        !iv_timestamp         TYPE timestamp OPTIONAL
        !iv_input             TYPE boolean DEFAULT abap_true
      RETURNING
        VALUE(rv_covertvalue) TYPE string .
    CLASS-METHODS encode_timestamp
      IMPORTING
        !iv_time            TYPE char19 OPTIONAL
        !iv_timezone        TYPE tznzone DEFAULT 'UTC'
      RETURNING
        VALUE(rv_timestamp) TYPE timestamp .
    CLASS-METHODS write_change_log
      IMPORTING
        !it_data_new TYPE INDEX TABLE OPTIONAL
        !iv_class    TYPE cdobjectcl DEFAULT 'ZCD_RESALE'
        !is_data_new TYPE data .
    CLASS-METHODS show_change_log
      IMPORTING
        !iv_class       TYPE cdobjectcl DEFAULT 'ZCD_RESALE'
        !is_data        TYPE data OPTIONAL
        !iv_tabname     TYPE tabname OPTIONAL
        !is_header      TYPE data
        !iv_line_offset TYPE string OPTIONAL
        !iv_objectid    TYPE cdobjectv OPTIONAL .
    CLASS-METHODS build_key
      IMPORTING
        !is_data       TYPE any
        !iv_add_client TYPE boolean DEFAULT abap_false
      EXPORTING
        !ev_tabname    TYPE tabname
      RETURNING
        VALUE(rv_key)  TYPE string .
    CLASS-METHODS if_exist_data
      IMPORTING
        !iv_tabname     TYPE tabname OPTIONAL
        !is_data        TYPE any
        !iv_key_apply   TYPE boolean DEFAULT abap_false
      RETURNING
        VALUE(rv_exist) TYPE boolean .
    CLASS-METHODS get_message_text
      RETURNING
        VALUE(rv_message) TYPE string .
    CLASS-METHODS conv_to_interal_date
      IMPORTING
        !iv_date       TYPE any
      RETURNING
        VALUE(rv_date) TYPE sy-datum .
    CLASS-METHODS conv_to_external_date
      IMPORTING
        !iv_date       TYPE sy-datum
      RETURNING
        VALUE(rv_date) TYPE char10 .
    CLASS-METHODS get_next_number
      IMPORTING
        !iv_number_range TYPE inri-nrrangenr
        !iv_object       TYPE inri-object
        !iv_to_year      TYPE inri-toyear DEFAULT '0000'
      RETURNING
        VALUE(rv_number) TYPE string
      RAISING
        ycx_abap_error .
    CLASS-METHODS get_stvarv_val
      IMPORTING
        !iv_varname      TYPE rvari_vnam
      RETURNING
        VALUE(rt_varval) TYPE ztt_range
      RAISING
        ycx_abap_error .
    CLASS-METHODS check_authourized
      IMPORTING
        !iv_user             TYPE usr02-bname DEFAULT sy-uname
        !it_objects          TYPE xuobject_t OPTIONAL
        !it_values           TYPE susr_t_usvalues
      RETURNING
        VALUE(rv_authorized) TYPE abap_bool .
    CLASS-METHODS binary_to_string
      IMPORTING
        !it_table        TYPE STANDARD TABLE
        !iv_length       TYPE i
        !iv_encoding     TYPE abap_encoding DEFAULT mc_encoding-utf_8
      RETURNING
        VALUE(rv_string) TYPE string .
    CLASS-METHODS binary_to_xstring
      IMPORTING
        !it_table         TYPE STANDARD TABLE
        !iv_length        TYPE i
      RETURNING
        VALUE(rv_xstring) TYPE xstring .
    CLASS-METHODS xstring_to_binary
      IMPORTING
        !iv_xstring TYPE xstring
      EXPORTING
        !ev_length  TYPE i
        !et_table   TYPE solix_tab .
    CLASS-METHODS xstring_to_base64
      IMPORTING
        !iv_xstring      TYPE xstring
      RETURNING
        VALUE(rv_base64) TYPE string .
    CLASS-METHODS xstring_to_string
      IMPORTING
        !iv_xstring      TYPE xstring
        !iv_encoding     TYPE abap_encoding DEFAULT mc_encoding-utf_8
      RETURNING
        VALUE(rv_string) TYPE string .
    CLASS-METHODS string_to_xstring
      IMPORTING
        !iv_string        TYPE string
        !iv_encoding      TYPE abap_encoding DEFAULT mc_encoding-utf_8
      RETURNING
        VALUE(rv_xstring) TYPE xstring .
    CLASS-METHODS string_to_text_table
      IMPORTING
        !iv_string TYPE string
      EXPORTING
        !et_text   TYPE table
        !ev_length TYPE i .
    CLASS-METHODS to_json
      IMPORTING
        !im_data       TYPE any
        !iv_pure       TYPE abap_bool DEFAULT abap_false
      RETURNING
        VALUE(rv_json) TYPE string .
    CLASS-METHODS from_json
      IMPORTING
        !iv_json TYPE string
        !iv_mode TYPE string DEFAULT mc_json_mode-standard
      EXPORTING
        !ex_data TYPE any
        !ev_ok   TYPE abap_bool .
    CLASS-METHODS xml_from_zip
      IMPORTING
        !io_zip    TYPE REF TO cl_abap_zip
        !iv_name   TYPE csequence
      EXPORTING
        !eo_xmldoc TYPE REF TO if_ixml_document
        !ev_sdoc   TYPE string .
    CLASS-METHODS xml_to_zip
      IMPORTING
        !io_zip    TYPE REF TO cl_abap_zip
        !iv_name   TYPE string
        !iv_xdoc   TYPE xstring OPTIONAL
        !iv_sdoc   TYPE string OPTIONAL
        !io_xmldoc TYPE REF TO if_ixml_document OPTIONAL .
    CLASS-METHODS xml_to_str
      IMPORTING
        !io_doc  TYPE REF TO if_ixml_document
      EXPORTING
        !ev_str  TYPE string
        !ev_xstr TYPE xstring .
    CLASS-METHODS str_to_xml
      IMPORTING
        !iv_str       TYPE string OPTIONAL
        !iv_xstr      TYPE xstring OPTIONAL
      RETURNING
        VALUE(ro_doc) TYPE REF TO if_ixml_document .
    CLASS-METHODS convert_amt_currency
      IMPORTING
        !iv_format       TYPE i DEFAULT 0
        !iv_amount       TYPE any
        !iv_currency     TYPE waers_curc DEFAULT 'VND'
      RETURNING
        VALUE(rv_amount) TYPE bapicurr_d .
    CLASS-METHODS file_download
      IMPORTING
        !default_extension   TYPE string OPTIONAL
        !prompt_on_overwrite TYPE boole_d DEFAULT abap_true
        !code_page           TYPE abap_encoding DEFAULT '4110'
        !file_type           TYPE char10 DEFAULT 'BIN'
        !bin_size            TYPE i OPTIONAL
      CHANGING
        !file_name           TYPE string
        !data_tab            TYPE ANY TABLE .
    CLASS-METHODS string_to_range
      IMPORTING
        !iv_string      TYPE string
      RETURNING
        VALUE(rt_range) TYPE ztt_range .
    CLASS-METHODS f4_int_table_request
      IMPORTING
        !it_values       TYPE STANDARD TABLE
        !it_map_name     TYPE dfies_tab OPTIONAL
        !iv_retfield     TYPE fieldname
      RETURNING
        VALUE(rt_values) TYPE umc_yt_ddshretval .
    CLASS-METHODS string_split_space
      IMPORTING
        !iv_string  TYPE string
        !iv_max_len TYPE i
      EXPORTING
        !ev_str1    TYPE string
        !ev_str2    TYPE string
        !ev_str3    TYPE string
        !ev_str4    TYPE string
        !ev_str5    TYPE string .
    CLASS-METHODS build_text
      IMPORTING
        !is_data       TYPE any
        !iv_textid     TYPE char5
        !iv_textmd     TYPE char5 DEFAULT 'H2H'
      RETURNING
        VALUE(rv_text) TYPE string
      RAISING
        ycx_abap_error .
    CLASS-METHODS call_method_rfc
      IMPORTING
        !iv_destination TYPE string
        !it_exceptions  TYPE abap_excpbind_tab OPTIONAL
        !iv_class       TYPE seoclsname
        !iv_method      TYPE seocpdname
      CHANGING
        !ct_parameters  TYPE abap_parmbind_tab OPTIONAL .
    CLASS-METHODS call_function_rfc
      IMPORTING
        !iv_function    TYPE rs38l_fnam
        !iv_destination TYPE string
        !it_exceptions  TYPE abap_func_excpbind_tab
      CHANGING
        !ct_parameters  TYPE abap_func_parmbind_tab .
    CLASS-METHODS remove_diacritics
      IMPORTING
        !iv_input        TYPE string
      RETURNING
        VALUE(rv_output) TYPE string .
  PROTECTED SECTION.
  PRIVATE SECTION.

    CLASS-METHODS _abap_2_json
      IMPORTING
        !im_data       TYPE data
        !iv_name       TYPE string OPTIONAL
      RETURNING
        VALUE(rv_json) TYPE string .
    CLASS-METHODS _json_2_abap
      IMPORTING
        !json_string          TYPE string OPTIONAL
        !var_name             TYPE string OPTIONAL
        !property_path        TYPE string DEFAULT 'json_obj'
      EXPORTING
        VALUE(property_table) TYPE js_property_tab
      CHANGING
        !js_object            TYPE REF TO cl_java_script OPTIONAL
        VALUE(abap_data)      TYPE any OPTIONAL .
    CLASS-METHODS _get_last_space
      IMPORTING
        !iv_string       TYPE string
        !iv_max_len      TYPE i
      RETURNING
        VALUE(rv_offset) TYPE i .
ENDCLASS.



CLASS ycl_abap_ul IMPLEMENTATION.


  METHOD binary_to_string.
    TRY.
        CALL FUNCTION 'SCMS_BINARY_TO_STRING'
          EXPORTING
            input_length = iv_length
            encoding     = iv_encoding
          IMPORTING
            text_buffer  = rv_string
          TABLES
            binary_tab   = it_table.
      CATCH cx_sy_dyn_call_error. " TODO CONV classes?
        CALL FUNCTION 'SCMS_BINARY_TO_STRING'
          EXPORTING
            input_length = iv_length
          IMPORTING
            text_buffer  = rv_string
          TABLES
            binary_tab   = it_table.
    ENDTRY.
  ENDMETHOD.


  METHOD binary_to_xstring.
    CALL FUNCTION 'SCMS_BINARY_TO_XSTRING'
      EXPORTING
        input_length = iv_length
      IMPORTING
        buffer       = rv_xstring
      TABLES
        binary_tab   = it_table.
  ENDMETHOD.


  METHOD build_key.

    DATA: lt_tabfield      TYPE TABLE OF dbfield,
          lv_value         TYPE string,
          lr_client_fields TYPE RANGE OF dbfield-name.

    CHECK is_data IS NOT INITIAL.

    TRY.
        NEW ycl_abap_rtts( iv_data = is_data )->get_struct_inf( IMPORTING et_ddic_fields = DATA(lt_ddic) ).
      CATCH ycx_abap_error INTO cx_error.
        cx_error->show_message( ).
        RETURN.
    ENDTRY.

    CHECK lt_ddic IS NOT INITIAL.
    ev_tabname = lt_ddic[ 1 ]-tabname.

    CALL FUNCTION 'DB_GET_TABLE_FIELDS'
      EXPORTING
        tabname  = ev_tabname
      TABLES
        dbfields = lt_tabfield.

    lr_client_fields = zcl_ul_abap=>string_to_range( 'MANDT, CLIENT' ).

    LOOP AT lt_tabfield INTO DATA(ls_tabfield) WHERE keyflag IS NOT INITIAL.
      IF iv_add_client = abap_false AND ls_tabfield-name IN lr_client_fields.
        CONTINUE.
      ENDIF.
      ASSIGN COMPONENT ls_tabfield-name OF STRUCTURE is_data TO FIELD-SYMBOL(<fv_value>).
      IF <fv_value> IS ASSIGNED.
        IF ls_tabfield-name IN lr_client_fields AND <fv_value> IS INITIAL AND iv_add_client = abap_true.
          MOVE sy-mandt TO lv_value.
        ELSE.
          lv_value = <fv_value>.
        ENDIF.
        DO ls_tabfield-length - strlen( lv_value ) TIMES.
          CONCATENATE lv_value cl_abap_char_utilities=>backspace INTO lv_value.
        ENDDO.
      ENDIF.
      rv_key = |{ rv_key }{ lv_value }|.
      CLEAR lv_value.
    ENDLOOP.

    CHECK rv_key IS NOT INITIAL.
    REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>backspace IN rv_key WITH ` `.

  ENDMETHOD.


  METHOD build_text.

    DATA result_tab TYPE match_result_tab.

    "Force text trading partner
    ASSIGN COMPONENT 'VBUND' OF STRUCTURE is_data TO FIELD-SYMBOL(<t>).
    IF <t> IS ASSIGNED.
      IF <t> IS INITIAL OR iv_textid = 'TXT05'.
        SELECT SINGLE FROM ztb_set_text FIELDS textval WHERE textmd = @iv_textmd AND textid = @iv_textid
        INTO @DATA(text).
      ELSE.
        ASSIGN COMPONENT 'ZBUKR' OF STRUCTURE is_data TO FIELD-SYMBOL(<b>).
        SELECT SINGLE FROM t001 FIELDS rcomp WHERE bukrs = @<b> INTO @DATA(vbund).
        IF iv_textid = 'TXT00'.
          text = |{ vbund }&VBLNR& &REQINFFRACCTACCTTITL& PAYS FOR VENDOR &LIFNR&|.
        ELSE.
          text = |{ vbund }&VBLNR& &SGTXT&|.
        ENDIF.
      ENDIF.
    ENDIF.

    IF text IS INITIAL.
      cx_error->add_text( iv_message = 'No text id &1 does not exist in module &2' iv_variable_1 = CONV #( iv_textid ) iv_variable_2 = CONV #( iv_textmd ) ).
      RAISE EXCEPTION cx_error.
    ENDIF.

    FIND ALL OCCURRENCES OF '&' IN text RESPECTING CASE RESULTS result_tab.
    SORT result_tab ASCENDING BY offset.
    rv_text = text.

    LOOP AT result_tab INTO DATA(result).
      IF sy-tabix MOD 2 NE 0.
        DATA(f) = result-offset.
      ELSE.
        DATA(s) = result-offset.
        DATA(l) = s - f + 1.
        DATA(r) = to_upper( text+f(l) ).
        DATA(c) = r.
        REPLACE ALL OCCURRENCES OF '&' IN c WITH space. CONDENSE c.
        ASSIGN COMPONENT c OF STRUCTURE is_data TO FIELD-SYMBOL(<v>).
        "Special convert for TCB
        IF c = 'REQINFFRACCTACCTTITL'.
          ASSIGN COMPONENT 'SYSTEM_BANK' OF STRUCTURE is_data TO FIELD-SYMBOL(<bank>).
          IF <bank> = 'TCB'.
            DATA(len) = strlen( <v> ) - 1.
          ENDIF.
        ENDIF.

        IF <v> IS ASSIGNED.
          IF len > 0.
            REPLACE r IN rv_text WITH <v>(len).
          ELSE.
            REPLACE r IN rv_text WITH <v>.
          ENDIF.
          UNASSIGN <v>.
          CLEAR len.
        ELSE.
          "Build on top
          IF c EQ 'ZBUKR_NAME'.
            ASSIGN COMPONENT 'ZBUKR' OF STRUCTURE is_data TO FIELD-SYMBOL(<c>).
            IF <c> IS ASSIGNED.
              SELECT SINGLE FROM ztb_cdt_map FIELDS * WHERE zbukr = @<c> INTO @DATA(s_zbukr).
              IF sy-subrc IS INITIAL.
                ASSIGN COMPONENT c OF STRUCTURE s_zbukr TO <v>.
                REPLACE r IN rv_text WITH <v>.
                UNASSIGN: <v>, <c>.
              ENDIF.
            ENDIF.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.


  METHOD call_function_rfc.

    CALL TRANSFORMATION id SOURCE mydata = ct_parameters
                           RESULT XML DATA(parameters)
                           OPTIONS data_refs = 'heap-or-create'.

    CALL TRANSFORMATION id SOURCE mydata = it_exceptions
                           RESULT XML DATA(exceptions).

    CALL FUNCTION 'ZFM_RFC_CALL_FUNCTION'
      DESTINATION iv_destination
      EXPORTING
        iv_function        = iv_function
        iv_exceptions      = exceptions
      CHANGING
        cv_parameters      = parameters
      EXCEPTIONS
        dynamic_call_error = 1
        OTHERS             = 2.

    IF sy-subrc IS NOT INITIAL.
      ycx_abap_error=>raise_message( EXPORTING iv_msg_text = 'Error in call RFC FM!' ). RETURN.
    ENDIF.

    CALL TRANSFORMATION id SOURCE XML parameters
                        RESULT  mydata = ct_parameters.

  ENDMETHOD.


  METHOD call_method_rfc.

    CALL TRANSFORMATION id SOURCE mydata = ct_parameters
    RESULT XML DATA(parameters)
    OPTIONS data_refs = 'heap-or-create'.

    CALL TRANSFORMATION id SOURCE mydata = it_exceptions
    RESULT XML DATA(exceptions).

    CALL FUNCTION 'ZFM_RFC_CALL_METHOD'
      DESTINATION iv_destination
      EXPORTING
        iv_class           = iv_class
        iv_method          = iv_method
        iv_exceptions      = exceptions
      CHANGING
        cv_parameters      = parameters
      EXCEPTIONS
        dynamic_call_error = 1
        not_valid_method   = 2
        OTHERS             = 3.

    IF sy-subrc IS NOT INITIAL.
      ycx_abap_error=>raise_message( EXPORTING iv_msg_text = 'Error in call RFC Method!' ). RETURN.
    ENDIF.

    CALL TRANSFORMATION id SOURCE XML parameters
                        RESULT  mydata = ct_parameters.

  ENDMETHOD.


  METHOD check_authourized.

    DATA: lv_full_authorized TYPE sap_bool,
          lt_values          TYPE TABLE OF usvalues.
    DATA: lt_objects TYPE xuobject_t.

    IF it_objects IS INITIAL.
      DATA(lt_copy_objects) = it_values.
      DELETE ADJACENT DUPLICATES FROM lt_copy_objects COMPARING objct.
      lt_objects = VALUE #( FOR ls_copy_object IN lt_copy_objects ( CONV #( ls_copy_object-objct ) ) ).
    ELSE.
      lt_objects = it_objects.
    ENDIF.

    LOOP AT lt_objects INTO DATA(ls_object).

      CALL FUNCTION 'SUSR_USER_AUTH_FOR_OBJ_GET'
        EXPORTING
          user_name                     = iv_user
          sel_object                    = ls_object
          optimize                      = abap_true
          respect_disablemnt_4_auth_chk = abap_true
        IMPORTING
          fully_authorized              = lv_full_authorized
        TABLES
          values                        = lt_values
        EXCEPTIONS
          user_name_not_exist           = 1
          not_authorized                = 2
          internal_error                = 3
          OTHERS                        = 4.

      IF sy-subrc IS NOT INITIAL.
        cx_error->add_system_message( ).
        cx_error->show_message( ).
        rv_authorized = abap_false.
        EXIT.
      ELSE.
        IF lv_full_authorized IS NOT INITIAL.
          rv_authorized = abap_true.
          CONTINUE.
        ELSE.
          DELETE ADJACENT DUPLICATES FROM lt_values COMPARING objct von bis.
          SORT lt_values BY objct field.
          LOOP AT lt_values INTO DATA(lg_value) GROUP BY ( key1 = lg_value-objct key2 = lg_value-field ) INTO DATA(lt_m_values).
            LOOP AT GROUP lt_m_values INTO DATA(ls_value).
              READ TABLE it_values INTO DATA(ls_object_value) WITH KEY objct = ls_value-objct field = ls_value-field.
              IF sy-subrc IS NOT INITIAL. DATA(lv_skip) = abap_true. CONTINUE.ENDIF.
              IF ls_value-bis IS NOT INITIAL.
                IF ls_object_value-bis IS NOT INITIAL.
                  IF ls_value-von = ls_object_value-von AND ls_value-bis = ls_object_value-bis.
                    rv_authorized = abap_true.
                    EXIT.
                  ELSE.
                    rv_authorized = abap_false.
                  ENDIF.
                ELSE.
                  IF ls_object_value-von BETWEEN ls_value-von AND ls_value-bis.
                    rv_authorized = abap_true.
                    EXIT.
                  ELSE.
                    rv_authorized = abap_false.
                  ENDIF.
                ENDIF.
              ELSE.
                IF ls_object_value-von = ls_value-von.
                  rv_authorized = abap_true.
                  EXIT.
                ELSE.
                  rv_authorized = abap_false.
                ENDIF.
              ENDIF.
            ENDLOOP.
            IF rv_authorized = abap_true OR lv_skip IS NOT INITIAL.
              CLEAR lv_skip. CONTINUE.
            ELSE.
              EXIT.
            ENDIF.
          ENDLOOP.
        ENDIF.
      ENDIF.

      IF rv_authorized = abap_true.
        CONTINUE.
      ELSE.
        EXIT.
      ENDIF.

    ENDLOOP.

  ENDMETHOD.


  METHOD class_constructor.

    CREATE OBJECT cx_error.

  ENDMETHOD.


  METHOD convert_amt_currency.

    TRY.

        CASE iv_format.

          WHEN 0.
            CALL FUNCTION 'BAPI_CURRENCY_CONV_TO_INTERNAL'
              EXPORTING
                amount_external      = CONV bapicurr_d( iv_amount )
                currency             = iv_currency
                max_number_of_digits = 20
              IMPORTING
                amount_internal      = rv_amount.
          WHEN 1.
            CALL FUNCTION 'BAPI_CURRENCY_CONV_TO_EXTERNAL'
              EXPORTING
                amount_internal = iv_amount
                currency        = iv_currency
              IMPORTING
                amount_external = rv_amount.
        ENDCASE.

      CATCH cx_sy_conversion_no_number INTO DATA(cx).
        cx_error->add_exception_object( cx ).
        cx_error->show_message( ).
    ENDTRY.

  ENDMETHOD.


  METHOD convert_timestamp.

    IF iv_timestamp IS NOT INITIAL.
      DATA(lv_timestamp) = iv_timestamp.
    ELSE.
      GET TIME STAMP FIELD lv_timestamp.
    ENDIF.

    IF iv_input IS NOT INITIAL.
      CONVERT TIME STAMP lv_timestamp TIME ZONE 'UTC'
             INTO DATE DATA(lv_date) TIME DATA(lv_time).
    ELSE.
      CONVERT TIME STAMP lv_timestamp TIME ZONE sy-zonlo
             INTO DATE lv_date TIME lv_time.
    ENDIF.

    rv_covertvalue = |{ lv_date+6(2) }-{ lv_date+4(2) }-{ lv_date(4) } { lv_time(2) }:{ lv_time+2(2) }:{ lv_time+4(2) }|.



  ENDMETHOD.


  METHOD convert_to_uppercase.

    DATA: lt_aptph_pos TYPE lty_zhtdb_sign_pos_tt,
          lv_aptph     TYPE lty_zhtdb_sign_pos,
          lv_char      TYPE string,
          lv_uppercase TYPE string.


    CALL METHOD zcl_ul_abap=>parse_aptph
      EXPORTING
        iv_condense    = ' '
        iv_log_handle  = 'DUMMY'
      IMPORTING
        et_aptph_pos   = lt_aptph_pos
      CHANGING
        cv_string      = cv_string
      EXCEPTIONS
        missing_aptph  = 1
        missing_parnth = 2
        OTHERS         = 3.

    LOOP AT lt_aptph_pos INTO lv_aptph.

      lv_aptph-position = lv_aptph-position - 1.
      lv_char = cv_string+lv_aptph-position(1).

      IF lv_aptph-type EQ 'O'.
        TRANSLATE lv_char TO UPPER CASE.
      ENDIF.

      IF lv_char = space.
        CONCATENATE lv_uppercase lv_char INTO lv_uppercase SEPARATED BY space.   " otherwise the SPACE will be lost ...
      ELSE.
        CONCATENATE lv_uppercase lv_char INTO lv_uppercase.
      ENDIF.

    ENDLOOP.

    cv_string = lv_uppercase.

  ENDMETHOD.                    "convert_to_uppercase


  METHOD conv_to_external_date.

    CALL FUNCTION 'CONVERT_DATE_TO_EXTERNAL'
      EXPORTING
        date_internal            = iv_date
      IMPORTING
        date_external            = rv_date
      EXCEPTIONS
        date_external_is_invalid = 1
        OTHERS                   = 2.

    IF sy-subrc <> 0.
      cx_error->add_system_message( ).
    ENDIF.

  ENDMETHOD.


  METHOD conv_to_interal_date.

    CALL FUNCTION 'CONVERT_DATE_TO_INTERNAL'
      EXPORTING
        date_external            = iv_date
        accept_initial_date      = abap_true
      IMPORTING
        date_internal            = rv_date
      EXCEPTIONS
        date_external_is_invalid = 1
        OTHERS                   = 2.

    IF sy-subrc <> 0.
      cx_error->add_system_message( ).
    ENDIF.

  ENDMETHOD.


  METHOD create_wf_item.

    CALL FUNCTION 'SAP_WAPI_CREATE_EVENT'
      EXPORTING
        object_type     = iv_objtype
        object_key      = iv_objkey
        event           = is_event
      IMPORTING
        return_code     = rv_code
      TABLES
        input_container = it_container.

    cx_error->add_system_message( ).

  ENDMETHOD.


  METHOD determinte_tab_type.

*    DATA: lv_tabname TYPE tabname.
*
*
** check if it is a transparent table
*    SELECT SINGLE tabname
*      INTO lv_tabname FROM dd03vv
*      WHERE tabname   = iv_table AND
*            tabclass  = 'TRANSP' AND
*            as4local  = 'A' AND
*            fieldname NOT LIKE '.%' AND
*            fieldname NOT LIKE '*%' AND
*            fieldname NOT LIKE '$_%' ESCAPE '$' AND
*            fieldname NOT LIKE '$%%' ESCAPE '$'.
*
** not transparent table
*    IF sy-subrc EQ 4.
*
**   check if it is a view
**   viewfield instead of fieldname, field alias may be defined in a view!
*      SELECT SINGLE viewname
*        INTO lv_tabname FROM dd27s
*        WHERE viewname  = iv_table AND
*              as4local  = 'A' AND
**           possible to define * in views to include all fields from a table, and - to exclude a field
*              viewfield <> '*' AND
*              viewfield <> '-' AND
*              fieldname NOT LIKE '.%' AND
*              fieldname NOT LIKE '*%' AND
*              fieldname NOT LIKE '$_%' ESCAPE '$' AND
*              fieldname NOT LIKE '$%%' ESCAPE '$'.
*
**   not a view
*      IF sy-subrc EQ 4.
*
**     check if it is a Clustered table
*        SELECT SINGLE dd16s~sqltab
*          INTO lv_tabname
*          FROM dd16s INNER JOIN dd06l ON dd06l~sqltab = dd16s~sqltab
*          WHERE dd16s~sqltab = iv_table AND
*                dd06l~as4local = 'A' AND
*                dd06l~sqlclass = 'CLUSTER' AND
*                dd16s~fieldname NOT LIKE '.%' AND
*                dd16s~fieldname NOT LIKE '*%' AND
*                dd16s~fieldname NOT LIKE '$_%' ESCAPE '$' AND
*                dd16s~fieldname NOT LIKE '$%%' ESCAPE '$'.
*
**     not a Clustered table
*        IF sy-subrc EQ 4.
*
**       check if it is a Pooled table
*          SELECT SINGLE dd16s~sqltab
*            INTO lv_tabname
*            FROM dd16s INNER JOIN dd06l ON dd06l~sqltab = dd16s~sqltab
*            WHERE dd16s~sqltab = iv_table AND
*                  dd06l~sqlclass = 'POOL' AND
*                  dd06l~as4local = 'A' AND
*                  dd16s~fieldname NOT LIKE '.%' AND
*                  dd16s~fieldname NOT LIKE '*%' AND
*                  dd16s~fieldname NOT LIKE '$_%' ESCAPE '$' AND
*                  dd16s~fieldname NOT LIKE '$%%' ESCAPE '$'.
*
**       not a Pooled table
*          IF sy-subrc EQ 4.
*            RAISE table_not_exist.
**       it is a Pooled table
*          ELSE.
*            ev_type = 'P'.
*          ENDIF.
*
**     it is a Clustered table
*        ELSE.
*          ev_type = 'C'.
**        CLEAR mv_can_edit.
*        ENDIF.
*
**   it is a view
*      ELSE.
*        ev_type = 'V'.
*
*      ENDIF.
*
** it is a transparent table
*    ELSE.
*      ev_type = 'T'.
*    ENDIF.

  ENDMETHOD.                    "determinte_tab_type


  METHOD encode_timestamp.

    IF iv_time IS INITIAL.
      GET TIME STAMP FIELD rv_timestamp.
      rv_timestamp = cl_kf_helper=>timestamp_utc_2_local_zone( i_time_zone = iv_timezone i_timestamp_utc = rv_timestamp ).
    ELSE.
      rv_timestamp = |{ iv_time+6(4) }{ iv_time+3(2) }{ iv_time(2) }{ iv_time+11(2) }{ iv_time+14(2) }{ iv_time+17(2) }|.
    ENDIF.

  ENDMETHOD.


  METHOD f4_int_table_request.

    DATA: tabname     TYPE tabname,
          lfieldname  TYPE fnam_____4,
          s_field_map TYPE dfies,
          t_field_map TYPE dfies_tab.


    READ TABLE it_values ASSIGNING FIELD-SYMBOL(<fs_value>) INDEX 1.

    DO.

      DATA(i) = sy-index.
      ASSIGN COMPONENT i OF STRUCTURE <fs_value> TO FIELD-SYMBOL(<f>).
      IF sy-subrc <> 0 . EXIT. ENDIF.
      DESCRIBE FIELD <f> HELP-ID DATA(hlp).
      SPLIT hlp AT '-' INTO tabname lfieldname.

      CALL FUNCTION 'DDIF_FIELDINFO_GET'
        EXPORTING
          tabname    = tabname
          lfieldname = lfieldname
          all_types  = 'X'
        IMPORTING
          dfies_wa   = s_field_map.

      s_field_map-fieldname = it_map_name[ i ]-fieldname.
      s_field_map-reptext   = s_field_map-scrtext_l =  it_map_name[ i ]-reptext.
      s_field_map-position  = i.
      s_field_map-mask+2(1) = abap_true.
      DESCRIBE DISTANCE BETWEEN <fs_value> AND <f> INTO s_field_map-offset IN BYTE MODE.

      APPEND s_field_map TO t_field_map.

    ENDDO.

    CALL FUNCTION 'F4IF_INT_TABLE_VALUE_REQUEST'
      EXPORTING
        retfield   = iv_retfield
        value_org  = 'S'
      TABLES
        value_tab  = it_values
        field_tab  = t_field_map
        return_tab = rt_values.



  ENDMETHOD.


  METHOD file_download.

    DATA: path      TYPE string,
          full_path TYPE string.

    cl_gui_frontend_services=>file_save_dialog( EXPORTING default_extension = default_extension prompt_on_overwrite = abap_true with_encoding = abap_true
                                                          default_file_name = file_name
                                                CHANGING  filename = file_name path = path fullpath = full_path
                                                EXCEPTIONS cntl_error = 1 error_no_gui = 2 invalid_default_file_name = 3 not_supported_by_gui = 4
                                                           OTHERS = 4  ).
    IF sy-subrc IS NOT INITIAL.
      ycx_abap_error=>raise_message( ).
      RETURN.
    ENDIF.

    cl_gui_frontend_services=>gui_download( EXPORTING codepage = code_page confirm_overwrite = abap_true bin_filesize = bin_size
                                            filename = file_name  filetype = file_type
                                            CHANGING data_tab = data_tab
                                            EXCEPTIONS access_denied = 1 control_flush_error = 2 dataprovider_exception = 3 disk_full = 4
                                                       dp_error_create = 4 dp_error_send = 5 dp_error_write = 6 dp_out_of_memory = 7
                                                       dp_timeout = 8 error_no_gui = 9 file_not_found = 10 file_write_error = 11
                                                       filesize_not_allowed = 12 gui_refuse_filetransfer = 13 header_not_allowed = 14
                                                       header_too_long = 15 invalid_type = 16 no_authority = 17 no_batch = 18 not_supported_by_gui = 19
                                                       separator_not_allowed = 20 unknown_dp_error = 21 unknown_error = 22 OTHERS = 23 ).

    IF sy-subrc IS NOT INITIAL.
      ycx_abap_error=>raise_message( ).
    ENDIF.

  ENDMETHOD.


  METHOD from_json.
    CLEAR:
     ev_ok,
     ex_data.

    " No need. Always have {"DATA":} ?
    CHECK iv_json IS NOT INITIAL.

    " Detect order
    DATA lt_mode TYPE stringtab.
    SPLIT iv_mode AT '-' INTO TABLE lt_mode.

    DATA lv_mode TYPE string.
    LOOP AT lt_mode INTO lv_mode.
      CASE lv_mode.
          " in most cases it works fine regardless the fact that in system there is no if_sxml=>co_xt_json declared
        WHEN '1'.
          TRY.
              CALL TRANSFORMATION id SOURCE XML iv_json
                                     RESULT data = ex_data.
              " Ok
              ev_ok = abap_true.
            CATCH cx_transformation_error.
              ev_ok = abap_false.
          ENDTRY.

          " For version ABAP 7.02 patch level 006
        WHEN '2'.
          TRY.
              _json_2_abap(
                EXPORTING
                  json_string = iv_json
                  var_name    = 'DATA'
                CHANGING
                  abap_data   = ex_data ).

              " Ok
              ev_ok = abap_true.
*              CATCH zcx_eui_exception.
*                ev_ok = abap_false.
          ENDTRY.
      ENDCASE.

      " All done
      IF ev_ok = abap_true.
        EXIT.
      ENDIF.
    ENDLOOP.

    " Is not procced in caller!
    IF ev_ok <> abap_true AND ev_ok IS NOT REQUESTED.
      " Jump to code below to get file
      cx_error->add_text( iv_message = `Error in 'IV_JSON'` ). "#EC NOTEXT
      cx_error->show_message( ).
    ENDIF.

*        " For debug
*        DATA lo_file TYPE REF TO zcl_eui_file.
*        lo_file->import_from_string( iv_json ).
*        TRY.
*            lo_file->download( iv_full_path   = 'dump_json.txt'
*                               iv_save_dialog = abap_true ).
*            lo_file->open( ).
*        ENDTRY.
*      ENDIF.
  ENDMETHOD.


  METHOD get_message_text.

    CALL FUNCTION 'MESSAGE_TEXT_BUILD'
      EXPORTING
        msgid               = sy-msgid
        msgnr               = sy-msgno
        msgv1               = sy-msgv1
        msgv2               = sy-msgv2
        msgv3               = sy-msgv3
        msgv4               = sy-msgv4
      IMPORTING
        message_text_output = rv_message.

  ENDMETHOD.


  METHOD get_name_user.

    SELECT SINGLE adrp~name_text INTO rv_user_name
      FROM usr21 JOIN adrp ON usr21~persnumber = adrp~persnumber AND
                              adrp~nation      = ''
     WHERE usr21~bname = iv_user.

  ENDMETHOD.


  METHOD get_next_number.

    CALL FUNCTION 'NUMBER_GET_NEXT'
      EXPORTING
        nr_range_nr             = iv_number_range
        object                  = iv_object
        toyear                  = iv_to_year
      IMPORTING
        number                  = rv_number
      EXCEPTIONS
        interval_not_found      = 1
        number_range_not_intern = 2
        object_not_found        = 3
        quantity_is_0           = 4
        quantity_is_not_1       = 5
        interval_overflow       = 6
        buffer_overflow         = 7
        OTHERS                  = 8.

    IF sy-subrc <> 0.
      cx_error->add_system_message( ).
      RAISE EXCEPTION cx_error.
    ENDIF.

  ENDMETHOD.


  METHOD get_stvarv_val.

    SELECT FROM tvarvc FIELDS
      CASE WHEN sign = @space THEN 'I'
      ELSE sign
      END AS sign,
      CASE WHEN opti = @space THEN 'EQ'
      ELSE opti
      END AS option,
      low, high
      WHERE name = @iv_varname INTO CORRESPONDING FIELDS OF TABLE @rt_varval.

    IF sy-subrc IS NOT INITIAL.
      cx_error->add_text( iv_message = 'Variant &1 not found!' iv_variable_1 = CONV #( iv_varname ) ).
      RAISE EXCEPTION cx_error.
      RETURN.
    ENDIF.

  ENDMETHOD.


  METHOD get_word_at_pos.

    DATA: lv_length TYPE i,
          lv_char   TYPE char1,
          lv_shift  TYPE i,
          lv_start  TYPE i,
          lv_end    TYPE i.


    lv_length = strlen( iv_string ).

* check if position is valid
    IF lv_length   < iv_position OR
       iv_position < 1.
      RETURN.
    ENDIF.

    lv_shift = iv_position - 1.
    lv_char = iv_string+lv_shift(1).

* space does not matter
    IF lv_char = space.
      RETURN.
    ENDIF.

* determine start
    DO.
      lv_char = iv_string+lv_shift(1).

      IF lv_char = space.
        lv_start = lv_shift + 1.
        EXIT.
      ENDIF.

      lv_shift = lv_shift - 1.
      IF lv_shift < 0.
        lv_start = lv_shift + 1.
        EXIT.
      ENDIF.
    ENDDO.

* determine end
    lv_shift = iv_position - 1.
    DO.
      lv_char = iv_string+lv_shift(1).

      IF lv_char = space.
        lv_end = lv_shift.
        EXIT.
      ENDIF.

      lv_shift = lv_shift + 1.
      IF lv_shift = lv_length.
        lv_end = lv_shift.
        EXIT.
      ENDIF.
    ENDDO.

    lv_length = lv_end - lv_start.
    ev_word = iv_string+lv_start(lv_length).

  ENDMETHOD.                    "


  METHOD has_client_field.

    DATA: x030l_wa TYPE x030l.


    CLEAR ev_has_client_field.

    CHECK iv_tabname IS NOT INITIAL.

    CALL FUNCTION 'DDIF_FIELDINFO_GET'
      EXPORTING
        tabname        = iv_tabname
      IMPORTING
        x030l_wa       = x030l_wa
      EXCEPTIONS
        not_found      = 1
        internal_error = 2
        OTHERS         = 3.

    IF sy-subrc <> 0.
      MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
         WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.
    ENDIF.

    IF x030l_wa-clpos NE 0.
      ev_has_client_field = 'X'.
    ENDIF.

  ENDMETHOD.                    "has_client_field


  METHOD if_exist_data.

    TYPES: BEGIN OF ty_s_clause,
             line(72) TYPE c,
           END OF ty_s_clause.

    DATA:lt_tabfield     TYPE TABLE OF dbfield,
         lt_condtab      TYPE TABLE OF hrcond,
         lt_whereclauses TYPE TABLE OF ty_s_clause,
         lv_tabname      TYPE tabname.

    CHECK is_data IS NOT INITIAL.

    IF iv_tabname IS NOT INITIAL.
      lv_tabname = iv_tabname.
    ELSE.
      TRY.
          lv_tabname = NEW ycl_abap_rtts( iv_data = is_data )->ar_datadescr->get_relative_name( ).
        CATCH ycx_abap_error INTO cx_error.
          cx_error->show_message(  ).
      ENDTRY.
    ENDIF.

    CALL FUNCTION 'DB_GET_TABLE_FIELDS'
      EXPORTING
        tabname  = lv_tabname
      TABLES
        dbfields = lt_tabfield.

    IF iv_key_apply EQ abap_true.
      LOOP AT lt_tabfield INTO DATA(ls_tabfield) WHERE keyflag IS NOT INITIAL.
        CHECK ls_tabfield-name NE 'MANDT' AND ls_tabfield-name NE 'CLIENT'.
        ASSIGN COMPONENT ls_tabfield-name OF STRUCTURE is_data TO FIELD-SYMBOL(<fv_value>).
        CHECK <fv_value> IS NOT INITIAL.
        lt_condtab = VALUE #( BASE lt_condtab ( field = ls_tabfield-name opera = 'EQ' low = <fv_value> ) ).
      ENDLOOP.
    ELSE.
      LOOP AT lt_tabfield INTO ls_tabfield.
        CHECK ls_tabfield-name NE 'MANDT' AND ls_tabfield-name NE 'CLIENT'.
        ASSIGN COMPONENT ls_tabfield-name OF STRUCTURE is_data TO <fv_value>.
        CHECK <fv_value> IS NOT INITIAL.
        lt_condtab = VALUE #( BASE lt_condtab ( field = ls_tabfield-name opera = 'EQ' low = <fv_value> ) ).
      ENDLOOP.
    ENDIF.

    CALL FUNCTION 'RH_DYNAMIC_WHERE_BUILD'
      EXPORTING
        dbtable      = space
      TABLES
        condtab      = lt_condtab
        where_clause = lt_whereclauses.

    CHECK lt_whereclauses IS NOT INITIAL.
    SELECT SINGLE FROM (lv_tabname) FIELDS @abap_true WHERE (lt_whereclauses) INTO @rv_exist. "#EC CI_SEL_NESTED

  ENDMETHOD.


  METHOD is_client_field.

    DATA: lv_datatype  TYPE dd03l-datatype,
          lv_fieldname TYPE fieldname,
          lv_tabname   TYPE tabname,

          lt_x031l_tab TYPE TABLE OF x031l,
          ls_x031l     TYPE x031l.

    CLEAR ev_client_field.

    lv_tabname   = iv_tabname.
    lv_fieldname = iv_fieldname.

    TRANSLATE lv_tabname   TO UPPER CASE.
    TRANSLATE lv_fieldname TO UPPER CASE.

    SELECT SINGLE datatype
      FROM dd03l INTO lv_datatype
      WHERE tabname   = lv_tabname AND
            fieldname = lv_fieldname AND
            keyflag   = 'X'.

    IF sy-subrc EQ 0.
      CALL FUNCTION 'DD_DICTIONARY_TO_NAMETAB'
        EXPORTING
          foreign_key = ' '
          status      = 'A'
          tabname     = lv_tabname
        TABLES
          x031l_tab   = lt_x031l_tab.

      IF sy-subrc EQ 0.
        READ TABLE lt_x031l_tab INTO ls_x031l
          WITH KEY fieldname = lv_fieldname.

        IF ls_x031l-dtyp = 'CLNT' AND ls_x031l-position = 1.
          ev_client_field = 'X'.
        ENDIF.
      ENDIF.
    ENDIF.

  ENDMETHOD.                    "is_client_field


  METHOD parse_aptph.
* fills up the et_aptph_pos table: for each character of the command
* it sets the following flag:
*  - O - if the character is not part of a text
*  - A - if it is an apostrophe
*  - I - if it is part of a text

* fills up the et_paranth table with the positions of paranthesis

* executes a kind of CONDENSE, but outside of apostrophes only

    DATA: ls_aptph     LIKE LINE OF et_aptph_pos,
          ls_paranth   LIKE LINE OF et_aptph_pos,

          lv_strg_lgth TYPE i,
          lv_char      TYPE string,

          lv_shift     TYPE i,
          lv_shift_sp  TYPE i,
          lv_shift_end TYPE i,
          lv_next      TYPE i,
          lv_in_apostr TYPE xfeld,
          lv_par_cnt   TYPE i.


    IF cv_string IS INITIAL.
      RETURN.
    ENDIF.

    lv_shift = -1.
    lv_strg_lgth = strlen( cv_string ).

    DO.
      lv_shift = lv_shift + 1.
      IF lv_shift >= lv_strg_lgth.
        EXIT.
      ENDIF.

      lv_char = cv_string+lv_shift(1).  " current character

      IF lv_char = ''''.

        IF lv_in_apostr = ' '.
*       => beginning of a text
          lv_in_apostr = 'X'.   " mark, that we are within a text

          ls_aptph-position = lv_shift + 1.
          ls_aptph-type = 'A'.
          APPEND ls_aptph TO et_aptph_pos.

          CONTINUE.
        ENDIF.

*     we are within a text

*     the next apostrophe closes the text, if it isn't doubled!
*     then both will be ignored
*     => the next character must be checked
        lv_next = lv_shift + 1.

        IF lv_next < lv_strg_lgth.

          IF cv_string+lv_next(1) = ''''.
*         these two apostrophes will be ignored
            ls_aptph-position = lv_shift + 1.
            ls_aptph-type = 'I'.
            APPEND ls_aptph TO et_aptph_pos.

            ls_aptph-position = lv_shift + 2.
            APPEND ls_aptph TO et_aptph_pos.

            lv_shift = lv_shift + 1.  " skip next character
          ELSE.
*         this apostrophe closes the text
            IF lv_in_apostr = 'X'.
              lv_in_apostr = ' '.   " mark, that we are not in a text
            ENDIF.
            ls_aptph-position = lv_shift + 1.
            ls_aptph-type = 'A'.
            APPEND ls_aptph TO et_aptph_pos.
          ENDIF.

        ELSE.

*       this apostrophe closes the text
          IF lv_in_apostr = 'X'.
            lv_in_apostr = ' '.   " mark, that we are not in a text
          ENDIF.
          ls_aptph-position = lv_shift + 1.
          ls_aptph-type = 'A'.
          APPEND ls_aptph TO et_aptph_pos.

        ENDIF.

      ELSE.  " lv_char <> ''''

        ls_aptph-position = lv_shift + 1.
        IF lv_in_apostr = 'X'.  " inside a text
          ls_aptph-type = 'I'.
        ELSE.
          ls_aptph-type = 'O'.  " outside of text
        ENDIF.
        APPEND ls_aptph TO et_aptph_pos.

*     check for '('
        IF lv_char      = '(' AND
           lv_in_apostr = ' '.    " not in a text

          lv_par_cnt = lv_par_cnt + 1.
          ls_paranth-type = lv_par_cnt.
          ls_paranth-position = lv_shift + 1.
          APPEND ls_paranth TO et_paranth.

        ENDIF.

*     check for ')'
        IF lv_char      = ')' AND
           lv_in_apostr = ' '.    " not in a text

          ls_paranth-type = lv_par_cnt.
          lv_par_cnt = lv_par_cnt - 1.
          ls_paranth-position = lv_shift + 1.
          APPEND ls_paranth TO et_paranth.

        ENDIF.

        IF iv_condense = 'X'.
*       condense SPACEs (outside of apostrophes only!)
          IF lv_char      = space AND
             lv_in_apostr = ' '.

            lv_shift_sp  = lv_shift + 1.
            lv_shift_end = lv_shift + 2.

            IF lv_shift_sp >= lv_strg_lgth.
              EXIT.
            ENDIF.

            DO.
              IF lv_shift_sp >= lv_strg_lgth.
                EXIT.
              ENDIF.

              lv_char = cv_string+lv_shift_sp(1).
              IF lv_char = space.
                lv_strg_lgth = lv_strg_lgth - 1.
*             remove SPACE from position lv_shift_sp + 1
                CONCATENATE cv_string(lv_shift_sp) cv_string+lv_shift_end INTO cv_string.
              ELSE.
                EXIT.
              ENDIF.
            ENDDO.

          ENDIF.
        ENDIF.

      ENDIF.

    ENDDO.

    IF lv_in_apostr = 'X'.  " the command was not closed properly

      IF iv_log_handle IS INITIAL.
*     Message: An ending apostrophe is missing
        MESSAGE e005(zsql_free) RAISING missing_aptph.
      ELSE.
        RAISE missing_aptph.
      ENDIF.

    ENDIF.

    IF lv_par_cnt <> 0.  " the command was not closed properly
      IF iv_log_handle IS INITIAL.
*     Message: An closing paranthesis is missing
        MESSAGE e059(zsql_free) RAISING missing_parnth.
      ELSE.
        RAISE missing_parnth.
      ENDIF.
    ENDIF.

  ENDMETHOD.                    "


  METHOD popup_to_confirm.

    CALL FUNCTION 'POPUP_TO_CONFIRM'
      EXPORTING
        text_question         = iv_text
        text_button_1         = 'Yes'
        icon_button_1         = 'icon_checked'
        text_button_2         = 'Cancel'
        icon_button_2         = 'icon_cancel'
        default_button        = '2'
        display_cancel_button = abap_false
      IMPORTING
        answer                = rv_value.

  ENDMETHOD.


  METHOD pretty_printer.

    DATA: ls_source LIKE LINE OF ct_source,
          lv_string TYPE string,
          lv_tabix  TYPE i.


    LOOP AT ct_source INTO ls_source.
      lv_tabix = sy-tabix.
      lv_string = ls_source-line.

      CALL METHOD zcl_ul_abap=>convert_to_uppercase
        CHANGING
          cv_string = lv_string.

      ls_source-line = lv_string.

      MODIFY ct_source FROM ls_source INDEX lv_tabix.
    ENDLOOP.

  ENDMETHOD.                    "pretty_printer


  METHOD pretty_printer_string.

    DATA: ls_source LIKE LINE OF ct_source,
          lv_tabix  TYPE i.


    LOOP AT ct_source INTO ls_source.
      lv_tabix = sy-tabix.

      CALL METHOD zcl_ul_abap=>convert_to_uppercase
        CHANGING
          cv_string = ls_source.

      MODIFY ct_source FROM ls_source INDEX lv_tabix.
    ENDLOOP.

  ENDMETHOD.                    "pretty_printer_string


  METHOD remove_diacritics.

    CHECK iv_input IS NOT INITIAL.
    rv_output = iv_input.

    "For abnormal text
    rv_output = replace( val = rv_output regex = ` ` with = `+` occ = 0 ).
    rv_output = replace( val = rv_output regex = `[̉ ̀ ́ ̂]` with = `` occ = 0 ).
    rv_output = replace( val = rv_output regex = `[+]` with = ` ` occ = 0 ).

    "For normal text
    rv_output = replace( val = rv_output regex = `[áàảãạâấầẩẫậăắằẳẵặ]` with = `a` occ = 0 ).
    rv_output = replace( val = rv_output regex = `[éèẻẽẹêếềểễệ]` with = `e` occ = 0 ).
    rv_output = replace( val = rv_output regex = `[íìỉĩị]` with = `i` occ = 0 ).
    rv_output = replace( val = rv_output regex = `[óòỏõọôốồổỗộơớờởỡợ]` with = `o` occ = 0 ).
    rv_output = replace( val = rv_output regex = `[úùủũụưứừửữự]` with = `u` occ = 0 ).
    rv_output = replace( val = rv_output regex = `đ` with = `d` occ = 0 ).
    rv_output = replace( val = rv_output regex = `[ýỳỷỹỵ]` with = `y` occ = 0 ).
    rv_output = replace( val = rv_output regex = `[ÁÀẢÃẠÂẤẦẨẪẬĂẮẰẲẴẶ]` with = `A` occ = 0 ).
    rv_output = replace( val = rv_output regex = `[ÉÈẺẼẸÊẾỀỂỄỆ]` with = `E` occ = 0 ).
    rv_output = replace( val = rv_output regex = `[ÍÌỈĨỊ]` with = `I` occ = 0 ).
    rv_output = replace( val = rv_output regex = `[ÓÒỎÕỌÔỐỒỔỖỘƠỚỜỞỠỢ]` with = `O` occ = 0 ).
    rv_output = replace( val = rv_output regex = `[ÚÙỦŨỤƯỨỪỬỮỰ]` with = `U` occ = 0 ).
    rv_output = replace( val = rv_output regex = `[ÝỲỶỸỴ]` with = `Y` occ = 0 ).
    rv_output = replace( val = rv_output regex = `Đ` with = `D` occ = 0 ).

  ENDMETHOD.


  METHOD select_single_gen.

    DATA: lv_keyfield TYPE fieldname,
          lr_data     TYPE REF TO data,
          lv_where    TYPE string,
          lv_keyval   TYPE string.

    FIELD-SYMBOLS: <ls_data>      TYPE any,
                   <lv_keyval>    TYPE any,
                   <ls_keyfields> TYPE any.


* create work area
    CREATE DATA lr_data TYPE (iv_table_name).
    ASSIGN lr_data->* TO <ls_data>.

    ASSIGN is_key_value->* TO <ls_keyfields>.

* create WHERE clause
    LOOP AT it_keyf_list INTO lv_keyfield.
      IF lv_where IS NOT INITIAL.
        CONCATENATE lv_where 'AND' INTO lv_where
          SEPARATED BY space.
      ENDIF.

      ASSIGN COMPONENT lv_keyfield OF STRUCTURE <ls_keyfields> TO <lv_keyval>.
      lv_keyval = <lv_keyval>.

      CONCATENATE lv_where lv_keyfield '= ''' INTO lv_where
        SEPARATED BY space.
      CONCATENATE lv_where lv_keyval '''' INTO lv_where.
    ENDLOOP.

    SELECT SINGLE * FROM (iv_table_name) INTO <ls_data>
      WHERE (lv_where).

    es_record = lr_data.

  ENDMETHOD.                    "


  METHOD set_dynpro_drop.

    DATA lt_values TYPE vrm_values.

    IF iv_use_domval IS NOT INITIAL.
      TRY.
          DATA(lt_fix_values) = NEW ycl_abap_rtts( iv_name = iv_use_domval )->get_fix_values( ).
          lt_values = CORRESPONDING #( lt_fix_values MAPPING key = low text = ddtext ).
        CATCH ycx_abap_error INTO cx_error.
          cx_error->show_message(  ).
      ENDTRY.
    ELSE.
      lt_values = it_values.
    ENDIF.

    CALL FUNCTION 'VRM_SET_VALUES'
      EXPORTING
        id              = iv_id
        values          = lt_values
      EXCEPTIONS
        id_illegal_name = 1.

    CHECK sy-subrc IS NOT INITIAL.
    cx_error->add_system_message( ).

  ENDMETHOD.


  METHOD show_change_log.

    DATA: lt_tabfield  TYPE TABLE OF dbfield,
          lv_tablekey  TYPE cdtabkey,
          lv_tabname   TYPE tabname,
          lv_objectid  TYPE cdhdr-objectid,
          lt_changelog TYPE TABLE OF cdred.

    DATA: BEGIN OF ls_logchange.
        INCLUDE TYPE cdred.
    DATA:   line TYPE sy-index.
    DATA: END OF ls_logchange.

    DATA: lt_s_logchange LIKE TABLE OF ls_logchange.

    " Build header key
    CHECK is_header IS NOT INITIAL.
    IF iv_objectid IS INITIAL.
      lv_objectid = build_key( iv_add_client = abap_true is_data = is_header ).
    ELSE.
      lv_objectid = iv_objectid.
    ENDIF.
    lv_tablekey = build_key( EXPORTING is_data    = is_data
                             IMPORTING ev_tabname = lv_tabname ).

    IF iv_tabname IS NOT INITIAL.
      lv_tabname = iv_tabname.
    ENDIF.

    CALL FUNCTION 'CHANGEDOCUMENT_READ'
      EXPORTING
        objectclass                = iv_class
        objectid                   = lv_objectid
        tablekey                   = lv_tablekey
        tablename                  = lv_tabname
      TABLES
        editpos                    = lt_changelog
      EXCEPTIONS
        no_position_found          = 1
        time_zone_conversion_error = 2
        wrong_access_to_archive    = 3
        OTHERS                     = 4.

    IF sy-subrc IS NOT INITIAL.
      cx_error->add_text( iv_type = 'I' iv_message = 'No Log Found!' ).
      cx_error->show_line_message( ).
    ENDIF.

    CHECK lt_changelog IS NOT INITIAL.
    SORT lt_changelog BY udate utime.
    MOVE-CORRESPONDING lt_changelog TO lt_s_logchange.
    IF iv_line_offset IS INITIAL.
      DATA(lv_au_offset) = strlen( lv_objectid ).
    ELSE.
      SPLIT iv_line_offset AT ':' INTO DATA(lv_offset) DATA(lv_len).
    ENDIF.

    LOOP AT lt_s_logchange ASSIGNING FIELD-SYMBOL(<fs_s_logchange>).
      TRY.
          IF lv_offset IS NOT INITIAL.
            <fs_s_logchange>-line = <fs_s_logchange>-tabkey+lv_offset(lv_len).
          ELSE.
            <fs_s_logchange>-line = <fs_s_logchange>-tabkey+lv_au_offset.
          ENDIF.
        CATCH cx_sy_conversion_no_number.
          IF lv_offset IS NOT INITIAL.
            <fs_s_logchange>-tabkey = <fs_s_logchange>-tabkey+lv_offset(lv_len).
          ELSE.
            <fs_s_logchange>-tabkey = <fs_s_logchange>-tabkey+lv_au_offset.
          ENDIF.
      ENDTRY.
    ENDLOOP.
    DATA(lt_col_set) = VALUE ztb_ul_alv_col( ( fieldname = 'UDATE' col_pos = 1 scrtext_m = 'Changed Date' )
                                             ( fieldname = 'UTIME' col_pos = 2 outputlen = 10 scrtext_m = 'Changed Time' )
                                             ( fieldname = 'USERNAME' col_pos = 3 scrtext_m = 'User name' )
                                             ( fieldname = 'CHNGIND' outputlen = 8 col_pos = 4 )
                                             ( fieldname = 'LINE' outputlen = 5 col_pos = 5 scrtext_s = 'Line' )
                                             ( fieldname = 'TABKEY' outputlen = 15 col_pos = 6 scrtext_m = 'Table Key'
                                             no_out = COND #( WHEN <fs_s_logchange>-line IS NOT INITIAL THEN abap_true ELSE abap_false ) )
                                             ( fieldname = 'FTEXT' col_pos = 7 outputlen = 15 scrtext_m = 'Changed Field' )
                                             ( fieldname = 'F_OLD' col_pos = 8 outputlen = 40 scrtext_m = 'Old Value' )
                                             ( fieldname = 'F_NEW' col_pos = 9 outputlen = 40 scrtext_m = 'New Value') ).

    DATA(lt_sort) = VALUE lvc_t_sort( ( fieldname = 'UDATE' spos = 1 down = abap_true )
                                      ( fieldname = 'UTIME' spos = 2 down = abap_true ) ).

    IF zcl_ul_alv_adapter=>o_grid IS BOUND.
      zcl_ul_alv_adapter=>o_grid->free( ).
    ENDIF.

    zcl_ul_alv_adapter=>create( EXPORTING iv_popup     = abap_true
                                          it_col_set   = lt_col_set
                                          it_sort      = lt_sort
                                          iv_auto_hide = abap_true
                                CHANGING  ct_table     = lt_s_logchange ).

  ENDMETHOD.


  METHOD split_string.

    DATA: lt_aptph_pos TYPE lty_zhtdb_sign_pos_tt,
          ls_aptph_pos TYPE lty_zhtdb_sign_pos,
          lv_string    TYPE string,
          lv_newstr    TYPE string,
          lv_actstr    TYPE string,
          lv_char      TYPE string,
          lv_shift     TYPE i,
          lv_lastsp    TYPE i,
          lv_length    TYPE i,
          lv_strg_lgth TYPE i,
          lv_index     TYPE i.


    IF iv_string IS INITIAL.
      RETURN.
    ENDIF.

    lv_string = iv_string.

    parse_aptph( EXPORTING  iv_condense   = space
                            iv_log_handle = iv_log_handle
                 IMPORTING  et_aptph_pos  = lt_aptph_pos
                 CHANGING   cv_string     = lv_string
                 EXCEPTIONS OTHERS        = 1 ).

    lv_shift = -1.
    lv_strg_lgth = strlen( lv_string ).

    DO.
      lv_shift = lv_shift + 1.
      IF lv_shift >= lv_strg_lgth.
        EXIT.
      ENDIF.

      lv_char = lv_string+lv_shift(1).  " current character

      IF lv_char = space.
        CONCATENATE lv_actstr lv_char INTO lv_actstr
          SEPARATED BY space.   " otherwise the SPACE will be lost ...
        lv_length = lv_length + 1.

*     check, if the SPACE is inside of apostrophes
        lv_index = lv_shift + 1.
        READ TABLE lt_aptph_pos INDEX lv_index INTO ls_aptph_pos.

        IF ls_aptph_pos-type = 'O'.  " outside of apostrophes
          IF lv_length > iv_maxlen.
*       the length of actual line is bigger than the maximum allowed
            IF lv_lastsp <> 0.   " there is a right position to cut
*           cut string at the last SPACE to get the current line
              lv_newstr = lv_actstr(lv_lastsp).
              IF lv_newstr(1) = '*'.
                SHIFT lv_newstr RIGHT BY 1 PLACES.
              ENDIF.

*           the rest is the new line
              lv_actstr = lv_actstr+lv_lastsp.
              lv_length = lv_length - lv_lastsp.
              lv_lastsp = lv_length.
              APPEND lv_newstr TO et_string_tab.

*           the new line might be already longer, than allowed
              IF lv_length >= iv_maxlen.
                IF lv_actstr(1) = '*'.
                  SHIFT lv_actstr RIGHT BY 1 PLACES.
                ENDIF.
                APPEND lv_actstr TO et_string_tab.
                CLEAR lv_actstr.
                lv_length = 0.
              ENDIF.
            ELSE.    " there is no right position to cut
              IF lv_actstr(1) = '*'.
                SHIFT lv_actstr RIGHT BY 1 PLACES.
              ENDIF.
              APPEND lv_actstr TO et_string_tab.
              CLEAR lv_actstr.
              lv_length = 0.
            ENDIF.
          ELSE.
*         this is the position of the last SPACE, where the string can be cut,
*         if no better position will be found
            lv_lastsp = lv_length.
          ENDIF.
        ENDIF.
      ELSE.    " not a SPACE
        CONCATENATE lv_actstr lv_char INTO lv_actstr.
        lv_length = lv_length + 1.
      ENDIF.
    ENDDO.

    IF lv_actstr IS NOT INITIAL.
      IF lv_length > iv_maxlen.
*   the length of actual line is bigger than the maximum allowed
        IF lv_lastsp <> 0.   " there is a right position to cut
*       cut string at the last SPACE to get the current line
          lv_newstr = lv_actstr(lv_lastsp).
          IF lv_newstr(1) = '*'.
            SHIFT lv_newstr RIGHT BY 1 PLACES.
          ENDIF.
          APPEND lv_newstr TO et_string_tab.

*       the rest is the new line
          lv_actstr = lv_actstr+lv_lastsp.
          IF lv_actstr(1) = '*'.
            SHIFT lv_actstr RIGHT BY 1 PLACES.
          ENDIF.
          APPEND lv_actstr TO et_string_tab.
        ELSE.    " there is no right position to cut
          IF lv_actstr(1) = '*'.
            SHIFT lv_actstr RIGHT BY 1 PLACES.
          ENDIF.
          APPEND lv_actstr TO et_string_tab.
        ENDIF.
      ELSE.  " length OK
        IF lv_actstr(1) = '*'.
          SHIFT lv_actstr RIGHT BY 1 PLACES.
        ENDIF.
        APPEND lv_actstr TO et_string_tab.
      ENDIF.
    ENDIF.

  ENDMETHOD.                    "


  METHOD string_split_space.

    DATA(f_len) = strlen( condense( iv_string ) ).
    IF f_len <= iv_max_len.
      ev_str1 = iv_string. RETURN.
    ENDIF.

    DATA(len1) = _get_last_space( iv_max_len = iv_max_len
                                  iv_string = iv_string ).
    ev_str1 = condense( iv_string(len1) ).
    ev_str2 = condense( iv_string+len1 ).

    IF strlen( ev_str2 ) > iv_max_len.
      DATA(len2) = _get_last_space( iv_max_len = iv_max_len
                                    iv_string = ev_str2 ).

      ev_str3 = condense( ev_str2+len2 ).
      ev_str2 = condense( ev_str2(len2) ).
    ENDIF.

    IF strlen( ev_str3 ) > iv_max_len.
      DATA(len3) = _get_last_space( iv_max_len = iv_max_len
                                    iv_string = ev_str3 ).

      ev_str4 = condense( ev_str3+len2 ).
      ev_str3 = condense( ev_str3(len2) ).
    ENDIF.

    IF strlen( ev_str4 ) > iv_max_len.
      DATA(len4) = _get_last_space( iv_max_len = iv_max_len
                                    iv_string = ev_str4 ).

      ev_str5 = condense( ev_str4+len2 ).
      ev_str4 = condense( ev_str4(len2) ).
    ENDIF.


  ENDMETHOD.


  METHOD string_to_range.

    SPLIT iv_string AT ',' INTO TABLE DATA(tab).

    LOOP AT tab ASSIGNING FIELD-SYMBOL(<line>).
      CONDENSE <line>.
      rt_range = VALUE #( BASE rt_range ( sign = 'I' option = 'EQ' low = <line> ) ).
    ENDLOOP.

  ENDMETHOD.


  METHOD string_to_text_table.
    CALL FUNCTION 'SCMS_STRING_TO_FTEXT'
      EXPORTING
        text      = iv_string
      IMPORTING
        length    = ev_length
      TABLES
        ftext_tab = et_text.
  ENDMETHOD.


  METHOD string_to_xstring.
    CALL FUNCTION 'SCMS_STRING_TO_XSTRING'
      EXPORTING
        text     = iv_string
        encoding = iv_encoding
      IMPORTING
        buffer   = rv_xstring.
  ENDMETHOD.


  METHOD str_to_xml.
    DATA:
      lo_xml     TYPE REF TO if_ixml,
      lo_factory TYPE REF TO if_ixml_stream_factory,
      lo_stream  TYPE REF TO if_ixml_istream,
      lo_parser  TYPE REF TO if_ixml_parser.

    lo_xml      = cl_ixml=>create( ).
    lo_factory  = lo_xml->create_stream_factory( ).

    " From xstring
    IF iv_xstr IS SUPPLIED.
      lo_stream   = lo_factory->create_istream_xstring( iv_xstr ).
    ELSEIF iv_str IS SUPPLIED. " From string
      lo_stream   = lo_factory->create_istream_cstring( iv_str ).
    ELSE.
      RETURN.
    ENDIF.

    " Parse a document and return re_doc
    ro_doc = lo_xml->create_document( ).
    lo_parser = lo_xml->create_parser(
      stream_factory = lo_factory
      istream        = lo_stream
      document       = ro_doc ).
    lo_parser->set_normalizing( ).
    lo_parser->set_validating( mode = if_ixml_parser=>co_no_validation ).
    lo_parser->parse( ).
  ENDMETHOD.


  METHOD to_json.
    DATA:
      lv_end TYPE i,
      lv_beg TYPE i.

    rv_json = _abap_2_json( im_data = im_data iv_name = 'DATA' ).
    CONCATENATE `{` rv_json `}` INTO rv_json.

    " delete surroundin DATA
    IF iv_pure = abap_true.
      lv_end = strlen( rv_json ).

      IF rv_json(9) CP `{"DATA":"`.
        lv_beg = 9.
        lv_end = lv_end - 11.
      ELSE.
        lv_beg = 8.
        lv_end = lv_end - 9.
      ENDIF.

      rv_json = rv_json+lv_beg(lv_end).
    ENDIF.
  ENDMETHOD.


  METHOD write_change_log.

    TYPES: BEGIN OF ty_s_clause,
             line(72) TYPE c,
           END OF ty_s_clause.

    DATA: lr_data   TYPE REF TO data,
          lr_t_data TYPE REF TO data.

    DATA: lt_condtab      TYPE TABLE OF hrcond,
          lt_whereclauses TYPE TABLE OF ty_s_clause.

    DATA: lt_tabfield TYPE TABLE OF dbfield,
          lv_objectid TYPE cdobjectv,
          lt_dummy    TYPE TABLE OF cdtxt,
          ls_ptab     TYPE abap_func_parmbind,
          lt_ptab     TYPE abap_func_parmbind_tab.

    FIELD-SYMBOLS: <fs_data_old> TYPE any,
                   <ft_data_old> TYPE INDEX TABLE,
                   <ft_data_new> TYPE INDEX TABLE.

    DATA(lv_funcname) = |{ iv_class }_WRITE_DOCUMENT|.

    TRY.
        IF it_data_new IS SUPPLIED.
          NEW ycl_abap_rtts( iv_data = it_data_new )->get_table_inf( IMPORTING et_ddic_fields = DATA(lt_ddic) ).
          DATA(lv_t_tabname) = lt_ddic[ 1 ]-tabname.
          DATA(lv_xtable) = |X{ lv_t_tabname }|.
          DATA(lv_ytable) = |Y{ lv_t_tabname }|.
          DATA(lv_update) = |UPD_{ lv_t_tabname }|.
        ENDIF.
        NEW ycl_abap_rtts( iv_data = is_data_new )->get_struct_inf( IMPORTING et_ddic_fields = lt_ddic ).
        DATA(lv_tabname) = lt_ddic[ 1 ]-tabname.
        IF lv_update IS INITIAL.
          lv_update = |UPD_{ lv_tabname }|.
        ENDIF.
      CATCH ycx_abap_error INTO cx_error.
        cx_error->show_message(  ).
    ENDTRY.

    CALL FUNCTION 'DB_GET_TABLE_FIELDS'
      EXPORTING
        tabname  = lv_tabname
      TABLES
        dbfields = lt_tabfield.

    LOOP AT lt_tabfield INTO DATA(ls_tabfield) WHERE keyflag IS NOT INITIAL.
      ASSIGN COMPONENT ls_tabfield-name OF STRUCTURE is_data_new TO FIELD-SYMBOL(<fv_value>).
      lv_objectid = |{ lv_objectid }{ <fv_value> }|.
      CHECK ls_tabfield-name NE 'MANDT' AND ls_tabfield-name NE 'CLIENT'.
      lt_condtab = VALUE #( BASE lt_condtab ( field = ls_tabfield-name opera = 'EQ' low = <fv_value> ) ).
    ENDLOOP.

    CALL FUNCTION 'RH_DYNAMIC_WHERE_BUILD'
      EXPORTING
        dbtable      = space
      TABLES
        condtab      = lt_condtab
        where_clause = lt_whereclauses.

    CHECK lt_whereclauses IS NOT INITIAL.
    IF it_data_new IS SUPPLIED.
      CREATE DATA lr_t_data TYPE TABLE OF (lv_t_tabname).
      ASSIGN lr_t_data->* TO <ft_data_old>.
      SELECT FROM (lv_t_tabname) FIELDS * WHERE (lt_whereclauses) INTO TABLE @<ft_data_old>.
    ELSE.
      CREATE DATA lr_data TYPE (lv_tabname).
      ASSIGN lr_data->* TO <fs_data_old>.
      SELECT SINGLE FROM (lv_tabname) FIELDS * WHERE (lt_whereclauses) INTO @<fs_data_old>.
    ENDIF.

    IF sy-subrc IS NOT INITIAL.
      DATA(lv_action) = 'I'.
    ELSE.
      lv_action = 'U'.
    ENDIF.

    cl_fb_function_utility=>meth_get_interface( EXPORTING im_name      = CONV #( lv_funcname )
                                                IMPORTING ex_interface = DATA(ls_interface) ).

    SORT ls_interface-import ASCENDING.

    LOOP AT ls_interface-import INTO DATA(ls_import).

      CLEAR ls_ptab.
      IF ls_import-parameter = 'OBJECTID'.
        ls_ptab-name = ls_import-parameter.
        ls_ptab-kind = abap_func_exporting.
        ls_ptab-value = REF #( lv_objectid ).
      ELSEIF ls_import-parameter = |N_{ lv_tabname }|.
        ls_ptab-name = ls_import-parameter.
        ls_ptab-kind = abap_func_exporting.
        IF it_data_new IS SUPPLIED.
          CONTINUE.
        ELSE.
          ls_ptab-value = REF #( is_data_new ).
        ENDIF.
      ELSEIF ls_import-parameter = |O_{ lv_tabname }|.
        ls_ptab-name = ls_import-parameter.
        ls_ptab-kind = abap_func_exporting.
        IF <ft_data_old> IS ASSIGNED.
          CONTINUE.
        ELSE.
          ls_ptab-value = REF #( <fs_data_old> ).
        ENDIF.
      ELSEIF ls_import-parameter = 'TCODE'.
        ls_ptab-name = ls_import-parameter.
        ls_ptab-kind = abap_func_exporting.
        ls_ptab-value = REF #( sy-tcode ).
      ELSEIF ls_import-parameter = 'UTIME'.
        ls_ptab-name = ls_import-parameter.
        ls_ptab-kind = abap_func_exporting.
        ls_ptab-value = REF #( sy-uzeit ).
      ELSEIF ls_import-parameter = 'UDATE'.
        ls_ptab-name = ls_import-parameter.
        ls_ptab-kind = abap_func_exporting.
        ls_ptab-value = REF #( sy-datum ).
      ELSEIF ls_import-parameter = 'USERNAME'.
        ls_ptab-name = ls_import-parameter.
        ls_ptab-kind = abap_func_exporting.
        ls_ptab-value = REF #( sy-uname ).
      ELSEIF ls_import-parameter = lv_update.
        ls_ptab-name = ls_import-parameter.
        ls_ptab-kind = abap_func_exporting.
        ls_ptab-value = REF #( lv_action ).
      ENDIF.

      CHECK ls_ptab IS NOT INITIAL.
      APPEND ls_ptab TO lt_ptab.

    ENDLOOP.

    LOOP AT ls_interface-tables INTO DATA(ls_table).

      CLEAR ls_ptab.
      IF ls_table-parameter CP 'ICDTXT*'.
        ls_ptab-name = ls_table-parameter.
        ls_ptab-kind = abap_func_tables.
        ls_ptab-value = REF #( lt_dummy ).
      ELSEIF ls_table-parameter = lv_xtable.
        DATA lr_data_new TYPE REF TO data.
        CREATE DATA lr_data_new TYPE TABLE OF (ls_table-structure).
        ASSIGN lr_data_new->* TO <ft_data_new>.
        <ft_data_new> = CORRESPONDING #( it_data_new ).
        ls_ptab-name = ls_table-parameter.
        ls_ptab-kind = abap_func_tables.
        ls_ptab-value = REF #( <ft_data_new> ).
      ELSEIF ls_table-parameter = lv_ytable.
        DATA lr_data_old TYPE REF TO data.
        CREATE DATA lr_data_old TYPE TABLE OF (ls_table-structure).
        ASSIGN lr_data_old->* TO FIELD-SYMBOL(<ft_data_yold>).
        <ft_data_yold> = CORRESPONDING #( <ft_data_old> ).
        ls_ptab-name = ls_table-parameter.
        ls_ptab-kind = abap_func_tables.
        ls_ptab-value = REF #( <ft_data_yold> ).
      ENDIF.

      CHECK ls_ptab IS NOT INITIAL.
      APPEND ls_ptab TO lt_ptab.

    ENDLOOP.

    CALL FUNCTION lv_funcname
      PARAMETER-TABLE
      lt_ptab.

    COMMIT WORK AND WAIT.

  ENDMETHOD.


  METHOD xml_from_zip.
    DATA:
      lv_value TYPE xstring.

    " As a string
    IF ev_sdoc IS REQUESTED.
      CLEAR ev_sdoc.
    ENDIF.

    " As an object
    IF eo_xmldoc IS REQUESTED.
      CLEAR eo_xmldoc.
    ENDIF.

    " Try to read the document from archive
    io_zip->get(
      EXPORTING
        name    = iv_name
      IMPORTING
        content = lv_value
      EXCEPTIONS
        OTHERS  = 1 ).
    CHECK sy-subrc = 0.

    " As a string
    IF ev_sdoc IS REQUESTED.
      ev_sdoc = xstring_to_string( lv_value ).
    ENDIF.

    " As an object
    IF eo_xmldoc IS REQUESTED.
      eo_xmldoc = str_to_xml( iv_xstr = lv_value ).
    ENDIF.
  ENDMETHOD.


  METHOD xml_to_str.
    DATA:
      lo_xml     TYPE REF TO if_ixml,
      lo_encode  TYPE REF TO if_ixml_encoding,
      lo_factory TYPE REF TO if_ixml_stream_factory,
      lo_stream  TYPE REF TO if_ixml_ostream,
      lo_rendr   TYPE REF TO if_ixml_renderer.

    lo_xml    = cl_ixml=>create( ).

*        In a different encoding
*        IF im_charset IS NOT INITIAL.
    lo_encode = lo_xml->create_encoding( byte_order    = if_ixml_encoding=>co_platform_endian
                                         character_set = 'UTF-8' ).
    io_doc->set_encoding( lo_encode ).
*        ENDIF.

    lo_factory = lo_xml->create_stream_factory( ).

    " Return a xtring
    IF ev_xstr IS REQUESTED.
      CLEAR ev_xstr.
      lo_stream = lo_factory->create_ostream_xstring( string = ev_xstr ).
    ELSEIF ev_str IS REQUESTED. " Return a string
      CLEAR ev_str.
      lo_stream = lo_factory->create_ostream_cstring( string = ev_str ).
    ELSE.
      RETURN.
    ENDIF.

    lo_rendr = lo_xml->create_renderer( ostream = lo_stream document = io_doc ).
    lo_rendr->render( ).

    " Change encoding. still utf-16 in header
    IF ev_str IS REQUESTED.
      REPLACE FIRST OCCURRENCE OF 'utf-16' IN ev_str WITH 'UTF-8'.
    ENDIF.
  ENDMETHOD.


  METHOD xml_to_zip.
    DATA:
     lv_value TYPE xstring.

    " From string
    IF iv_xdoc IS SUPPLIED.
      lv_value = iv_xdoc.
    ELSEIF iv_sdoc IS SUPPLIED.
      " Transform string to xString
      lv_value = string_to_xstring( iv_sdoc ).
    ELSEIF io_xmldoc IS SUPPLIED. " From object
      " Transform document to xString
      xml_to_str(
        EXPORTING
          io_doc  = io_xmldoc
        IMPORTING
          ev_xstr = lv_value ).
    ELSE.
      RETURN.
    ENDIF.

    " Delete from ZIP
    io_zip->delete( EXPORTING name = iv_name EXCEPTIONS OTHERS = 1 ).

    " Add to ZIP
    io_zip->add( name = iv_name content = lv_value ).
  ENDMETHOD.


  METHOD xstring_to_base64.
    TRY.
        CALL METHOD ('CL_HTTP_UTILITY')=>('ENCODE_X_BASE64')
          EXPORTING
            unencoded = iv_xstring
          RECEIVING
            encoded   = rv_base64.
      CATCH cx_sy_dyn_call_error.
        " 7.00 doesn't have cl_http_utility=>encode_x_base64( ).
        DATA lv_error TYPE i.
        SYSTEM-CALL ict                              "#EC CI_SYSTEMCALL
          DID
            86 " ihttp_scid_base64_escape_x
          PARAMETERS
            iv_xstring
            rv_base64
            lv_error.                      " < return code
    ENDTRY.
  ENDMETHOD.


  METHOD xstring_to_binary.
    CALL FUNCTION 'SCMS_XSTRING_TO_BINARY'
      EXPORTING
        buffer        = iv_xstring
      IMPORTING
        output_length = ev_length
      TABLES
        binary_tab    = et_table.
  ENDMETHOD.


  METHOD xstring_to_string.
    DATA:
      lo_conv  TYPE REF TO cl_abap_conv_in_ce.

    lo_conv = cl_abap_conv_in_ce=>create(
      encoding = iv_encoding
      input    = iv_xstring ).

    lo_conv->read(
      IMPORTING
        data = rv_string ).
  ENDMETHOD.


  METHOD _abap_2_json.
    CONSTANTS:
      c_comma TYPE c VALUE ',',
      c_colon TYPE c VALUE ':',
      c_quote TYPE c VALUE '"'.

    DATA:
      dont_quote     TYPE xfeld,
      json_fragments TYPE TABLE OF string,
      rec_rv_json    TYPE string,
      l_comps        TYPE i,
      l_lines        TYPE i,
      l_index        TYPE i,
      l_value        TYPE string,
      l_name         TYPE string,
      l_strudescr    TYPE REF TO cl_abap_structdescr,
      lo_type        TYPE REF TO cl_abap_typedescr,
      lo_subtype     TYPE REF TO cl_abap_typedescr,
      lv_type        TYPE REF TO string.

    FIELD-SYMBOLS:
      <abap_data> TYPE any,
      <itab>      TYPE ANY TABLE,
      <comp>      TYPE any,
      <abapcomp>  TYPE abap_compdescr.

    DEFINE get_scalar_value.
      " &1 : assigned var
      " &2 : abap data
      " &3 : abap type
      &1 = &2.
*    ***************************************************
*     Adapt some basic ABAP types (pending inclusion of all basic abap types?)
*     Feel free to customize this for your needs
      CASE &3->type_kind.
*           1. ABAP numeric types
        WHEN 'I'. " Integer
          CONDENSE &1.
          IF sign( &1 ) < 0.
            SHIFT &1 BY 1 PLACES RIGHT CIRCULAR.
          ENDIF.
          dont_quote = 'X'.

        WHEN 'F'. " Float
          CONDENSE &1.
          dont_quote = 'X'.

        WHEN 'P'. " Packed number (used in quantities or currency, for example)
          CONDENSE &1.
          IF sign( &1 ) < 0.
            SHIFT &1 BY 1 PLACES RIGHT CIRCULAR.
          ENDIF.
          dont_quote = 'X'.

        WHEN 'X'. " Hexadecimal
          CONDENSE &1.
          CONCATENATE '0x' &1 INTO &1.
*            dont_quote = 'X'.
*            "Quote it, as JSON doesn't support Hex or Octal as native types.

*           2. ABAP char types
        WHEN 'D'. " Date type
          CONCATENATE &1(4) '-' &1+4(2) '-' &1+6(2) INTO &1.
          " &1 = convert_to_timestamp( iv_date = &1 ). 'T00:00:00'

        WHEN 'T'. " Time representation
          CONCATENATE &1(2) ':' &1+2(2) ':' &1+4(2) INTO &1.
          " '0000-00-00T'  &1 = convert_to_timestamp( iv_time = &1 ).

        WHEN 'N'. " Numeric text field
*               condense &1.

        WHEN 'C' OR 'g'. " Char sequences and Strings
          READ TABLE lcl_json_util=>mt_xsdboolean TRANSPORTING NO FIELDS BINARY SEARCH
           WITH KEY table_line = &3->absolute_name.
          IF sy-subrc = 0.
            dont_quote = 'X'.
            IF &2 = abap_true.
              &1 = 'true'.
            ELSE.
              &1 = 'false'.
            ENDIF.
          ELSEIF &3->absolute_name = '\TYPE=XSDDATETIME_LOCAL'." others ?

            IF strlen( &1 ) = 14.
              CONCATENATE &1(4) '-' &1+4(2) '-' &1+6(2)
                 'T' &1+8(2) ':' &1+10(2) ':' &1+12(2) INTO &1.
*                lv_date = &1(8).
*                lv_time = &1+8.
*                &1 = convert_to_timestamp( iv_date = lv_date iv_time = lv_time ).
            ELSE.
              &1 = ''.
            ENDIF.
          ELSE.
            " Put safe chars
            REPLACE ALL OCCURRENCES OF '\' IN &1 WITH '\\' .
            REPLACE ALL OCCURRENCES OF '"' IN &1 WITH '\"' .
            REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>cr_lf IN &1 WITH '\r\n' .
            REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>newline IN &1 WITH '\n' .
            REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>horizontal_tab IN &1 WITH '\t' .
            REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>backspace IN &1 WITH '\b' .
            REPLACE ALL OCCURRENCES OF cl_abap_char_utilities=>form_feed IN &1 WITH '\f' .
          ENDIF.

        WHEN 'y'.  " XSTRING
          &1 = xstring_to_base64( &2 ).

        WHEN OTHERS.
*     Don't hesitate to add and modify scalar abap types to suit your taste.

      ENDCASE.
*    * End of scalar data preparing.

*     Enclose value in quotes (or not)
      IF dont_quote NE 'X'.
        CONCATENATE c_quote &1 c_quote INTO &1.
      ENDIF.

      CLEAR dont_quote.

    END-OF-DEFINITION.


*    **************************************************
*      Prepare field names, JSON does quote names!!   *
*      You must be strict in what you produce.        *
*    **************************************************
    IF iv_name IS NOT INITIAL.
      CONCATENATE c_quote iv_name c_quote c_colon INTO rec_rv_json.
      APPEND rec_rv_json TO json_fragments.
      CLEAR rec_rv_json.
    ENDIF.

*    *
*     Get ABAP data type
    lo_type = cl_abap_typedescr=>describe_by_data( im_data ).
    " DESCRIBE FIELD im_data TYPE l_type COMPONENTS l_comps.

*    **************************************************
*      Get rid of data references
*    **************************************************
    IF lo_type->type_kind EQ cl_abap_typedescr=>typekind_dref.
      ASSIGN im_data->* TO <abap_data>.
      IF sy-subrc = 0.
        lo_type = cl_abap_typedescr=>describe_by_data( <abap_data> ).
      ELSE.
        CLEAR lo_type.
      ENDIF.

      IF sy-subrc <> 0 OR lo_type IS INITIAL.
        APPEND '{}' TO json_fragments.
        CONCATENATE LINES OF json_fragments INTO rv_json.
        EXIT.
      ENDIF.
    ELSE.
      ASSIGN im_data TO <abap_data>.
    ENDIF.

*     Get ABAP data type again and start
    " DESCRIBE FIELD <abap_data> TYPE l_type COMPONENTS l_comps.

    " A little fastaer than description of description
    TRY.
        l_strudescr ?= lo_type.
      CATCH cx_sy_move_cast_error.
        CLEAR l_strudescr.
    ENDTRY.

*    **************************************************
*      Tables
*    **************************************************
    IF lo_type->type_kind EQ cl_abap_typedescr=>typekind_table.
*     '[' JSON table opening bracket
      APPEND '[' TO json_fragments.
      ASSIGN <abap_data> TO <itab>.
      l_lines = lines( <itab> ).
      LOOP AT <itab> ASSIGNING <comp>.
        ADD 1 TO l_index.
*    > Recursive call for each table row:
        rec_rv_json = _abap_2_json( im_data = <comp> ).
        APPEND rec_rv_json TO json_fragments.
        CLEAR rec_rv_json.
        IF l_index < l_lines.
          APPEND c_comma TO json_fragments.
        ENDIF.
      ENDLOOP.
      APPEND ']' TO json_fragments.
*     ']' JSON table closing bracket

*    **************************************************
*      Objects
*    **************************************************
    ELSEIF lo_type->type_kind EQ cl_abap_typedescr=>typekind_oref.
      " Dump in 7.02 Only for jekyll info
      TRY.
          CALL METHOD ('/UI2/CL_JSON')=>serialize
            EXPORTING
              data   = <abap_data>
            RECEIVING
              r_json = rec_rv_json.
        CATCH cx_sy_dyn_call_error.
          rec_rv_json = '{}'.
      ENDTRY.
      APPEND rec_rv_json TO json_fragments.
      CLEAR rec_rv_json.

*    **************************************************
*      Structures
*    **************************************************
    ELSE.
      IF l_strudescr IS NOT INITIAL. " lo_class->absolute_name = '\CLASS=CL_ABAP_STRUCTDESCR'. " l_comps IS NOT INITIAL.
*     '{' JSON object opening curly brace
        APPEND '{' TO json_fragments.
        " l_strudescr ?=  lo_type. " cl_abap_typedescr=>describe_by_data( <abap_data> ).
        l_comps = lines( l_strudescr->components ).
        LOOP AT l_strudescr->components ASSIGNING <abapcomp>.
          l_index = sy-tabix .
          ASSIGN COMPONENT <abapcomp>-name OF STRUCTURE <abap_data> TO <comp>.
          l_name = <abapcomp>-name.
*    * ABAP names are usually in caps, set upcase to avoid the conversion to lower case.
          " DESCRIBE FIELD <comp> TYPE s_type.
          lo_subtype = cl_abap_typedescr=>describe_by_data( <comp> ).
          IF lo_subtype->type_kind EQ cl_abap_typedescr=>typekind_table   OR lo_subtype->type_kind EQ cl_abap_typedescr=>typekind_dref OR
             lo_subtype->type_kind EQ cl_abap_typedescr=>typekind_struct1 OR lo_subtype->type_kind EQ cl_abap_typedescr=>typekind_struct2.
*    > Recursive call for non-scalars:
            rec_rv_json = _abap_2_json( im_data = <comp> iv_name = l_name ).
          ELSE.
            IF lo_subtype->type_kind EQ cl_abap_typedescr=>typekind_oref OR lo_subtype->type_kind EQ cl_abap_typedescr=>typekind_iref.
              rec_rv_json = '"REF UNSUPPORTED"'.
            ELSE.
              get_scalar_value rec_rv_json <comp> lo_subtype.
            ENDIF.
            CONCATENATE c_quote l_name c_quote c_colon rec_rv_json INTO rec_rv_json.
          ENDIF.
          APPEND rec_rv_json TO json_fragments.
          CLEAR rec_rv_json. CLEAR l_name.
          IF l_index < l_comps.
            APPEND c_comma TO json_fragments.
          ENDIF.
        ENDLOOP.
        APPEND '}' TO json_fragments.
*     '}' JSON object closing curly brace

*    ***************************************************
*                      - Scalars -                     *
*    ***************************************************
      ELSE.
        get_scalar_value l_value <abap_data> lo_type.
        APPEND l_value TO json_fragments.

      ENDIF.
*     End of structure/scalar IF block.
*    **********************************

    ENDIF.
*     End of main IF block.
*    *********************

*     Use a loop in older releases that don't support concatenate lines.
    CONCATENATE LINES OF json_fragments INTO rv_json.
  ENDMETHOD.


  METHOD _get_last_space.

    IF strlen( iv_string ) > iv_max_len.
      rv_offset = iv_max_len - 1.
      DO.
        IF iv_string+rv_offset(1) = ` `.
          EXIT.
        ELSE.
          rv_offset = rv_offset - 1.
        ENDIF.
      ENDDO.
    ENDIF.

  ENDMETHOD.


  METHOD _json_2_abap.
*    /************************************************/*
*    / Input any abap data and this method tries to   /*
*    / fill it with the data in the JSON string.      /*
*    /  Thanks to Juan Diaz for helping here!!        /*
*    /************************************************/*

    TYPE-POOLS: abap, js.

    DATA:
      js_script         TYPE string,
      js_started        TYPE i VALUE 0,
      l_json_string     TYPE string,
      js_property_table TYPE   js_property_tab,
      js_property       TYPE LINE OF js_property_tab,
      l_property_path   TYPE string,
      compname          TYPE string,
      item_path         TYPE string.

    DATA:
*        l_type   TYPE c,
      l_value  TYPE string,
      linetype TYPE string,
      l_comp   TYPE LINE OF abap_compdescr_tab.

    DATA:
      datadesc  TYPE REF TO cl_abap_typedescr,
      drefdesc  TYPE REF TO cl_abap_typedescr,
      linedesc  TYPE REF TO cl_abap_typedescr,
      strudesc  TYPE REF TO cl_abap_structdescr,
      tabldesc  TYPE REF TO cl_abap_tabledescr,
      data_desc TYPE REF TO cl_abap_datadescr.

    DATA newline TYPE REF TO data.

    FIELD-SYMBOLS:
      <abap_data> TYPE any,
      <itab>      TYPE ANY TABLE,
      <comp>      TYPE any,
      <jsprop>    TYPE LINE OF js_property_tab,
      <abapcomp>  TYPE abap_compdescr.

    DATA lo_type TYPE REF TO cl_abap_typedescr.

    DEFINE assign_scalar_value.
      "   &1   <abap_data>
      "   &2   js_property-value
      "DESCRIBE FIELD &1 TYPE l_type.
      lo_type = cl_abap_typedescr=>describe_by_data( &1 ).

      l_value = &2.
*     convert or adapt scalar values to ABAP.
      CASE lo_type->type_kind.
        WHEN 'D'. " date type
          IF l_value CS '-'.
            REPLACE ALL OCCURRENCES OF '-' IN l_value WITH space.
            CONDENSE l_value NO-GAPS.
          ENDIF.
        WHEN 'T'. " time type
          IF l_value CS ':'.
            REPLACE ALL OCCURRENCES OF ':' IN l_value WITH space.
            CONDENSE l_value NO-GAPS.
          ENDIF.
        WHEN 'C'. " char
          READ TABLE lcl_json_util=>mt_xsdboolean TRANSPORTING NO FIELDS BINARY SEARCH
           WITH KEY table_line = lo_type->absolute_name.
          IF sy-subrc = 0.
            CASE l_value.
              WHEN 'true'.
                l_value = abap_true.

              WHEN 'false'.
                l_value = abap_false.

              WHEN OTHERS.
                l_value = abap_undefined.

            ENDCASE.
          ENDIF.

        WHEN OTHERS.
          " may be other conversions or checks could be implemented here.
      ENDCASE.
      &1 = l_value.
    END-OF-DEFINITION.


    IF js_object IS NOT BOUND.

      IF json_string IS INITIAL. EXIT. ENDIF. " exit method if there is nothing to parse

      l_json_string = json_string.
      " js_object = cl_java_script=>create( STACKSIZE = 16384 ).
      js_object = cl_java_script=>create( stacksize = 16384 heapsize = 960000 ).

*    **************************************************
*      Parse JSON using JavaScript                    *
*    **************************************************
      js_object->bind( EXPORTING name_obj = 'abap_data' name_prop = 'json_string'    CHANGING data = l_json_string ).
      js_object->bind( EXPORTING name_obj = 'abap_data' name_prop = 'script_started' CHANGING data = js_started ).

*     We use the JavaScript engine included in ABAP to read the JSON string.
*     We simply use the recommended way to eval a JSON string as specified
*     in RFC 4627 (http://www.ietf.org/rfc/rfc4627.txt).
*
*     Security considerations:
*
*       Generally there are security issues with scripting languages.  JSON
*       is a subset of JavaScript, but it is a safe subset that excludes
*       assignment and invocation.
*
*       A JSON text can be safely passed into JavaScript's eval() function
*       (which compiles and executes a string) if all the characters not
*       enclosed in strings are in the set of characters that form JSON
*       tokens.  This can be quickly determined in JavaScript with two
*       regular expressions and calls to the test and replace methods.
*
*          var my_JSON_object = !(/[^,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t]/.test(
*                 text.replace(/"(\\.|[^"\\])*"/g, ''))) &&
*             eval('(' + text + ')');

      CONCATENATE

           'var json_obj; '
           'var json_text; '

           'function start() { '
           '  if(abap_data.script_started) { return; } '
           '  json_text = abap_data.json_string;'
           '  json_obj = !(/[^,:{}\[\]0-9.\-+Eaeflnr-u \n\r\t]/.test( '
           '      json_text.replace(/"(\\.|[^"\\])*"/g, ''''))) && '
           '    eval(''('' + json_text + '')''); '
           '  abap_data.script_started = 1; '
           '} '

           'if(!abap_data.script_started) start(); '


         INTO js_script RESPECTING BLANKS SEPARATED BY cl_abap_char_utilities=>newline.

      js_object->compile( script_name = 'json_parser'     script = js_script ).
      js_object->execute( script_name = 'json_parser' ).

      IF js_object->last_error_message IS NOT INITIAL.
        cx_error->add_text( iv_message = CONV #( js_object->last_error_message ) ).
        cx_error->show_message( ).
      ENDIF.

    ENDIF.
*    * End of JS processing.

*    *
    IF var_name IS NOT INITIAL.
      CONCATENATE property_path var_name INTO l_property_path SEPARATED BY '.'.
    ELSE.
      l_property_path = property_path.
    ENDIF.
*    *
*    *
    js_property_table = js_object->get_properties_scope_global( property_path = l_property_path ).
    property_table = js_property_table.

*     Exit if abap_data is not supplied, normally when called
*     from json_deserialize to get top level properties
    IF abap_data IS NOT SUPPLIED.
      EXIT.
    ENDIF. "***

*
*     Get ABAP data type, dereference if necessary and start
    datadesc = cl_abap_typedescr=>describe_by_data( abap_data ).
    IF datadesc->kind EQ cl_abap_typedescr=>kind_ref.
      ASSIGN abap_data->* TO <abap_data>.
    ELSE.
      ASSIGN abap_data TO <abap_data>.
    ENDIF.
    datadesc = cl_abap_typedescr=>describe_by_data( <abap_data> ).


    CASE datadesc->kind.

      WHEN cl_abap_typedescr=>kind_elem.
*     Scalar: process ABAP elements. Assume no type conversions for the moment.
        IF var_name IS INITIAL.
          cx_error->add_text( iv_message = 'VAR_NAME is required for scalar values.' ).
          cx_error->show_message( ).
        ENDIF.
        js_property_table = js_object->get_properties_scope_global( property_path = property_path ).
        READ TABLE js_property_table WITH KEY name = var_name INTO js_property.
        IF sy-subrc EQ 0.
          assign_scalar_value <abap_data> js_property-value.
        ENDIF.


      WHEN cl_abap_typedescr=>kind_struct.
*     Process ABAP structures
        strudesc ?= datadesc.
        LOOP AT js_property_table ASSIGNING <jsprop>.
          compname = <jsprop>-name.
          TRANSLATE compname TO UPPER CASE.
          READ TABLE strudesc->components WITH KEY name = compname INTO l_comp.
          IF sy-subrc EQ 0.
            ASSIGN COMPONENT l_comp-name OF STRUCTURE <abap_data> TO <comp>.
            CASE l_comp-type_kind.
              WHEN    cl_abap_typedescr=>typekind_struct1  " 'v'
                   OR cl_abap_typedescr=>typekind_struct2  " 'u'
                   OR cl_abap_typedescr=>typekind_table.   " 'h' (may need a different treatment one day)
                CONCATENATE l_property_path <jsprop>-name INTO item_path SEPARATED BY '.'.
*    > Recursive call here
                _json_2_abap( EXPORTING property_path = item_path CHANGING abap_data = <comp> js_object = js_object ).

              WHEN OTHERS.
*     Process scalars in structures (same as the kind_elem above)
                assign_scalar_value <comp> <jsprop>-value.

            ENDCASE.
          ENDIF.
        ENDLOOP.

      WHEN cl_abap_typedescr=>kind_table.
*     Process ABAP tables
        IF js_property_table IS NOT INITIAL.
          tabldesc ?= datadesc.
          data_desc ?= tabldesc->get_table_line_type( ).

          ASSIGN <abap_data> TO <itab>.
          LOOP AT js_property_table INTO js_property WHERE name NE 'length'. " the JS object length

*              linetype = linedesc->get_relative_name( ).
            CREATE DATA newline TYPE HANDLE data_desc.
            ASSIGN newline->* TO <comp>.

            CASE js_property-kind.
              WHEN 'O'.
                CONCATENATE l_property_path js_property-name INTO item_path SEPARATED BY '.'.
                CONDENSE item_path.
*    > Recursive call here
                _json_2_abap( EXPORTING property_path = item_path CHANGING abap_data = newline js_object = js_object ).
              WHEN OTHERS. " Assume scalars, 'S', 'I', or other JS types
                " Process scalars in plain table components(same as the kind_elem above)
                assign_scalar_value <comp> js_property-value.
            ENDCASE.
            INSERT <comp> INTO TABLE <itab>.
            FREE newline.
          ENDLOOP.
        ENDIF.

      WHEN OTHERS. " kind_class, kind_intf
        " forget it.

    ENDCASE.
  ENDMETHOD.
ENDCLASS.
