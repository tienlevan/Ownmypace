CLASS ycl_abap_document_create DEFINITION
  PUBLIC
  FINAL
  CREATE PUBLIC .

  PUBLIC SECTION.

    TYPES:
      BEGIN OF ts_merge,
        key TYPE string,
        val TYPE REF TO data,
        obj TYPE REF TO object, " For 160 only
      END OF ts_merge .
    TYPES:
      tt_merge TYPE STANDARD TABLE OF ts_merge WITH DEFAULT KEY .

    DATA av_type TYPE string .
    DATA ar_xtt TYPE REF TO zcl_xtt .
    DATA ar_file TYPE REF TO zif_xtt_file .
    DATA at_merge_field TYPE tt_merge .
    DATA ar_container TYPE REF TO cl_gui_container .
    DATA ar_email TYPE REF TO ycl_abap_email .
    CONSTANTS mc_act_dowload TYPE char1 VALUE 'D' ##NO_TEXT.
    CONSTANTS mc_act_show TYPE char1 VALUE 'S' ##NO_TEXT.
    CONSTANTS mc_act_send TYPE char1 VALUE 'X' ##NO_TEXT.
    CONSTANTS mc_act_generate TYPE char1 VALUE 'G' ##NO_TEXT.
    CONSTANTS mc_act_download_as_pdf TYPE char1 VALUE 'P' ##NO_TEXT.

    METHODS constructor
      IMPORTING
        !iv_template  TYPE csequence
        !io_container TYPE REF TO cl_gui_container OPTIONAL .
    METHODS merge_field_data
      IMPORTING
        !is_root    TYPE any
        !iv_root_id TYPE char1 DEFAULT 'R'
        !io_helper  TYPE REF TO object OPTIONAL .
    METHODS show .
    METHODS download
      RETURNING
        VALUE(rv_downloaded) TYPE boole_d .
    METHODS send .
    METHODS execute
      IMPORTING
        !iv_action         TYPE action_done_kk DEFAULT 'S'
        !is_node           TYPE ztb_treeload OPTIONAL
        !iv_input          TYPE string OPTIONAL
        !iv_file_name      TYPE string OPTIONAL
      EXPORTING
        VALUE(ev_base64)   TYPE string
        VALUE(ev_download) TYPE boole_d
        !et_html           TYPE solix_tab
      CHANGING
        !ct_wb_code        TYPE soli_tab OPTIONAL
      RETURNING
        VALUE(rv_runtime)  TYPE bwsd_runtime .
    METHODS genreate_base64
      RETURNING
        VALUE(rv_base64_data) TYPE string .
    METHODS generate_html
      IMPORTING
        !i_data        TYPE any OPTIONAL
      RETURNING
        VALUE(rt_html) TYPE solix_tab .
    METHODS generate
      IMPORTING
        !iv_action        TYPE action_done_kk DEFAULT zcl_ul_file_create=>mc_act_dowload
        !it_data          TYPE any
      RETURNING
        VALUE(rv_success) TYPE boole_d.
    METHODS download_as_pdf
      RETURNING VALUE(rv_dowloaded) TYPE boole_d.
  PROTECTED SECTION.

    METHODS _merge
      IMPORTING
        !it_merge TYPE tt_merge .
    METHODS _do_download RETURNING VALUE(rv_downloaded) TYPE boole_d.
    METHODS _send_email .
    METHODS _make_string_message
      IMPORTING
        !iv_info          TYPE csequence
      RETURNING
        VALUE(rr_message) TYPE REF TO string .
    METHODS load_editor
      IMPORTING
        !iv_section    TYPE char3
        !is_node       TYPE ztb_treeload OPTIONAL
      RETURNING
        VALUE(rt_code) TYPE soli_tab .
  PRIVATE SECTION.

    CONSTANTS mc_cp_word TYPE string VALUE '*.DOC*' ##NO_TEXT.
    CONSTANTS mc_cp_excel TYPE string VALUE '*.XLS*' ##NO_TEXT.
    CONSTANTS mc_cp_word_xml TYPE string VALUE '*WORD*-XML' ##NO_TEXT.
    CONSTANTS mc_cp_excel_xml TYPE string VALUE '*EXCEL*-XML' ##NO_TEXT.
    CONSTANTS mc_cp_pdf TYPE string VALUE '*PDF' ##NO_TEXT.
    CONSTANTS mc_cp_xdp TYPE string VALUE '*XDP' ##NO_TEXT.
    CONSTANTS mc_cp_html TYPE string VALUE '*HTM*' ##NO_TEXT.
    CONSTANTS mc_cl_word TYPE string VALUE 'ZCL_XTT_WORD_DOCX' ##NO_TEXT.
    CONSTANTS mc_cl_excel TYPE string VALUE 'ZCL_XTT_EXCEL_XLSX' ##NO_TEXT.
    CONSTANTS mc_cl_word_xml TYPE string VALUE 'ZCL_XTT_WORD_XML' ##NO_TEXT.
    CONSTANTS mc_cl_excel_xml TYPE string VALUE 'ZCL_XTT_EXCEL_XML' ##NO_TEXT.
    CONSTANTS mc_cl_pdf TYPE string VALUE 'ZCL_XTT_PDF' ##NO_TEXT.
    CONSTANTS mc_cl_html TYPE string VALUE 'ZCL_XTT_HTML' ##NO_TEXT.
    DATA _tree_node TYPE ztb_treeload .
ENDCLASS.



CLASS ycl_abap_document_create IMPLEMENTATION.


  METHOD constructor.

    DATA lv_class TYPE string.
    IF iv_template CP mc_cp_word.
      lv_class = mc_cl_word.
      av_type  = 'Word'.                                    "#EC NOTEXT
    ELSEIF iv_template CP mc_cp_excel.
      lv_class = mc_cl_excel.
      av_type  = 'Excel'.                                   "#EC NOTEXT
    ELSEIF iv_template CP mc_cp_word_xml.
      lv_class = mc_cl_word_xml.
      av_type  = 'Word XML'.                                "#EC NOTEXT
    ELSEIF iv_template CP mc_cp_excel_xml.
      lv_class = mc_cl_excel_xml.
      av_type  = 'Excel XML'.                               "#EC NOTEXT
    ELSEIF iv_template CP mc_cp_pdf OR iv_template CP mc_cp_xdp.
      lv_class = mc_cl_pdf.
      av_type  = 'Adobe PDF'.                               "#EC NOTEXT
    ELSEIF iv_template CP mc_cp_html.
      lv_class = mc_cl_html.
      av_type  = 'Html'.                                    "#EC NOTEXT
    ENDIF.

    CREATE OBJECT ar_file TYPE zcl_xtt_file_oaor
      EXPORTING
        iv_classname  = 'SOFFICEINTEGRATION'
        iv_classtype  = 'OT'
        iv_object_key = 'DOI'
        iv_filename   = iv_template.

    CREATE OBJECT ar_xtt TYPE (lv_class)
      EXPORTING
       io_file = ar_file.

    SPLIT iv_template AT '.' INTO DATA(filename) DATA(ext).
    SELECT SINGLE FROM ztb_treeload FIELDS * WHERE text = @filename AND modulelo = 'WB_TEMP'
     INTO CORRESPONDING FIELDS OF @_tree_node.
    IF sy-subrc IS INITIAL.
      _tree_node-text = iv_template.
    ENDIF.

    CHECK io_container IS BOUND.
    ar_container = io_container.

  ENDMETHOD.


  METHOD download.

    " Paste data
    _merge( it_merge = at_merge_field ).

    rv_downloaded = _do_download( ).

  ENDMETHOD.


  METHOD execute.

    DATA: lv_mess(225),
          lv_line      TYPE i,
          lv_word(30),
          lv_prog      TYPE sy-repid.

    DATA: lo_data    TYPE REF TO data,
          lv_runtime TYPE bwsd_runtime,
          lt_code    TYPE soli_tab.

    DATA(lt_top) = load_editor( iv_section = 'TOP' ).
    _tree_node = COND #( WHEN is_node IS NOT INITIAL THEN is_node ELSE _tree_node ).
    DATA(lt_exe) = load_editor( iv_section = 'EXE' is_node = _tree_node ).
    IF ct_wb_code NE lt_exe AND lt_exe IS NOT INITIAL AND ct_wb_code IS NOT INITIAL.
      IF zcl_ul_abap=>popup_to_confirm( 'Logic code has been changed, Do you want to overwrite the saved code?' ) = '1'.
        lt_exe = ct_wb_code.
      ELSE.
        ct_wb_code = lt_exe.
      ENDIF.
    ENDIF.
    DATA(lt_end) = load_editor( iv_section = 'END' ).
    APPEND LINES OF lt_top TO lt_code.
    APPEND LINES OF lt_exe TO lt_code.
    APPEND LINES OF lt_end TO lt_code.

    GENERATE SUBROUTINE POOL lt_code NAME lv_prog
             MESSAGE lv_mess LINE lv_line WORD lv_word.

    IF sy-subrc NE 0.
      ycx_abap_error=>raise_message( iv_msg_text = | { lv_mess }( line:{ lv_line - 6 }, word: { lv_word } )| ).
      RETURN.
    ENDIF.

    IF iv_file_name IS NOT INITIAL.
      _tree_node-text = iv_file_name.
    ENDIF.

    PERFORM run IN PROGRAM (lv_prog)
    USING iv_input
    CHANGING lo_data lv_runtime.
    IF lo_data IS NOT INITIAL.
      ASSIGN lo_data->* TO FIELD-SYMBOL(<ft_data>).
      merge_field_data( <ft_data> ).
      CASE iv_action.
        WHEN mc_act_show.
          LOOP AT ar_container->children INTO DATA(children).
            children->free(  ).
          ENDLOOP.
          show( ).
        WHEN mc_act_dowload.
          ev_download = download( ).
        WHEN mc_act_send.
          send( ).
        WHEN mc_act_generate.
          IF ev_base64 IS REQUESTED.
            ev_base64 = genreate_base64( ).
          ENDIF.
          IF et_html IS REQUESTED.
            et_html = generate_html( ).
          ENDIF.
        WHEN mc_act_download_as_pdf.
          ev_download = download_as_pdf( ).
      ENDCASE.
      rv_runtime = lv_runtime.
    ELSE.
      ycx_abap_error=>raise_message( iv_msg_text = 'No data processing!' ).
    ENDIF.

  ENDMETHOD.


  METHOD generate.

    merge_field_data( it_data ).

    CASE iv_action.
      WHEN mc_act_show.
        show( ).
      WHEN mc_act_dowload.
        rv_success = download( ).
      WHEN mc_act_send.
        send( ).
      WHEN mc_act_download_as_pdf.
        rv_success = download_as_pdf( ).
    ENDCASE.

  ENDMETHOD.


  METHOD generate_html.

    "Added by TIENLV1 on 10 Dec 2024 14:43:40
    "Purpose: Support import parameter
    IF i_data IS SUPPLIED.
      merge_field_data( i_data ).
    ENDIF.
    "End

    " Paste data
    _merge( it_merge = at_merge_field ).

    rt_html = cl_bcs_convert=>xstring_to_solix( EXPORTING iv_xstring = ar_xtt->get_raw( ) ).

  ENDMETHOD.


  METHOD genreate_base64.

    " Paste data
    _merge( it_merge = at_merge_field ).

    CASE av_type.
      WHEN 'Word'.
        rv_base64_data = `data:application/vnd.openxmlformats-officedocument.wordprocessingml.document;base64,`.
      WHEN 'Excel'.
        rv_base64_data = `data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,`.
    ENDCASE.

    rv_base64_data = rv_base64_data && zcl_eui_conv=>xstring_to_base64( ar_xtt->get_raw( ) ).

  ENDMETHOD.


  METHOD load_editor.
    CASE iv_section.
      WHEN 'TOP'.
        rt_code = VALUE #(  ( line = | PROGRAM SUBPOOL. | )
                            ( line = | LOAD-OF-PROGRAM. | )
                            ( line = | FORM run USING input TYPE string  |
                                   & | CHANGING fo_data TYPE REF TO data |
                                   & |        runtime TYPE bwsd_runtime. | )
                            ( line = | DATA: w_timestart type timestampl,| )
                            ( line = |       w_timeend type timestampl.  |  )
                            ( line = | GET TIME STAMP FIELD w_timestart. | ) ).
      WHEN 'EXE'.
        SELECT SINGLE FROM ztb_tree_rtcode FIELDS rt_code
         WHERE modulelo = @is_node-modulelo
         AND  node_key = @is_node-node_key
         INTO @DATA(lv_rtcode).
        IF lv_rtcode IS INITIAL.
          SELECT SINGLE FROM ztb_tree_rtcode FIELDS rt_code
           WHERE modulelo = @is_node-modulelo
           AND  node_key = @is_node-relatkey
           INTO @lv_rtcode.
        ENDIF.
        CHECK lv_rtcode IS NOT INITIAL.
        SPLIT lv_rtcode AT cl_abap_char_utilities=>cr_lf
                      INTO TABLE rt_code.
      WHEN 'END'.
        rt_code = VALUE #( ( line = | GET TIME STAMP FIELD w_timeend. | )
                           ( line = | FIELD-SYMBOLS <ft_data> LIKE m_data .| )
                           ( line = | CREATE DATA fo_data LIKE m_data .| )
                           ( line = | ASSIGN fo_data->* TO <ft_data> .| )
                           ( line = | <ft_data> = m_data. | )
                           ( line = | runtime = w_timeend - w_timestart. | )
                           ( line = | ENDFORM. | ) ).
    ENDCASE.
  ENDMETHOD.


  METHOD merge_field_data.

    DATA          ls_merge  TYPE ts_merge.
    FIELD-SYMBOLS <l_value> TYPE any.

    ls_merge-key = iv_root_id.

    CREATE DATA ls_merge-val LIKE is_root.
    ASSIGN ls_merge-val->* TO <l_value>.
    <l_value> = is_root.

    ls_merge-obj = io_helper.

    INSERT ls_merge INTO TABLE at_merge_field.

  ENDMETHOD.


  METHOD send.

    " Paste data
    _merge( it_merge = at_merge_field ).

    _send_email( ).

  ENDMETHOD.


  METHOD show.

    " Paste data
    _merge( it_merge = at_merge_field ).

    " For PAI & PBO events
    ar_xtt->show( io_handler = me ).

  ENDMETHOD.


  METHOD _do_download.

    DATA: path      TYPE string,
          full_path TYPE string,
          file_name TYPE string.

    file_name = _tree_node-text.

    cl_gui_frontend_services=>file_save_dialog( EXPORTING prompt_on_overwrite = abap_true with_encoding = abap_true default_file_name = file_name
                                                CHANGING filename = file_name path = path fullpath = full_path
                                                EXCEPTIONS cntl_error = 1 error_no_gui = 2 invalid_default_file_name = 3 not_supported_by_gui = 4
                                                OTHERS = 5  ).
    IF sy-subrc IS NOT INITIAL OR path IS INITIAL.
      ycx_abap_error=>raise_message(  ). RETURN.
    ENDIF.

    ar_xtt->download(  CHANGING  cv_fullpath = full_path ).
    rv_downloaded = abap_true.

  ENDMETHOD.


  METHOD _make_string_message.

    CREATE DATA rr_message.
    rr_message->* = iv_info.

  ENDMETHOD.


  METHOD _merge.

    FIELD-SYMBOLS: <ls_merge> LIKE LINE OF it_merge,
                   <ls_root>  TYPE any.


    LOOP AT it_merge ASSIGNING <ls_merge>.
      ASSIGN <ls_merge>-val->* TO <ls_root>.

      ar_xtt->merge( is_block      = <ls_root>
                     iv_block_name = <ls_merge>-key " <--- 'R' by default
                     io_helper     = <ls_merge>-obj " For 160 example only
                    ).
    ENDLOOP.

  ENDMETHOD.


  METHOD _send_email.

    DATA: lv_value     TYPE xstring,
          lt_header    TYPE soli_tab,
          lv_filename  TYPE string,
          ls_header    TYPE REF TO soli,
          lv_file_size TYPE i,
          lv_size      TYPE sood-objlen,
          lt_data      TYPE solix_tab,
          lv_ext       TYPE soodk-objtp.

    CHECK ar_email IS BOUND.

    IF ar_xtt->mv_file_name IS NOT INITIAL.
      " File name
      APPEND INITIAL LINE TO lt_header REFERENCE INTO ls_header.
      lv_filename = ar_xtt->mv_file_name.
      CONCATENATE '&SO_FILENAME=' lv_filename INTO ls_header->line.

      " Show icon
      zcl_eui_file=>split_file_path(
        EXPORTING
          iv_fullpath  = lv_filename
        IMPORTING
          ev_extension = lv_ext ). " First 3 chars
      TRANSLATE lv_ext TO UPPER CASE.

      " Convert to table
      lv_value = ar_xtt->get_raw( ).
      zcl_eui_conv=>xstring_to_binary( EXPORTING iv_xstring = lv_value
                                       IMPORTING ev_length  = lv_file_size
                                                 et_table   = lt_data ).
      lv_size = lv_file_size.

      " Add attachment
      TRY.
          ar_email->create_document(
            is_attachment        = abap_true
            i_type               = lv_ext
            i_subject            = CONV #( lv_filename )
            i_size               = lv_size
            i_hex                = lt_data
            i_attachment_header  = lt_header ).

          ar_email->send_email( ).
        CATCH ycx_abap_error INTO DATA(error).
          error->show_message( ).
      ENDTRY.

    ENDIF.

  ENDMETHOD.

  METHOD download_as_pdf.

    "->OLE2
    INCLUDE ole2incl.
    DATA: word     TYPE ole2_object,
          doc_temp TYPE ole2_object,
          doc_pdf  TYPE ole2_object,
          excel    TYPE ole2_object,
          ws_temp  TYPE ole2_object,
          ws_pdf   TYPE ole2_object.
    "<-OLE2

    "->SAVE_ON_PC
    TYPES: ty_x_row_type(100) TYPE x.
    DATA: lt_bin_data TYPE STANDARD TABLE OF ty_x_row_type,
          ls_bin_data LIKE LINE OF lt_bin_data.
    DATA: lv_bin_data_len TYPE i.
    "<-SAVE_ON_PC

    DATA: lv_open_path TYPE string,
          lv_save_path TYPE string,
          lv_save_dir  TYPE string,
          lv_ext       TYPE char10,
          lv_index     TYPE i.

    DATA lv_postfix TYPE i.
    DATA lv_rc TYPE i.

    CHECK av_type IN zcl_ul_abap=>string_to_range( 'Excel,Word' ) AND ar_xtt->get_raw( ) IS NOT INITIAL.
    lv_postfix = 1.
    cl_gui_frontend_services=>get_temp_directory(
        CHANGING temp_dir  = lv_save_dir    " Temporary Directory
        EXCEPTIONS
         OTHERS            = 4 ).
    cl_gui_cfw=>flush( EXCEPTIONS
                        OTHERS = 3 ).

    lv_open_path =  lv_save_dir && '\' && 'temp' && SWITCH string( av_type
                                                                   WHEN 'Excel' THEN '.xlsx'
                                                                   WHEN 'Word'  THEN '.docx' ).

    "->SAVE_ON_PC
    CALL FUNCTION 'SCMS_XSTRING_TO_BINARY'
      EXPORTING
        buffer        = ar_xtt->get_raw( )
      IMPORTING
        output_length = lv_bin_data_len
      TABLES
        binary_tab    = lt_bin_data.


    CALL METHOD cl_gui_frontend_services=>gui_download
      EXPORTING
        bin_filesize  = lv_bin_data_len
        filename      = lv_open_path
        filetype      = 'BIN'
        no_auth_check = abap_true
      CHANGING
        data_tab      = lt_bin_data
      EXCEPTIONS
        OTHERS        = 1.
    IF sy-subrc <> 0.
      ycx_abap_error=>raise_message(  ). RETURN.
    ENDIF.
    "<-SAVE_ON_PC

    "->OLE2
    lv_save_path = lv_save_dir && '\' && 'temp' && '.pdf'.

    CASE av_type.

      WHEN 'Word'.
        CREATE OBJECT word 'Word.Application'.
        SET PROPERTY OF word 'Visible' = 0.
        CALL METHOD OF word 'Documents' = doc_temp.
        CALL METHOD OF doc_temp 'OPEN'
          EXPORTING
            #1  = lv_open_path
            #2  = 0
            #12 = 0.
        CALL METHOD OF word 'ActiveDocument' = doc_pdf.
        CALL METHOD OF doc_pdf 'SaveAs2'
          EXPORTING
            #1 = lv_save_path
            #2 = 17. "PDF
        CALL FUNCTION 'FLUSH'.
        CALL METHOD OF word 'QUIT'.
        CALL METHOD OF doc_pdf 'CLOSE'
          EXPORTING
            #1 = 0.
        CALL METHOD OF doc_temp 'CLOSE'
          EXPORTING
            #1 = 0.

        FREE OBJECT word.
        FREE OBJECT doc_pdf.
        FREE OBJECT doc_temp.

      WHEN 'Excel'.
        CREATE OBJECT excel 'Excel.Application'.
        SET PROPERTY OF excel 'Visible' = 0.
        CALL METHOD OF excel 'Workbooks' = ws_temp.
        CALL METHOD OF ws_temp 'OPEN'
          EXPORTING
            #1  = lv_open_path
            #2  = 0
            #12 = 0.
        CALL METHOD OF excel 'ActiveSheet' = ws_pdf.
        CALL METHOD OF ws_pdf 'ExportAsFixedFormat'
          EXPORTING
            #1 = 0 "PDF
            #2 = lv_save_path
            #5 = 1. "Print area
        CALL FUNCTION 'FLUSH'.
        CALL METHOD OF excel 'QUIT'.
        CALL METHOD OF ws_pdf 'CLOSE'
          EXPORTING
            #1 = 0.
        CALL METHOD OF ws_temp 'CLOSE'
          EXPORTING
            #1 = 0.

        FREE OBJECT excel.
        FREE OBJECT ws_pdf.
        FREE OBJECT ws_temp.

    ENDCASE.

    CALL FUNCTION 'FLUSH'.
    "<-OLE2

    "->OPEN_xstring_PC
    CLEAR lt_bin_data[].
    CLEAR lv_index.
    CALL METHOD cl_gui_frontend_services=>gui_upload
      EXPORTING
        filename   = lv_save_path "PDF
        filetype   = 'BIN'
      IMPORTING
        filelength = lv_index
      CHANGING
        data_tab   = lt_bin_data
      EXCEPTIONS
        OTHERS     = 1.
    IF sy-subrc <> 0.
      ycx_abap_error=>raise_message(  ). RETURN.
    ENDIF.
    "<-OPEN_xstring_PC

    CHECK lt_bin_data IS NOT INITIAL.
    CALL METHOD cl_gui_frontend_services=>file_delete
      EXPORTING
        filename             = lv_save_path
      CHANGING
        rc                   = lv_rc
      EXCEPTIONS
        file_delete_failed   = 1
        cntl_error           = 2
        error_no_gui         = 3
        file_not_found       = 4
        access_denied        = 5
        unknown_error        = 6
        not_supported_by_gui = 7
        wrong_parameter      = 8
        OTHERS               = 9.
    IF sy-subrc <> 0.
      ycx_abap_error=>raise_message(  ). RETURN.
    ENDIF.

    CALL METHOD cl_gui_frontend_services=>file_delete
      EXPORTING
        filename             = lv_open_path
      CHANGING
        rc                   = lv_rc
      EXCEPTIONS
        file_delete_failed   = 1
        cntl_error           = 2
        error_no_gui         = 3
        file_not_found       = 4
        access_denied        = 5
        unknown_error        = 6
        not_supported_by_gui = 7
        wrong_parameter      = 8
        OTHERS               = 9.
    IF sy-subrc <> 0.
      ycx_abap_error=>raise_message(  ). RETURN.
    ENDIF.

    CHECK lt_bin_data[] IS NOT INITIAL.
    CALL FUNCTION 'TRINT_FILE_GET_EXTENSION'
      EXPORTING
        filename  = _tree_node-text
      IMPORTING
        extension = lv_ext.
    IF lv_ext IS NOT INITIAL.
      REPLACE lv_ext IN _tree_node-text WITH '' IGNORING CASE.
    ENDIF.
    lv_open_path = _tree_node-text && 'pdf'.
    cl_gui_frontend_services=>file_save_dialog( EXPORTING prompt_on_overwrite        = abap_true
                                                          with_encoding              = abap_true
                                                          default_file_name          = lv_open_path
                                                CHANGING filename                    = lv_open_path
                                                         path                        = lv_save_dir
                                                         fullpath                    = lv_save_path
                                                EXCEPTIONS cntl_error                = 1
                                                           error_no_gui              = 2
                                                           invalid_default_file_name = 3
                                                           not_supported_by_gui      = 4
                                                           OTHERS                    = 5  ).

    CALL METHOD cl_gui_frontend_services=>gui_download
      EXPORTING
        bin_filesize  = lv_index
        filename      = lv_save_path
        filetype      = 'BIN'
        no_auth_check = abap_true
      CHANGING
        data_tab      = lt_bin_data
      EXCEPTIONS
        OTHERS        = 1.

    IF sy-subrc <> 0.
      ycx_abap_error=>raise_message(  ). RETURN.
    ELSE.
      rv_dowloaded = abap_true.
    ENDIF.

  ENDMETHOD.

ENDCLASS.
