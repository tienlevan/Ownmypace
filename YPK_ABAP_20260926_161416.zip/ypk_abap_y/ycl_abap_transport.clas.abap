class YCL_ABAP_TRANSPORT definition
  public
  final
  create public .

public section.

  types:
    BEGIN OF ts_email,
        name   TYPE string,
        desc   TYPE string,
        reason TYPE string,
        tester TYPE char10,
      END OF ts_email .
  types:
    BEGIN OF ts_tr_list,
        request  TYPE e070-trkorr,
        name     TYPE  e07t-as4text,
        trstatus TYPE trstatus,
      END OF ts_tr_list .
  types:
    tt_tr_list TYPE TABLE OF ts_tr_list .
  types:
    tt_e071 TYPE TABLE OF e071 .
  types:
    tt_e071k TYPE TABLE OF e071k .

  constants:
    BEGIN OF mc_req_type,
        workbench         TYPE trfunction VALUE 'K',
        customizing       TYPE trfunction VALUE 'W',
        relocation_wo     TYPE trfunction VALUE 'C',
        relocation_w      TYPE trfunction VALUE 'O',
        relocation_cp     TYPE trfunction VALUE 'E',
        transport_copy    TYPE trfunction VALUE 'T',
        development       TYPE trfunction VALUE 'S',
        repair            TYPE trfunction VALUE 'R',
        unclassified_task TYPE trfunction VALUE 'X',
        customizing_task  TYPE trfunction VALUE 'Q',
        piece_list        TYPE trfunction VALUE 'G',
      END OF mc_req_type .
  constants:
    BEGIN OF mc_tr_status,
        modifiable   TYPE trstatus VALUE 'D',
        modifiable_p TYPE trstatus VALUE 'L',
        release_s    TYPE trstatus VALUE 'O',
        released     TYPE trstatus VALUE 'R',
        released_p   TYPE trstatus VALUE 'N',
      END OF mc_tr_status .
  data MS_HEADER type TRWBO_REQUEST_HEADER .
  data MT_KEYS type TT_E071K .
  data MT_OBJECT type TT_E071 .
  constants MC_RFC_CONNECTION type RFCDEST value 'TMSSUP@PEC.DOMAIN_DEC' ##NO_TEXT.

  methods CONSTRUCTOR
    importing
      !IV_REQUEST type E070-TRKORR .
  class-methods CREATE
    importing
      !IV_TEXT type TREXREQHD-TEXT optional
      !IV_AUTHOR type TREXREQHD-AUTHOR default SY-UNAME
      !IV_TARGET type TREXREQHD-TARGET default ' '
      !IV_TYPE type TREXREQHD-TYPE default MC_REQ_TYPE-WORKBENCH
    returning
      value(RO_TR) type ref to YCL_ABAP_TRANSPORT .
  class-methods SHOW_OBJ
    importing
      !IV_PGMID type E071-PGMID
      !IV_OBJ type E071-OBJECT
      !IV_OBJ_NAME type E071-OBJ_NAME
    returning
      value(RV_ERROR) type ABAP_BOOL .
  methods ADD_OBJ
    importing
      !IT_OBJECTS type TR_OBJECTS
      !IT_KEYS type TR_KEYS
    returning
      value(RV_ERROR) type ABAP_BOOL .
  methods ADD_TABKEY
    importing
      !IT_TABKEY type SFW_T_TRANSKEY
      !IV_TABNAME type TROBJ_NAME
    returning
      value(RV_ERROR) type ABAP_BOOL .
  class-methods SEARCH_OBJ
    importing
      !IS_OBJ type E071
      !IS_KEY type E071K optional
      !IV_REQUEST_TYPES type TRFUNCTION default MC_REQ_TYPE-DEVELOPMENT
      !IV_REQUEST_STATES type TRSTATUS default MC_TR_STATUS-MODIFIABLE
      !IV_REQUEST_OWNER type E070-AS4USER default SY-UNAME
      !IV_ALLCLIENTS type TRBOOLEAN default ABAP_TRUE
      !IV_LOCKED_OBJECTS_ONLY type TRBOOLEAN default ABAP_TRUE
    returning
      value(RT_REQUESTS) type CTS_TRKORRS .
  methods DELETE_OBJ
    importing
      !IT_OBJECT type TR_OBJECTS
      !IT_TABKEY type TR_KEYS
    returning
      value(RV_ERROR) type ABAP_BOOL .
  methods GET_TR_STATE
    importing
      !IV_SYSTEM type TMSCSYS-SYSNAM optional .
  methods READ_LOG
    importing
      !IV_SYSTEM type TMSCSYS-SYSNAM .
  class-methods TR_QUEUE_DISPLAY
    importing
      !IV_SYSTEM type TMSCSYS-SYSNAM .
  methods RELEASE
    returning
      value(RV_ERROR) type ABAP_BOOL .
  methods IMPORT
    importing
      !IV_SYSTEM type TMSCSYS-SYSNAM
      !IV_TARCLI type TMSBUFFER-TARCLI optional
    returning
      value(RV_ERROR) type ABAP_BOOL .
  methods EXPORT_TR_FILE .
  methods COPY_TR
    importing
      !IV_REQUEST type E070-TRKORR .
  methods MERGE_TR
    importing
      !IV_MERGED_REQUEST type TRKORR
    returning
      value(RV_ERROR) type ABAP_BOOL .
  methods INCLUDED_TR .
  class-methods GET_TR_LIST
    importing
      !IV_USERNAME type SY-UNAME default SY-UNAME
    exporting
      !ET_REQUESTS type YCL_ABAP_TRANSPORT=>TT_TR_LIST .
  methods CALL_TR_ORGANIZER .
  methods SEND_EMAIL .
  class-methods COMPARE_TR_SYSTEM
    importing
      !IV_OWNER type SY-UNAME default SY-UNAME
      !IV_SYSTEM type STRING optional
    exporting
      !ET_DATA type STANDARD TABLE .
  class-methods IMPORT_TR_FILE .
  methods CREATE_TOC .
  methods DELETE_TR .
  PROTECTED SECTION.
private section.

  methods _CHECK_BEF_REL .
  methods _TR_QUEUE
    importing
      !IV_SYSTEM type TMSSYSNAM
    returning
      value(RT_REQUEST) type TMSIQREQS .
ENDCLASS.



CLASS YCL_ABAP_TRANSPORT IMPLEMENTATION.


  METHOD add_obj.

    CALL FUNCTION 'TR_REQUEST_CHOICE'
      EXPORTING
        iv_suppress_dialog   = abap_true
        iv_request_types     = ms_header-trfunction
        iv_request           = ms_header-trkorr
        it_e071              = it_objects
        it_e071k             = it_keys
      EXCEPTIONS
        invalid_request      = 1
        invalid_request_type = 2
        user_not_owner       = 3
        no_objects_appended  = 4
        enqueue_error        = 5
        cancelled_by_user    = 6
        recursive_call       = 7
        OTHERS               = 8.

    IF sy-subrc <> 0.
      ycx_abap_error=>raise_message( ).
    ENDIF.

  ENDMETHOD.


  METHOD add_tabkey.

    DATA lt_e071 TYPE tr_objects.
    DATA lt_e071k TYPE tr_keys.

    lt_e071 = VALUE #( ( pgmid = 'R3TR' object = 'TABU' obj_name = iv_tabname objfunc = ms_header-trfunction ) ).
    lt_e071k = VALUE #( FOR ls_tabkey IN it_tabkey ( mastertype = 'TABU' mastername = iv_tabname pgmid = 'R3TR' object = 'TABU' objname = iv_tabname tabkey = ls_tabkey ) ).

    CALL FUNCTION 'TR_REQUEST_CHOICE'
      EXPORTING
        iv_request_types     = ms_header-trfunction
        it_e071              = lt_e071
        it_e071k             = lt_e071k
      EXCEPTIONS
        invalid_request      = 1
        invalid_request_type = 2
        user_not_owner       = 3
        no_objects_appended  = 4
        enqueue_error        = 5
        cancelled_by_user    = 6
        recursive_call       = 7
        OTHERS               = 8.

    CHECK sy-subrc <> 0.
    rv_error = ycx_abap_error=>raise_message( ).


  ENDMETHOD.


  METHOD call_tr_organizer.

    DATA(lt_selection) = VALUE trwbo_selections( ( trkorrpattern = ms_header-trkorr ) ).

    CALL FUNCTION 'TR_PRESENT_REQUESTS_ORGANIZER'
      EXPORTING
        iv_organizer_type = 'T'
        it_selections     = lt_selection
      EXCEPTIONS
        OTHERS            = 1.

    ycx_abap_error=>raise_message( ).

  ENDMETHOD.


  METHOD compare_tr_system.

    DATA: t_tr_list_main TYPE tmsiqreqs,
          t_tr_list_sub  TYPE tmsiqreqs.

    DATA: lt_components TYPE cl_abap_structdescr=>component_table,
          ls_component  LIKE LINE OF lt_components,
          lr_struc      TYPE REF TO data,
          lr_table      TYPE REF TO data,
          lr_system     TYPE REF TO data.

    FIELD-SYMBOLS <ft_table> TYPE STANDARD TABLE.

    IF iv_system IS NOT INITIAL.
      SPLIT iv_system AT ';' INTO TABLE DATA(lt_systems).
    ELSE.
      REFRESH lcl_event=>t_tms.
      zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'WB_DEV' iv_mainkey = 'SET_STMS'
                                    IMPORTING e_data         = lcl_event=>t_tms  ).
      IF lcl_event=>t_tms IS INITIAL.
        ycx_abap_error=>raise_message( iv_msg_text = 'No settings found!' ).
        RETURN.
      ENDIF.
      APPEND lcl_event=>t_tms[ dev_flag = abap_true ]-sysnam TO lt_systems.
      APPEND lcl_event=>t_tms[ qas_flag = abap_true ]-sysnam TO lt_systems.
      LOOP AT lcl_event=>t_tms INTO DATA(s_stms) WHERE prd_flag = abap_true.
        APPEND s_stms-sysnam TO lt_systems.
      ENDLOOP.
    ENDIF.

    ls_component-name = 'TRKORR'.
    ls_component-type ?= cl_abap_typedescr=>describe_by_name( 'TRKORR' ).
    APPEND ls_component TO lt_components.

    CLEAR ls_component.
    ls_component-name = 'TEXT'.
    ls_component-type ?= cl_abap_typedescr=>describe_by_name( 'AS4TEXT' ).
    APPEND ls_component TO lt_components.

    DATA(devsys) = lcl_event=>t_tms[ dev_flag = abap_true ]-sysnam.

    LOOP AT lt_systems INTO DATA(ls_system).
      CLEAR ls_component.
      ls_component-name = ls_system.
      ls_component-type ?= cl_abap_typedescr=>describe_by_name( 'ICON_D' ).
      APPEND ls_component TO lt_components.
      IF devsys = ls_system.
        ycl_abap_transport=>get_tr_list( EXPORTING iv_username = sy-uname
                                 IMPORTING et_requests = DATA(t_dev_list) ).
        t_tr_list_sub = VALUE #( FOR s_dev_list IN t_dev_list ( sysnam = ls_system trkorr = s_dev_list-request text = s_dev_list-name info0 = s_dev_list-trstatus owner = iv_owner ) ).
      ELSE.
        CALL FUNCTION 'TMS_UIQ_IQD_READ_QUEUE'
          EXPORTING
            iv_system         = CONV sysname( ls_system )
            iv_collect        = abap_true
            iv_read_shadow    = abap_true
          IMPORTING
            et_requests       = t_tr_list_sub
          EXCEPTIONS
            read_queue_failed = 1
            OTHERS            = 2.
        IF sy-subrc <> 0.
          ycx_abap_error=>raise_message( iv_msg_type = ycx_abap_error=>msgtype-abort ).
        ENDIF.
      ENDIF.
      APPEND LINES OF t_tr_list_sub TO t_tr_list_main.
      REFRESH t_tr_list_sub.
    ENDLOOP.

    DELETE t_tr_list_main WHERE owner NE iv_owner.
    SORT t_tr_list_main ASCENDING BY trkorr.

    TRY.
        DATA(lo_table) = NEW ycl_abap_rtts( )->create_table( lt_components ).
        DATA(lo_struc) = NEW ycl_abap_rtts( )->create_struct( lt_components ).
        CREATE DATA lr_struc TYPE HANDLE lo_struc.
        CREATE DATA lr_table TYPE HANDLE lo_table.
        ASSIGN lr_table->* TO <ft_table>.
        ASSIGN lr_struc->* TO FIELD-SYMBOL(<fs_struc>).
      CATCH ycx_abap_error INTO DATA(cx_error).
        ycx_abap_error=>raise_message( io_msg_object = cx_error ).
        RETURN.
    ENDTRY.

    DATA(t_tr_list_base) = t_tr_list_main.
    DELETE t_tr_list_base WHERE sysnam NE lt_systems[ 1 ].

    LOOP AT t_tr_list_base INTO DATA(s_tr_list_base).
      LOOP AT lt_components INTO ls_component.
        ASSIGN COMPONENT ls_component-name OF STRUCTURE <fs_struc> TO FIELD-SYMBOL(<fv_value>).
        IF ls_component-name = 'TRKORR'.
          <fv_value> = s_tr_list_base-trkorr.
        ELSEIF ls_component-name = 'TEXT'.
          <fv_value> = s_tr_list_base-text.
        ELSE.
          READ TABLE t_tr_list_main INTO DATA(s_tr_list_main) WITH KEY trkorr = s_tr_list_base-trkorr sysnam = ls_component-name.
          IF sy-subrc IS NOT INITIAL.
            <fv_value> = icon_led_inactive.
          ELSE.
            IF s_tr_list_main-info0 IS NOT INITIAL.
              <fv_value> =  SWITCH #( s_tr_list_main-info0 WHEN mc_tr_status-released THEN icon_led_green ELSE icon_led_inactive ).
            ELSE.
              <fv_value> = SWITCH #( s_tr_list_main-maxrc
                                 WHEN '0000' THEN icon_led_green
                                 WHEN '0004' THEN icon_led_yellow
                                 WHEN ''     THEN icon_led_inactive
                                 ELSE  icon_led_red ).
            ENDIF.
          ENDIF.
        ENDIF.
      ENDLOOP.
      APPEND <fs_struc> TO <ft_table>.
    ENDLOOP.

    SORT <ft_table> DESCENDING.

    IF et_data IS REQUESTED.
      et_data = <ft_table>.
      RETURN.
    ENDIF.

    zcl_ul_alv_adapter=>create( EXPORTING it_col_set = VALUE #( FOR ls_comp IN lt_components ( fieldname = ls_comp-name reptext = ls_comp-name
                                                                hotspot = COND #( WHEN ls_comp-name NE 'TRKORR' AND ls_comp-name NE 'TEXT'
                                                                                  THEN abap_true ELSE abap_false ) ) )
                                                                is_layout = VALUE #( sel_mode = 'A' )
                                                                it_toolbar_add = VALUE #( ( icon = icon_refresh                                   function = 'REFRESH' )
                                                                                          ( icon = icon_create          text = 'Create'           function = 'CREATE' )
                                                                                          ( icon = icon_copy_object     text = 'Create ToC'       function = 'TOC' )
                                                                                          ( icon = icon_transfer        text = 'Merge TR'         function = 'MERGE' )
                                                                                          ( icon = icon_include_objects text = 'Include TR'       function = 'INCLD' )
                                                                                          ( icon = icon_delete          text = 'Delete TR'        function = 'DELETE' )
                                                                                          ( icon = icon_transport       text = 'Transport'        function = 'TRANSPORT' )
                                                                                          ( icon = icon_export          text = 'Export TR File'   function = 'EXPORT' )
                                                                                          ( icon = icon_import          text = 'Import TR File'   function = 'IMPORT' )
                                                                                          ( icon = icon_mail            text = 'Generating Email' function = 'EMAIL' ) )
                                                                ir_local_class = cl_abap_classdescr=>describe_by_name( 'LCL_EVENT' )
                                                                iv_title = |SAP Transport System - { sy-uname }|
                               CHANGING    ct_table   = <ft_table> ).

  ENDMETHOD.


  METHOD constructor.

    DATA: ls_e070  TYPE e070,
          ls_e070c TYPE e070c.

    CALL FUNCTION 'TR_READ_COMM'
      EXPORTING
        wi_trkorr        = iv_request
        wi_sel_e070      = abap_true
        wi_sel_e071      = abap_true
        wi_sel_e070c     = abap_true
        wi_sel_e071k     = abap_true
      IMPORTING
        we_e070          = ls_e070
        we_e070c         = ls_e070c
      TABLES
        wt_e071          = mt_object
        wt_e071k         = mt_keys
      EXCEPTIONS
        not_exist_e070   = 1
        no_authorization = 2
        OTHERS           = 3.

    IF sy-subrc IS NOT INITIAL.
      ycx_abap_error=>raise_message( ).
    ELSE.
      ms_header = CORRESPONDING #( ls_e070 ).
      SELECT SINGLE FROM e07t FIELDS as4text WHERE trkorr = @iv_request AND langu = @sy-langu INTO @ms_header-as4text.
      ms_header-client = ls_e070c-client.
      ms_header-tarclient = ls_e070c-tarclient.
    ENDIF.

  ENDMETHOD.


  METHOD copy_tr.

    DATA(lo_request) = NEW ycl_abap_transport( iv_request ).

    SELECT FROM e070 FIELDS trkorr WHERE strkorr = @lo_request->ms_header-trkorr AND trstatus = @mc_tr_status-modifiable INTO TABLE @DATA(lt_tasks).
    LOOP AT lt_tasks INTO DATA(ls_task).
      copy_tr( ls_task-trkorr ).
    ENDLOOP.

    CHECK lo_request->mt_object IS NOT INITIAL.
    DELETE lo_request->mt_object WHERE object = 'MERG' OR object = 'RELE'.

    DATA lt_objects TYPE tt_e071.
    DATA lt_keys    TYPE tt_e071k.
    lt_objects = CORRESPONDING #( lo_request->mt_object EXCEPT trkorr ).
    lt_keys    = CORRESPONDING #( lo_request->mt_keys EXCEPT trkorr ).
    add_obj( it_objects = lt_objects it_keys = lt_keys ).

  ENDMETHOD.


  METHOD create.

    DATA lv_request_id TYPE trkorr.

    IF iv_type  = mc_req_type-transport_copy.
      IF iv_target IS INITIAL.
        ycx_abap_error=>raise_message( iv_msg_text = 'Transport target is required!' ).
        RETURN.
      ENDIF.
    ENDIF.

    CALL FUNCTION 'TR_EXT_CREATE_REQUEST'
      EXPORTING
        iv_request_type = iv_type
        iv_target       = iv_target
        iv_author       = iv_author
        iv_text         = iv_text
      IMPORTING
        es_req_id       = lv_request_id.

    ro_tr = NEW #( iv_request = lv_request_id ).

  ENDMETHOD.


  method CREATE_TOC.
  endmethod.


  METHOD delete_obj.

    LOOP AT it_object INTO DATA(ls_object).
      DATA(lt_tabkey) = it_tabkey.
      DELETE lt_tabkey WHERE pgmid NE 'R3TR' AND object NE 'TABU'.
      CALL FUNCTION 'TRINT_DELETE_COMM_KEYS'
        EXPORTING
          wi_e071                = ls_object
          wi_trkorr              = ms_header-trkorr
        TABLES
          wt_e071k               = lt_tabkey
        EXCEPTIONS
          e070_update_error      = 1
          keys_protected         = 2
          order_already_released = 3
          unallowed_ordertyp     = 4
          user_not_owner         = 5
          wrong_client           = 6
          OTHERS                 = 7.
      IF sy-subrc <> 0.
        rv_error = ycx_abap_error=>raise_message( ).
        EXIT.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.


  METHOD delete_tr.

    CALL FUNCTION 'TR_DELETE_COMM'
      EXPORTING
        wi_dialog = abap_true
        wi_trkorr = ms_header-trkorr
      EXCEPTIONS
        OTHERS    = 1.

    IF sy-subrc IS NOT INITIAL.
      ycx_abap_error=>raise_message( ).
    ENDIF.

  ENDMETHOD.


  METHOD export_tr_file.

    DATA: s_file_bin(1000) TYPE x,
          t_file_bin       LIKE TABLE OF s_file_bin,
          len              TYPE i,
          desktop          TYPE string,
          content          TYPE xstring.

    DATA(zip) = NEW cl_abap_zip( ).

    DATA(cofile_name) = |{ ms_header-trkorr+3 }.{ ms_header-trkorr(3) }|.

    DATA(cofile_source) = |/usr/sap/trans/cofiles/{ cofile_name }|.
    DATA(cofile_len) = strlen( cofile_source ) - 1.

    cl_gui_frontend_services=>get_sapgui_workdir( CHANGING sapworkdir = desktop ).
    DATA(cofile_target) = |{ desktop }/{ ms_header-trkorr }.zip|.

    OPEN DATASET cofile_source FOR INPUT IN BINARY MODE.
    REFRESH t_file_bin.

    TRY.
        DO.
          READ DATASET cofile_source INTO s_file_bin LENGTH cofile_len.
          IF sy-subrc IS INITIAL.
            APPEND s_file_bin TO t_file_bin.
            len = len + cofile_len.
          ELSEIF sy-subrc = 4.
            IF NOT s_file_bin IS INITIAL.
              APPEND s_file_bin TO t_file_bin.
              len = len + cofile_len.
            ENDIF.
            EXIT.
          ENDIF.
        ENDDO.
      CATCH cx_sy_file_open_mode INTO DATA(cx_error).
        ycx_abap_error=>raise_message( io_msg_object = cx_error ).
        EXIT.
    ENDTRY.

    CLOSE DATASET cofile_source.

    content = zcl_ul_abap=>binary_to_xstring( EXPORTING it_table = t_file_bin iv_length = len ).
    zip->add( name = cofile_name content = content ).

    DATA(datafile_name) = |R{ ms_header-trkorr+4 }.{ ms_header-trkorr(3) }|.
    DATA(datafile_source) = |/usr/sap/trans/data/{ datafile_name }|.
    DATA(datafile_len) = strlen( datafile_source ) - 1.

    CLEAR content.
    OPEN DATASET datafile_source FOR INPUT IN BINARY MODE.
    REFRESH t_file_bin.

    DO.
      READ DATASET datafile_source INTO s_file_bin LENGTH datafile_len.
      IF sy-subrc IS INITIAL.
        APPEND s_file_bin TO t_file_bin.
        len = len + cofile_len.
      ELSEIF sy-subrc = 4.
        IF NOT s_file_bin IS INITIAL.
          APPEND s_file_bin TO t_file_bin.
          len = len + cofile_len.
        ENDIF.
        EXIT.
      ENDIF.
    ENDDO.

    CLOSE DATASET datafile_source.

    content = zcl_ul_abap=>binary_to_xstring( EXPORTING it_table = t_file_bin iv_length = len ).
    zip->add( name = datafile_name content = content ).

    DATA(file) = zip->save(  ).
    zcl_ul_abap=>xstring_to_binary( EXPORTING iv_xstring = file IMPORTING et_table = DATA(t_bin) ev_length = DATA(bin_len) ).

    cl_gui_frontend_services=>gui_download( EXPORTING filename = cofile_target
                                                      filetype  = 'BIN'
                                                      confirm_overwrite = abap_true
                                                      bin_filesize = bin_len
                                            CHANGING  data_tab = t_bin
                                            EXCEPTIONS access_denied = 1
                                                       control_flush_error = 2
                                                       dataprovider_exception = 3
                                                       disk_full = 4
                                                       dp_error_create = 5
                                                       error_no_gui = 6
                                                       file_not_found = 7
                                                       filesize_not_allowed = 8
                                                       gui_refuse_filetransfer = 9
                                                       OTHERS = 10 ).
    IF sy-subrc <> 0.
      ycx_abap_error=>raise_message( ).
    ENDIF.

  ENDMETHOD.


  METHOD get_tr_list.

    DATA: lt_request TYPE trwbo_request_headers.
    CALL FUNCTION 'TRINT_SELECT_REQUESTS'
      EXPORTING
        iv_username_pattern    = sy-uname
      IMPORTING
        et_requests            = lt_request
      EXCEPTIONS
        action_aborted_by_user = 1
        OTHERS                 = 2.
    IF sy-subrc <> 0.
      ycx_abap_error=>raise_message( ).
      RETURN.
    ENDIF.

    SORT lt_request DESCENDING BY as4date as4time.
    DELETE lt_request WHERE strkorr IS NOT INITIAL.

    et_requests = VALUE #( FOR ls_request IN lt_request ( request = ls_request-trkorr name = ls_request-as4text trstatus = ls_request-trstatus ) ).

  ENDMETHOD.


  METHOD get_tr_state.

    DATA: lt_components TYPE cl_abap_structdescr=>component_table,
          ls_component  LIKE LINE OF lt_components,
          lr_struc      TYPE REF TO data,
          lr_table      TYPE REF TO data.

    FIELD-SYMBOLS <ft_table> TYPE STANDARD TABLE.

    ls_component-name = 'TR_NUM'.
    ls_component-type ?= cl_abap_typedescr=>describe_by_name( 'TRKORR' ).
    APPEND ls_component TO lt_components.

    CLEAR ls_component.
    ls_component-name = 'TR_TEXT'.
    ls_component-type ?= cl_abap_typedescr=>describe_by_name( 'AS4TEXT' ).
    APPEND ls_component TO lt_components.

    SELECT FROM tmscsys FIELDS * INTO TABLE @DATA(lt_systems).
    IF iv_system IS NOT INITIAL.
      DELETE lt_systems WHERE sysnam NE iv_system.
    ENDIF.

    LOOP AT lt_systems INTO DATA(ls_system).
      CLEAR ls_component.
      ls_component-name = ls_system-sysnam.
      ls_component-type ?= cl_abap_typedescr=>describe_by_name( 'ICON_D' ).
      APPEND ls_component TO lt_components.
    ENDLOOP.

    TRY.
        DATA(lo_table) = NEW ycl_abap_rtts( )->create_table( lt_components ).
        DATA(lo_struc) = NEW ycl_abap_rtts( )->create_struct( lt_components ).
        CREATE DATA lr_struc TYPE HANDLE lo_struc.
        CREATE DATA lr_table TYPE HANDLE lo_table.
        ASSIGN lr_table->* TO <ft_table>.
        ASSIGN lr_struc->* TO FIELD-SYMBOL(<fs_struc>).
      CATCH ycx_abap_error INTO DATA(cx_error).
        ycx_abap_error=>raise_message( io_msg_object = cx_error ).
        RETURN.
    ENDTRY.

    LOOP AT lt_components INTO ls_component.
      ASSIGN COMPONENT ls_component-name OF STRUCTURE <fs_struc> TO FIELD-SYMBOL(<fv_value>).
      IF ls_component-name = 'TR_NUM'.
        <fv_value> = ms_header-trkorr.
      ELSEIF ls_component-name = 'TR_TEXT'.
        SELECT SINGLE FROM e07t FIELDS as4text WHERE trkorr = @ms_header-trkorr INTO @<fv_value>.
      ELSE.
        ls_system = lt_systems[ sysnam = ls_component-name ].
        DATA(lt_request) = _tr_queue( iv_system = ls_system-sysnam ).
        IF ls_system-dlcfg IS INITIAL.
          <fv_value> = COND #( WHEN ms_header-trstatus = mc_tr_status-released THEN icon_okay ELSE icon_led_inactive ).
        ELSE.
          IF lt_request IS NOT INITIAL.
            DATA(ls_request) = lt_request[ 1 ].
            <fv_value> = SWITCH #( ls_request-maxrc
                                 WHEN '0000' THEN icon_led_green
                                 WHEN '0004' THEN icon_led_yellow
                                 WHEN ''     THEN icon_led_inactive
                                 ELSE  icon_led_red ).
          ELSE.
            <fv_value> = icon_no_status.
          ENDIF.
        ENDIF.
      ENDIF.
    ENDLOOP.

    APPEND <fs_struc> TO <ft_table>.
    zcl_ul_alv_adapter=>create( EXPORTING it_col_set = VALUE #( FOR ls_comp IN lt_components ( fieldname = ls_comp-name reptext = ls_comp-name ) )
                                CHANGING  ct_table   = <ft_table> ).


  ENDMETHOD.


  METHOD import.

    DATA subrc TYPE sy-subrc.

    IF ms_header-trstatus = mc_tr_status-modifiable.
      CHECK release( ) IS INITIAL.
    ENDIF.


    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'WB_DEV' iv_mainkey = 'SET_STMS'
                                  IMPORTING e_data         = lcl_event=>t_tms  ).

    READ TABLE lcl_event=>t_tms WITH KEY dev_flag = abap_true INTO DATA(tms).
    IF tms-sync_client IS NOT INITIAL.
      SELECT SINGLE FROM ztb_dyn_rfc FIELDS * WHERE system_user = @sy-uname AND logon_client = @tms-sync_client
        INTO @DATA(s_rfc).
      IF sy-subrc IS INITIAL.
        DATA(destination) = cl_dynamic_destination=>create_rfc_destination( logon_client = s_rfc-logon_client
                                                                            logon_user   = s_rfc-logon_user
                                                                            logon_language = sy-langu
                                                                            logon_password = s_rfc-logon_password
                                                                            group = s_rfc-logon_group
                                                                            sid = s_rfc-sid
                                                                            system_number = s_rfc-system_number
                                                                            server = s_rfc-server ).
      ELSE.
        destination = 'TMSSUP@DEC.DOMAIN_DEC'.
      ENDIF.

      CALL FUNCTION 'ZFM_SCCR_PERFORM_SCC1'
        DESTINATION destination
        EXPORTING
          cccomfile    = ms_header-trkorr
          quellmandant = ms_header-client
          incl_task    = abap_true
          ccsupcopy    = abap_false
        IMPORTING
          rcod         = subrc.

      IF subrc IS NOT INITIAL.
        rv_error = ycx_abap_error=>raise_message( ).
      ENDIF.

    ENDIF.

    CALL FUNCTION 'TMS_UI_IMPORT_TR_REQUEST'
      EXPORTING
        iv_system             = iv_system
        iv_request            = ms_header-trkorr
        iv_tarcli             = iv_tarcli
      EXCEPTIONS
        cancelled_by_user     = 1
        import_request_denied = 2
        import_request_failed = 3
        OTHERS                = 4.

    IF sy-subrc <> 0.
      rv_error = ycx_abap_error=>raise_message( ).
      RETURN.
    ENDIF.

  ENDMETHOD.


  METHOD import_tr_file.

    TYPES: BEGIN OF ty_tms,
             sysnam   TYPE tmssysnam,
             systxt   TYPE as4text,
             dev_flag TYPE flag,
             qas_flag TYPE flag,
             prd_flag TYPE flag,
           END OF ty_tms.

    DATA: rc       TYPE i,
          t_file   TYPE filetable,
          bin_data TYPE solix_tab,
          bin_name TYPE string,
          system   TYPE tmsmconf-sysnam,
          request  TYPE trkorr,
          t_tms    TYPE TABLE OF ty_tms.

    cl_gui_frontend_services=>file_open_dialog( EXPORTING window_title  = 'Select a file'
                                                          file_filter   = '(*.zip)|*.zip|'
                                                CHANGING  file_table = t_file
                                                          rc         = rc
                                                EXCEPTIONS file_open_dialog_failed = 1
                                                           cntl_error              = 2
                                                           error_no_gui            = 3
                                                           not_supported_by_gui    = 4
                                                           OTHERS                  = 5 ).
    IF sy-subrc IS NOT INITIAL.
      ycx_abap_error=>raise_message( ). RETURN.
    ENDIF.

    DATA(zip) = NEW cl_abap_zip( ).

    LOOP AT t_file INTO DATA(s_file).

      cl_gui_frontend_services=>gui_upload( EXPORTING filename = CONV #( s_file-filename )
                                                      filetype = 'BIN'
                                            IMPORTING filelength = DATA(bin_len)
                                            CHANGING  data_tab   = bin_data
                                            EXCEPTIONS file_open_error         = 1
                                                       file_read_error         = 2
                                                       no_batch                = 3
                                                       gui_refuse_filetransfer = 4
                                                       invalid_type            = 5
                                                       no_authority            = 6
                                                       unknown_error           = 7
                                                       bad_data_format         = 8
                                                       header_not_allowed      = 9
                                                       separator_not_allowed   = 10
                                                       header_too_long         = 11
                                                       unknown_dp_error        = 12
                                                       access_denied           = 13
                                                       dp_out_of_memory        = 14
                                                       disk_full               = 15
                                                       dp_timeout              = 16
                                                       not_supported_by_gui    = 17
                                                       error_no_gui            = 18
                                                       OTHERS                  = 19 ).

      IF sy-subrc IS NOT INITIAL.
        ycx_abap_error=>raise_message( ). EXIT.
      ENDIF.

      DATA(xcontent) = zcl_ul_abap=>binary_to_xstring( it_table = bin_data iv_length = bin_len ).
      DATA(zip_files) = zip->splice( xcontent ).

      LOOP AT zip_files INTO DATA(s_zip_file).

        CASE s_zip_file-name(1).
          WHEN 'K'.
            DATA(file) = |/usr/sap/trans/cofiles/{ s_zip_file-name }|.
            request = |{ s_zip_file-name+8 }{ s_zip_file-name(7) }|.
          WHEN 'R'.
            file = |/usr/sap/trans/data/{ s_zip_file-name }|.
        ENDCASE.

        OPEN DATASET file FOR INPUT IN BINARY MODE.
        IF sy-subrc IS INITIAL.
          CHECK zcl_ul_abap=>popup_to_confirm( |File { s_zip_file-name } has been existed in /usr/sap/trans/cofiles/, Overwrite?| ) = '1'.
        ENDIF.
        CLOSE DATASET file.

        zip->load( xcontent ).
        zip->get( EXPORTING name = s_zip_file-name IMPORTING content = DATA(zcontent) ).
        zcl_ul_abap=>xstring_to_binary( EXPORTING iv_xstring = zcontent IMPORTING et_table = DATA(z_bin_data) ev_length = DATA(z_bin_len) ).

        OPEN DATASET file FOR OUTPUT IN BINARY MODE.
        IF sy-subrc IS NOT INITIAL.
          ycx_abap_error=>raise_message( iv_msg_text = 'Can not create file remote!' ). EXIT.
        ENDIF.

        LOOP AT z_bin_data INTO DATA(s_bin_data).
          IF z_bin_len > 1000.
            DATA(len) = 1000.
          ELSE.
            len = z_bin_len.
          ENDIF.
          TRANSFER s_bin_data TO file LENGTH len.
          z_bin_len = z_bin_len - len.
        ENDLOOP.

        CLOSE DATASET file.

      ENDLOOP.

      CALL FUNCTION 'TMS_UI_CONFIGURE_SYSTEM'
        IMPORTING
          ev_system_name = system.

      zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'WB_DEV' iv_mainkey = 'SET_STMS'
                                    IMPORTING e_data         = t_tms  ).

      IF t_tms IS INITIAL.
        ycx_abap_error=>raise_message( iv_msg_text = 'No configuration found!' ). EXIT.
      ENDIF.

      READ TABLE t_tms WITH KEY sysnam = system dev_flag = abap_true TRANSPORTING NO FIELDS.
      IF sy-subrc IS NOT INITIAL.
        ycx_abap_error=>raise_message( iv_msg_text = |The system { system } is not permitted!| ). EXIT.
      ENDIF.

      CALL FUNCTION 'TMS_UI_APPEND_TR_REQUEST'
        EXPORTING
          iv_system             = system
          iv_request            = request
        EXCEPTIONS
          cancelled_by_user     = 1
          append_request_failed = 2
          OTHERS                = 3.

      IF sy-subrc IS NOT INITIAL.
        ycx_abap_error=>raise_message( ).EXIT.
      ELSE.
        ycx_abap_error=>raise_message( iv_msg_text = 'Import sucessfully!' iv_msg_type = ycx_abap_error=>msgtype-information ).
      ENDIF.

    ENDLOOP.

  ENDMETHOD.


  METHOD included_tr.

    SUBMIT rswbo070 AND RETURN WITH target = ms_header-trkorr.

  ENDMETHOD.


  METHOD merge_tr.

    DATA: ls_merging_request TYPE trwbo_request,
          ls_merged_request  TYPE trwbo_request.

    MOVE ms_header-trkorr  TO ls_merging_request-h-trkorr.
    MOVE iv_merged_request TO ls_merged_request-h-trkorr.

    CALL FUNCTION 'TR_MERGE_REQUESTS'
      EXPORTING
        is_request_from        = ls_merged_request
        is_request_to          = ls_merging_request
        iv_request_choice      = ' '
      EXCEPTIONS
        illegal_from_request   = 1
        illegal_to_request     = 2
        requests_dont_match    = 3
        error_db_access        = 4
        request_locked         = 5
        action_aborted_by_user = 6
        OTHERS                 = 7.

    IF sy-subrc <> 0.
      rv_error = ycx_abap_error=>raise_message( ).
    ENDIF.

  ENDMETHOD.


  METHOD read_log.

    DATA(s_popup) =  VALUE strhi_popup( start_column = 5 start_row = 5 end_column = 150 end_row = 50 ).

    CALL FUNCTION 'TMS_UI_SHOW_TRANSPORT_LOGS'
      EXPORTING
        iv_request                 = ms_header-trkorr
        iv_system                  = iv_system
        is_popup                   = s_popup
      EXCEPTIONS
        show_transport_logs_failed = 1
        OTHERS                     = 2.

    IF sy-subrc <> 0.
      ycx_abap_error=>raise_message( ).
    ENDIF.

  ENDMETHOD.


  METHOD release.

    IF ms_header-trstatus = mc_tr_status-released.
      rv_error = ycx_abap_error=>raise_message( iv_msg_text = |The TR { ms_header-trkorr } had been released!| ).
      RETURN.
    ENDIF.

    IF zcl_ul_abap=>popup_to_confirm( 'Do you want check request before release?' ) = '1'.
      _check_bef_rel( ).
      IF zcl_ul_abap=>popup_to_confirm( 'Continue to release?' ) NE '1'.
        MOVE abap_true TO rv_error.
        RETURN.
      ENDIF.
    ENDIF.

    IF ms_header-strkorr IS NOT INITIAL.
      SELECT FROM e070 FIELDS trkorr WHERE strkorr = @ms_header-strkorr AND trstatus = @mc_tr_status-modifiable INTO TABLE @DATA(lt_sub_requests).
      DATA(lv_main_request) = ms_header-strkorr.
    ELSE.
      SELECT FROM e070 FIELDS trkorr WHERE strkorr = @ms_header-trkorr AND trstatus = @mc_tr_status-modifiable INTO TABLE @lt_sub_requests.
      lv_main_request = ms_header-trkorr.
    ENDIF.

    " Release the sub-requests
    IF lt_sub_requests IS NOT INITIAL.
      rv_error = abap_true.
      CHECK zcl_ul_abap=>popup_to_confirm( 'All related requests will be released?' ) = '1'.
      CLEAR rv_error.
      LOOP AT lt_sub_requests REFERENCE INTO DATA(lr_sub_request).
        IF rv_error IS NOT INITIAL.
          EXIT.
        ELSE.
          CALL FUNCTION 'TR_RELEASE_REQUEST'
            EXPORTING
              iv_trkorr                  = lr_sub_request->trkorr
              iv_dialog                  = abap_false
              iv_display_export_log      = abap_false
              iv_without_locking         = abap_true
            EXCEPTIONS
              cts_initialization_failure = 1
              enqueue_failed             = 2
              no_authorization           = 3
              invalid_request            = 4
              request_already_released   = 5
              repeat_too_early           = 6
              error_in_export_methods    = 7
              object_check_error         = 8
              docu_missing               = 9
              db_access_error            = 10
              action_aborted_by_user     = 11
              export_failed              = 12
              OTHERS                     = 13.
          IF sy-subrc <> 0.
            rv_error = ycx_abap_error=>raise_message( ).
          ENDIF.
        ENDIF.
      ENDLOOP.
    ENDIF.

    " Release the main request
    CHECK rv_error IS INITIAL.
    CALL FUNCTION 'TR_RELEASE_REQUEST'
      EXPORTING
        iv_trkorr                  = lv_main_request
        iv_dialog                  = abap_false
        iv_display_export_log      = abap_false
        iv_without_locking         = abap_true
      EXCEPTIONS
        cts_initialization_failure = 1
        enqueue_failed             = 2
        no_authorization           = 3
        invalid_request            = 4
        request_already_released   = 5
        repeat_too_early           = 6
        error_in_export_methods    = 7
        object_check_error         = 8
        docu_missing               = 9
        db_access_error            = 10
        action_aborted_by_user     = 11
        export_failed              = 12
        OTHERS                     = 13.
    IF sy-subrc <> 0.
      rv_error = ycx_abap_error=>raise_message( ).
    ENDIF.

  ENDMETHOD.


  METHOD search_obj.

    CALL FUNCTION 'TR_SEARCH_OBJECT_IN_REQUESTS'
      EXPORTING
        is_object              = is_obj
        is_key                 = is_key
        iv_request_types       = iv_request_types
        iv_request_states      = iv_request_states
        iv_request_owner       = iv_request_owner
        iv_allclients          = iv_allclients
        iv_locked_objects_only = iv_locked_objects_only
      IMPORTING
        et_requests            = rt_requests.

  ENDMETHOD.


  METHOD send_email.

    DATA rfcdest TYPE rfcdest.
    DATA is_failed TYPE boole_d.

    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'WB_DEV' iv_mainkey = 'SET_STMS'
                              IMPORTING e_data         = lcl_event=>t_tms  ).
    TRY.
        DATA(prd_sys) = lcl_event=>t_tms[ prd_flag = abap_true ]-sysnam.
        SELECT SINGLE FROM tmscsys FIELDS dessup WHERE sysnam = @prd_sys INTO @rfcdest.
      CATCH cx_sy_itab_line_not_found.
        ycx_abap_error=>raise_message( iv_msg_text = 'No TR destination found!' ).
    ENDTRY.

    CALL FUNCTION 'ZFM_INS_SEND_TR_EMAIL'
      DESTINATION rfcdest
      EXPORTING
        iv_trkorr = ms_header-trkorr    " Request/Task
        iv_text   = ms_header-as4text   " Short Description of Repository Objects
      IMPORTING
        is_failed = is_failed.          " Result

    IF is_failed IS INITIAL.
      ycx_abap_error=>raise_message( iv_msg_text = 'Email sent!' iv_msg_type = ycx_abap_error=>msgtype-information ).
    ELSE.
      ycx_abap_error=>raise_message( iv_msg_text = 'Failed to sent email!' ).
    ENDIF.

  ENDMETHOD.


  METHOD show_obj.

    CALL FUNCTION 'TR_OBJECT_JUMP_TO_TOOL'
      EXPORTING
        iv_pgmid          = iv_pgmid
        iv_object         = iv_obj
        iv_obj_name       = iv_obj_name
      EXCEPTIONS
        jump_not_possible = 1
        OTHERS            = 2.

    IF sy-subrc <> 0.
      rv_error = ycx_abap_error=>raise_message( ).
    ENDIF.

  ENDMETHOD.


  METHOD tr_queue_display.

    CALL FUNCTION 'TMS_UIQ_IMPORT_QUEUE_DISPLAY'
      EXPORTING
        iv_system                   = iv_system
      EXCEPTIONS
        import_queue_display_failed = 1
        OTHERS                      = 2.
    IF sy-subrc <> 0.
      ycx_abap_error=>raise_message( ).
    ENDIF.

  ENDMETHOD.


  METHOD _check_bef_rel.

*    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'WB_DEV' iv_mainkey = 'SET_STMS'
*                                  IMPORTING e_data         = lcl_event=>t_tms  ).
*    READ TABLE lcl_event=>t_tms INTO DATA(ls_system) WITH KEY qas_flag = abap_true.
*    IF sy-subrc IS NOT INITIAL.
*      ycx_abap_error=>raise_message( iv_msg_text = 'No QA system found, Please set it at ZWBX tool!' ).
*      RETURN.
*    ELSE.
*      SELECT SINGLE FROM tmscsys FIELDS desadm WHERE sysnam = @ls_system-sysnam INTO @DATA(rfc_des).
*    ENDIF.
*    rfc_des+3(3) = 'SUP'.
*
*    DATA(bdc_data) = VALUE bdcdata_tab( ( program = '/SDF/CMO_TR_CHECK' dynpro = '1000' dynbegin = abap_true )
*                                        ( fnam = 'P_SOURCE'     fval = 'NODE' )
*                                        ( fnam = 'P_TARGET'     fval = rfc_des )
*                                        ( fnam = 'R_PRJ_CO'     fval = abap_true )
*                                        ( fnam = 'P_ORI_TR-LOW' fval = ms_header-trkorr )
*                                        ( fnam = 'P_CRSREF'     fval = abap_true )
*                                        ( fnam = 'P_DGP'        fval = abap_true )
*                                        ( fnam = 'P_SWCOMP'     fval = abap_true )
*                                        ( fnam = 'BDC_OKCODE'   fval = '=ONLI') ).
*    DATA(opt) = VALUE ctu_params( dismode = 'A' defsize = abap_true ).
*
*    CALL TRANSACTION '/SDF/TRCHECK' WITHOUT AUTHORITY-CHECK
*      USING bdc_data OPTIONS FROM opt.

    SUBMIT /sdf/cmo_tr_check
    WITH p_source = 'NONE'                  "-- Source System
    WITH p_target = mc_rfc_connection       "-- Target System
    WITH r_prj_co = abap_true               "-- Check TR
    WITH p_ori_tr = ms_header-trkorr        "-- Give TR number
    WITH p_crsref = abap_true               "-- Cross reference
    WITH p_dgp    = abap_true               "-- Sequence Check
    WITH p_swcomp = abap_true               "-- Cross release
  "-- WITH p_imptim = abap_true             "-- Import Time in source
  "-- WITH p_oichck = abap_true             "-- Online import check
  AND RETURN.

  ENDMETHOD.


  METHOD _tr_queue.

    CALL FUNCTION 'TMS_UIQ_IQD_READ_QUEUE'
      EXPORTING
        iv_system         = iv_system
        iv_collect        = abap_true
        iv_read_shadow    = abap_true
      IMPORTING
        et_requests       = rt_request
      EXCEPTIONS
        read_queue_failed = 1
        OTHERS            = 2.

    IF sy-subrc <> 0.
      ycx_abap_error=>raise_message( ).
    ELSE.
      DELETE rt_request WHERE trkorr NE ms_header-trkorr.
    ENDIF.

  ENDMETHOD.
ENDCLASS.
