*----------------------------------------------------------------------*
***INCLUDE ZPG_CCM_CPM_SALES_STATUS_01O01.
*----------------------------------------------------------------------*
AT SELECTION-SCREEN ON VALUE-REQUEST FOR p_file.
  lcl_control=>get_file(  ).

AT SELECTION-SCREEN OUTPUT.
  lcl_control=>get_list_box(  ).

  LOOP AT SCREEN.

    CASE p_action.
      WHEN gc_act_upld.
        IF screen-group1 EQ 'M1'
        OR screen-name = '%B002004_BLOCK_1000'.
          screen-active   = 1.
        ELSE.
          screen-active = 0.
        ENDIF.
      WHEN gc_act_view OR gc_act_temp.
        screen-active = 0.
    ENDCASE.

    IF screen-name = '%B001000_BLOCK_1000'
    OR screen-group1 = 'M0'.
      screen-active = 1.
    ENDIF.

    MODIFY SCREEN.
  ENDLOOP.


*&---------------------------------------------------------------------*
*&      Module  STATUS_0100  OUTPUT
*&---------------------------------------------------------------------*
*       text
*----------------------------------------------------------------------*
MODULE status_0100 OUTPUT.

  DATA: lt_excl TYPE TABLE OF sy-ucomm.
  IF ( p_action = gc_act_upld AND ( p_func = 'M0003' OR p_func = 'M0004' ) AND sy-tcode = 'ZMGT'
     AND sy-uname NOT IN zcl_ul_abap=>get_stvarv_val( 'ZTABM_SUPERUSER' ) )
     OR p_action = gc_act_view.
    APPEND 'SAVE' TO lt_excl.
  ENDIF.

  SET PF-STATUS 'STATUS_0100' EXCLUDING lt_excl.
  DATA(func) =  SWITCH string( p_action WHEN gc_act_upld THEN 'Tải lên dữ liệu'
                                        WHEN gc_act_view THEN 'Xem dữ liệu'
                                        WHEN gc_act_temp THEN 'Tải xuống biểu mẫu' ).
  DATA(title) = gt_migration[ migration_id = p_func ]-migration_name.
  CONCATENATE func title INTO title SEPARATED BY space.
  SET TITLEBAR 'TITLE_0100' WITH title.

  CHECK application IS NOT BOUND.
  CREATE OBJECT application.
  application->start(  ).

ENDMODULE.
