CLASS lcl_view DEFINITION.

  PUBLIC SECTION.

    DATA: tree TYPE REF TO cl_gui_simple_tree,
          grid TYPE REF TO zcl_ul_alv_adapter.

    METHODS: constructor,
      show_data IMPORTING col_tab     TYPE ztb_ul_alv_col
                          menu_button TYPE ttb_button OPTIONAL
                CHANGING  ct_table    TYPE STANDARD TABLE.

  PRIVATE SECTION.

    METHODS: _split_view,
      _create_tree IMPORTING container  TYPE REF TO cl_gui_container.

ENDCLASS.

CLASS lcl_view IMPLEMENTATION.

  METHOD constructor.

    _split_view(  ).

  ENDMETHOD.

  METHOD show_data.
    grid->t_toolbar_add = menu_button.
    grid->s_layout = VALUE #( sel_mode = 'A' ctab_fname = 'CELLCOLORS' ).
    TRY.
        grid->display( EXPORTING it_col_set = col_tab
                       CHANGING  ct_data = ct_table ).
      CATCH zcx_ul_handle_errors INTO DATA(error).
        error->show_message(  ).
    ENDTRY.

  ENDMETHOD.


  METHOD _split_view.

    DATA(splitter) = NEW cl_gui_splitter_container( parent = cl_gui_container=>screen0
                                                    rows = 1 columns = 2  ).

    DATA(tree) = splitter->get_container( row = 1 column = 1 ).
    DATA(alv) = splitter->get_container( row = 1 column = 2 ).

    IF gt_tree IS NOT INITIAL.
      splitter->set_column_width( id = 1 width = 10 ).
    ELSE.
      splitter->set_column_width( id = 1 width = 0 ).
      splitter->set_column_sash( id =  1 type = cl_gui_splitter_container=>type_sashvisible value = CONV #( cl_gui_splitter_container=>visible_false ) ).
    ENDIF.

    _create_tree( tree ).

    grid = zcl_ul_alv_adapter=>create( io_parent = alv
                                       iv_input = 0
                                       ir_local_class = cl_abap_classdescr=>describe_by_name( p_name = 'LCL_EVENT' ) ).

    splitter->remove_control( row = 1 column = 1 ).

  ENDMETHOD.

  METHOD _create_tree.

    DATA node_table TYPE TABLE OF ztb_treeload.

    tree = NEW #( parent = container node_selection_mode = cl_gui_simple_tree=>node_sel_mode_single ).
    tree->set_registered_events( events = VALUE #( ( eventid = cl_gui_simple_tree=>eventid_selection_changed
                                                     appl_event = abap_true ) ) ).

    node_table = VALUE #( FOR node IN gt_tree ( node_key = node-node_key text = node-node_text n_image = node-node_icon ) ).
    IF node_table IS INITIAL.
      node_table = VALUE #( ( node_key = 'DUMMY' ) ).
    ENDIF.

    tree->add_nodes( table_structure_name = 'ZTB_TREELOAD'
                     node_table = node_table ).
    tree->set_selected_node( node_table[ 1 ]-node_key ).


  ENDMETHOD.

ENDCLASS.

CLASS lcl_control DEFINITION.
  PUBLIC SECTION.
    DATA: model  TYPE REF TO zif_data_migration,
          view   TYPE REF TO lcl_view,
          r_data TYPE REF TO data.
    CLASS-METHODS: get_file, get_list_box.
    METHODS: constructor,
      start,
      refresh,
      selection_changed
                    FOR EVENT selection_changed OF cl_gui_simple_tree
        IMPORTING node_key.

ENDCLASS.

CLASS lcl_control IMPLEMENTATION.

  METHOD selection_changed.

    CASE p_action.
      WHEN gc_act_upld.
        model->get_data_external( file_location = p_file ).
        model->convert_to_itab( EXPORTING key = node_key ).
        IF model->r_data IS INITIAL.
          MESSAGE 'No data to display!' TYPE 'I'.
          LEAVE TO SCREEN 0.
        ENDIF.
        refresh(  ).
      WHEN gc_act_view.
        model->get_data_system( EXPORTING key = node_key ).
        IF model->r_data IS INITIAL.
          MESSAGE 'No data to display!' TYPE 'I'.
          LEAVE TO SCREEN 0.
        ENDIF.
        refresh(  ).
    ENDCASE.

  ENDMETHOD.

  METHOD get_file.

    CALL FUNCTION 'KD_GET_FILENAME_ON_F4'
      CHANGING
        file_name     = p_file
      EXCEPTIONS
        mask_too_long = 1
        OTHERS        = 2.

    IF sy-subrc <> 0.
      zcx_ul_handle_errors=>raise_message(  ).
    ENDIF.

  ENDMETHOD.

  METHOD constructor.

    DATA(s_migration) = gt_migration[ migration_id = p_func ].

    CASE p_action.
      WHEN gc_act_temp.
        zcl_ul_doi_usage=>download_template( s_migration-template_id ).
        LEAVE TO SCREEN 0.
      WHEN gc_act_upld OR gc_act_view.
        CREATE OBJECT model TYPE (s_migration-class_id).
        model->s_migration = s_migration.
    ENDCASE.

    model->register_mode = p_action.
    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'SET_TREE'
                                  IMPORTING e_data = gt_tree ).
    DELETE gt_tree WHERE migration_id NE p_func.

    CREATE OBJECT view.
    SET HANDLER selection_changed FOR view->tree.

  ENDMETHOD.

  METHOD start.

    cl_gui_cfw=>flush(  ).
    view->tree->get_selected_node( IMPORTING node_key = DATA(node_key) ).
    selection_changed( node_key = node_key ).

  ENDMETHOD.

  METHOD get_list_box.

    DATA users TYPE TABLE OF zcl_migration_configure=>ty_user.

    zcl_ul_abap=>set_dynpro_drop( iv_id = 'P_ACTION'
                                  it_values = VALUE #( ( key = gc_act_upld text = 'Tải lên dữ liệu' )
                                                       ( key = gc_act_view text = 'Xem dữ liệu' )
                                                       ( key = gc_act_temp text = 'Tải xuống biểu mẫu' ) ) ).
    CHECK gt_migration IS INITIAL.
    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'SET_TOOL' IMPORTING e_data = gt_migration ).
    zcl_ul_data_layer=>read_data( EXPORTING iv_application = 'DYNAMICSET' iv_mainkey = 'SET_USER' IMPORTING e_data = users ).
    DELETE users WHERE username NE sy-uname.
    LOOP AT gt_migration INTO DATA(s_mig).
      DATA(index) = sy-tabix.
      IF line_exists( users[ migration_id = s_mig-migration_id ] ).
      ELSE.
        DELETE gt_migration INDEX index.
      ENDIF.
    ENDLOOP.
    IF lines( gt_migration ) = 1.
      p_func = gt_migration[ 1 ]-migration_id.
    ENDIF.
    zcl_ul_abap=>set_dynpro_drop( iv_id = 'P_FUNC'
                                  it_values = VALUE #( FOR s_migration IN gt_migration ( key = s_migration-migration_id text = s_migration-migration_name ) ) ).

  ENDMETHOD.

  METHOD refresh.

    ASSIGN model->r_data->* TO FIELD-SYMBOL(<ft_data>).
    CHECK <ft_data> IS ASSIGNED.
    model->prepare_display( IMPORTING col_tab = DATA(col_tab)
                                      menu_button = DATA(menu_button)
                            CHANGING ct_data = <ft_data> ).

    view->show_data(  EXPORTING col_tab = col_tab
                                menu_button = menu_button
                      CHANGING ct_table = <ft_data> ).
  ENDMETHOD.

ENDCLASS.

CLASS lcl_event DEFINITION INHERITING FROM zcl_ul_alv_adapter.
  PROTECTED SECTION.
    METHODS: mine_user_command REDEFINITION,
      mine_hotspot_click REDEFINITION,
      mine_double_click REDEFINITION.

ENDCLASS.

CLASS lcl_event IMPLEMENTATION.

  METHOD mine_double_click.

    application->model->r_data = mt_outtab.
    application->model->grid_double_click( es_row_no = es_row_no e_row = e_row e_column = e_column ).

  ENDMETHOD.

  METHOD mine_hotspot_click.

    application->model->r_data = mt_outtab.
    application->model->grid_hotspot_click( e_row_id = e_row_id e_column_id = e_column_id es_row_no = es_row_no ).

  ENDMETHOD.

  METHOD mine_user_command.

    application->model->r_data = mt_outtab.
    application->model->grid_user_command( e_ucomm = e_ucomm ).

    IF application->model->register_refresh = abap_true.
      application->refresh( ).
    ENDIF.

    IF application->model->register_edit IS NOT INITIAL.
      application->view->grid->set_ready_for_input( 1 ).
    ELSE.
      application->view->grid->set_ready_for_input( 0 ).
    ENDIF.

  ENDMETHOD.


ENDCLASS.
